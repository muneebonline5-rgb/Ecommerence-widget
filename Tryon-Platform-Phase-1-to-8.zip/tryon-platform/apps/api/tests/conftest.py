"""
Root pytest configuration.

Integration tests (tests/integration) require a real PostgreSQL instance
because several columns use Postgres-specific dialect types (UUID, JSONB,
ARRAY) that SQLite cannot emulate faithfully. Run them via:

    docker compose -f docker-compose.test.yml up -d
    DATABASE_URL=postgresql://tryon:tryon@localhost:5433/tryon_test pytest tests/integration

Unit tests (tests/unit) have zero external dependencies and run in
milliseconds — these are what CI runs on every push; integration tests run
on merge to main and nightly.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

# Allow `from src...` imports when pytest is invoked from apps/api/.
sys.path.insert(0, str(Path(__file__).parent))

os.environ.setdefault("DATABASE_URL", "postgresql://tryon:tryon@localhost:5432/tryon_test")
os.environ.setdefault("REDIS_URL", "redis://localhost:6379/0")
os.environ.setdefault("CELERY_BROKER_URL", "redis://localhost:6379/1")
os.environ.setdefault("CELERY_RESULT_BACKEND", "redis://localhost:6379/2")
os.environ.setdefault("API_KEY_PEPPER", "test-pepper-do-not-use-in-production-xxxxxxxxxxxxxxxx")
os.environ.setdefault("JWT_SECRET", "test-jwt-secret-do-not-use-in-production-xxxxxxxxxxxxx")
