import pytest
from sqlalchemy.exc import IntegrityError

from src.domain.entities.ai_request import AIRequest
from src.domain.entities.merchant import Merchant
from src.domain.entities.tryon import TryOn
from src.domain.entities.tryon_session import TryOnSession
from src.domain.value_objects.ai_provider import AIProviderName, ProviderRequestStatus
from src.infrastructure.db.repositories.ai_request_repository import SqlAlchemyAIRequestRepository
from src.infrastructure.db.repositories.merchant_repository import SqlAlchemyMerchantRepository
from src.infrastructure.db.repositories.tryon_repository import SqlAlchemyTryOnRepository
from src.infrastructure.db.repositories.tryon_session_repository import (
    SqlAlchemyTryOnSessionRepository,
)

pytestmark = pytest.mark.integration


async def _seed_merchant(db_session):
    repo = SqlAlchemyMerchantRepository(db_session)
    merchant = Merchant.register("Acme", "acme-tryon.com", "a@acme.com")
    await repo.save(merchant)
    return merchant


async def test_tryon_session_round_trips(db_session):
    merchant = await _seed_merchant(db_session)
    repo = SqlAlchemyTryOnSessionRepository(db_session)

    session = TryOnSession.start(
        merchant.id, "visitor-abc", country="US", device_type="mobile", browser="Safari"
    )
    await repo.save(session)

    fetched = await repo.get_by_id(session.id)
    assert fetched is not None
    assert fetched.merchant_id == merchant.id
    assert fetched.anonymous_visitor_id == "visitor-abc"
    assert fetched.country == "US"
    assert fetched.ended_at is None


async def test_tryon_session_end_persists(db_session):
    merchant = await _seed_merchant(db_session)
    repo = SqlAlchemyTryOnSessionRepository(db_session)

    session = TryOnSession.start(merchant.id, "visitor-abc")
    await repo.save(session)
    session.end()
    await repo.save(session)

    fetched = await repo.get_by_id(session.id)
    assert fetched.ended_at is not None


async def test_tryon_round_trips_and_state_transitions_persist(db_session):
    merchant = await _seed_merchant(db_session)
    session_repo = SqlAlchemyTryOnSessionRepository(db_session)
    tryon_repo = SqlAlchemyTryOnRepository(db_session)

    session = TryOnSession.start(merchant.id, "visitor-abc")
    await session_repo.save(session)

    tryon = TryOn.create(session.id, "uploads/customer.png")
    await tryon_repo.save(tryon)

    tryon.start_processing()
    tryon.complete("results/generated.png")
    await tryon_repo.save(tryon)

    fetched = await tryon_repo.get_by_id(tryon.id)
    assert fetched.status.value == "completed"
    assert fetched.result_image_key == "results/generated.png"


async def test_list_for_session_scopes_correctly(db_session):
    merchant = await _seed_merchant(db_session)
    session_repo = SqlAlchemyTryOnSessionRepository(db_session)
    tryon_repo = SqlAlchemyTryOnRepository(db_session)

    session_a = TryOnSession.start(merchant.id, "visitor-a")
    session_b = TryOnSession.start(merchant.id, "visitor-b")
    await session_repo.save(session_a)
    await session_repo.save(session_b)

    tryon_a1 = TryOn.create(session_a.id, "uploads/a1.png")
    tryon_a2 = TryOn.create(session_a.id, "uploads/a2.png")
    tryon_b1 = TryOn.create(session_b.id, "uploads/b1.png")
    for t in (tryon_a1, tryon_a2, tryon_b1):
        await tryon_repo.save(t)

    results = await tryon_repo.list_for_session(session_a.id)
    assert {t.id for t in results} == {tryon_a1.id, tryon_a2.id}


async def test_ai_request_round_trips_with_idempotency_key(db_session):
    merchant = await _seed_merchant(db_session)
    session_repo = SqlAlchemyTryOnSessionRepository(db_session)
    tryon_repo = SqlAlchemyTryOnRepository(db_session)
    ai_repo = SqlAlchemyAIRequestRepository(db_session)

    session = TryOnSession.start(merchant.id, "visitor-abc")
    await session_repo.save(session)
    tryon = TryOn.create(session.id, "uploads/customer.png")
    await tryon_repo.save(tryon)

    ai_request = AIRequest.create(
        tryon.id,
        merchant.id,
        AIProviderName.FASHN,
        "idem-key-xyz",
        request_payload={"customer_image_key": "uploads/customer.png"},
    )
    await ai_repo.save(ai_request)

    fetched = await ai_repo.get_by_id(ai_request.id)
    assert fetched.idempotency_key == "idem-key-xyz"
    assert fetched.status == ProviderRequestStatus.QUEUED

    by_key = await ai_repo.get_by_idempotency_key(merchant.id, "idem-key-xyz")
    assert by_key is not None
    assert by_key.id == ai_request.id

    by_tryon = await ai_repo.get_by_tryon_id(tryon.id)
    assert by_tryon is not None
    assert by_tryon.id == ai_request.id


async def test_idempotency_key_is_unique_per_merchant_at_the_db_level(db_session):
    """
    The domain-level idempotency check in TryOnGenerationService is the
    primary guard, but the DB unique constraint (merchant_id,
    idempotency_key) is the actual source of truth that prevents a race
    between two concurrent requests with the same key from both passing the
    application-level check before either has committed.
    """
    merchant = await _seed_merchant(db_session)
    session_repo = SqlAlchemyTryOnSessionRepository(db_session)
    tryon_repo = SqlAlchemyTryOnRepository(db_session)
    ai_repo = SqlAlchemyAIRequestRepository(db_session)

    session = TryOnSession.start(merchant.id, "visitor-abc")
    await session_repo.save(session)

    tryon_1 = TryOn.create(session.id, "uploads/customer1.png")
    await tryon_repo.save(tryon_1)
    ai_request_1 = AIRequest.create(tryon_1.id, merchant.id, AIProviderName.FASHN, "duplicate-key")
    await ai_repo.save(ai_request_1)

    tryon_2 = TryOn.create(session.id, "uploads/customer2.png")
    await tryon_repo.save(tryon_2)
    ai_request_2 = AIRequest.create(tryon_2.id, merchant.id, AIProviderName.FASHN, "duplicate-key")

    with pytest.raises(IntegrityError):
        await ai_repo.save(ai_request_2)
    await db_session.rollback()
