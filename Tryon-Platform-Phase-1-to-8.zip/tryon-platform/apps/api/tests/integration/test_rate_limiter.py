import asyncio
import os

import pytest
from redis.asyncio import Redis

from src.infrastructure.cache.redis_rate_limiter import RedisRateLimiter

pytestmark = pytest.mark.integration


@pytest.fixture
async def redis_client():
    # Reuses the same REDIS_URL as the rest of the integration suite (see
    # tests/conftest.py), but on db index 15 — dedicated to these tests so
    # flushdb() here can never wipe data used by other integration tests
    # sharing the same Redis instance.
    base_url = os.environ["REDIS_URL"].rsplit("/", 1)[0]
    client = Redis.from_url(f"{base_url}/15", decode_responses=True)
    await client.flushdb()
    yield client
    await client.flushdb()
    await client.aclose()


@pytest.fixture
def limiter(redis_client) -> RedisRateLimiter:
    return RedisRateLimiter(redis_client)


async def test_allows_requests_within_the_limit(limiter):
    for _ in range(5):
        result = await limiter.check("test:key", limit=5, window_seconds=60)
        assert result.allowed is True


async def test_blocks_requests_once_limit_is_exceeded(limiter):
    for _ in range(5):
        await limiter.check("test:key", limit=5, window_seconds=60)

    result = await limiter.check("test:key", limit=5, window_seconds=60)
    assert result.allowed is False
    assert result.remaining == 0
    assert result.retry_after_seconds > 0


async def test_remaining_count_decreases_correctly(limiter):
    first = await limiter.check("test:key", limit=5, window_seconds=60)
    second = await limiter.check("test:key", limit=5, window_seconds=60)

    assert first.remaining == 4
    assert second.remaining == 3


async def test_different_keys_have_independent_limits(limiter):
    for _ in range(5):
        await limiter.check("test:key-a", limit=5, window_seconds=60)

    result_a = await limiter.check("test:key-a", limit=5, window_seconds=60)
    result_b = await limiter.check("test:key-b", limit=5, window_seconds=60)

    assert result_a.allowed is False
    assert result_b.allowed is True


async def test_counter_expires_and_resets_after_the_window(limiter):
    # Small window so the test doesn't need to sleep long.
    for _ in range(3):
        await limiter.check("test:short-window", limit=3, window_seconds=1)

    blocked = await limiter.check("test:short-window", limit=3, window_seconds=1)
    assert blocked.allowed is False

    await asyncio.sleep(1.2)

    allowed_again = await limiter.check("test:short-window", limit=3, window_seconds=1)
    assert allowed_again.allowed is True


async def test_concurrent_requests_are_counted_atomically(limiter):
    """
    Regression-style check for the INCR+EXPIRE atomicity claim: fire 20
    concurrent requests against a limit of 10 and confirm exactly 10 are
    allowed — a race condition in the Lua script would let more through.
    """
    results = await asyncio.gather(
        *[limiter.check("test:concurrent", limit=10, window_seconds=60) for _ in range(20)]
    )
    allowed_count = sum(1 for r in results if r.allowed)
    assert allowed_count == 10
