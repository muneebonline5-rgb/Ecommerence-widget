"""
End-to-end test of the Celery pipeline's actual processing logic
(`_process`), exercised directly against:
  - a real Postgres database (via the `engine` fixture),
  - a real S3-compatible bucket (via moto, no live AWS calls),
  - a mocked FASHN HTTP API (via respx, no live network calls).

This calls `_process` directly rather than going through
`generate_tryon.delay()` / Celery's eager mode, specifically to avoid the
`get_settings()` process-wide `lru_cache` making per-test settings overrides
(fast polling intervals for the test, a test-only S3 bucket) impossible once
any earlier test in the session has already triggered a real settings load.
Calling `_process` directly with an explicitly constructed `Settings`
instance sidesteps that entirely while still exercising the exact same
async pipeline logic the real Celery task runs.
"""

from __future__ import annotations

import os
from datetime import UTC, datetime

import boto3
import httpx
import pytest
import structlog
from moto import mock_aws
from sqlalchemy.ext.asyncio import async_sessionmaker

from src.config.settings import Settings
from src.domain.entities.ai_request import AIRequest
from src.domain.entities.merchant import Merchant
from src.domain.entities.tryon import TryOn
from src.domain.entities.tryon_session import TryOnSession
from src.domain.exceptions.base import ProviderTransientError
from src.domain.value_objects.ai_provider import AIProviderName
from src.infrastructure.db.repositories.ai_request_repository import SqlAlchemyAIRequestRepository
from src.infrastructure.db.repositories.merchant_repository import SqlAlchemyMerchantRepository
from src.infrastructure.db.repositories.tryon_repository import SqlAlchemyTryOnRepository
from src.infrastructure.db.repositories.tryon_session_repository import (
    SqlAlchemyTryOnSessionRepository,
)
from src.infrastructure.db.repositories.usage_record_repository import (
    SqlAlchemyUsageRecordRepository,
)
from src.worker.tasks.generate_tryon_task import _process

pytestmark = pytest.mark.integration

BUCKET = "tryon-worker-pipeline-test"
FASHN_BASE = "https://api.fashn.ai"


def _settings(**overrides) -> Settings:
    base = dict(
        database_url=os.environ["DATABASE_URL"],
        redis_url=os.environ["REDIS_URL"],
        celery_broker_url=os.environ["CELERY_BROKER_URL"],
        celery_result_backend=os.environ["CELERY_RESULT_BACKEND"],
        api_key_pepper=os.environ["API_KEY_PEPPER"],
        jwt_secret=os.environ["JWT_SECRET"],
        tryon_status_poll_interval_seconds=0,
        tryon_status_poll_max_attempts=3,
        fashn_api_key="test-key",
        fashn_api_base_url=FASHN_BASE,
        default_ai_provider="fashn",
        storage_bucket_name=BUCKET,
        storage_endpoint_url="",
        storage_access_key_id="test",
        storage_secret_access_key="test",
    )
    base.update(overrides)
    return Settings(**base)


@pytest.fixture
def s3_bucket():
    with mock_aws():
        boto3.client(
            "s3", region_name="us-east-1", aws_access_key_id="test", aws_secret_access_key="test"
        ).create_bucket(Bucket=BUCKET)
        yield


async def _seed(db_session, *, idempotency_key: str = "pipeline-test-key"):
    merchant_repo = SqlAlchemyMerchantRepository(db_session)
    merchant = Merchant.register("Acme", f"acme-{idempotency_key}.com", "a@acme.com")
    await merchant_repo.save(merchant)

    session_repo = SqlAlchemyTryOnSessionRepository(db_session)
    tryon_session = TryOnSession.start(merchant.id, "visitor-1")
    await session_repo.save(tryon_session)

    tryon_repo = SqlAlchemyTryOnRepository(db_session)
    tryon = TryOn.create(tryon_session.id, "customer-uploads/m1/customer.png")
    await tryon_repo.save(tryon)

    ai_repo = SqlAlchemyAIRequestRepository(db_session)
    ai_request = AIRequest.create(
        tryon.id,
        merchant.id,
        AIProviderName.FASHN,
        idempotency_key,
        request_payload={
            "customer_image_key": "customer-uploads/m1/customer.png",
            "product_image_url": "https://shop.example/product.png",
        },
    )
    await ai_repo.save(ai_request)
    await db_session.commit()
    return merchant, tryon_session, tryon, ai_request


@pytest.fixture
def log():
    return structlog.get_logger("test").bind(test=True)


async def test_full_pipeline_success_end_to_end(engine, respx_mock, s3_bucket, log):
    session_factory: async_sessionmaker = async_sessionmaker(bind=engine, expire_on_commit=False)

    async with session_factory() as seed_session:
        merchant, tryon_session, tryon, ai_request = await _seed(seed_session)

    # Preload the customer's image into the bucket, since generate_tryon's
    # request needs a real, fetchable signed URL for FASHN to "receive".
    boto3.client(
        "s3", region_name="us-east-1", aws_access_key_id="test", aws_secret_access_key="test"
    ).put_object(Bucket=BUCKET, Key="customer-uploads/m1/customer.png", Body=b"customer-bytes")

    respx_mock.post(f"{FASHN_BASE}/v1/run").mock(
        return_value=httpx.Response(200, json={"id": "job_e2e"})
    )
    respx_mock.get(f"{FASHN_BASE}/v1/status/job_e2e").mock(
        side_effect=[
            httpx.Response(200, json={"id": "job_e2e", "status": "processing"}),
            httpx.Response(
                200,
                json={
                    "id": "job_e2e",
                    "status": "completed",
                    "output": ["https://cdn.fashn.ai/result.png"],
                },
            ),
        ]
    )
    respx_mock.get("https://cdn.fashn.ai/result.png").mock(
        return_value=httpx.Response(
            200, content=b"generated-result-bytes", headers={"content-type": "image/png"}
        )
    )

    settings = _settings()
    http_client = httpx.AsyncClient()
    try:
        await _process(str(ai_request.id), settings, session_factory, http_client, log)
    finally:
        await http_client.aclose()

    async with session_factory() as verify_session:
        ai_repo = SqlAlchemyAIRequestRepository(verify_session)
        tryon_repo = SqlAlchemyTryOnRepository(verify_session)

        final_ai_request = await ai_repo.get_by_id(ai_request.id)
        final_tryon = await tryon_repo.get_by_id(tryon.id)

    assert final_ai_request.status.value == "completed"
    assert final_ai_request.provider_request_id == "job_e2e"
    assert final_ai_request.latency_ms is not None
    assert final_tryon.status.value == "completed"
    assert final_tryon.result_image_key is not None
    assert final_tryon.result_image_key.startswith("tryon-results/generated/")

    # Phase 6: this generation must also have been metered into cost_usd
    # and the merchant's daily UsageRecord — in the SAME transaction as the
    # completion, per generate_tryon_task._finalize.
    assert final_ai_request.cost_usd is not None
    assert final_ai_request.cost_usd > 0

    async with session_factory() as usage_verify_session:
        usage_repo = SqlAlchemyUsageRecordRepository(usage_verify_session)
        usage_record = await usage_repo.get_for_merchant_and_date(
            merchant.id, datetime.now(UTC).date()
        )
    assert usage_record is not None
    assert usage_record.generations_count == 1
    assert usage_record.breakdown_by_provider["fashn"]["count"] == 1
    assert usage_record.breakdown_by_provider["fashn"]["cost_usd"] == final_ai_request.cost_usd

    # The result was genuinely re-persisted into OUR bucket, not just referenced.
    stored = boto3.client(
        "s3", region_name="us-east-1", aws_access_key_id="test", aws_secret_access_key="test"
    ).get_object(Bucket=BUCKET, Key=final_tryon.result_image_key)
    assert stored["Body"].read() == b"generated-result-bytes"


async def test_pipeline_marks_failed_on_provider_failure(engine, respx_mock, s3_bucket, log):
    session_factory: async_sessionmaker = async_sessionmaker(bind=engine, expire_on_commit=False)

    async with session_factory() as seed_session:
        merchant, tryon_session, tryon, ai_request = await _seed(
            seed_session, idempotency_key="pipeline-fail-key"
        )

    boto3.client(
        "s3", region_name="us-east-1", aws_access_key_id="test", aws_secret_access_key="test"
    ).put_object(Bucket=BUCKET, Key="customer-uploads/m1/customer.png", Body=b"customer-bytes")

    respx_mock.post(f"{FASHN_BASE}/v1/run").mock(
        return_value=httpx.Response(200, json={"id": "job_fail"})
    )
    respx_mock.get(f"{FASHN_BASE}/v1/status/job_fail").mock(
        return_value=httpx.Response(
            200,
            json={"id": "job_fail", "status": "failed", "error": {"message": "No face detected"}},
        )
    )

    settings = _settings()
    http_client = httpx.AsyncClient()
    try:
        await _process(str(ai_request.id), settings, session_factory, http_client, log)
    finally:
        await http_client.aclose()

    async with session_factory() as verify_session:
        ai_repo = SqlAlchemyAIRequestRepository(verify_session)
        tryon_repo = SqlAlchemyTryOnRepository(verify_session)
        final_ai_request = await ai_repo.get_by_id(ai_request.id)
        final_tryon = await tryon_repo.get_by_id(tryon.id)

    assert final_ai_request.status.value == "failed"
    assert final_tryon.status.value == "failed"
    assert final_tryon.error_message == "No face detected"


async def test_redelivered_task_after_completion_is_a_no_op(engine, respx_mock, s3_bucket, log):
    """
    Idempotency guarantee: if the same AIRequest is processed twice (e.g. a
    redelivered Celery message after a broker visibility-timeout), the
    second run must NOT call the provider again — verified here by only
    registering the FASHN routes to fire once each.
    """
    session_factory: async_sessionmaker = async_sessionmaker(bind=engine, expire_on_commit=False)

    async with session_factory() as seed_session:
        merchant, tryon_session, tryon, ai_request = await _seed(
            seed_session, idempotency_key="pipeline-redelivery-key"
        )

    boto3.client(
        "s3", region_name="us-east-1", aws_access_key_id="test", aws_secret_access_key="test"
    ).put_object(Bucket=BUCKET, Key="customer-uploads/m1/customer.png", Body=b"customer-bytes")

    submit_route = respx_mock.post(f"{FASHN_BASE}/v1/run").mock(
        return_value=httpx.Response(200, json={"id": "job_once"})
    )
    respx_mock.get(f"{FASHN_BASE}/v1/status/job_once").mock(
        return_value=httpx.Response(
            200,
            json={
                "id": "job_once",
                "status": "completed",
                "output": ["https://cdn.fashn.ai/r2.png"],
            },
        )
    )
    respx_mock.get("https://cdn.fashn.ai/r2.png").mock(
        return_value=httpx.Response(200, content=b"bytes", headers={"content-type": "image/png"})
    )

    settings = _settings()

    http_client_1 = httpx.AsyncClient()
    try:
        await _process(str(ai_request.id), settings, session_factory, http_client_1, log)
    finally:
        await http_client_1.aclose()

    assert submit_route.call_count == 1

    # Redelivery: process the exact same AIRequest again.
    http_client_2 = httpx.AsyncClient()
    try:
        await _process(str(ai_request.id), settings, session_factory, http_client_2, log)
    finally:
        await http_client_2.aclose()

    # Still only ever called once — the second run saw a terminal status and returned immediately.
    assert submit_route.call_count == 1


async def test_polling_exhaustion_raises_transient_error_for_celery_to_retry(
    engine, respx_mock, s3_bucket, log
):
    session_factory: async_sessionmaker = async_sessionmaker(bind=engine, expire_on_commit=False)

    async with session_factory() as seed_session:
        merchant, tryon_session, tryon, ai_request = await _seed(
            seed_session, idempotency_key="pipeline-exhaustion-key"
        )

    boto3.client(
        "s3", region_name="us-east-1", aws_access_key_id="test", aws_secret_access_key="test"
    ).put_object(Bucket=BUCKET, Key="customer-uploads/m1/customer.png", Body=b"customer-bytes")

    respx_mock.post(f"{FASHN_BASE}/v1/run").mock(
        return_value=httpx.Response(200, json={"id": "job_stuck"})
    )
    # Never reaches a terminal status within the (small, test-configured) max attempts.
    respx_mock.get(f"{FASHN_BASE}/v1/status/job_stuck").mock(
        return_value=httpx.Response(200, json={"id": "job_stuck", "status": "processing"})
    )

    settings = _settings()
    http_client = httpx.AsyncClient()
    try:
        with pytest.raises(ProviderTransientError):
            await _process(str(ai_request.id), settings, session_factory, http_client, log)
    finally:
        await http_client.aclose()

    async with session_factory() as verify_session:
        ai_repo = SqlAlchemyAIRequestRepository(verify_session)
        final_ai_request = await ai_repo.get_by_id(ai_request.id)

    # Not marked failed — a transient/retryable error leaves it in-flight
    # (with provider_request_id already saved) for Celery's retry to resume.
    assert final_ai_request.status.value == "processing"
    assert final_ai_request.provider_request_id == "job_stuck"
