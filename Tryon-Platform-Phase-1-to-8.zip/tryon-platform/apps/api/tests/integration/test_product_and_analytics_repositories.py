from datetime import UTC, datetime, timedelta

import pytest

from src.domain.entities.analytics_event import AnalyticsEvent, AnalyticsEventType
from src.domain.entities.merchant import Merchant
from src.domain.entities.product import Product
from src.infrastructure.db.repositories.analytics_event_repository import (
    SqlAlchemyAnalyticsEventRepository,
)
from src.infrastructure.db.repositories.merchant_repository import SqlAlchemyMerchantRepository
from src.infrastructure.db.repositories.product_repository import SqlAlchemyProductRepository

pytestmark = pytest.mark.integration


async def _seed_merchant(db_session, suffix: str = "1"):
    repo = SqlAlchemyMerchantRepository(db_session)
    merchant = Merchant.register("Acme", f"acme-catalog-{suffix}.com", "a@acme.com")
    await repo.save(merchant)
    return merchant


async def test_product_round_trips(db_session):
    merchant = await _seed_merchant(db_session)
    repo = SqlAlchemyProductRepository(db_session)

    product = Product.create(
        merchant.id,
        "SKU-1",
        "Blue Sneakers",
        "https://shop.example/p/1",
        "https://shop.example/img/1.png",
        category="Footwear",
        metadata={"color": "blue"},
    )
    await repo.save(product)

    fetched = await repo.get_by_id(product.id)
    assert fetched is not None
    assert fetched.external_id == "SKU-1"
    assert fetched.title == "Blue Sneakers"
    assert fetched.category == "Footwear"
    assert fetched.metadata == {"color": "blue"}


async def test_get_by_external_id_scopes_to_merchant(db_session):
    merchant_a = await _seed_merchant(db_session, "a")
    merchant_b = await _seed_merchant(db_session, "b")
    repo = SqlAlchemyProductRepository(db_session)

    product_a = Product.create(merchant_a.id, "SKU-SHARED", "A", "https://x", "https://y")
    product_b = Product.create(merchant_b.id, "SKU-SHARED", "B", "https://x2", "https://y2")
    await repo.save(product_a)
    await repo.save(product_b)

    fetched_a = await repo.get_by_external_id(merchant_a.id, "SKU-SHARED")
    fetched_b = await repo.get_by_external_id(merchant_b.id, "SKU-SHARED")

    assert fetched_a.id == product_a.id
    assert fetched_b.id == product_b.id


async def test_list_for_merchant_scopes_and_orders(db_session):
    merchant = await _seed_merchant(db_session)
    other_merchant = await _seed_merchant(db_session, "other")
    repo = SqlAlchemyProductRepository(db_session)

    p1 = Product.create(merchant.id, "SKU-1", "A", "https://x", "https://y")
    p2 = Product.create(merchant.id, "SKU-2", "B", "https://x2", "https://y2")
    other = Product.create(other_merchant.id, "SKU-3", "C", "https://x3", "https://y3")
    for p in (p1, p2, other):
        await repo.save(p)

    results = await repo.list_for_merchant(merchant.id)
    assert {p.id for p in results} == {p1.id, p2.id}


async def test_delete_product_removes_it(db_session):
    merchant = await _seed_merchant(db_session)
    repo = SqlAlchemyProductRepository(db_session)

    product = Product.create(merchant.id, "SKU-1", "A", "https://x", "https://y")
    await repo.save(product)
    await repo.delete(product.id)

    assert await repo.get_by_id(product.id) is None


async def test_analytics_event_batch_save_and_count_by_type(db_session):
    merchant = await _seed_merchant(db_session)
    repo = SqlAlchemyAnalyticsEventRepository(db_session)

    now = datetime.now(UTC)
    events = [
        AnalyticsEvent.create(merchant.id, AnalyticsEventType.WIDGET_LOADED, occurred_at=now),
        AnalyticsEvent.create(merchant.id, AnalyticsEventType.WIDGET_LOADED, occurred_at=now),
        AnalyticsEvent.create(merchant.id, AnalyticsEventType.BUTTON_CLICKED, occurred_at=now),
    ]
    await repo.save_batch(events)

    counts = await repo.count_by_type(
        merchant.id, start=now - timedelta(hours=1), end=now + timedelta(hours=1)
    )
    assert counts["widget_loaded"] == 2
    assert counts["button_clicked"] == 1


async def test_analytics_event_count_respects_date_range(db_session):
    merchant = await _seed_merchant(db_session)
    repo = SqlAlchemyAnalyticsEventRepository(db_session)

    now = datetime.now(UTC)
    old_event = AnalyticsEvent.create(
        merchant.id, AnalyticsEventType.WIDGET_LOADED, occurred_at=now - timedelta(days=30)
    )
    recent_event = AnalyticsEvent.create(
        merchant.id, AnalyticsEventType.WIDGET_LOADED, occurred_at=now
    )
    await repo.save_batch([old_event, recent_event])

    counts = await repo.count_by_type(
        merchant.id, start=now - timedelta(days=1), end=now + timedelta(hours=1)
    )
    assert counts["widget_loaded"] == 1  # only the recent one falls in range


async def test_analytics_event_count_scopes_to_merchant(db_session):
    merchant_a = await _seed_merchant(db_session, "analytics-a")
    merchant_b = await _seed_merchant(db_session, "analytics-b")
    repo = SqlAlchemyAnalyticsEventRepository(db_session)

    now = datetime.now(UTC)
    await repo.save_batch(
        [
            AnalyticsEvent.create(merchant_a.id, AnalyticsEventType.CONVERSION, occurred_at=now),
            AnalyticsEvent.create(merchant_b.id, AnalyticsEventType.CONVERSION, occurred_at=now),
            AnalyticsEvent.create(merchant_b.id, AnalyticsEventType.CONVERSION, occurred_at=now),
        ]
    )

    counts_a = await repo.count_by_type(
        merchant_a.id, start=now - timedelta(hours=1), end=now + timedelta(hours=1)
    )
    counts_b = await repo.count_by_type(
        merchant_b.id, start=now - timedelta(hours=1), end=now + timedelta(hours=1)
    )
    assert counts_a["conversion"] == 1
    assert counts_b["conversion"] == 2


async def test_save_batch_with_empty_list_is_a_no_op(db_session):
    repo = SqlAlchemyAnalyticsEventRepository(db_session)
    await repo.save_batch([])  # must not raise
