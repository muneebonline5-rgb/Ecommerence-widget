import asyncio
import os

import pytest
from redis.asyncio import Redis

from src.infrastructure.cache.redis_lock import RedisLock

pytestmark = pytest.mark.integration


@pytest.fixture
async def redis_client():
    base_url = os.environ["REDIS_URL"].rsplit("/", 1)[0]
    client = Redis.from_url(f"{base_url}/14", decode_responses=True)
    await client.flushdb()
    yield client
    await client.flushdb()
    await client.aclose()


async def test_second_acquire_fails_while_first_holds_the_lock(redis_client):
    lock_a = RedisLock(redis_client, key="ai_request:1", ttl_seconds=30)
    lock_b = RedisLock(redis_client, key="ai_request:1", ttl_seconds=30)

    assert await lock_a.acquire() is True
    assert await lock_b.acquire() is False


async def test_lock_is_available_again_after_release(redis_client):
    lock_a = RedisLock(redis_client, key="ai_request:2", ttl_seconds=30)
    lock_b = RedisLock(redis_client, key="ai_request:2", ttl_seconds=30)

    await lock_a.acquire()
    await lock_a.release()

    assert await lock_b.acquire() is True


async def test_release_does_not_release_a_lock_held_by_someone_else(redis_client):
    """
    Simulates: lock A's TTL expires, lock B acquires it, then A's (stale)
    release call fires. A must NOT be able to release B's active lock.
    """
    lock_a = RedisLock(redis_client, key="ai_request:3", ttl_seconds=30)
    await lock_a.acquire()

    # Simulate expiry by deleting the key directly, then another worker acquires it.
    await redis_client.delete("lock:ai_request:3")
    lock_b = RedisLock(redis_client, key="ai_request:3", ttl_seconds=30)
    assert await lock_b.acquire() is True

    await lock_a.release()  # stale release from the "expired" holder

    # B's lock must still be held — a third acquire attempt must fail.
    lock_c = RedisLock(redis_client, key="ai_request:3", ttl_seconds=30)
    assert await lock_c.acquire() is False


async def test_lock_self_expires_after_ttl(redis_client):
    lock_a = RedisLock(redis_client, key="ai_request:4", ttl_seconds=1)
    await lock_a.acquire()

    await asyncio.sleep(1.3)

    lock_b = RedisLock(redis_client, key="ai_request:4", ttl_seconds=30)
    assert await lock_b.acquire() is True


async def test_concurrent_acquire_attempts_only_one_wins(redis_client):
    locks = [RedisLock(redis_client, key="ai_request:5", ttl_seconds=30) for _ in range(10)]
    results = await asyncio.gather(*[lock.acquire() for lock in locks])
    assert sum(1 for r in results if r) == 1
