"""
Phase 8 observability tests.

These run against the real FastAPI app with real Postgres and Redis, since
the entire point of a readiness probe is that it reflects genuine
dependency state — a mocked readiness check verifies nothing worth
verifying.
"""

import pytest
from fastapi.testclient import TestClient

from src.main import create_app

pytestmark = pytest.mark.integration


@pytest.fixture(scope="module")
def client() -> TestClient:
    return TestClient(create_app(), raise_server_exceptions=False)


class TestLiveness:
    def test_healthz_returns_ok(self, client):
        response = client.get("/healthz")
        assert response.status_code == 200
        assert response.json() == {"status": "ok"}

    def test_healthz_does_not_touch_dependencies(self, client):
        """
        Liveness must stay green during a dependency outage. If it didn't,
        a brief Postgres blip would fail liveness on every replica at once
        and get them all killed — converting a recoverable dependency
        outage into a total one.
        """
        response = client.get("/healthz")
        assert response.status_code == 200
        assert "checks" not in response.json()


class TestReadiness:
    def test_readyz_reports_each_dependency(self, client):
        response = client.get("/readyz")
        assert response.status_code == 200
        body = response.json()
        assert body["status"] == "ready"
        assert body["checks"]["postgres"] == "ok"
        assert body["checks"]["redis"] == "ok"


class TestRequestContext:
    def test_response_carries_a_request_id(self, client):
        response = client.get("/healthz")
        assert response.headers.get("X-Request-ID")

    def test_inbound_request_id_is_preserved_for_cross_service_tracing(self, client):
        """An upstream gateway's correlation ID must survive, not be overwritten."""
        response = client.get("/healthz", headers={"X-Request-ID": "upstream-trace-abc"})
        assert response.headers["X-Request-ID"] == "upstream-trace-abc"

    def test_each_request_without_an_id_gets_a_distinct_one(self, client):
        first = client.get("/healthz").headers["X-Request-ID"]
        second = client.get("/healthz").headers["X-Request-ID"]
        assert first != second


class TestMetrics:
    def test_metrics_endpoint_serves_prometheus_format(self, client):
        response = client.get("/metrics")
        assert response.status_code == 200
        assert "text/plain" in response.headers["content-type"]
        assert "tryon_http_requests_total" in response.text

    def test_route_labels_use_the_template_not_the_raw_path(self, client):
        """
        The cardinality guard. Labelling by raw path would mint a new time
        series per merchant ID and eventually take down Prometheus; the
        label must stay the route template.
        """
        client.get("/api/v1/merchants/11111111-1111-1111-1111-111111111111")
        client.get("/api/v1/merchants/22222222-2222-2222-2222-222222222222")

        body = client.get("/metrics").text

        assert 'route="/merchants/{merchant_id}"' in body
        assert "11111111-1111-1111-1111-111111111111" not in body
        assert "22222222-2222-2222-2222-222222222222" not in body

    def test_unmatched_routes_collapse_to_a_single_label(self, client):
        """A 404 scanner must not be able to mint unbounded label values."""
        client.get("/definitely-not-a-real-route-1")
        client.get("/definitely-not-a-real-route-2")

        body = client.get("/metrics").text
        assert "definitely-not-a-real-route" not in body
        assert 'route="unmatched"' in body

    def test_latency_histogram_is_recorded(self, client):
        client.get("/healthz")
        body = client.get("/metrics").text
        assert "tryon_http_request_duration_seconds_bucket" in body


class TestSecurityHeadersOnProbes:
    def test_probe_endpoints_are_not_in_the_public_openapi_schema(self, client):
        """/metrics is infrastructure, not API surface merchants should discover."""
        schema = client.get("/openapi.json").json()
        assert "/metrics" not in schema["paths"]
