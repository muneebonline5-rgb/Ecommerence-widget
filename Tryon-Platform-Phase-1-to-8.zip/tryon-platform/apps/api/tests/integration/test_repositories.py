import pytest

from src.domain.entities.merchant import Merchant
from src.domain.entities.widget_settings import WidgetPosition, WidgetSettings
from src.domain.value_objects.identifiers import MerchantId
from src.infrastructure.db.repositories.merchant_repository import SqlAlchemyMerchantRepository
from src.infrastructure.db.repositories.widget_settings_repository import (
    SqlAlchemyWidgetSettingsRepository,
)

pytestmark = pytest.mark.integration


async def test_merchant_round_trips_through_postgres(db_session):
    repo = SqlAlchemyMerchantRepository(db_session)
    merchant = Merchant.register("Acme", "acme.com", "a@acme.com")

    await repo.save(merchant)
    fetched = await repo.get_by_id(merchant.id)

    assert fetched is not None
    assert fetched.id == merchant.id
    assert fetched.domain == "acme.com"
    assert fetched.status == merchant.status


async def test_merchant_domain_lookup_is_case_insensitive(db_session):
    repo = SqlAlchemyMerchantRepository(db_session)
    merchant = Merchant.register("Acme", "Acme.com", "a@acme.com")
    await repo.save(merchant)

    fetched = await repo.get_by_domain("ACME.COM")
    assert fetched is not None
    assert fetched.id == merchant.id


async def test_get_by_id_returns_none_for_unknown_merchant(db_session):
    repo = SqlAlchemyMerchantRepository(db_session)
    assert await repo.get_by_id(MerchantId.new()) is None


async def test_widget_settings_theme_json_round_trips_correctly(db_session):
    merchant_repo = SqlAlchemyMerchantRepository(db_session)
    settings_repo = SqlAlchemyWidgetSettingsRepository(db_session)

    merchant = Merchant.register("Acme", "acme.com", "a@acme.com")
    await merchant_repo.save(merchant)

    settings = WidgetSettings.default_for(merchant.id)
    settings.update_position(WidgetPosition.TOP_LEFT)
    await settings_repo.save(settings)

    fetched = await settings_repo.get_by_merchant_id(merchant.id)
    assert fetched is not None
    assert fetched.position == WidgetPosition.TOP_LEFT
    # Confirms the JSONB round-trip preserved the nested theme, including the
    # enum field we manually pop/reinsert around dataclasses.asdict().
    assert fetched.theme.primary_color == settings.theme.primary_color
    assert fetched.theme.button_shape == settings.theme.button_shape
