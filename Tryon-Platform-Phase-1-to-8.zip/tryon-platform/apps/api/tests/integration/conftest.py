from __future__ import annotations

import os
from collections.abc import AsyncGenerator

import pytest_asyncio
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker

from src.config.settings import Settings
from src.infrastructure.db.models import Base
from src.infrastructure.db.session import create_engine


def _test_settings() -> Settings:
    return Settings(
        database_url=os.environ["DATABASE_URL"],
        redis_url=os.environ["REDIS_URL"],
        celery_broker_url=os.environ["CELERY_BROKER_URL"],
        celery_result_backend=os.environ["CELERY_RESULT_BACKEND"],
        api_key_pepper=os.environ["API_KEY_PEPPER"],
        jwt_secret=os.environ["JWT_SECRET"],
    )


@pytest_asyncio.fixture
async def engine() -> AsyncGenerator[AsyncEngine, None]:
    """
    Function-scoped deliberately: pytest-asyncio gives each test function its
    own event loop by default, and asyncpg connections are bound to the loop
    they were created on. A session-scoped engine whose connections were
    opened under a different test's loop raises
    'Future attached to a different loop' the moment a later test tries to
    reuse it. Recreating the engine (and re-running create_all/drop_all) per
    test costs a little time but keeps every test loop-safe and independent.
    """
    eng = create_engine(_test_settings())
    async with eng.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield eng
    async with eng.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    await eng.dispose()


@pytest_asyncio.fixture
async def db_session(engine: AsyncEngine) -> AsyncGenerator[AsyncSession, None]:
    """
    Each test runs inside a transaction that is rolled back afterward, so
    tests never leak state into one another regardless of execution order.
    """
    session_factory = async_sessionmaker(bind=engine, expire_on_commit=False)
    async with engine.connect() as connection:
        transaction = await connection.begin()
        session = session_factory(bind=connection)
        try:
            yield session
        finally:
            await session.close()
            await transaction.rollback()
