from datetime import UTC, date, datetime, timedelta

import pytest

from src.domain.entities.audit_log import AuditLog
from src.domain.entities.credit_note import CreditNote
from src.domain.entities.invoice import Invoice
from src.domain.entities.merchant import Merchant
from src.domain.entities.plan import Plan
from src.domain.entities.subscription import Subscription
from src.domain.entities.webhook_event import WebhookEventRecord
from src.domain.value_objects.billing import BillingInterval, InvoiceStatus, PlanTier
from src.infrastructure.db.repositories.audit_log_repository import SqlAlchemyAuditLogRepository
from src.infrastructure.db.repositories.credit_note_repository import (
    SqlAlchemyCreditNoteRepository,
)
from src.infrastructure.db.repositories.invoice_repository import SqlAlchemyInvoiceRepository
from src.infrastructure.db.repositories.merchant_repository import SqlAlchemyMerchantRepository
from src.infrastructure.db.repositories.plan_repository import SqlAlchemyPlanRepository
from src.infrastructure.db.repositories.subscription_repository import (
    SqlAlchemySubscriptionRepository,
)
from src.infrastructure.db.repositories.webhook_event_repository import (
    SqlAlchemyWebhookEventRepository,
)

pytestmark = pytest.mark.integration


async def _seed_merchant(db_session, suffix: str = "1") -> Merchant:
    repo = SqlAlchemyMerchantRepository(db_session)
    merchant = Merchant.register("Acme", f"acme-billing-{suffix}.com", "a@acme.com")
    await repo.save(merchant)
    return merchant


async def test_merchant_stripe_customer_id_round_trips(db_session):
    merchant = await _seed_merchant(db_session)
    merchant.attach_stripe_customer("cus_abc123")
    repo = SqlAlchemyMerchantRepository(db_session)
    await repo.save(merchant)

    fetched = await repo.get_by_id(merchant.id)
    assert fetched.stripe_customer_id == "cus_abc123"


async def test_plan_round_trips_with_yearly_pricing(db_session):
    repo = SqlAlchemyPlanRepository(db_session)
    plan = Plan.create(
        PlanTier.PRO,
        "Pro",
        monthly_price_usd=99.0,
        monthly_stripe_price_id="price_pro_monthly",
        included_generations=1000,
        overage_price_usd=0.05,
        yearly_price_usd=990.0,
        yearly_stripe_price_id="price_pro_yearly",
    )
    await repo.save(plan)

    fetched = await repo.get_by_id(plan.id)
    assert fetched.tier == PlanTier.PRO
    assert fetched.yearly_price_usd == 990.0

    by_tier = await repo.get_by_tier(PlanTier.PRO)
    assert by_tier.id == plan.id


async def test_list_active_plans_excludes_inactive(db_session):
    repo = SqlAlchemyPlanRepository(db_session)
    active_plan = Plan.create(
        PlanTier.STARTER,
        "Starter",
        monthly_price_usd=29.0,
        monthly_stripe_price_id="price_starter_monthly_a",
        included_generations=100,
        overage_price_usd=0.1,
    )
    inactive_plan = Plan.create(
        PlanTier.ENTERPRISE,
        "Enterprise",
        monthly_price_usd=499.0,
        monthly_stripe_price_id="price_enterprise_monthly_a",
        included_generations=10000,
        overage_price_usd=0.02,
    )
    inactive_plan.deactivate()
    await repo.save(active_plan)
    await repo.save(inactive_plan)

    active = await repo.list_active()
    tiers = {p.tier for p in active}
    assert PlanTier.STARTER in tiers
    assert PlanTier.ENTERPRISE not in tiers


async def test_subscription_round_trips(db_session):
    merchant = await _seed_merchant(db_session)
    plan_repo = SqlAlchemyPlanRepository(db_session)
    plan = Plan.create(
        PlanTier.STARTER,
        "Starter",
        monthly_price_usd=29.0,
        monthly_stripe_price_id="price_sub_test",
        included_generations=100,
        overage_price_usd=0.1,
    )
    await plan_repo.save(plan)

    now = datetime.now(UTC)
    subscription = Subscription.start(
        merchant.id, plan.id, "sub_abc123", BillingInterval.MONTHLY, now, now + timedelta(days=30)
    )
    repo = SqlAlchemySubscriptionRepository(db_session)
    await repo.save(subscription)

    fetched = await repo.get_by_merchant_id(merchant.id)
    assert fetched.stripe_subscription_id == "sub_abc123"
    assert fetched.billing_interval == BillingInterval.MONTHLY

    by_stripe_id = await repo.get_by_stripe_subscription_id("sub_abc123")
    assert by_stripe_id.id == subscription.id


async def test_invoice_round_trips(db_session):
    merchant = await _seed_merchant(db_session)
    invoice = Invoice.create(
        merchant.id,
        "in_abc123",
        InvoiceStatus.PAID,
        29.0,
        date(2026, 1, 1),
        date(2026, 1, 31),
        amount_paid_usd=29.0,
        hosted_invoice_url="https://stripe.example/in_abc123",
    )
    repo = SqlAlchemyInvoiceRepository(db_session)
    await repo.save(invoice)

    fetched = await repo.get_by_stripe_invoice_id("in_abc123")
    assert fetched.status == InvoiceStatus.PAID
    assert fetched.amount_paid_usd == 29.0

    listed = await repo.list_for_merchant(merchant.id)
    assert len(listed) == 1


async def test_credit_note_round_trips(db_session):
    merchant = await _seed_merchant(db_session)
    invoice = Invoice.create(
        merchant.id, "in_cn_test", InvoiceStatus.PAID, 29.0, date(2026, 1, 1), date(2026, 1, 31)
    )
    invoice_repo = SqlAlchemyInvoiceRepository(db_session)
    await invoice_repo.save(invoice)

    credit_note = CreditNote.create(merchant.id, invoice.id, "cn_abc123", 5.0, "Goodwill credit")
    repo = SqlAlchemyCreditNoteRepository(db_session)
    await repo.save(credit_note)

    listed = await repo.list_for_invoice(invoice.id)
    assert len(listed) == 1
    assert listed[0].stripe_credit_note_id == "cn_abc123"


async def test_webhook_event_round_trips_and_idempotency_lookup(db_session):
    repo = SqlAlchemyWebhookEventRepository(db_session)
    record = WebhookEventRecord.receive("evt_abc123", "invoice.paid")
    await repo.save(record)

    fetched = await repo.get_by_stripe_event_id("evt_abc123")
    assert fetched is not None
    assert fetched.is_processed() is False

    fetched.mark_processed()
    await repo.save(fetched)

    reloaded = await repo.get_by_stripe_event_id("evt_abc123")
    assert reloaded.is_processed() is True


async def test_webhook_event_unknown_id_returns_none(db_session):
    repo = SqlAlchemyWebhookEventRepository(db_session)
    assert await repo.get_by_stripe_event_id("evt_does_not_exist") is None


async def test_audit_log_round_trips_and_scopes_to_merchant(db_session):
    merchant_a = await _seed_merchant(db_session, "audit-a")
    merchant_b = await _seed_merchant(db_session, "audit-b")
    repo = SqlAlchemyAuditLogRepository(db_session)

    entry_a = AuditLog.record(
        "subscription.created", "subscription", "sub_1", merchant_id=merchant_a.id
    )
    entry_b = AuditLog.record(
        "subscription.created", "subscription", "sub_2", merchant_id=merchant_b.id
    )
    await repo.save(entry_a)
    await repo.save(entry_b)

    logs_a = await repo.list_for_merchant(merchant_a.id)
    assert len(logs_a) == 1
    assert logs_a[0].resource_id == "sub_1"
