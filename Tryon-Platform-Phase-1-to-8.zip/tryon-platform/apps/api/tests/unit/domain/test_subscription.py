from datetime import UTC, datetime, timedelta

import pytest

from src.domain.entities.subscription import Subscription
from src.domain.exceptions.base import SubscriptionStateError, ValidationError
from src.domain.value_objects.billing import BillingInterval, SubscriptionStatus
from src.domain.value_objects.identifiers import MerchantId, PlanId


def _period():
    start = datetime.now(UTC)
    return start, start + timedelta(days=30)


def test_start_without_trial_is_active():
    start, end = _period()
    sub = Subscription.start(
        MerchantId.new(), PlanId.new(), "sub_123", BillingInterval.MONTHLY, start, end
    )
    assert sub.status == SubscriptionStatus.ACTIVE
    assert sub.is_usable() is True


def test_start_with_trial_is_trialing():
    start, end = _period()
    trial_end = start + timedelta(days=14)
    sub = Subscription.start(
        MerchantId.new(),
        PlanId.new(),
        "sub_123",
        BillingInterval.MONTHLY,
        start,
        end,
        trial_end=trial_end,
    )
    assert sub.status == SubscriptionStatus.TRIALING
    assert sub.is_usable() is True


def test_start_rejects_invalid_period():
    start, end = _period()
    with pytest.raises(ValidationError):
        Subscription.start(
            MerchantId.new(), PlanId.new(), "sub_1", BillingInterval.MONTHLY, end, start
        )


def test_start_rejects_blank_stripe_subscription_id():
    start, end = _period()
    with pytest.raises(ValidationError):
        Subscription.start(
            MerchantId.new(), PlanId.new(), "   ", BillingInterval.MONTHLY, start, end
        )


def test_change_plan_updates_plan_and_interval():
    start, end = _period()
    sub = Subscription.start(
        MerchantId.new(), PlanId.new(), "sub_1", BillingInterval.MONTHLY, start, end
    )
    new_plan_id = PlanId.new()
    sub.change_plan(new_plan_id, BillingInterval.YEARLY)
    assert sub.plan_id == new_plan_id
    assert sub.billing_interval == BillingInterval.YEARLY


def test_change_plan_rejects_on_canceled_subscription():
    start, end = _period()
    sub = Subscription.start(
        MerchantId.new(), PlanId.new(), "sub_1", BillingInterval.MONTHLY, start, end
    )
    sub.cancel_immediately()
    with pytest.raises(SubscriptionStateError):
        sub.change_plan(PlanId.new())


def test_schedule_cancellation_then_reactivate_reverses_it():
    start, end = _period()
    sub = Subscription.start(
        MerchantId.new(), PlanId.new(), "sub_1", BillingInterval.MONTHLY, start, end
    )
    sub.schedule_cancellation()
    assert sub.cancel_at_period_end is True
    assert sub.status == SubscriptionStatus.ACTIVE  # still usable until period end

    sub.reactivate()
    assert sub.cancel_at_period_end is False
    assert sub.status == SubscriptionStatus.ACTIVE


def test_cancel_immediately_transitions_to_canceled():
    start, end = _period()
    sub = Subscription.start(
        MerchantId.new(), PlanId.new(), "sub_1", BillingInterval.MONTHLY, start, end
    )
    sub.cancel_immediately()
    assert sub.status == SubscriptionStatus.CANCELED
    assert sub.is_usable() is False


def test_reactivate_from_fully_canceled_status():
    start, end = _period()
    sub = Subscription.start(
        MerchantId.new(), PlanId.new(), "sub_1", BillingInterval.MONTHLY, start, end
    )
    sub.cancel_immediately()
    sub.reactivate()
    assert sub.status == SubscriptionStatus.ACTIVE


def test_reactivate_raises_when_nothing_to_reverse():
    start, end = _period()
    sub = Subscription.start(
        MerchantId.new(), PlanId.new(), "sub_1", BillingInterval.MONTHLY, start, end
    )
    with pytest.raises(SubscriptionStateError):
        sub.reactivate()


def test_mark_past_due_and_back_to_active():
    start, end = _period()
    sub = Subscription.start(
        MerchantId.new(), PlanId.new(), "sub_1", BillingInterval.MONTHLY, start, end
    )
    sub.mark_past_due()
    assert sub.status == SubscriptionStatus.PAST_DUE
    assert sub.is_usable() is False

    sub.mark_active()
    assert sub.status == SubscriptionStatus.ACTIVE


def test_cannot_schedule_cancellation_twice_from_canceled():
    start, end = _period()
    sub = Subscription.start(
        MerchantId.new(), PlanId.new(), "sub_1", BillingInterval.MONTHLY, start, end
    )
    sub.cancel_immediately()
    with pytest.raises(SubscriptionStateError):
        sub.schedule_cancellation()


def test_renew_period_rejects_invalid_range():
    start, end = _period()
    sub = Subscription.start(
        MerchantId.new(), PlanId.new(), "sub_1", BillingInterval.MONTHLY, start, end
    )
    with pytest.raises(ValidationError):
        sub.renew_period(end, start)
