import pytest

from src.domain.entities.merchant import Merchant, MerchantStatus, MerchantTier
from src.domain.exceptions.base import ValidationError


def test_register_creates_pending_free_tier_merchant():
    merchant = Merchant.register(
        name="Acme Apparel", domain="ACME.com", contact_email="Owner@Acme.com"
    )

    assert merchant.status == MerchantStatus.PENDING
    assert merchant.tier == MerchantTier.FREE
    # Normalization: domain/email are lower-cased for consistent lookups.
    assert merchant.domain == "acme.com"
    assert merchant.contact_email == "owner@acme.com"


@pytest.mark.parametrize(
    "name,domain,email",
    [
        ("", "acme.com", "a@b.com"),
        ("Acme", "not-a-domain", "a@b.com"),
        ("Acme", "acme.com", "not-an-email"),
    ],
)
def test_register_rejects_invalid_input(name, domain, email):
    with pytest.raises(ValidationError):
        Merchant.register(name=name, domain=domain, contact_email=email)


def test_activate_moves_pending_to_active():
    merchant = Merchant.register("Acme", "acme.com", "a@acme.com")
    merchant.activate()
    assert merchant.status == MerchantStatus.ACTIVE
    assert merchant.is_operational() is True


def test_suspend_requires_a_reason_and_blocks_operation():
    merchant = Merchant.register("Acme", "acme.com", "a@acme.com")
    merchant.activate()

    with pytest.raises(ValidationError):
        merchant.suspend("   ")

    merchant.suspend("Chargeback rate exceeded threshold")
    assert merchant.status == MerchantStatus.SUSPENDED
    assert merchant.suspended_reason == "Chargeback rate exceeded threshold"
    assert merchant.is_operational() is False


def test_churned_merchant_cannot_be_reactivated_directly():
    merchant = Merchant.register("Acme", "acme.com", "a@acme.com")
    merchant.churn()
    with pytest.raises(ValidationError):
        merchant.activate()


def test_activation_clears_previous_suspension_reason():
    merchant = Merchant.register("Acme", "acme.com", "a@acme.com")
    merchant.activate()
    merchant.suspend("late payment")
    merchant.activate()
    assert merchant.suspended_reason is None
