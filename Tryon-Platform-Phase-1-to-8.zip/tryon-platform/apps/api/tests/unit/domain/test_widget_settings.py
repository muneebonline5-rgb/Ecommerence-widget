import pytest

from src.domain.entities.widget_settings import WidgetPosition, WidgetSettings, WidgetTheme
from src.domain.exceptions.base import ValidationError
from src.domain.value_objects.identifiers import MerchantId


def test_default_for_produces_sane_defaults():
    settings = WidgetSettings.default_for(MerchantId.new())
    assert settings.is_enabled is True
    assert settings.position == WidgetPosition.BOTTOM_RIGHT
    assert settings.allowed_origins == []


def test_theme_rejects_invalid_hex_colors():
    with pytest.raises(ValidationError):
        WidgetTheme(primary_color="not-a-color")


def test_set_allowed_origins_requires_scheme_or_wildcard():
    settings = WidgetSettings.default_for(MerchantId.new())
    with pytest.raises(ValidationError):
        settings.set_allowed_origins(["shop.example.com"])  # missing scheme

    settings.set_allowed_origins(["https://shop.example.com", "*"])
    assert settings.allowed_origins == ["https://shop.example.com", "*"]


def test_is_origin_allowed_open_by_default():
    settings = WidgetSettings.default_for(MerchantId.new())
    assert settings.is_origin_allowed("https://anything.example.com") is True


def test_is_origin_allowed_enforces_allowlist_once_configured():
    settings = WidgetSettings.default_for(MerchantId.new())
    settings.set_allowed_origins(["https://shop.example.com"])
    assert settings.is_origin_allowed("https://shop.example.com") is True
    assert settings.is_origin_allowed("https://evil.example.com") is False


def test_disable_and_enable_toggle_state_and_touch_updated_at():
    settings = WidgetSettings.default_for(MerchantId.new())
    original_updated_at = settings.updated_at
    settings.disable()
    assert settings.is_enabled is False
    assert settings.updated_at >= original_updated_at
