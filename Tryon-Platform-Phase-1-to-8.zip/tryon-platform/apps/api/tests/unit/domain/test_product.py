import pytest

from src.domain.entities.product import Product
from src.domain.exceptions.base import ValidationError
from src.domain.value_objects.identifiers import MerchantId


def test_create_normalizes_fields():
    product = Product.create(
        MerchantId.new(),
        "  SKU-1  ",
        "  Blue Sneakers  ",
        "  https://shop.example/p/1  ",
        "  https://shop.example/img/1.png  ",
        category="  Footwear  ",
    )
    assert product.external_id == "SKU-1"
    assert product.title == "Blue Sneakers"
    assert product.product_url == "https://shop.example/p/1"
    assert product.image_url == "https://shop.example/img/1.png"
    assert product.category == "Footwear"
    assert product.is_try_on_eligible is True


@pytest.mark.parametrize(
    "external_id,title,product_url,image_url",
    [
        ("", "Title", "https://x", "https://y"),
        ("SKU", "", "https://x", "https://y"),
        ("SKU", "Title", "", "https://y"),
        ("SKU", "Title", "https://x", ""),
    ],
)
def test_create_rejects_empty_required_fields(external_id, title, product_url, image_url):
    with pytest.raises(ValidationError):
        Product.create(MerchantId.new(), external_id, title, product_url, image_url)


def test_update_details_applies_changes_and_touches_updated_at():
    product = Product.create(MerchantId.new(), "SKU-1", "Old Title", "https://x", "https://y")
    original_updated_at = product.updated_at

    product.update_details(
        title="New Title",
        product_url="https://x2",
        image_url="https://y2",
        category="New Category",
    )

    assert product.title == "New Title"
    assert product.product_url == "https://x2"
    assert product.image_url == "https://y2"
    assert product.category == "New Category"
    assert product.updated_at >= original_updated_at


def test_update_details_rejects_empty_title():
    product = Product.create(MerchantId.new(), "SKU-1", "Title", "https://x", "https://y")
    with pytest.raises(ValidationError):
        product.update_details(
            title="  ", product_url="https://x", image_url="https://y", category=None
        )


def test_set_try_on_eligible_toggles():
    product = Product.create(MerchantId.new(), "SKU-1", "Title", "https://x", "https://y")
    product.set_try_on_eligible(False)
    assert product.is_try_on_eligible is False
    product.set_try_on_eligible(True)
    assert product.is_try_on_eligible is True


def test_metadata_defaults_to_empty_dict():
    product = Product.create(MerchantId.new(), "SKU-1", "Title", "https://x", "https://y")
    assert product.metadata == {}
