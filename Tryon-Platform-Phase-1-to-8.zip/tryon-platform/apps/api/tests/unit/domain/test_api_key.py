import pytest

from src.domain.entities.api_key import ApiKey, ApiKeyStatus
from src.domain.exceptions.base import AuthorizationError
from src.domain.value_objects.api_key import ApiKeyEnvironment, ApiKeyHash, PlaintextApiKey
from src.domain.value_objects.identifiers import MerchantId

PEPPER = "test-pepper-value-not-used-in-production"


def _issue_key() -> tuple[ApiKey, str]:
    plaintext = PlaintextApiKey.generate(ApiKeyEnvironment.LIVE)
    key_hash = ApiKeyHash.from_plaintext(plaintext, PEPPER)
    api_key = ApiKey.issue(MerchantId.new(), "Test key", key_hash, ApiKeyEnvironment.LIVE)
    return api_key, plaintext.full_key


def test_plaintext_key_is_never_stored_on_the_hash():
    api_key, plaintext = _issue_key()
    # The hash object must not expose or equal the plaintext anywhere.
    assert plaintext not in str(api_key.key_hash.hash_value)
    assert api_key.key_hash.hash_value != plaintext


def test_verify_succeeds_with_correct_plaintext_and_pepper():
    api_key, plaintext = _issue_key()
    assert api_key.verify(plaintext, PEPPER) is True


def test_verify_fails_with_wrong_plaintext():
    api_key, _ = _issue_key()
    assert api_key.verify("tk_live_wrongkey_00000000", PEPPER) is False


def test_verify_fails_with_wrong_pepper():
    api_key, plaintext = _issue_key()
    assert api_key.verify(plaintext, "a-different-pepper") is False


def test_revoked_key_never_verifies_even_with_correct_secret():
    api_key, plaintext = _issue_key()
    api_key.revoke()
    assert api_key.verify(plaintext, PEPPER) is False


def test_revoke_is_idempotent():
    api_key, _ = _issue_key()
    api_key.revoke()
    first_revoked_at = api_key.revoked_at
    api_key.revoke()
    assert api_key.revoked_at == first_revoked_at
    assert api_key.status == ApiKeyStatus.REVOKED


def test_record_usage_raises_for_revoked_key():
    api_key, _ = _issue_key()
    api_key.revoke()
    with pytest.raises(AuthorizationError):
        api_key.record_usage()


def test_generated_keys_are_unique():
    keys = {PlaintextApiKey.generate(ApiKeyEnvironment.LIVE).full_key for _ in range(1000)}
    assert len(keys) == 1000
