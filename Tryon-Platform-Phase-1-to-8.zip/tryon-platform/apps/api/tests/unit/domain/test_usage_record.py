from datetime import date

import pytest

from src.domain.entities.usage_record import UsageRecord
from src.domain.exceptions.base import ValidationError
from src.domain.value_objects.identifiers import MerchantId


def test_start_for_day_defaults_to_zero():
    record = UsageRecord.start_for_day(MerchantId.new(), date(2026, 1, 15))
    assert record.generations_count == 0
    assert record.breakdown_by_provider == {}


def test_add_usage_accumulates_count_and_cost():
    record = UsageRecord.start_for_day(MerchantId.new(), date(2026, 1, 15))
    record.add_usage("fashn", 0.05)
    record.add_usage("fashn", 0.05)
    record.add_usage("openai", 0.08)

    assert record.generations_count == 3
    assert record.breakdown_by_provider["fashn"]["count"] == 2
    assert record.breakdown_by_provider["fashn"]["cost_usd"] == 0.10
    assert record.breakdown_by_provider["openai"]["count"] == 1
    assert record.breakdown_by_provider["openai"]["cost_usd"] == 0.08


def test_add_usage_rejects_negative_cost():
    record = UsageRecord.start_for_day(MerchantId.new(), date(2026, 1, 15))
    with pytest.raises(ValidationError):
        record.add_usage("fashn", -0.01)


def test_total_cost_usd_sums_across_providers():
    record = UsageRecord.start_for_day(MerchantId.new(), date(2026, 1, 15))
    record.add_usage("fashn", 0.05)
    record.add_usage("openai", 0.08)
    assert record.total_cost_usd() == pytest.approx(0.13)
