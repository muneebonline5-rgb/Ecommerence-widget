import pytest

from src.domain.entities.ai_request import AIRequest
from src.domain.exceptions.base import TryOnStateError
from src.domain.value_objects.ai_provider import AIProviderName, ProviderRequestStatus
from src.domain.value_objects.identifiers import MerchantId, TryOnId


def _make() -> AIRequest:
    return AIRequest.create(TryOnId.new(), MerchantId.new(), AIProviderName.FASHN, "idem-key-123")


def test_create_starts_queued_with_given_idempotency_key():
    ai_request = _make()
    assert ai_request.status == ProviderRequestStatus.QUEUED
    assert ai_request.idempotency_key == "idem-key-123"
    assert ai_request.provider_request_id is None
    assert ai_request.is_terminal() is False


def test_mark_submitted_transitions_to_processing_and_stores_provider_id():
    ai_request = _make()
    ai_request.mark_submitted("prov-req-1")
    assert ai_request.status == ProviderRequestStatus.PROCESSING
    assert ai_request.provider_request_id == "prov-req-1"


def test_mark_completed_stores_response_and_metrics():
    ai_request = _make()
    ai_request.mark_submitted("prov-req-1")
    ai_request.mark_completed({"result_object_key": "k1"}, latency_ms=1200, cost_usd=0.05)

    assert ai_request.status == ProviderRequestStatus.COMPLETED
    assert ai_request.response_payload == {"result_object_key": "k1"}
    assert ai_request.latency_ms == 1200
    assert ai_request.cost_usd == 0.05
    assert ai_request.is_terminal() is True


def test_mark_failed_from_queued_is_valid_and_preserves_prior_response_payload():
    ai_request = _make()
    ai_request.mark_failed("Rejected input image.")
    assert ai_request.status == ProviderRequestStatus.FAILED
    assert ai_request.response_payload["error"] == "Rejected input image."
    assert ai_request.is_terminal() is True


def test_cannot_complete_directly_from_queued():
    ai_request = _make()
    with pytest.raises(TryOnStateError):
        ai_request.mark_completed({})


def test_cannot_transition_out_of_terminal_state():
    ai_request = _make()
    ai_request.mark_failed("boom")
    with pytest.raises(TryOnStateError):
        ai_request.mark_submitted("prov-req-2")
