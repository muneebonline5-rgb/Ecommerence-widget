import pytest

from src.domain.entities.user import User
from src.domain.exceptions.base import ValidationError


def test_create_normalizes_email():
    user = User.create("clerk_123", "  Ada@ACME.com  ", "  Ada  ")
    assert user.email == "ada@acme.com"
    assert user.full_name == "Ada"
    assert user.is_platform_admin is False


def test_create_rejects_empty_clerk_user_id():
    with pytest.raises(ValidationError):
        User.create("   ", "a@acme.com")


def test_create_rejects_invalid_email():
    with pytest.raises(ValidationError):
        User.create("clerk_123", "not-an-email")


def test_create_allows_missing_full_name():
    user = User.create("clerk_123", "a@acme.com")
    assert user.full_name is None


def test_update_profile_validates_email():
    user = User.create("clerk_123", "a@acme.com")
    with pytest.raises(ValidationError):
        user.update_profile("not-an-email", "Ada")


def test_update_profile_applies_changes():
    user = User.create("clerk_123", "a@acme.com", "Ada")
    original_updated_at = user.updated_at

    user.update_profile("new@acme.com", "Ada Lovelace")

    assert user.email == "new@acme.com"
    assert user.full_name == "Ada Lovelace"
    assert user.updated_at >= original_updated_at


def test_grant_and_revoke_platform_admin():
    user = User.create("clerk_123", "a@acme.com")
    assert user.is_platform_admin is False

    user.grant_platform_admin()
    assert user.is_platform_admin is True

    user.revoke_platform_admin()
    assert user.is_platform_admin is False
