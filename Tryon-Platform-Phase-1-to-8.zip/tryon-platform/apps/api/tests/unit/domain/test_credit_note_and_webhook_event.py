import pytest

from src.domain.entities.credit_note import CreditNote
from src.domain.entities.webhook_event import WebhookEventRecord
from src.domain.exceptions.base import ValidationError
from src.domain.value_objects.identifiers import InvoiceId, MerchantId


class TestCreditNote:
    def test_create_succeeds(self):
        note = CreditNote.create(
            MerchantId.new(), InvoiceId.new(), "cn_123", 10.0, "Goodwill credit"
        )
        assert note.amount_usd == 10.0
        assert note.reason == "Goodwill credit"

    def test_create_rejects_non_positive_amount(self):
        with pytest.raises(ValidationError):
            CreditNote.create(MerchantId.new(), InvoiceId.new(), "cn_123", 0, "reason")

    def test_create_rejects_blank_stripe_id(self):
        with pytest.raises(ValidationError):
            CreditNote.create(MerchantId.new(), InvoiceId.new(), "   ", 10.0, "reason")

    def test_create_rejects_blank_reason(self):
        with pytest.raises(ValidationError):
            CreditNote.create(MerchantId.new(), InvoiceId.new(), "cn_123", 10.0, "   ")


class TestWebhookEventRecord:
    def test_receive_starts_unprocessed(self):
        record = WebhookEventRecord.receive("evt_123", "invoice.paid")
        assert record.is_processed() is False
        assert record.processed_at is None

    def test_mark_processed(self):
        record = WebhookEventRecord.receive("evt_123", "invoice.paid")
        record.mark_processed()
        assert record.is_processed() is True
        assert record.processed_at is not None

    def test_receive_rejects_blank_event_id(self):
        with pytest.raises(ValidationError):
            WebhookEventRecord.receive("   ", "invoice.paid")

    def test_receive_rejects_blank_event_type(self):
        with pytest.raises(ValidationError):
            WebhookEventRecord.receive("evt_123", "   ")
