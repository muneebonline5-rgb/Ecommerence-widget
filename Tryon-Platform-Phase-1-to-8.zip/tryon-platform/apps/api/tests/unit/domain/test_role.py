import pytest

from src.domain.entities.role import BuiltInRole, Role
from src.domain.exceptions.base import ValidationError


def test_create_normalizes_and_dedupes_permission_codes():
    role = Role.create(
        "Editor", "  Can edit widgets  ", ["widget:edit", "widget:edit", " widget:view "]
    )
    assert role.permission_codes == ["widget:edit", "widget:view"]
    assert role.description == "Can edit widgets"


def test_create_rejects_empty_name():
    with pytest.raises(ValidationError):
        Role.create("   ", None, ["widget:view"])


def test_has_permission():
    role = Role.create("viewer", None, ["widget:view"])
    assert role.has_permission("widget:view") is True
    assert role.has_permission("widget:edit") is False


@pytest.mark.parametrize("built_in_role", list(BuiltInRole))
def test_built_in_roles_have_at_least_one_permission(built_in_role):
    role = Role.built_in(built_in_role)
    assert role.name == built_in_role.value
    assert len(role.permission_codes) > 0


def test_owner_role_is_a_superset_of_viewer_role():
    owner = Role.built_in(BuiltInRole.OWNER)
    viewer = Role.built_in(BuiltInRole.VIEWER)
    assert set(viewer.permission_codes).issubset(set(owner.permission_codes))
