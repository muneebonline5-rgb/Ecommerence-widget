import pytest

from src.domain.entities.plan import Plan
from src.domain.exceptions.base import ValidationError
from src.domain.value_objects.billing import BillingInterval, PlanTier


def test_create_monthly_only_plan():
    plan = Plan.create(
        PlanTier.STARTER,
        "Starter",
        monthly_price_usd=29.0,
        monthly_stripe_price_id="price_monthly_1",
        included_generations=100,
        overage_price_usd=0.10,
    )
    assert plan.yearly_price_usd is None
    assert plan.yearly_stripe_price_id is None
    assert plan.is_active is True


def test_create_with_yearly_pricing():
    plan = Plan.create(
        PlanTier.PRO,
        "Pro",
        monthly_price_usd=99.0,
        monthly_stripe_price_id="price_monthly_2",
        included_generations=1000,
        overage_price_usd=0.08,
        yearly_price_usd=990.0,
        yearly_stripe_price_id="price_yearly_2",
    )
    assert plan.yearly_price_usd == 990.0


def test_create_rejects_negative_prices():
    with pytest.raises(ValidationError):
        Plan.create(
            PlanTier.STARTER,
            "Starter",
            monthly_price_usd=-1,
            monthly_stripe_price_id="price_1",
            included_generations=100,
            overage_price_usd=0.1,
        )


def test_create_rejects_yearly_price_without_yearly_stripe_id():
    with pytest.raises(ValidationError):
        Plan.create(
            PlanTier.STARTER,
            "Starter",
            monthly_price_usd=29.0,
            monthly_stripe_price_id="price_1",
            included_generations=100,
            overage_price_usd=0.1,
            yearly_price_usd=290.0,
            yearly_stripe_price_id=None,
        )


def test_stripe_price_id_for_monthly():
    plan = Plan.create(
        PlanTier.STARTER,
        "Starter",
        monthly_price_usd=29.0,
        monthly_stripe_price_id="price_monthly",
        included_generations=100,
        overage_price_usd=0.1,
    )
    assert plan.stripe_price_id_for(BillingInterval.MONTHLY) == "price_monthly"


def test_stripe_price_id_for_yearly_raises_when_unsupported():
    plan = Plan.create(
        PlanTier.STARTER,
        "Starter",
        monthly_price_usd=29.0,
        monthly_stripe_price_id="price_monthly",
        included_generations=100,
        overage_price_usd=0.1,
    )
    with pytest.raises(ValidationError):
        plan.stripe_price_id_for(BillingInterval.YEARLY)


def test_supports_interval():
    plan = Plan.create(
        PlanTier.STARTER,
        "Starter",
        monthly_price_usd=29.0,
        monthly_stripe_price_id="price_monthly",
        included_generations=100,
        overage_price_usd=0.1,
    )
    assert plan.supports_interval(BillingInterval.MONTHLY) is True
    assert plan.supports_interval(BillingInterval.YEARLY) is False


def test_activate_deactivate():
    plan = Plan.create(
        PlanTier.STARTER,
        "Starter",
        monthly_price_usd=29.0,
        monthly_stripe_price_id="price_monthly",
        included_generations=100,
        overage_price_usd=0.1,
    )
    plan.deactivate()
    assert plan.is_active is False
    plan.activate()
    assert plan.is_active is True
