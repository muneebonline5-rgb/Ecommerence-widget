import pytest

from src.domain.entities.audit_log import AuditLog
from src.domain.exceptions.base import ValidationError
from src.domain.value_objects.identifiers import MerchantId, UserId


def test_record_minimal():
    entry = AuditLog.record("subscription.created", "subscription", "sub_123")
    assert entry.action == "subscription.created"
    assert entry.merchant_id is None
    assert entry.actor_type == "user"
    assert entry.metadata == {}


def test_record_with_full_context():
    merchant_id = MerchantId.new()
    user_id = UserId.new()
    entry = AuditLog.record(
        "invoice.refunded",
        "invoice",
        "in_123",
        merchant_id=merchant_id,
        actor_user_id=user_id,
        actor_type="user",
        metadata={"amount_usd": 10.0},
        ip_address="203.0.113.5",
    )
    assert entry.merchant_id == merchant_id
    assert entry.actor_user_id == user_id
    assert entry.metadata == {"amount_usd": 10.0}
    assert entry.ip_address == "203.0.113.5"


@pytest.mark.parametrize(
    "action,resource_type,resource_id",
    [
        ("", "invoice", "in_1"),
        ("invoice.refunded", "", "in_1"),
        ("invoice.refunded", "invoice", ""),
    ],
)
def test_record_rejects_blank_required_fields(action, resource_type, resource_id):
    with pytest.raises(ValidationError):
        AuditLog.record(action, resource_type, resource_id)
