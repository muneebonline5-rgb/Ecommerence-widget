import pytest

from src.domain.entities.analytics_event import AnalyticsEvent, AnalyticsEventType
from src.domain.exceptions.base import ValidationError
from src.domain.value_objects.identifiers import MerchantId, TryOnSessionId


def test_create_defaults_properties_and_timestamp():
    event = AnalyticsEvent.create(MerchantId.new(), AnalyticsEventType.WIDGET_LOADED)
    assert event.properties == {}
    assert event.session_id is None
    assert event.created_at is not None


def test_create_accepts_session_id_and_properties():
    session_id = TryOnSessionId.new()
    event = AnalyticsEvent.create(
        MerchantId.new(),
        AnalyticsEventType.BUTTON_CLICKED,
        session_id=session_id,
        properties={"merchant_id": "abc"},
    )
    assert event.session_id == session_id
    assert event.properties == {"merchant_id": "abc"}


def test_parse_event_type_accepts_known_types():
    assert AnalyticsEvent.parse_event_type("widget_loaded") == AnalyticsEventType.WIDGET_LOADED
    assert AnalyticsEvent.parse_event_type("conversion") == AnalyticsEventType.CONVERSION


def test_parse_event_type_rejects_unknown_type():
    with pytest.raises(ValidationError):
        AnalyticsEvent.parse_event_type("not_a_real_event")
