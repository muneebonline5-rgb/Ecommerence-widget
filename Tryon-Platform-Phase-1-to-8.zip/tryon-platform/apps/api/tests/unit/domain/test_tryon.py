import pytest

from src.domain.entities.tryon import TryOn, TryOnStatus
from src.domain.exceptions.base import TryOnStateError, ValidationError
from src.domain.value_objects.identifiers import TryOnSessionId


def test_create_starts_in_pending():
    tryon = TryOn.create(TryOnSessionId.new(), "customer-uploads/abc.png")
    assert tryon.status == TryOnStatus.PENDING
    assert tryon.result_image_key is None


def test_create_rejects_empty_image_key():
    with pytest.raises(ValidationError):
        TryOn.create(TryOnSessionId.new(), "   ")


def test_valid_lifecycle_pending_to_processing_to_completed():
    tryon = TryOn.create(TryOnSessionId.new(), "customer-uploads/abc.png")
    tryon.start_processing()
    assert tryon.status == TryOnStatus.PROCESSING

    tryon.complete("tryon-results/xyz.png")
    assert tryon.status == TryOnStatus.COMPLETED
    assert tryon.result_image_key == "tryon-results/xyz.png"


def test_valid_lifecycle_pending_to_failed():
    tryon = TryOn.create(TryOnSessionId.new(), "customer-uploads/abc.png")
    tryon.fail("Provider rejected the image.")
    assert tryon.status == TryOnStatus.FAILED
    assert tryon.error_message == "Provider rejected the image."


def test_processing_to_failed_is_valid():
    tryon = TryOn.create(TryOnSessionId.new(), "customer-uploads/abc.png")
    tryon.start_processing()
    tryon.fail("Timed out.")
    assert tryon.status == TryOnStatus.FAILED


def test_cannot_skip_from_pending_to_completed():
    tryon = TryOn.create(TryOnSessionId.new(), "customer-uploads/abc.png")
    with pytest.raises(TryOnStateError):
        tryon.complete("tryon-results/xyz.png")


def test_cannot_transition_out_of_a_terminal_state():
    tryon = TryOn.create(TryOnSessionId.new(), "customer-uploads/abc.png")
    tryon.start_processing()
    tryon.complete("tryon-results/xyz.png")

    with pytest.raises(TryOnStateError):
        tryon.fail("too late")
    with pytest.raises(TryOnStateError):
        tryon.start_processing()


def test_complete_rejects_empty_result_key():
    tryon = TryOn.create(TryOnSessionId.new(), "customer-uploads/abc.png")
    tryon.start_processing()
    with pytest.raises(ValidationError):
        tryon.complete("   ")


def test_mark_downloaded_requires_completed_status():
    tryon = TryOn.create(TryOnSessionId.new(), "customer-uploads/abc.png")
    with pytest.raises(TryOnStateError):
        tryon.mark_downloaded()

    tryon.start_processing()
    tryon.complete("tryon-results/xyz.png")
    tryon.mark_downloaded()
    assert tryon.was_downloaded is True


def test_fail_defaults_message_when_blank():
    tryon = TryOn.create(TryOnSessionId.new(), "customer-uploads/abc.png")
    tryon.fail("   ")
    assert tryon.error_message == "Unknown error"
