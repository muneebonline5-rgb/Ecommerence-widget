from src.domain.entities.team_membership import TeamMembership
from src.domain.value_objects.identifiers import MerchantId, RoleId, UserId


def test_create_sets_all_fields():
    merchant_id = MerchantId.new()
    user_id = UserId.new()
    role_id = RoleId.new()

    membership = TeamMembership.create(merchant_id, user_id, role_id)

    assert membership.merchant_id == merchant_id
    assert membership.user_id == user_id
    assert membership.role_id == role_id
    assert membership.created_at == membership.updated_at


def test_change_role_updates_role_and_touches_updated_at():
    membership = TeamMembership.create(MerchantId.new(), UserId.new(), RoleId.new())
    original_updated_at = membership.updated_at
    new_role_id = RoleId.new()

    membership.change_role(new_role_id)

    assert membership.role_id == new_role_id
    assert membership.updated_at >= original_updated_at
