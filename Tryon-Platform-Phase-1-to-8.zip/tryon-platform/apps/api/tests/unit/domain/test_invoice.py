from datetime import date, timedelta

import pytest

from src.domain.entities.invoice import Invoice
from src.domain.exceptions.base import SubscriptionStateError, ValidationError
from src.domain.value_objects.billing import InvoiceStatus
from src.domain.value_objects.identifiers import MerchantId


def _period():
    start = date(2026, 1, 1)
    return start, start + timedelta(days=30)


def test_create_defaults_status_and_amounts():
    start, end = _period()
    invoice = Invoice.create(MerchantId.new(), "in_123", InvoiceStatus.DRAFT, 29.0, start, end)
    assert invoice.amount_paid_usd == 0.0
    assert invoice.status == InvoiceStatus.DRAFT


def test_create_rejects_invalid_period():
    start, end = _period()
    with pytest.raises(ValidationError):
        Invoice.create(MerchantId.new(), "in_123", InvoiceStatus.DRAFT, 29.0, end, start)


def test_create_rejects_negative_amounts():
    start, end = _period()
    with pytest.raises(ValidationError):
        Invoice.create(MerchantId.new(), "in_123", InvoiceStatus.DRAFT, -1, start, end)


def test_mark_open_then_paid():
    start, end = _period()
    invoice = Invoice.create(MerchantId.new(), "in_123", InvoiceStatus.DRAFT, 29.0, start, end)
    invoice.mark_open()
    assert invoice.status == InvoiceStatus.OPEN

    invoice.mark_paid(29.0)
    assert invoice.status == InvoiceStatus.PAID
    assert invoice.amount_paid_usd == 29.0


def test_cannot_pay_a_draft_invoice_directly():
    start, end = _period()
    invoice = Invoice.create(MerchantId.new(), "in_123", InvoiceStatus.DRAFT, 29.0, start, end)
    with pytest.raises(SubscriptionStateError):
        invoice.mark_paid(29.0)


def test_void_from_open():
    start, end = _period()
    invoice = Invoice.create(MerchantId.new(), "in_123", InvoiceStatus.OPEN, 29.0, start, end)
    invoice.void()
    assert invoice.status == InvoiceStatus.VOID


def test_cannot_transition_out_of_paid():
    start, end = _period()
    invoice = Invoice.create(MerchantId.new(), "in_123", InvoiceStatus.OPEN, 29.0, start, end)
    invoice.mark_paid(29.0)
    with pytest.raises(SubscriptionStateError):
        invoice.void()


def test_uncollectible_can_still_later_be_paid():
    start, end = _period()
    invoice = Invoice.create(MerchantId.new(), "in_123", InvoiceStatus.OPEN, 29.0, start, end)
    invoice.mark_uncollectible()
    assert invoice.status == InvoiceStatus.UNCOLLECTIBLE

    invoice.mark_paid(29.0)
    assert invoice.status == InvoiceStatus.PAID
