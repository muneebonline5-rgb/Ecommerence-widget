import httpx
import jwt as pyjwt
import pytest

from src.domain.exceptions.base import ProviderPermanentError
from src.domain.value_objects.ai_provider import (
    AIProviderName,
    ProviderRequestStatus,
    TryOnGenerationRequest,
)
from src.infrastructure.ai_providers.kling_provider import KlingProviderAdapter

# ≥32 bytes: PyJWT warns on short HMAC keys (RFC 7518 §3.2).
SECRET = "sk_test_secret_at_least_32_bytes_ok"
BASE_URL = "https://api.klingai.com"


@pytest.fixture
def adapter():
    client = httpx.AsyncClient()
    return KlingProviderAdapter(client, access_key="ak_test", secret_key=SECRET, base_url=BASE_URL)


def _request() -> TryOnGenerationRequest:
    return TryOnGenerationRequest(
        customer_image_url="https://storage.example/customer.png",
        product_image_url="https://storage.example/product.png",
        merchant_reference="ai_req_1",
    )


class TestKlingProviderAdapter:
    def test_name(self, adapter):
        assert adapter.name == AIProviderName.KLING

    def test_jwt_is_signed_with_correct_issuer_and_verifiable_with_secret(self, adapter):
        token = adapter._build_jwt()
        claims = pyjwt.decode(token, SECRET, algorithms=["HS256"])
        assert claims["iss"] == "ak_test"
        assert "exp" in claims

    @pytest.mark.respx(base_url=BASE_URL)
    async def test_generate_tryon_sends_bearer_jwt(self, adapter, respx_mock):
        route = respx_mock.post("/v1/images/kolors-virtual-try-on").mock(
            return_value=httpx.Response(
                200, json={"code": 0, "data": {"task_id": "task_1", "task_status": "submitted"}}
            )
        )

        handle = await adapter.generate_tryon(_request())

        assert handle.provider_request_id == "task_1"
        assert handle.status == ProviderRequestStatus.QUEUED
        auth_header = route.calls[0].request.headers["authorization"]
        assert auth_header.startswith("Bearer ")
        claims = pyjwt.decode(auth_header[7:], SECRET, algorithms=["HS256"])
        assert claims["iss"] == "ak_test"

    @pytest.mark.respx(base_url=BASE_URL)
    async def test_generate_tryon_raises_permanent_error_without_task_id(self, adapter, respx_mock):
        respx_mock.post("/v1/images/kolors-virtual-try-on").mock(
            return_value=httpx.Response(200, json={"data": {}})
        )
        with pytest.raises(ProviderPermanentError):
            await adapter.generate_tryon(_request())

    @pytest.mark.respx(base_url=BASE_URL)
    async def test_check_status_processing(self, adapter, respx_mock):
        respx_mock.get("/v1/images/kolors-virtual-try-on/task_1").mock(
            return_value=httpx.Response(200, json={"data": {"task_status": "processing"}})
        )
        result = await adapter.check_status("task_1")
        assert result.status == ProviderRequestStatus.PROCESSING

    @pytest.mark.respx(base_url=BASE_URL)
    async def test_check_status_succeed_extracts_result_url(self, adapter, respx_mock):
        respx_mock.get("/v1/images/kolors-virtual-try-on/task_1").mock(
            return_value=httpx.Response(
                200,
                json={
                    "data": {
                        "task_status": "succeed",
                        "task_result": {"images": [{"url": "https://cdn.kling.ai/r.png"}]},
                    }
                },
            )
        )
        result = await adapter.check_status("task_1")
        assert result.status == ProviderRequestStatus.COMPLETED
        assert result.result_image_url == "https://cdn.kling.ai/r.png"

    @pytest.mark.respx(base_url=BASE_URL)
    async def test_check_status_failed_extracts_message(self, adapter, respx_mock):
        respx_mock.get("/v1/images/kolors-virtual-try-on/task_1").mock(
            return_value=httpx.Response(
                200,
                json={"data": {"task_status": "failed", "task_status_msg": "Face not detected"}},
            )
        )
        result = await adapter.check_status("task_1")
        assert result.status == ProviderRequestStatus.FAILED
        assert result.error_message == "Face not detected"

    async def test_cancel_not_supported(self, adapter):
        with pytest.raises(ProviderPermanentError):
            await adapter.cancel("task_1")
