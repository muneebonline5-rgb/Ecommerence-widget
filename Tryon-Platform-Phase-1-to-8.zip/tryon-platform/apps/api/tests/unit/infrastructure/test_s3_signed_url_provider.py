import boto3
import pytest
from moto import mock_aws

from src.infrastructure.storage.s3_signed_url_provider import S3SignedUrlProvider

BUCKET = "tryon-test-bucket"


@pytest.fixture
def provider():
    with mock_aws():
        boto3.client(
            "s3", region_name="us-east-1", aws_access_key_id="test", aws_secret_access_key="test"
        ).create_bucket(Bucket=BUCKET)

        yield S3SignedUrlProvider(
            bucket_name=BUCKET,
            endpoint_url="",
            access_key_id="test",
            secret_access_key="test",
        )


class TestS3SignedUrlProvider:
    def test_create_upload_url_returns_a_unique_key_per_merchant(self, provider):
        signed_a = provider.create_upload_url(merchant_id="merchant-1", content_type="image/png")
        signed_b = provider.create_upload_url(merchant_id="merchant-1", content_type="image/png")

        assert signed_a.object_key != signed_b.object_key
        assert signed_a.object_key.startswith("customer-uploads/merchant-1/")
        assert signed_a.object_key.endswith(".png")
        assert signed_a.upload_url.startswith("https://")
        assert BUCKET in signed_a.upload_url

    def test_create_upload_url_uses_correct_extension_per_content_type(self, provider):
        jpeg = provider.create_upload_url(merchant_id="m1", content_type="image/jpeg")
        webp = provider.create_upload_url(merchant_id="m1", content_type="image/webp")
        assert jpeg.object_key.endswith(".jpg")
        assert webp.object_key.endswith(".webp")

    def test_upload_bytes_actually_persists_and_is_retrievable(self, provider):
        object_key = provider.upload_bytes(
            key_prefix="tryon-results/test", data=b"hello world", content_type="image/png"
        )

        raw_client = boto3.client(
            "s3", region_name="us-east-1", aws_access_key_id="test", aws_secret_access_key="test"
        )
        stored = raw_client.get_object(Bucket=BUCKET, Key=object_key)
        assert stored["Body"].read() == b"hello world"
        assert stored["ContentType"] == "image/png"

    def test_get_object_url_is_a_valid_presigned_url_for_an_existing_object(self, provider):
        object_key = provider.upload_bytes(
            key_prefix="tryon-results/test", data=b"data", content_type="image/png"
        )
        url = provider.get_object_url(object_key, expires_in_seconds=120)
        assert object_key in url
        assert "X-Amz-Expires=120" in url or "Expires=" in url
