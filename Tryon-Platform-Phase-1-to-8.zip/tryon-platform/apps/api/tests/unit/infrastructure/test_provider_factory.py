import pytest

from src.domain.exceptions.base import ValidationError
from src.domain.repositories.ai_provider import AIProvider
from src.domain.value_objects.ai_provider import (
    AIProviderName,
    ProviderJobHandle,
    ProviderJobResult,
    ProviderRequestStatus,
    TryOnGenerationRequest,
)
from src.infrastructure.ai_providers.provider_factory import RegistryAIProviderFactory


class _StubProvider(AIProvider):
    def __init__(self, name: AIProviderName) -> None:
        self._name = name

    @property
    def name(self) -> AIProviderName:
        return self._name

    async def generate_tryon(self, request: TryOnGenerationRequest) -> ProviderJobHandle:
        return ProviderJobHandle(provider_request_id="x", status=ProviderRequestStatus.QUEUED)

    async def check_status(self, provider_request_id: str) -> ProviderJobResult:
        return ProviderJobResult(status=ProviderRequestStatus.PROCESSING)

    async def cancel(self, provider_request_id: str) -> None:
        pass


def test_get_provider_returns_the_registered_adapter():
    fashn = _StubProvider(AIProviderName.FASHN)
    factory = RegistryAIProviderFactory({AIProviderName.FASHN: fashn})

    assert factory.get_provider(AIProviderName.FASHN) is fashn


def test_get_provider_raises_for_unconfigured_provider():
    factory = RegistryAIProviderFactory({AIProviderName.FASHN: _StubProvider(AIProviderName.FASHN)})

    with pytest.raises(ValidationError):
        factory.get_provider(AIProviderName.KLING)
