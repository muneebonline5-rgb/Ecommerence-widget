"""
Tests the actual RS256 verification path end-to-end against a real,
locally generated keypair — not mocked crypto — so a bug in algorithm
selection, JWKS parsing, or expiry handling would show up here exactly as
it would against real Clerk-issued tokens.
"""

from __future__ import annotations

import base64
import time

import jwt as pyjwt
import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa

from src.domain.exceptions.base import InvalidTokenError
from src.infrastructure.security.clerk_jwt import ClerkJWTVerifier


def _b64(n: int) -> str:
    """Base64url-encodes an integer per RFC 7518 (JWK numeric fields)."""
    byte_length = (n.bit_length() + 7) // 8
    return base64.urlsafe_b64encode(n.to_bytes(byte_length, "big")).rstrip(b"=").decode("ascii")


def _generate_rsa_jwk(kid: str) -> tuple[dict, dict]:
    """Returns (private_jwk_for_signing, public_jwks_document).

    The private JWK carries the PEM under a private "_pem" key so _sign()
    can hand PyJWT a real key object — PyJWT signs with PEM/key objects
    rather than raw JWK dicts the way python-jose did.
    """
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    numbers = private_key.private_numbers()
    public_numbers = numbers.public_numbers

    private_jwk = {
        "kty": "RSA",
        "kid": kid,
        "alg": "RS256",
        "use": "sig",
        "n": _b64(public_numbers.n),
        "e": _b64(public_numbers.e),
        "d": _b64(numbers.d),
        "p": _b64(numbers.p),
        "q": _b64(numbers.q),
        "dp": _b64(numbers.dmp1),
        "dq": _b64(numbers.dmq1),
        "qi": _b64(numbers.iqmp),
    }
    private_jwk["_pem"] = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode("ascii")

    public_jwk = {
        "kty": "RSA",
        "kid": kid,
        "alg": "RS256",
        "use": "sig",
        "n": private_jwk["n"],
        "e": private_jwk["e"],
    }
    return private_jwk, {"keys": [public_jwk]}


def _sign(private_jwk: dict, claims: dict) -> str:
    return pyjwt.encode(
        claims, private_jwk["_pem"], algorithm="RS256", headers={"kid": private_jwk["kid"]}
    )


@pytest.fixture
def keypair():
    return _generate_rsa_jwk("test-key-1")


async def test_verify_succeeds_for_a_correctly_signed_token(keypair):
    private_jwk, public_jwks = keypair

    async def fetch_jwks() -> dict:
        return public_jwks

    verifier = ClerkJWTVerifier(jwks_fetcher=fetch_jwks)
    token = _sign(private_jwk, {"sub": "user_123", "email": "a@acme.com", "exp": time.time() + 300})

    claims = await verifier.verify(token)
    assert claims["sub"] == "user_123"
    assert claims["email"] == "a@acme.com"


async def test_verify_rejects_expired_token(keypair):
    private_jwk, public_jwks = keypair

    async def fetch_jwks() -> dict:
        return public_jwks

    verifier = ClerkJWTVerifier(jwks_fetcher=fetch_jwks)
    token = _sign(private_jwk, {"sub": "user_123", "exp": time.time() - 60})

    with pytest.raises(InvalidTokenError):
        await verifier.verify(token)


async def test_verify_rejects_token_signed_with_a_different_key(keypair):
    _, public_jwks = keypair
    other_private_jwk, _ = _generate_rsa_jwk("test-key-1")  # same kid, different key material

    async def fetch_jwks() -> dict:
        return public_jwks

    verifier = ClerkJWTVerifier(jwks_fetcher=fetch_jwks)
    forged_token = _sign(other_private_jwk, {"sub": "attacker", "exp": time.time() + 300})

    with pytest.raises(InvalidTokenError):
        await verifier.verify(forged_token)


async def test_verify_rejects_malformed_token():
    async def fetch_jwks() -> dict:
        return {"keys": []}

    verifier = ClerkJWTVerifier(jwks_fetcher=fetch_jwks)
    with pytest.raises(InvalidTokenError):
        await verifier.verify("not-a-jwt-at-all")


async def test_verify_refreshes_jwks_once_on_unknown_kid_then_fails_if_still_missing(keypair):
    """Simulates key rotation where the cached JWKS is stale but no matching key ever arrives."""
    private_jwk, _ = keypair
    fetch_calls = 0

    async def fetch_jwks() -> dict:
        nonlocal fetch_calls
        fetch_calls += 1
        return {"keys": []}  # never has the right key, even after "refresh"

    verifier = ClerkJWTVerifier(jwks_fetcher=fetch_jwks)
    token = _sign(private_jwk, {"sub": "user_123", "exp": time.time() + 300})

    with pytest.raises(InvalidTokenError):
        await verifier.verify(token)

    # Initial fetch + exactly one retry-on-miss, not an unbounded loop.
    assert fetch_calls == 2


async def test_verify_recovers_when_jwks_rotates_mid_flight(keypair):
    """The realistic rotation case: cached JWKS is stale, but a refresh finds the new key."""
    private_jwk, public_jwks = keypair
    call_count = 0

    async def fetch_jwks() -> dict:
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return {"keys": []}  # stale cache, doesn't have the key yet
        return public_jwks  # "refreshed" JWKS now has it

    verifier = ClerkJWTVerifier(jwks_fetcher=fetch_jwks)
    token = _sign(private_jwk, {"sub": "user_123", "exp": time.time() + 300})

    claims = await verifier.verify(token)
    assert claims["sub"] == "user_123"
    assert call_count == 2


async def test_jwks_is_cached_across_multiple_verifications(keypair):
    private_jwk, public_jwks = keypair
    fetch_calls = 0

    async def fetch_jwks() -> dict:
        nonlocal fetch_calls
        fetch_calls += 1
        return public_jwks

    verifier = ClerkJWTVerifier(jwks_fetcher=fetch_jwks, cache_ttl_seconds=3600)
    token = _sign(private_jwk, {"sub": "user_123", "exp": time.time() + 300})

    await verifier.verify(token)
    await verifier.verify(token)
    await verifier.verify(token)

    assert fetch_calls == 1
