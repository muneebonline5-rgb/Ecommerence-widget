import base64

import httpx
import pytest
import respx

from src.domain.exceptions.base import ProviderPermanentError, ProviderTransientError
from src.domain.repositories.storage import SignedUploadUrl, SignedUrlProvider
from src.domain.value_objects.ai_provider import (
    AIProviderName,
    ProviderRequestStatus,
    TryOnGenerationRequest,
)
from src.infrastructure.ai_providers.openai_provider import OpenAIProviderAdapter

BASE_URL = "https://api.openai.com"


class FakeStorage(SignedUrlProvider):
    def __init__(self) -> None:
        self.uploaded: dict[str, bytes] = {}

    def create_upload_url(self, *, merchant_id: str, content_type: str) -> SignedUploadUrl:
        raise NotImplementedError

    def get_object_url(self, object_key: str, *, expires_in_seconds: int = 3600) -> str:
        return f"https://storage.example/{object_key}?signed=1"

    def upload_bytes(self, *, key_prefix: str, data: bytes, content_type: str) -> str:
        key = f"{key_prefix}/generated.png"
        self.uploaded[key] = data
        return key


@pytest.fixture
def storage() -> FakeStorage:
    return FakeStorage()


@pytest.fixture
def adapter(storage):
    client = httpx.AsyncClient()
    return OpenAIProviderAdapter(client, storage, api_key="sk-test-key", base_url=BASE_URL)


def _request() -> TryOnGenerationRequest:
    return TryOnGenerationRequest(
        customer_image_url="https://storage.example/customer.png",
        product_image_url="https://storage.example/product.png",
        merchant_reference="ai_req_1",
    )


class TestOpenAIProviderAdapter:
    def test_name(self, adapter):
        assert adapter.name == AIProviderName.OPENAI

    @pytest.mark.respx(base_url=BASE_URL)
    async def test_generate_tryon_returns_completed_immediately(self, adapter, storage, respx_mock):
        respx_mock.get("https://storage.example/customer.png").mock(
            return_value=httpx.Response(200, content=b"fake-customer-bytes")
        )
        image_b64 = base64.b64encode(b"fake-generated-png-bytes").decode()
        respx_mock.post("/v1/images/edits").mock(
            return_value=httpx.Response(200, json={"data": [{"b64_json": image_b64}]})
        )

        handle = await adapter.generate_tryon(_request())

        assert handle.status == ProviderRequestStatus.COMPLETED
        assert handle.provider_request_id in storage.uploaded
        assert storage.uploaded[handle.provider_request_id] == b"fake-generated-png-bytes"

    @pytest.mark.respx(base_url=BASE_URL)
    async def test_check_status_resolves_a_fresh_signed_url_without_a_network_call(
        self, adapter, respx_mock
    ):
        # No route registered for OpenAI's API here at all — check_status
        # must not make any HTTP call, since the result already exists.
        result = await adapter.check_status("tryon-results/openai/generated.png")
        assert result.status == ProviderRequestStatus.COMPLETED
        assert result.result_image_url == (
            "https://storage.example/tryon-results/openai/generated.png?signed=1"
        )

    @pytest.mark.respx(base_url=BASE_URL)
    async def test_generate_tryon_raises_permanent_error_on_4xx(self, adapter, respx_mock):
        respx_mock.get("https://storage.example/customer.png").mock(
            return_value=httpx.Response(200, content=b"fake-customer-bytes")
        )
        respx_mock.post("/v1/images/edits").mock(
            return_value=httpx.Response(400, text="invalid_request_error")
        )
        with pytest.raises(ProviderPermanentError):
            await adapter.generate_tryon(_request())

    @pytest.mark.respx(base_url=BASE_URL)
    async def test_generate_tryon_raises_transient_error_on_5xx(self, adapter, respx_mock):
        respx_mock.get("https://storage.example/customer.png").mock(
            return_value=httpx.Response(200, content=b"fake-customer-bytes")
        )
        respx_mock.post("/v1/images/edits").mock(return_value=httpx.Response(503))
        with pytest.raises(ProviderTransientError):
            await adapter.generate_tryon(_request())

    async def test_fetch_source_image_failure_is_transient(self, adapter):
        with respx.mock:
            respx.get("https://storage.example/customer.png").mock(
                side_effect=httpx.ConnectError("refused")
            )
            with pytest.raises(ProviderTransientError):
                await adapter.generate_tryon(_request())

    async def test_cancel_not_supported(self, adapter):
        with pytest.raises(ProviderPermanentError):
            await adapter.cancel("anything")
