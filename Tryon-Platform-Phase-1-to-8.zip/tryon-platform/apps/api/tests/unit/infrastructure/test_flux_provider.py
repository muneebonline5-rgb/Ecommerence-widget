import httpx
import pytest

from src.domain.exceptions.base import ProviderPermanentError, ProviderTransientError
from src.domain.value_objects.ai_provider import (
    AIProviderName,
    ProviderRequestStatus,
    TryOnGenerationRequest,
)
from src.infrastructure.ai_providers.flux_provider import FluxProviderAdapter

BASE_URL = "https://api.bfl.ai"


@pytest.fixture
def adapter():
    client = httpx.AsyncClient()
    return FluxProviderAdapter(client, api_key="flux-test-key", base_url=BASE_URL)


def _request() -> TryOnGenerationRequest:
    return TryOnGenerationRequest(
        customer_image_url="https://storage.example/customer.png",
        product_image_url="https://storage.example/product.png",
        merchant_reference="ai_req_1",
    )


class TestFluxProviderAdapter:
    def test_name(self, adapter):
        assert adapter.name == AIProviderName.FLUX

    @pytest.mark.respx(base_url=BASE_URL)
    async def test_generate_tryon_uses_x_key_header(self, adapter, respx_mock):
        route = respx_mock.post("/v1/flux-kontext-pro").mock(
            return_value=httpx.Response(200, json={"id": "flux_job_1"})
        )

        handle = await adapter.generate_tryon(_request())

        assert handle.provider_request_id == "flux_job_1"
        assert handle.status == ProviderRequestStatus.QUEUED
        assert route.calls[0].request.headers["x-key"] == "flux-test-key"

    @pytest.mark.respx(base_url=BASE_URL)
    async def test_generate_tryon_raises_permanent_error_without_id(self, adapter, respx_mock):
        respx_mock.post("/v1/flux-kontext-pro").mock(return_value=httpx.Response(200, json={}))
        with pytest.raises(ProviderPermanentError):
            await adapter.generate_tryon(_request())

    @pytest.mark.respx(base_url=BASE_URL)
    async def test_check_status_pending(self, adapter, respx_mock):
        respx_mock.get("/v1/get_result", params={"id": "flux_job_1"}).mock(
            return_value=httpx.Response(200, json={"status": "Pending"})
        )
        result = await adapter.check_status("flux_job_1")
        assert result.status == ProviderRequestStatus.QUEUED

    @pytest.mark.respx(base_url=BASE_URL)
    async def test_check_status_ready_extracts_result_url(self, adapter, respx_mock):
        respx_mock.get("/v1/get_result", params={"id": "flux_job_1"}).mock(
            return_value=httpx.Response(
                200, json={"status": "Ready", "result": {"sample": "https://delivery.bfl.ai/r.png"}}
            )
        )
        result = await adapter.check_status("flux_job_1")
        assert result.status == ProviderRequestStatus.COMPLETED
        assert result.result_image_url == "https://delivery.bfl.ai/r.png"

    @pytest.mark.respx(base_url=BASE_URL)
    async def test_check_status_moderated_maps_to_failed(self, adapter, respx_mock):
        respx_mock.get("/v1/get_result", params={"id": "flux_job_1"}).mock(
            return_value=httpx.Response(200, json={"status": "Content Moderated"})
        )
        result = await adapter.check_status("flux_job_1")
        assert result.status == ProviderRequestStatus.FAILED

    @pytest.mark.respx(base_url=BASE_URL)
    async def test_unrecognized_status_is_permanent_error(self, adapter, respx_mock):
        respx_mock.get("/v1/get_result", params={"id": "flux_job_1"}).mock(
            return_value=httpx.Response(200, json={"status": "Something Else"})
        )
        with pytest.raises(ProviderPermanentError):
            await adapter.check_status("flux_job_1")

    @pytest.mark.respx(base_url=BASE_URL)
    async def test_5xx_is_transient(self, adapter, respx_mock):
        respx_mock.post("/v1/flux-kontext-pro").mock(return_value=httpx.Response(502))
        with pytest.raises(ProviderTransientError):
            await adapter.generate_tryon(_request())

    async def test_cancel_not_supported(self, adapter):
        with pytest.raises(ProviderPermanentError):
            await adapter.cancel("flux_job_1")
