import httpx
import pytest
import respx

from src.domain.exceptions.base import ProviderPermanentError, ProviderTransientError
from src.domain.value_objects.ai_provider import (
    AIProviderName,
    ProviderRequestStatus,
    TryOnGenerationRequest,
)
from src.infrastructure.ai_providers.fashn_provider import FashnProviderAdapter

BASE_URL = "https://api.fashn.ai"


@pytest.fixture
def adapter():
    client = httpx.AsyncClient()
    return FashnProviderAdapter(client, api_key="fashn-test-key", base_url=BASE_URL)


def _request() -> TryOnGenerationRequest:
    return TryOnGenerationRequest(
        customer_image_url="https://storage.example/customer.png",
        product_image_url="https://storage.example/product.png",
        merchant_reference="ai_req_1",
    )


class TestFashnProviderAdapter:
    def test_name(self, adapter):
        assert adapter.name == AIProviderName.FASHN

    @pytest.mark.respx(base_url=BASE_URL)
    async def test_generate_tryon_submits_correct_payload(self, adapter, respx_mock):
        route = respx_mock.post("/v1/run").mock(
            return_value=httpx.Response(200, json={"id": "job_123"})
        )

        handle = await adapter.generate_tryon(_request())

        assert handle.provider_request_id == "job_123"
        assert handle.status == ProviderRequestStatus.QUEUED
        sent_body = route.calls[0].request.content
        assert b"customer.png" in sent_body
        assert b"product.png" in sent_body
        assert route.calls[0].request.headers["authorization"] == "Bearer fashn-test-key"

    @pytest.mark.respx(base_url=BASE_URL)
    async def test_generate_tryon_raises_permanent_error_without_job_id(self, adapter, respx_mock):
        respx_mock.post("/v1/run").mock(return_value=httpx.Response(200, json={}))
        with pytest.raises(ProviderPermanentError):
            await adapter.generate_tryon(_request())

    @pytest.mark.respx(base_url=BASE_URL)
    async def test_check_status_processing(self, adapter, respx_mock):
        respx_mock.get("/v1/status/job_123").mock(
            return_value=httpx.Response(200, json={"id": "job_123", "status": "processing"})
        )
        result = await adapter.check_status("job_123")
        assert result.status == ProviderRequestStatus.PROCESSING
        assert result.result_image_url is None

    @pytest.mark.respx(base_url=BASE_URL)
    async def test_check_status_completed_extracts_result_url(self, adapter, respx_mock):
        respx_mock.get("/v1/status/job_123").mock(
            return_value=httpx.Response(
                200,
                json={
                    "id": "job_123",
                    "status": "completed",
                    "output": ["https://cdn.fashn.ai/r.png"],
                },
            )
        )
        result = await adapter.check_status("job_123")
        assert result.status == ProviderRequestStatus.COMPLETED
        assert result.result_image_url == "https://cdn.fashn.ai/r.png"

    @pytest.mark.respx(base_url=BASE_URL)
    async def test_check_status_failed_extracts_error_message(self, adapter, respx_mock):
        respx_mock.get("/v1/status/job_123").mock(
            return_value=httpx.Response(
                200,
                json={"id": "job_123", "status": "failed", "error": {"message": "Bad input image"}},
            )
        )
        result = await adapter.check_status("job_123")
        assert result.status == ProviderRequestStatus.FAILED
        assert result.error_message == "Bad input image"

    @pytest.mark.respx(base_url=BASE_URL)
    async def test_check_status_unrecognized_status_is_permanent_error(self, adapter, respx_mock):
        respx_mock.get("/v1/status/job_123").mock(
            return_value=httpx.Response(200, json={"id": "job_123", "status": "something_new"})
        )
        with pytest.raises(ProviderPermanentError):
            await adapter.check_status("job_123")

    @pytest.mark.respx(base_url=BASE_URL)
    async def test_5xx_response_is_transient_error(self, adapter, respx_mock):
        respx_mock.post("/v1/run").mock(return_value=httpx.Response(503, text="unavailable"))
        with pytest.raises(ProviderTransientError):
            await adapter.generate_tryon(_request())

    @pytest.mark.respx(base_url=BASE_URL)
    async def test_429_response_is_transient_error(self, adapter, respx_mock):
        respx_mock.post("/v1/run").mock(return_value=httpx.Response(429, text="rate limited"))
        with pytest.raises(ProviderTransientError):
            await adapter.generate_tryon(_request())

    @pytest.mark.respx(base_url=BASE_URL)
    async def test_4xx_response_is_permanent_error(self, adapter, respx_mock):
        respx_mock.post("/v1/run").mock(return_value=httpx.Response(400, text="bad request"))
        with pytest.raises(ProviderPermanentError):
            await adapter.generate_tryon(_request())

    async def test_timeout_is_transient_error(self, adapter, respx_mock=None):
        with respx.mock(base_url=BASE_URL) as mock:
            mock.post("/v1/run").mock(side_effect=httpx.TimeoutException("timed out"))
            with pytest.raises(ProviderTransientError):
                await adapter.generate_tryon(_request())

    async def test_cancel_is_not_supported(self, adapter):
        with pytest.raises(ProviderPermanentError):
            await adapter.cancel("job_123")
