"""
Tests the actual signature-verification logic in StripeGateway against
manually constructed HMAC-SHA256 signatures following Stripe's documented
webhook signing scheme (`t=<timestamp>,v1=<hex_hmac>`) — real cryptographic
verification, not a mocked stripe.Webhook.construct_event call.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import time

import pytest

from src.domain.exceptions.base import WebhookSignatureError
from src.infrastructure.billing.stripe_gateway import StripeGateway

SECRET = "whsec_test_secret_12345"


def _build_signature_header(payload: bytes, secret: str, *, timestamp: int | None = None) -> str:
    ts = timestamp if timestamp is not None else int(time.time())
    signed_payload = f"{ts}.{payload.decode()}".encode()
    signature = hmac.new(secret.encode(), signed_payload, hashlib.sha256).hexdigest()
    return f"t={ts},v1={signature}"


@pytest.fixture
def gateway() -> StripeGateway:
    return StripeGateway(api_key="sk_test_dummy", webhook_secret=SECRET)


def _payload(event_type: str = "invoice.paid") -> bytes:
    return json.dumps(
        {
            "id": "evt_test_123",
            "type": event_type,
            "data": {"object": {"id": "in_test_123", "status": "paid"}},
        }
    ).encode()


class TestConstructWebhookEvent:
    def test_valid_signature_is_accepted_and_parsed(self, gateway):
        payload = _payload()
        header = _build_signature_header(payload, SECRET)

        event = gateway.construct_webhook_event(payload, header)

        assert event.stripe_event_id == "evt_test_123"
        assert event.event_type == "invoice.paid"
        assert event.data["id"] == "in_test_123"

    def test_wrong_secret_is_rejected(self, gateway):
        payload = _payload()
        header = _build_signature_header(payload, "whsec_totally_different_secret")

        with pytest.raises(WebhookSignatureError):
            gateway.construct_webhook_event(payload, header)

    def test_tampered_payload_is_rejected(self, gateway):
        payload = _payload()
        header = _build_signature_header(payload, SECRET)

        tampered_payload = _payload(event_type="customer.subscription.deleted")

        with pytest.raises(WebhookSignatureError):
            gateway.construct_webhook_event(tampered_payload, header)

    def test_malformed_header_is_rejected(self, gateway):
        payload = _payload()
        with pytest.raises(WebhookSignatureError):
            gateway.construct_webhook_event(payload, "not-a-valid-signature-header")

    def test_empty_header_is_rejected(self, gateway):
        payload = _payload()
        with pytest.raises(WebhookSignatureError):
            gateway.construct_webhook_event(payload, "")

    def test_expired_timestamp_is_rejected(self, gateway):
        """Stripe's SDK enforces a default 5-minute tolerance window against replay attacks."""
        payload = _payload()
        old_timestamp = int(time.time()) - 3600  # 1 hour old
        header = _build_signature_header(payload, SECRET, timestamp=old_timestamp)

        with pytest.raises(WebhookSignatureError):
            gateway.construct_webhook_event(payload, header)
