"""
Regression tests for issues found in the Phase 8 production-readiness
audit. Each test pins a specific fix so the vulnerability or defect cannot
silently return.
"""

import pytest

from src.application.services.auth_service import AuthService
from src.application.services.team_service import TeamService
from src.domain.entities.merchant import Merchant
from src.domain.entities.role import Role
from src.domain.entities.team_membership import TeamMembership
from src.domain.entities.user import User
from src.domain.exceptions.base import NotAMemberError
from src.domain.repositories.token_verifier import TokenVerifier
from src.domain.value_objects.identifiers import MerchantId, UserId
from tests.unit.application.fakes import (
    FakeMerchantRepository,
    FakeRoleRepository,
    FakeTeamMembershipRepository,
    FakeUserRepository,
)


class CountingMerchantRepository(FakeMerchantRepository):
    """Counts calls so the N+1 fix can be asserted on, not just assumed."""

    def __init__(self) -> None:
        super().__init__()
        self.get_by_id_calls = 0
        self.list_by_ids_calls = 0

    async def get_by_id(self, merchant_id):
        self.get_by_id_calls += 1
        return await super().get_by_id(merchant_id)

    async def list_by_ids(self, merchant_ids):
        self.list_by_ids_calls += 1
        return await super().list_by_ids(merchant_ids)


class TestNPlusOneFix:
    """AUDIT ISSUE-5: list_merchants_for_user looped one query per membership."""

    @pytest.fixture
    async def setup(self):
        users = FakeUserRepository()
        roles = FakeRoleRepository()
        memberships = FakeTeamMembershipRepository()
        merchants = CountingMerchantRepository()

        role = Role.create("member", None, ["widget:view"])
        await roles.save(role)
        user = User.create("clerk_1", "a@acme.com", "Ada")
        await users.save(user)

        # A user belonging to five merchants — the pathological case for N+1.
        for i in range(5):
            merchant = Merchant.register(f"M{i}", f"m{i}-audit.com", f"m{i}@acme.com")
            await merchants.save(merchant)
            await memberships.save(TeamMembership.create(merchant.id, user.id, role.id))

        service = TeamService(memberships, users, roles, merchant_repository=merchants)
        return service, user, merchants

    async def test_resolves_all_merchants_in_a_single_batched_query(self, setup):
        service, user, merchants = setup

        result = await service.list_merchants_for_user(user.id)

        assert len(result) == 5
        assert merchants.list_by_ids_calls == 1
        assert merchants.get_by_id_calls == 0  # the N+1 path must not be used

    async def test_returns_empty_without_querying_when_user_has_no_memberships(self, setup):
        service, _user, merchants = setup

        assert await service.list_merchants_for_user(UserId.new()) == []
        assert merchants.list_by_ids_calls == 0


class _StubVerifier(TokenVerifier):
    """AUDIT ISSUE-1: proves AuthService accepts any TokenVerifier, not just Clerk's."""

    def __init__(self, claims: dict) -> None:
        self._claims = claims

    async def verify(self, token: str) -> dict:
        return self._claims


class TestDependencyInversionFix:
    """AUDIT ISSUE-1: AuthService previously imported a concrete infrastructure class."""

    async def test_auth_service_works_with_any_token_verifier_implementation(self):
        users = FakeUserRepository()
        service = AuthService(
            jwt_verifier=_StubVerifier({"sub": "clerk_x", "email": "x@acme.com", "name": "Ex"}),
            user_repository=users,
            role_repository=FakeRoleRepository(),
            team_membership_repository=FakeTeamMembershipRepository(),
        )

        user = await service.authenticate("any-token")

        assert user.email == "x@acme.com"
        assert await users.get_by_clerk_user_id("clerk_x") is not None

    def test_clerk_verifier_declares_itself_as_the_port(self):
        from src.infrastructure.security.clerk_jwt import ClerkJWTVerifier

        assert issubclass(ClerkJWTVerifier, TokenVerifier)


class TestMerchantMembershipGuard:
    """
    AUDIT ISSUE-2: GET /merchants/{id} was unauthenticated, exposing every
    merchant's name, domain, contact email, status and tier to any caller.
    The guard relies on AuthService.get_membership raising for non-members.
    """

    @pytest.fixture
    async def auth_service(self):
        memberships = FakeTeamMembershipRepository()
        roles = FakeRoleRepository()
        users = FakeUserRepository()
        role = Role.create("member", None, ["widget:view"])
        await roles.save(role)
        return (
            AuthService(
                jwt_verifier=_StubVerifier({}),
                user_repository=users,
                role_repository=roles,
                team_membership_repository=memberships,
            ),
            memberships,
            role,
        )

    async def test_non_member_is_rejected(self, auth_service):
        service, _memberships, _role = auth_service
        with pytest.raises(NotAMemberError):
            await service.get_membership(MerchantId.new(), UserId.new())

    async def test_member_is_accepted(self, auth_service):
        service, memberships, role = auth_service
        merchant_id, user_id = MerchantId.new(), UserId.new()
        await memberships.save(TeamMembership.create(merchant_id, user_id, role.id))

        membership = await service.get_membership(merchant_id, user_id)
        assert membership.merchant_id == merchant_id
