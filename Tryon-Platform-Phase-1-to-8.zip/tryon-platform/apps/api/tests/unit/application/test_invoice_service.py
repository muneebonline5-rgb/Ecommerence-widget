from datetime import date

import pytest

from src.application.services.invoice_service import InvoiceService
from src.domain.entities.invoice import Invoice
from src.domain.exceptions.base import EntityNotFoundError, NotAMemberError
from src.domain.value_objects.billing import InvoiceStatus
from src.domain.value_objects.identifiers import InvoiceId, MerchantId
from tests.unit.application.fake_payment_gateway import FakePaymentGateway
from tests.unit.application.fakes import (
    FakeAuditLogRepository,
    FakeCreditNoteRepository,
    FakeInvoiceRepository,
)


@pytest.fixture
def invoice_repo() -> FakeInvoiceRepository:
    return FakeInvoiceRepository()


@pytest.fixture
def credit_note_repo() -> FakeCreditNoteRepository:
    return FakeCreditNoteRepository()


@pytest.fixture
def audit_repo() -> FakeAuditLogRepository:
    return FakeAuditLogRepository()


@pytest.fixture
def gateway() -> FakePaymentGateway:
    return FakePaymentGateway()


@pytest.fixture
def service(invoice_repo, credit_note_repo, audit_repo, gateway) -> InvoiceService:
    return InvoiceService(invoice_repo, credit_note_repo, audit_repo, gateway)


async def _seed_invoice(invoice_repo, merchant_id) -> Invoice:
    invoice = Invoice.create(
        merchant_id,
        "in_123",
        InvoiceStatus.PAID,
        29.0,
        date(2026, 1, 1),
        date(2026, 1, 31),
        amount_paid_usd=29.0,
    )
    await invoice_repo.save(invoice)
    return invoice


async def test_list_invoices_scopes_to_merchant(service, invoice_repo):
    merchant_a = MerchantId.new()
    merchant_b = MerchantId.new()
    await _seed_invoice(invoice_repo, merchant_a)
    await _seed_invoice(invoice_repo, merchant_b)

    invoices = await service.list_invoices(merchant_a)
    assert len(invoices) == 1
    assert invoices[0].merchant_id == merchant_a


async def test_get_invoice_raises_not_found(service):
    with pytest.raises(EntityNotFoundError):
        await service.get_invoice(MerchantId.new(), InvoiceId.new())


async def test_get_invoice_raises_not_a_member_for_wrong_merchant(service, invoice_repo):
    merchant_id = MerchantId.new()
    invoice = await _seed_invoice(invoice_repo, merchant_id)
    with pytest.raises(NotAMemberError):
        await service.get_invoice(MerchantId.new(), invoice.id)


async def test_issue_refund_calls_gateway_and_audits(service, invoice_repo, audit_repo):
    merchant_id = MerchantId.new()
    invoice = await _seed_invoice(invoice_repo, merchant_id)

    refund = await service.issue_refund(merchant_id, invoice.id, "ch_123", amount_usd=10.0)

    assert refund.amount_usd == 10.0
    assert any(e.action == "invoice.refunded" for e in audit_repo.saved)


async def test_issue_refund_raises_for_invoice_owned_by_another_merchant(service, invoice_repo):
    merchant_id = MerchantId.new()
    invoice = await _seed_invoice(invoice_repo, merchant_id)
    with pytest.raises(NotAMemberError):
        await service.issue_refund(MerchantId.new(), invoice.id, "ch_123")


async def test_issue_credit_note_persists_and_audits(
    service, invoice_repo, credit_note_repo, audit_repo
):
    merchant_id = MerchantId.new()
    invoice = await _seed_invoice(invoice_repo, merchant_id)

    credit_note = await service.issue_credit_note(merchant_id, invoice.id, 5.0, "Goodwill credit")

    assert credit_note.amount_usd == 5.0
    stored = await credit_note_repo.list_for_invoice(invoice.id)
    assert len(stored) == 1
    assert any(e.action == "invoice.credit_note_issued" for e in audit_repo.saved)


async def test_issue_credit_note_raises_for_invoice_owned_by_another_merchant(
    service, invoice_repo
):
    merchant_id = MerchantId.new()
    invoice = await _seed_invoice(invoice_repo, merchant_id)
    with pytest.raises(NotAMemberError):
        await service.issue_credit_note(MerchantId.new(), invoice.id, 5.0, "reason")
