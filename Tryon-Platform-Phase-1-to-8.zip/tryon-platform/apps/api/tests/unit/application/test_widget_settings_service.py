import pytest

from src.application.services.widget_settings_service import WidgetSettingsService
from src.domain.entities.widget_settings import WidgetButtonShape, WidgetPosition, WidgetSettings
from src.domain.exceptions.base import EntityNotFoundError, ValidationError
from src.domain.value_objects.identifiers import MerchantId
from tests.unit.application.fakes import FakeWidgetSettingsRepository


@pytest.fixture
async def repo() -> FakeWidgetSettingsRepository:
    return FakeWidgetSettingsRepository()


@pytest.fixture
async def service(repo) -> WidgetSettingsService:
    return WidgetSettingsService(repo)


async def _seed(repo: FakeWidgetSettingsRepository, merchant_id: MerchantId) -> WidgetSettings:
    settings = WidgetSettings.default_for(merchant_id)
    await repo.save(settings)
    return settings


async def test_get_for_merchant_raises_when_not_provisioned(service):
    with pytest.raises(EntityNotFoundError):
        await service.get_for_merchant(MerchantId.new())


async def test_update_theme_persists_all_fields(service, repo):
    merchant_id = MerchantId.new()
    await _seed(repo, merchant_id)

    updated = await service.update_theme(
        merchant_id,
        primary_color="#000000",
        accent_color="#FFFFFF",
        text_color="#123456",
        font_family="Roboto, sans-serif",
        button_shape=WidgetButtonShape.PILL,
        border_radius_px=8,
    )

    assert updated.theme.primary_color == "#000000"
    assert updated.theme.button_shape == WidgetButtonShape.PILL
    assert updated.theme.border_radius_px == 8


async def test_update_theme_rejects_invalid_color(service, repo):
    merchant_id = MerchantId.new()
    await _seed(repo, merchant_id)

    with pytest.raises(ValidationError):
        await service.update_theme(
            merchant_id,
            primary_color="banana",
            accent_color="#FFFFFF",
            text_color="#123456",
            font_family="Roboto",
            button_shape=WidgetButtonShape.CIRCLE,
            border_radius_px=8,
        )


async def test_update_position(service, repo):
    merchant_id = MerchantId.new()
    await _seed(repo, merchant_id)
    updated = await service.update_position(merchant_id, WidgetPosition.TOP_LEFT)
    assert updated.position == WidgetPosition.TOP_LEFT


async def test_set_allowed_origins_and_disable_enable(service, repo):
    merchant_id = MerchantId.new()
    await _seed(repo, merchant_id)

    updated = await service.set_allowed_origins(merchant_id, ["https://shop.example.com"])
    assert updated.allowed_origins == ["https://shop.example.com"]

    disabled = await service.set_enabled(merchant_id, False)
    assert disabled.is_enabled is False

    enabled = await service.set_enabled(merchant_id, True)
    assert enabled.is_enabled is True
