import pytest

from src.application.services.plan_service import PlanService
from src.domain.exceptions.base import EntityAlreadyExistsError, EntityNotFoundError
from src.domain.value_objects.billing import PlanTier
from src.domain.value_objects.identifiers import PlanId
from tests.unit.application.fakes import FakePlanRepository


@pytest.fixture
def service() -> PlanService:
    return PlanService(FakePlanRepository())


async def test_create_plan_succeeds(service):
    plan = await service.create_plan(
        PlanTier.STARTER,
        "Starter",
        monthly_price_usd=29.0,
        monthly_stripe_price_id="price_1",
        included_generations=100,
        overage_price_usd=0.1,
    )
    assert plan.tier == PlanTier.STARTER


async def test_create_plan_rejects_duplicate_tier(service):
    await service.create_plan(
        PlanTier.STARTER,
        "Starter",
        monthly_price_usd=29.0,
        monthly_stripe_price_id="price_1",
        included_generations=100,
        overage_price_usd=0.1,
    )
    with pytest.raises(EntityAlreadyExistsError):
        await service.create_plan(
            PlanTier.STARTER,
            "Starter v2",
            monthly_price_usd=39.0,
            monthly_stripe_price_id="price_2",
            included_generations=200,
            overage_price_usd=0.1,
        )


async def test_get_by_tier_raises_when_missing(service):
    with pytest.raises(EntityNotFoundError):
        await service.get_by_tier(PlanTier.ENTERPRISE)


async def test_list_active_plans_excludes_deactivated(service):
    plan = await service.create_plan(
        PlanTier.STARTER,
        "Starter",
        monthly_price_usd=29.0,
        monthly_stripe_price_id="price_1",
        included_generations=100,
        overage_price_usd=0.1,
    )
    await service.create_plan(
        PlanTier.PRO,
        "Pro",
        monthly_price_usd=99.0,
        monthly_stripe_price_id="price_2",
        included_generations=1000,
        overage_price_usd=0.05,
    )

    await service.deactivate_plan(plan.id)
    active = await service.list_active_plans()

    assert len(active) == 1
    assert active[0].tier == PlanTier.PRO


async def test_activate_plan_reverses_deactivation(service):
    plan = await service.create_plan(
        PlanTier.STARTER,
        "Starter",
        monthly_price_usd=29.0,
        monthly_stripe_price_id="price_1",
        included_generations=100,
        overage_price_usd=0.1,
    )
    await service.deactivate_plan(plan.id)
    reactivated = await service.activate_plan(plan.id)
    assert reactivated.is_active is True


async def test_get_plan_raises_for_unknown_id(service):
    with pytest.raises(EntityNotFoundError):
        await service.get_plan(PlanId.new())
