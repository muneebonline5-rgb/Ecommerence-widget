"""
Fake PaymentGateway implementing the real port, used by billing service
unit tests. Simulates Stripe's essential behavior (assigns IDs, tracks
subscription/invoice state, computes period boundaries) without any
network calls or the real `stripe` SDK — the same "test the real contract
against a fake, not a mock" approach used for every other port in this
project.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta

from src.domain.exceptions.base import PaymentGatewayError
from src.domain.repositories.payment_gateway import (
    GatewayCreditNote,
    GatewayCustomer,
    GatewayInvoice,
    GatewayRefund,
    GatewaySubscription,
    GatewayWebhookEvent,
    PaymentGateway,
)


@dataclass
class _FakeSubscriptionState:
    stripe_price_id: str
    status: str = "active"
    cancel_at_period_end: bool = False
    current_period_start: datetime = field(default_factory=lambda: datetime.now(UTC))
    current_period_end: datetime = field(
        default_factory=lambda: datetime.now(UTC) + timedelta(days=30)
    )
    trial_end: datetime | None = None


class FakePaymentGateway(PaymentGateway):
    def __init__(self) -> None:
        self.customers: dict[str, GatewayCustomer] = {}
        self.subscriptions: dict[str, _FakeSubscriptionState] = {}
        self.invoices: dict[str, GatewayInvoice] = {}
        self.fail_next_call = False

    async def create_customer(
        self, *, email: str, name: str, metadata: dict[str, str]
    ) -> GatewayCustomer:
        self._maybe_fail()
        customer_id = f"cus_{uuid.uuid4().hex[:12]}"
        customer = GatewayCustomer(stripe_customer_id=customer_id, email=email)
        self.customers[customer_id] = customer
        return customer

    async def update_customer_metadata(
        self, stripe_customer_id: str, metadata: dict[str, str]
    ) -> None:
        self._maybe_fail()

    async def get_customer(self, stripe_customer_id: str) -> GatewayCustomer:
        self._maybe_fail()
        return self.customers[stripe_customer_id]

    async def create_subscription(
        self, *, stripe_customer_id: str, stripe_price_id: str, trial_days: int | None = None
    ) -> GatewaySubscription:
        self._maybe_fail()
        subscription_id = f"sub_{uuid.uuid4().hex[:12]}"
        trial_end = (
            datetime.now(UTC) + timedelta(days=trial_days)
            if trial_days and trial_days > 0
            else None
        )
        state = _FakeSubscriptionState(stripe_price_id=stripe_price_id, trial_end=trial_end)
        self.subscriptions[subscription_id] = state
        return self._to_gateway_subscription(subscription_id, state)

    async def update_subscription(
        self, stripe_subscription_id: str, *, new_stripe_price_id: str, proration: bool = True
    ) -> GatewaySubscription:
        self._maybe_fail()
        state = self.subscriptions[stripe_subscription_id]
        state.stripe_price_id = new_stripe_price_id
        state.current_period_start = datetime.now(UTC)
        state.current_period_end = datetime.now(UTC) + timedelta(days=30)
        return self._to_gateway_subscription(stripe_subscription_id, state)

    async def cancel_subscription(
        self, stripe_subscription_id: str, *, at_period_end: bool
    ) -> GatewaySubscription:
        self._maybe_fail()
        state = self.subscriptions[stripe_subscription_id]
        if at_period_end:
            state.cancel_at_period_end = True
        else:
            state.status = "canceled"
            state.cancel_at_period_end = False
        return self._to_gateway_subscription(stripe_subscription_id, state)

    async def reactivate_subscription(self, stripe_subscription_id: str) -> GatewaySubscription:
        self._maybe_fail()
        state = self.subscriptions[stripe_subscription_id]
        state.cancel_at_period_end = False
        return self._to_gateway_subscription(stripe_subscription_id, state)

    async def list_invoices(
        self, stripe_customer_id: str, *, limit: int = 20
    ) -> list[GatewayInvoice]:
        self._maybe_fail()
        return list(self.invoices.values())[:limit]

    async def get_invoice(self, stripe_invoice_id: str) -> GatewayInvoice:
        self._maybe_fail()
        return self.invoices[stripe_invoice_id]

    async def issue_refund(
        self, *, stripe_charge_id: str, amount_usd: float | None = None
    ) -> GatewayRefund:
        self._maybe_fail()
        return GatewayRefund(
            stripe_refund_id=f"re_{uuid.uuid4().hex[:12]}",
            amount_usd=amount_usd or 10.0,
            status="succeeded",
        )

    async def create_credit_note(
        self, *, stripe_invoice_id: str, amount_usd: float, reason: str
    ) -> GatewayCreditNote:
        self._maybe_fail()
        return GatewayCreditNote(
            stripe_credit_note_id=f"cn_{uuid.uuid4().hex[:12]}", amount_usd=amount_usd
        )

    async def report_usage(
        self, stripe_subscription_item_id: str, quantity: int, *, timestamp: datetime
    ) -> None:
        self._maybe_fail()

    def construct_webhook_event(self, payload: bytes, signature_header: str) -> GatewayWebhookEvent:
        raise NotImplementedError("Use FakeWebhookGateway for webhook-specific tests.")

    def _maybe_fail(self) -> None:
        if self.fail_next_call:
            self.fail_next_call = False
            raise PaymentGatewayError("Simulated Stripe API failure.")

    @staticmethod
    def _to_gateway_subscription(
        subscription_id: str, state: _FakeSubscriptionState
    ) -> GatewaySubscription:
        return GatewaySubscription(
            stripe_subscription_id=subscription_id,
            stripe_price_id=state.stripe_price_id,
            status=state.status,
            current_period_start=state.current_period_start,
            current_period_end=state.current_period_end,
            cancel_at_period_end=state.cancel_at_period_end,
            trial_end=state.trial_end,
        )
