import pytest

from src.application.services.auth_service import AuthService
from src.domain.entities.role import Role
from src.domain.entities.team_membership import TeamMembership
from src.domain.exceptions.base import (
    InsufficientPermissionError,
    InvalidTokenError,
    NotAMemberError,
)
from src.domain.value_objects.identifiers import MerchantId, UserId
from tests.unit.application.fakes import (
    FakeRoleRepository,
    FakeTeamMembershipRepository,
    FakeUserRepository,
)


class StubJWTVerifier:
    """Duck-typed stand-in for ClerkJWTVerifier — returns pre-set claims or raises."""

    def __init__(self, claims: dict | None = None, error: Exception | None = None) -> None:
        self._claims = claims
        self._error = error

    async def verify(self, token: str) -> dict:
        if self._error:
            raise self._error
        return self._claims


@pytest.fixture
def repos():
    return {
        "users": FakeUserRepository(),
        "roles": FakeRoleRepository(),
        "memberships": FakeTeamMembershipRepository(),
    }


def make_service(repos, claims=None, error=None) -> AuthService:
    return AuthService(
        jwt_verifier=StubJWTVerifier(claims=claims, error=error),
        user_repository=repos["users"],
        role_repository=repos["roles"],
        team_membership_repository=repos["memberships"],
    )


async def test_authenticate_creates_a_new_user_on_first_sight(repos):
    service = make_service(repos, claims={"sub": "clerk_abc", "email": "a@acme.com", "name": "Ada"})

    user = await service.authenticate("some-jwt")

    assert user.clerk_user_id == "clerk_abc"
    assert user.email == "a@acme.com"
    assert user.full_name == "Ada"

    reloaded = await repos["users"].get_by_clerk_user_id("clerk_abc")
    assert reloaded is not None
    assert reloaded.id == user.id


async def test_authenticate_returns_existing_user_without_duplicating(repos):
    service = make_service(repos, claims={"sub": "clerk_abc", "email": "a@acme.com", "name": "Ada"})
    first = await service.authenticate("jwt-1")
    second = await service.authenticate("jwt-2")

    assert first.id == second.id


async def test_authenticate_syncs_profile_changes_from_claims(repos):
    service = make_service(repos, claims={"sub": "clerk_abc", "email": "a@acme.com", "name": "Ada"})
    original = await service.authenticate("jwt-1")

    service_updated = make_service(
        repos, claims={"sub": "clerk_abc", "email": "new@acme.com", "name": "Ada Lovelace"}
    )
    updated = await service_updated.authenticate("jwt-2")

    assert updated.id == original.id
    assert updated.email == "new@acme.com"
    assert updated.full_name == "Ada Lovelace"


async def test_authenticate_raises_for_missing_subject_claim(repos):
    service = make_service(repos, claims={"email": "a@acme.com"})
    with pytest.raises(InvalidTokenError):
        await service.authenticate("jwt")


async def test_authenticate_raises_for_missing_email_on_first_sight(repos):
    service = make_service(repos, claims={"sub": "clerk_abc"})
    with pytest.raises(InvalidTokenError):
        await service.authenticate("jwt")


async def test_authenticate_propagates_verifier_errors(repos):
    service = make_service(repos, error=InvalidTokenError("bad token"))
    with pytest.raises(InvalidTokenError):
        await service.authenticate("jwt")


async def test_require_permission_raises_not_a_member_when_no_membership(repos):
    service = make_service(repos)
    with pytest.raises(NotAMemberError):
        await service.require_permission(MerchantId.new(), UserId.new(), "widget:edit")


async def test_require_permission_raises_insufficient_permission(repos):
    role = Role.create("viewer", None, ["widget:view"])
    await repos["roles"].save(role)

    merchant_id = MerchantId.new()
    user_id = UserId.new()
    membership = TeamMembership.create(merchant_id, user_id, role.id)
    await repos["memberships"].save(membership)

    service = make_service(repos)
    with pytest.raises(InsufficientPermissionError):
        await service.require_permission(merchant_id, user_id, "widget:edit")


async def test_require_permission_succeeds_when_role_grants_it(repos):
    role = Role.create("editor", None, ["widget:edit"])
    await repos["roles"].save(role)

    merchant_id = MerchantId.new()
    user_id = UserId.new()
    membership = TeamMembership.create(merchant_id, user_id, role.id)
    await repos["memberships"].save(membership)

    service = make_service(repos)
    result = await service.require_permission(merchant_id, user_id, "widget:edit")
    assert result.id == membership.id
