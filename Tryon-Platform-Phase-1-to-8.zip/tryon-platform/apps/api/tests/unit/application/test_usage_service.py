from datetime import UTC, date, datetime, timedelta

import pytest

from src.application.services.usage_service import UsageService
from src.domain.entities.plan import Plan
from src.domain.entities.subscription import Subscription
from src.domain.exceptions.base import NoActiveSubscriptionError, ValidationError
from src.domain.value_objects.billing import BillingInterval, PlanTier
from src.domain.value_objects.identifiers import MerchantId
from tests.unit.application.fakes import (
    FakePlanRepository,
    FakeSubscriptionRepository,
    FakeUsageRecordRepository,
)


@pytest.fixture
def usage_repo() -> FakeUsageRecordRepository:
    return FakeUsageRecordRepository()


@pytest.fixture
def subscription_repo() -> FakeSubscriptionRepository:
    return FakeSubscriptionRepository()


@pytest.fixture
def plan_repo() -> FakePlanRepository:
    return FakePlanRepository()


@pytest.fixture
def service(usage_repo, subscription_repo, plan_repo) -> UsageService:
    return UsageService(usage_repo, subscription_repo, plan_repo)


async def _seed_subscription_and_plan(subscription_repo, plan_repo, merchant_id, included=100):
    plan = Plan.create(
        PlanTier.STARTER,
        "Starter",
        monthly_price_usd=29.0,
        monthly_stripe_price_id="price_1",
        included_generations=included,
        overage_price_usd=0.10,
    )
    await plan_repo.save(plan)

    now = datetime.now(UTC)
    subscription = Subscription.start(
        merchant_id, plan.id, "sub_1", BillingInterval.MONTHLY, now, now + timedelta(days=30)
    )
    await subscription_repo.save(subscription)
    return plan, subscription


async def test_record_usage_creates_new_record_for_first_call(service, usage_repo):
    merchant_id = MerchantId.new()
    record = await service.record_usage(merchant_id, "fashn", 0.05, occurred_on=date(2026, 1, 15))
    assert record.generations_count == 1
    assert record.breakdown_by_provider["fashn"]["cost_usd"] == 0.05


async def test_record_usage_accumulates_into_the_same_day(service):
    merchant_id = MerchantId.new()
    await service.record_usage(merchant_id, "fashn", 0.05, occurred_on=date(2026, 1, 15))
    record = await service.record_usage(merchant_id, "fashn", 0.05, occurred_on=date(2026, 1, 15))
    assert record.generations_count == 2


async def test_record_usage_keeps_different_days_separate(service, usage_repo):
    merchant_id = MerchantId.new()
    await service.record_usage(merchant_id, "fashn", 0.05, occurred_on=date(2026, 1, 15))
    await service.record_usage(merchant_id, "fashn", 0.05, occurred_on=date(2026, 1, 16))

    day1 = await usage_repo.get_for_merchant_and_date(merchant_id, date(2026, 1, 15))
    day2 = await usage_repo.get_for_merchant_and_date(merchant_id, date(2026, 1, 16))
    assert day1.generations_count == 1
    assert day2.generations_count == 1


async def test_get_usage_summary_within_allowance_has_zero_overage(
    service, subscription_repo, plan_repo
):
    merchant_id = MerchantId.new()
    await _seed_subscription_and_plan(subscription_repo, plan_repo, merchant_id, included=100)

    await service.record_usage(merchant_id, "fashn", 0.05, occurred_on=date(2026, 1, 15))

    summary = await service.get_usage_summary(
        merchant_id, period_start=date(2026, 1, 1), period_end=date(2026, 1, 31)
    )
    assert summary.used_generations == 1
    assert summary.overage_generations == 0
    assert summary.overage_cost_usd == 0.0


async def test_get_usage_summary_computes_overage_cost(service, subscription_repo, plan_repo):
    merchant_id = MerchantId.new()
    await _seed_subscription_and_plan(subscription_repo, plan_repo, merchant_id, included=2)

    for _ in range(5):
        await service.record_usage(merchant_id, "fashn", 0.05, occurred_on=date(2026, 1, 15))

    summary = await service.get_usage_summary(
        merchant_id, period_start=date(2026, 1, 1), period_end=date(2026, 1, 31)
    )
    assert summary.used_generations == 5
    assert summary.overage_generations == 3  # 5 used - 2 included
    assert summary.overage_cost_usd == pytest.approx(0.30)  # 3 * 0.10


async def test_get_usage_summary_raises_without_subscription(service):
    with pytest.raises(NoActiveSubscriptionError):
        await service.get_usage_summary(
            MerchantId.new(), period_start=date(2026, 1, 1), period_end=date(2026, 1, 31)
        )


async def test_get_usage_summary_rejects_invalid_range(service, subscription_repo, plan_repo):
    merchant_id = MerchantId.new()
    await _seed_subscription_and_plan(subscription_repo, plan_repo, merchant_id)
    with pytest.raises(ValidationError):
        await service.get_usage_summary(
            merchant_id, period_start=date(2026, 1, 31), period_end=date(2026, 1, 1)
        )


async def test_get_usage_summary_breaks_down_by_provider(service, subscription_repo, plan_repo):
    merchant_id = MerchantId.new()
    await _seed_subscription_and_plan(subscription_repo, plan_repo, merchant_id, included=100)

    await service.record_usage(merchant_id, "fashn", 0.05, occurred_on=date(2026, 1, 15))
    await service.record_usage(merchant_id, "openai", 0.08, occurred_on=date(2026, 1, 16))

    summary = await service.get_usage_summary(
        merchant_id, period_start=date(2026, 1, 1), period_end=date(2026, 1, 31)
    )
    assert summary.breakdown_by_provider["fashn"]["count"] == 1
    assert summary.breakdown_by_provider["openai"]["count"] == 1
