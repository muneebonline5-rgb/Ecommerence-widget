import pytest

from src.application.services.tryon_generation_service import TryOnGenerationService
from src.domain.exceptions.base import (
    EntityNotFoundError,
    NotAMemberError,
    TryOnStateError,
    ValidationError,
)
from src.domain.value_objects.ai_provider import AIProviderName
from src.domain.value_objects.identifiers import MerchantId, ProductId, TryOnId
from tests.unit.application.fakes import (
    FakeAIRequestRepository,
    FakeProductRepository,
    FakeTryOnRepository,
    FakeTryOnSessionRepository,
)


@pytest.fixture
def enqueued_ids() -> list[str]:
    return []


@pytest.fixture
def product_repo() -> FakeProductRepository:
    return FakeProductRepository()


@pytest.fixture
def service(enqueued_ids, product_repo) -> TryOnGenerationService:
    return TryOnGenerationService(
        session_repository=FakeTryOnSessionRepository(),
        tryon_repository=FakeTryOnRepository(),
        ai_request_repository=FakeAIRequestRepository(),
        enqueue_generation=lambda ai_request_id: enqueued_ids.append(ai_request_id),
        product_repository=product_repo,
    )


async def test_request_generation_creates_session_tryon_and_ai_request(service, enqueued_ids):
    merchant_id = MerchantId.new()

    result = await service.request_generation(
        merchant_id=merchant_id,
        anonymous_visitor_id="visitor-1",
        customer_image_key="uploads/customer.png",
        product_image_url="https://shop.example/product.png",
        provider=AIProviderName.FASHN,
        idempotency_key="idem-key-1",
    )

    assert result.was_deduplicated is False
    assert result.tryon.customer_image_key == "uploads/customer.png"
    assert result.ai_request.idempotency_key == "idem-key-1"
    assert str(result.ai_request.id) in enqueued_ids


async def test_request_generation_is_idempotent_for_the_same_key(service, enqueued_ids):
    merchant_id = MerchantId.new()
    kwargs = dict(
        merchant_id=merchant_id,
        anonymous_visitor_id="visitor-1",
        customer_image_key="uploads/customer.png",
        product_image_url="https://shop.example/product.png",
        provider=AIProviderName.FASHN,
        idempotency_key="idem-key-1",
    )

    first = await service.request_generation(**kwargs)
    second = await service.request_generation(**kwargs)

    assert second.was_deduplicated is True
    assert second.ai_request.id == first.ai_request.id
    assert second.tryon.id == first.tryon.id
    # Only enqueued once — the whole point of idempotency here is never
    # calling the (paid) provider twice for the same logical request.
    assert len(enqueued_ids) == 1


async def test_same_idempotency_key_is_independent_per_merchant(service, enqueued_ids):
    result_a = await service.request_generation(
        merchant_id=MerchantId.new(),
        anonymous_visitor_id="visitor-1",
        customer_image_key="uploads/a.png",
        product_image_url="https://shop.example/a.png",
        provider=AIProviderName.FASHN,
        idempotency_key="shared-key",
    )
    result_b = await service.request_generation(
        merchant_id=MerchantId.new(),
        anonymous_visitor_id="visitor-2",
        customer_image_key="uploads/b.png",
        product_image_url="https://shop.example/b.png",
        provider=AIProviderName.FASHN,
        idempotency_key="shared-key",
    )

    assert result_a.ai_request.id != result_b.ai_request.id
    assert len(enqueued_ids) == 2


async def test_request_generation_rejects_blank_idempotency_key(service):
    with pytest.raises(ValidationError):
        await service.request_generation(
            merchant_id=MerchantId.new(),
            anonymous_visitor_id="visitor-1",
            customer_image_key="uploads/customer.png",
            product_image_url="https://shop.example/product.png",
            provider=AIProviderName.FASHN,
            idempotency_key="   ",
        )


async def test_request_generation_rejects_blank_product_image_url(service):
    with pytest.raises(ValidationError):
        await service.request_generation(
            merchant_id=MerchantId.new(),
            anonymous_visitor_id="visitor-1",
            customer_image_key="uploads/customer.png",
            product_image_url="",
            provider=AIProviderName.FASHN,
            idempotency_key="idem-1",
        )


async def test_get_status_returns_tryon_and_ai_request(service):
    merchant_id = MerchantId.new()
    result = await service.request_generation(
        merchant_id=merchant_id,
        anonymous_visitor_id="visitor-1",
        customer_image_key="uploads/customer.png",
        product_image_url="https://shop.example/product.png",
        provider=AIProviderName.FASHN,
        idempotency_key="idem-1",
    )

    status = await service.get_status(result.tryon.id, merchant_id)
    assert status.tryon.id == result.tryon.id
    assert status.ai_request is not None
    assert status.ai_request.id == result.ai_request.id


async def test_get_status_raises_not_found_for_unknown_tryon(service):
    with pytest.raises(EntityNotFoundError):
        await service.get_status(TryOnId.new(), MerchantId.new())


async def test_get_status_raises_not_a_member_for_wrong_merchant(service):
    merchant_id = MerchantId.new()
    result = await service.request_generation(
        merchant_id=merchant_id,
        anonymous_visitor_id="visitor-1",
        customer_image_key="uploads/customer.png",
        product_image_url="https://shop.example/product.png",
        provider=AIProviderName.FASHN,
        idempotency_key="idem-1",
    )

    with pytest.raises(NotAMemberError):
        await service.get_status(result.tryon.id, MerchantId.new())


async def test_mark_downloaded_requires_completed_tryon(service):
    merchant_id = MerchantId.new()
    result = await service.request_generation(
        merchant_id=merchant_id,
        anonymous_visitor_id="visitor-1",
        customer_image_key="uploads/customer.png",
        product_image_url="https://shop.example/product.png",
        provider=AIProviderName.FASHN,
        idempotency_key="idem-1",
    )

    with pytest.raises(TryOnStateError):
        await service.mark_downloaded(result.tryon.id, merchant_id)


async def test_request_generation_via_product_id_derives_image_url(service, product_repo):
    from src.domain.entities.product import Product

    merchant_id = MerchantId.new()
    product = Product.create(
        merchant_id,
        "SKU-1",
        "Blue Sneakers",
        "https://shop.example/p/1",
        "https://shop.example/img/1.png",
    )
    await product_repo.save(product)

    result = await service.request_generation(
        merchant_id=merchant_id,
        anonymous_visitor_id="visitor-1",
        customer_image_key="uploads/customer.png",
        product_id=product.id,
        provider=AIProviderName.FASHN,
        idempotency_key="idem-product-1",
    )

    assert (
        result.ai_request.request_payload["product_image_url"] == "https://shop.example/img/1.png"
    )


async def test_request_generation_via_product_id_rejects_unknown_product(service):
    with pytest.raises(EntityNotFoundError):
        await service.request_generation(
            merchant_id=MerchantId.new(),
            anonymous_visitor_id="visitor-1",
            customer_image_key="uploads/customer.png",
            product_id=ProductId.new(),
            provider=AIProviderName.FASHN,
            idempotency_key="idem-product-2",
        )


async def test_request_generation_via_product_id_rejects_cross_merchant_product(
    service, product_repo
):
    from src.domain.entities.product import Product

    other_merchant_id = MerchantId.new()
    product = Product.create(
        other_merchant_id,
        "SKU-1",
        "Title",
        "https://shop.example/p/1",
        "https://shop.example/img/1.png",
    )
    await product_repo.save(product)

    with pytest.raises(NotAMemberError):
        await service.request_generation(
            merchant_id=MerchantId.new(),  # different merchant than the product's owner
            anonymous_visitor_id="visitor-1",
            customer_image_key="uploads/customer.png",
            product_id=product.id,
            provider=AIProviderName.FASHN,
            idempotency_key="idem-product-3",
        )


async def test_request_generation_rejects_when_neither_product_id_nor_url_given(service):
    with pytest.raises(ValidationError):
        await service.request_generation(
            merchant_id=MerchantId.new(),
            anonymous_visitor_id="visitor-1",
            customer_image_key="uploads/customer.png",
            provider=AIProviderName.FASHN,
            idempotency_key="idem-product-4",
        )


async def test_request_generation_without_product_repository_configured_rejects_product_id():
    """A service wired without a ProductRepository (e.g. a caller that never needs catalog lookups)
    must fail clearly rather than crash with an AttributeError if a product_id is passed anyway."""
    enqueued: list[str] = []
    service_without_products = TryOnGenerationService(
        session_repository=FakeTryOnSessionRepository(),
        tryon_repository=FakeTryOnRepository(),
        ai_request_repository=FakeAIRequestRepository(),
        enqueue_generation=lambda ai_request_id: enqueued.append(ai_request_id),
    )

    with pytest.raises(ValidationError):
        await service_without_products.request_generation(
            merchant_id=MerchantId.new(),
            anonymous_visitor_id="visitor-1",
            customer_image_key="uploads/customer.png",
            product_id=ProductId.new(),
            provider=AIProviderName.FASHN,
            idempotency_key="idem-product-5",
        )
