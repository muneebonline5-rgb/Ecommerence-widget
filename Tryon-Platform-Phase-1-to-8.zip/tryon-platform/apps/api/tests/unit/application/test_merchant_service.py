import pytest

from src.application.services.merchant_service import MerchantOnboardingService
from src.domain.entities.merchant import MerchantStatus, MerchantTier
from src.domain.exceptions.base import EntityAlreadyExistsError, EntityNotFoundError
from src.domain.value_objects.identifiers import MerchantId
from tests.unit.application.fakes import FakeMerchantRepository, FakeWidgetSettingsRepository


@pytest.fixture
def service() -> MerchantOnboardingService:
    return MerchantOnboardingService(FakeMerchantRepository(), FakeWidgetSettingsRepository())


async def test_register_merchant_also_provisions_default_widget_settings(service):
    merchant = await service.register_merchant("Acme", "acme.com", "a@acme.com")

    widget_settings_repo = service._widget_settings  # inspect fake for test purposes
    settings = await widget_settings_repo.get_by_merchant_id(merchant.id)

    assert settings is not None
    assert settings.merchant_id == merchant.id


async def test_register_merchant_rejects_duplicate_domain(service):
    await service.register_merchant("Acme", "acme.com", "a@acme.com")
    with pytest.raises(EntityAlreadyExistsError):
        await service.register_merchant("Acme Clone", "acme.com", "b@acme.com")


async def test_get_merchant_raises_when_missing(service):
    with pytest.raises(EntityNotFoundError):
        await service.get_merchant(MerchantId.new())


async def test_suspend_and_activate_roundtrip(service):
    merchant = await service.register_merchant("Acme", "acme.com", "a@acme.com")
    await service.activate_merchant(merchant.id)

    suspended = await service.suspend_merchant(merchant.id, "fraud review")
    assert suspended.status == MerchantStatus.SUSPENDED

    activated = await service.activate_merchant(merchant.id)
    assert activated.status == MerchantStatus.ACTIVE
    assert activated.suspended_reason is None


async def test_change_tier_persists(service):
    merchant = await service.register_merchant("Acme", "acme.com", "a@acme.com")
    updated = await service.change_tier(merchant.id, MerchantTier.GROWTH)
    assert updated.tier == MerchantTier.GROWTH

    reloaded = await service.get_merchant(merchant.id)
    assert reloaded.tier == MerchantTier.GROWTH
