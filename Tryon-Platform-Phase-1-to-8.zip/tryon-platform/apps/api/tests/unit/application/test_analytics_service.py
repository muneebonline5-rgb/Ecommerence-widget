from datetime import UTC, datetime, timedelta

import pytest

from src.application.services.analytics_service import AnalyticsService
from src.domain.exceptions.base import ValidationError
from src.domain.value_objects.identifiers import MerchantId, TryOnSessionId
from tests.unit.application.fakes import FakeAnalyticsEventRepository


@pytest.fixture
def repo() -> FakeAnalyticsEventRepository:
    return FakeAnalyticsEventRepository()


@pytest.fixture
def service(repo) -> AnalyticsService:
    return AnalyticsService(repo)


async def test_ingest_batch_accepts_valid_events(service, repo):
    merchant_id = MerchantId.new()
    accepted = await service.ingest_batch(
        merchant_id,
        [
            {"type": "widget_loaded", "properties": {}},
            {"type": "button_clicked", "properties": {"foo": "bar"}},
        ],
    )
    assert accepted == 2
    assert len(repo.saved) == 2
    assert all(e.merchant_id == merchant_id for e in repo.saved)


async def test_ingest_batch_skips_malformed_events_without_failing_the_batch(service, repo):
    merchant_id = MerchantId.new()
    accepted = await service.ingest_batch(
        merchant_id,
        [
            {"type": "widget_loaded"},
            {"type": "not_a_real_event_type"},  # dropped
            {"type": "button_clicked", "properties": "not-a-dict"},  # dropped
            {},  # missing "type" entirely — dropped
            {"type": "conversion"},
        ],
    )
    assert accepted == 2
    assert len(repo.saved) == 2


async def test_ingest_batch_rejects_oversized_batch(service):
    merchant_id = MerchantId.new()
    with pytest.raises(ValidationError):
        await service.ingest_batch(merchant_id, [{"type": "widget_loaded"}] * 101)


async def test_ingest_batch_parses_explicit_timestamp(service, repo):
    merchant_id = MerchantId.new()
    await service.ingest_batch(
        merchant_id, [{"type": "widget_loaded", "timestamp": "2026-01-15T10:00:00.000Z"}]
    )
    assert repo.saved[0].created_at == datetime(2026, 1, 15, 10, 0, 0, tzinfo=UTC)


async def test_ingest_batch_extracts_session_id_from_properties(service, repo):
    merchant_id = MerchantId.new()
    session_id = TryOnSessionId.new()
    await service.ingest_batch(
        merchant_id,
        [{"type": "modal_opened", "properties": {"session_id": str(session_id)}}],
    )
    assert repo.saved[0].session_id == session_id


async def test_get_event_counts_returns_repository_result(service, repo):
    merchant_id = MerchantId.new()
    await service.ingest_batch(merchant_id, [{"type": "widget_loaded"}, {"type": "widget_loaded"}])

    now = datetime.now(UTC)
    counts = await service.get_event_counts(
        merchant_id, start=now - timedelta(days=1), end=now + timedelta(days=1)
    )
    assert counts.get("widget_loaded") == 2


async def test_get_event_counts_rejects_invalid_range(service):
    merchant_id = MerchantId.new()
    now = datetime.now(UTC)
    with pytest.raises(ValidationError):
        await service.get_event_counts(merchant_id, start=now, end=now - timedelta(days=1))
