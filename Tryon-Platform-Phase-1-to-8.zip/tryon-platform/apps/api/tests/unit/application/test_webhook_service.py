from datetime import UTC, datetime, timedelta

import pytest

from src.application.services.webhook_service import WebhookService
from src.domain.entities.subscription import Subscription
from src.domain.repositories.payment_gateway import GatewayWebhookEvent, PaymentGateway
from src.domain.value_objects.billing import BillingInterval, SubscriptionStatus
from src.domain.value_objects.identifiers import MerchantId, PlanId
from tests.unit.application.fakes import (
    FakeAuditLogRepository,
    FakeInvoiceRepository,
    FakeSubscriptionRepository,
    FakeWebhookEventRepository,
)


class StubGateway(PaymentGateway):
    """Only construct_webhook_event is exercised by WebhookService; the rest is unused here."""

    def __init__(self, event: GatewayWebhookEvent) -> None:
        self._event = event

    def construct_webhook_event(self, payload: bytes, signature_header: str) -> GatewayWebhookEvent:
        return self._event

    async def create_customer(self, *, email, name, metadata):
        raise NotImplementedError

    async def update_customer_metadata(self, stripe_customer_id, metadata):
        raise NotImplementedError

    async def get_customer(self, stripe_customer_id):
        raise NotImplementedError

    async def create_subscription(self, *, stripe_customer_id, stripe_price_id, trial_days=None):
        raise NotImplementedError

    async def update_subscription(
        self, stripe_subscription_id, *, new_stripe_price_id, proration=True
    ):
        raise NotImplementedError

    async def cancel_subscription(self, stripe_subscription_id, *, at_period_end):
        raise NotImplementedError

    async def reactivate_subscription(self, stripe_subscription_id):
        raise NotImplementedError

    async def list_invoices(self, stripe_customer_id, *, limit=20):
        raise NotImplementedError

    async def get_invoice(self, stripe_invoice_id):
        raise NotImplementedError

    async def issue_refund(self, *, stripe_charge_id, amount_usd=None):
        raise NotImplementedError

    async def create_credit_note(self, *, stripe_invoice_id, amount_usd, reason):
        raise NotImplementedError

    async def report_usage(self, stripe_subscription_item_id, quantity, *, timestamp):
        raise NotImplementedError


@pytest.fixture
def webhook_event_repo() -> FakeWebhookEventRepository:
    return FakeWebhookEventRepository()


@pytest.fixture
def subscription_repo() -> FakeSubscriptionRepository:
    return FakeSubscriptionRepository()


@pytest.fixture
def invoice_repo() -> FakeInvoiceRepository:
    return FakeInvoiceRepository()


@pytest.fixture
def audit_repo() -> FakeAuditLogRepository:
    return FakeAuditLogRepository()


def _make_service(event, webhook_event_repo, subscription_repo, invoice_repo, audit_repo):
    return WebhookService(
        webhook_event_repo, subscription_repo, invoice_repo, audit_repo, StubGateway(event)
    )


async def _seed_subscription(subscription_repo, status=SubscriptionStatus.ACTIVE) -> Subscription:
    now = datetime.now(UTC)
    sub = Subscription.start(
        MerchantId.new(),
        PlanId.new(),
        "sub_1",
        BillingInterval.MONTHLY,
        now,
        now + timedelta(days=30),
    )
    if status == SubscriptionStatus.PAST_DUE:
        sub.mark_past_due()
    await subscription_repo.save(sub)
    return sub


async def test_handle_processes_a_new_event(
    webhook_event_repo, subscription_repo, invoice_repo, audit_repo
):
    event = GatewayWebhookEvent(stripe_event_id="evt_1", event_type="unhandled.type", data={})
    service = _make_service(event, webhook_event_repo, subscription_repo, invoice_repo, audit_repo)

    result = await service.handle(b"payload", "sig")

    assert result == "processed"
    record = await webhook_event_repo.get_by_stripe_event_id("evt_1")
    assert record.is_processed() is True


async def test_handle_ignores_duplicate_delivery_of_an_already_processed_event(
    webhook_event_repo, subscription_repo, invoice_repo, audit_repo
):
    event = GatewayWebhookEvent(stripe_event_id="evt_dup", event_type="unhandled.type", data={})
    service = _make_service(event, webhook_event_repo, subscription_repo, invoice_repo, audit_repo)

    first = await service.handle(b"payload", "sig")
    second = await service.handle(b"payload", "sig")

    assert first == "processed"
    assert second == "duplicate_ignored"


async def test_subscription_updated_syncs_status_and_period(
    webhook_event_repo, subscription_repo, invoice_repo, audit_repo
):
    await _seed_subscription(subscription_repo, status=SubscriptionStatus.PAST_DUE)
    now = datetime.now(UTC)
    new_period_end = now + timedelta(days=60)

    event = GatewayWebhookEvent(
        stripe_event_id="evt_sub_updated",
        event_type="customer.subscription.updated",
        data={
            "id": "sub_1",
            "status": "active",
            "current_period_start": int(now.timestamp()),
            "current_period_end": int(new_period_end.timestamp()),
            "cancel_at_period_end": False,
        },
    )
    service = _make_service(event, webhook_event_repo, subscription_repo, invoice_repo, audit_repo)
    await service.handle(b"payload", "sig")

    updated = await subscription_repo.get_by_stripe_subscription_id("sub_1")
    assert updated.status == SubscriptionStatus.ACTIVE


async def test_subscription_deleted_cancels_subscription(
    webhook_event_repo, subscription_repo, invoice_repo, audit_repo
):
    await _seed_subscription(subscription_repo)

    event = GatewayWebhookEvent(
        stripe_event_id="evt_sub_deleted",
        event_type="customer.subscription.deleted",
        data={"id": "sub_1"},
    )
    service = _make_service(event, webhook_event_repo, subscription_repo, invoice_repo, audit_repo)
    await service.handle(b"payload", "sig")

    updated = await subscription_repo.get_by_stripe_subscription_id("sub_1")
    assert updated.status == SubscriptionStatus.CANCELED


async def test_subscription_event_for_unknown_subscription_is_a_safe_no_op(
    webhook_event_repo, subscription_repo, invoice_repo, audit_repo
):
    event = GatewayWebhookEvent(
        stripe_event_id="evt_unknown_sub",
        event_type="customer.subscription.deleted",
        data={"id": "sub_does_not_exist"},
    )
    service = _make_service(event, webhook_event_repo, subscription_repo, invoice_repo, audit_repo)
    result = await service.handle(b"payload", "sig")
    assert result == "processed"  # no error, just nothing to reconcile


async def test_invoice_paid_creates_invoice_and_marks_paid(
    webhook_event_repo, subscription_repo, invoice_repo, audit_repo
):
    await _seed_subscription(subscription_repo)
    now = datetime.now(UTC)

    event = GatewayWebhookEvent(
        stripe_event_id="evt_invoice_paid",
        event_type="invoice.paid",
        data={
            "id": "in_1",
            "status": "paid",
            "amount_due": 2900,
            "amount_paid": 2900,
            "period_start": int(now.timestamp()),
            "period_end": int((now + timedelta(days=30)).timestamp()),
            "hosted_invoice_url": "https://stripe.example/invoice/in_1",
            "subscription": "sub_1",
        },
    )
    service = _make_service(event, webhook_event_repo, subscription_repo, invoice_repo, audit_repo)
    await service.handle(b"payload", "sig")

    invoice = await invoice_repo.get_by_stripe_invoice_id("in_1")
    assert invoice is not None
    assert invoice.status.value == "paid"
    assert invoice.amount_paid_usd == 29.0


async def test_invoice_payment_failed_marks_subscription_past_due(
    webhook_event_repo, subscription_repo, invoice_repo, audit_repo
):
    await _seed_subscription(subscription_repo, status=SubscriptionStatus.ACTIVE)
    now = datetime.now(UTC)

    event = GatewayWebhookEvent(
        stripe_event_id="evt_invoice_failed",
        event_type="invoice.payment_failed",
        data={
            "id": "in_2",
            "status": "open",
            "amount_due": 2900,
            "amount_paid": 0,
            "period_start": int(now.timestamp()),
            "period_end": int((now + timedelta(days=30)).timestamp()),
            "subscription": "sub_1",
        },
    )
    service = _make_service(event, webhook_event_repo, subscription_repo, invoice_repo, audit_repo)
    await service.handle(b"payload", "sig")

    updated = await subscription_repo.get_by_stripe_subscription_id("sub_1")
    assert updated.status == SubscriptionStatus.PAST_DUE


async def test_invoice_event_without_subscription_context_is_a_safe_no_op(
    webhook_event_repo, subscription_repo, invoice_repo, audit_repo
):
    now = datetime.now(UTC)
    event = GatewayWebhookEvent(
        stripe_event_id="evt_orphan_invoice",
        event_type="invoice.paid",
        data={
            "id": "in_orphan",
            "status": "paid",
            "amount_due": 100,
            "amount_paid": 100,
            "period_start": int(now.timestamp()),
            "period_end": int((now + timedelta(days=30)).timestamp()),
            "subscription": None,
        },
    )
    service = _make_service(event, webhook_event_repo, subscription_repo, invoice_repo, audit_repo)
    result = await service.handle(b"payload", "sig")
    assert result == "processed"
    assert await invoice_repo.get_by_stripe_invoice_id("in_orphan") is None
