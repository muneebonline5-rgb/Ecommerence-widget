import pytest

from src.application.services.customer_service import CustomerService
from src.application.services.subscription_service import SubscriptionService
from src.domain.entities.merchant import Merchant, MerchantTier
from src.domain.entities.plan import Plan
from src.domain.exceptions.base import NoActiveSubscriptionError, ValidationError
from src.domain.value_objects.billing import BillingInterval, PlanTier
from tests.unit.application.fake_payment_gateway import FakePaymentGateway
from tests.unit.application.fakes import (
    FakeAuditLogRepository,
    FakeMerchantRepository,
    FakePlanRepository,
    FakeSubscriptionRepository,
)


@pytest.fixture
def merchant_repo() -> FakeMerchantRepository:
    return FakeMerchantRepository()


@pytest.fixture
def plan_repo() -> FakePlanRepository:
    return FakePlanRepository()


@pytest.fixture
def subscription_repo() -> FakeSubscriptionRepository:
    return FakeSubscriptionRepository()


@pytest.fixture
def audit_repo() -> FakeAuditLogRepository:
    return FakeAuditLogRepository()


@pytest.fixture
def gateway() -> FakePaymentGateway:
    return FakePaymentGateway()


@pytest.fixture
def service(
    merchant_repo, plan_repo, subscription_repo, audit_repo, gateway
) -> SubscriptionService:
    customer_service = CustomerService(merchant_repo, gateway)
    return SubscriptionService(
        subscription_repository=subscription_repo,
        plan_repository=plan_repo,
        merchant_repository=merchant_repo,
        audit_log_repository=audit_repo,
        customer_service=customer_service,
        gateway=gateway,
    )


async def _seed_merchant(merchant_repo) -> Merchant:
    merchant = Merchant.register("Acme", "acme.com", "a@acme.com")
    await merchant_repo.save(merchant)
    return merchant


async def _seed_plan(plan_repo, tier=PlanTier.STARTER, yearly=False) -> Plan:
    plan = Plan.create(
        tier,
        tier.value.capitalize(),
        monthly_price_usd=29.0,
        monthly_stripe_price_id=f"price_{tier.value}_monthly",
        included_generations=100,
        overage_price_usd=0.10,
        yearly_price_usd=290.0 if yearly else None,
        yearly_stripe_price_id=f"price_{tier.value}_yearly" if yearly else None,
    )
    await plan_repo.save(plan)
    return plan


async def test_subscribe_creates_subscription_and_syncs_merchant_tier(
    service, merchant_repo, plan_repo, subscription_repo
):
    merchant = await _seed_merchant(merchant_repo)
    await _seed_plan(plan_repo, PlanTier.PRO)

    subscription = await service.subscribe(merchant.id, PlanTier.PRO, BillingInterval.MONTHLY)

    assert subscription.merchant_id == merchant.id
    assert subscription.is_usable() is True

    updated_merchant = await merchant_repo.get_by_id(merchant.id)
    assert updated_merchant.tier == MerchantTier.GROWTH  # PlanTier.PRO maps to legacy GROWTH


async def test_subscribe_with_trial_days_starts_trialing(service, merchant_repo, plan_repo):
    merchant = await _seed_merchant(merchant_repo)
    await _seed_plan(plan_repo, PlanTier.STARTER)

    subscription = await service.subscribe(
        merchant.id, PlanTier.STARTER, BillingInterval.MONTHLY, trial_days=14
    )
    assert subscription.trial_end is not None
    assert subscription.status.value == "trialing"


async def test_subscribe_rejects_unsupported_yearly_interval(service, merchant_repo, plan_repo):
    merchant = await _seed_merchant(merchant_repo)
    await _seed_plan(plan_repo, PlanTier.STARTER, yearly=False)

    with pytest.raises(ValidationError):
        await service.subscribe(merchant.id, PlanTier.STARTER, BillingInterval.YEARLY)


async def test_subscribe_twice_without_canceling_first_raises(service, merchant_repo, plan_repo):
    merchant = await _seed_merchant(merchant_repo)
    await _seed_plan(plan_repo, PlanTier.STARTER)

    await service.subscribe(merchant.id, PlanTier.STARTER, BillingInterval.MONTHLY)
    with pytest.raises(ValidationError):
        await service.subscribe(merchant.id, PlanTier.STARTER, BillingInterval.MONTHLY)


async def test_change_plan_upgrades_and_updates_stripe_price(
    service, merchant_repo, plan_repo, gateway
):
    merchant = await _seed_merchant(merchant_repo)
    await _seed_plan(plan_repo, PlanTier.STARTER)
    await _seed_plan(plan_repo, PlanTier.PRO)

    subscription = await service.subscribe(merchant.id, PlanTier.STARTER, BillingInterval.MONTHLY)
    original_plan_id = subscription.plan_id  # captured before mutation — see note below
    updated = await service.change_plan(merchant.id, PlanTier.PRO)

    # Note: FakeSubscriptionRepository stores/returns the same object by
    # reference (unlike a real DB round-trip, which always produces a
    # fresh object), so `subscription` and `updated` are literally the same
    # Python object after this call — comparing against the captured value
    # above is what actually verifies the mutation happened.
    assert updated.plan_id != original_plan_id
    gateway_state = gateway.subscriptions[subscription.stripe_subscription_id]
    assert gateway_state.stripe_price_id == "price_pro_monthly"


async def test_change_plan_raises_without_active_subscription(service, merchant_repo, plan_repo):
    merchant = await _seed_merchant(merchant_repo)
    await _seed_plan(plan_repo, PlanTier.PRO)
    with pytest.raises(NoActiveSubscriptionError):
        await service.change_plan(merchant.id, PlanTier.PRO)


async def test_cancel_at_period_end_keeps_subscription_usable(service, merchant_repo, plan_repo):
    merchant = await _seed_merchant(merchant_repo)
    await _seed_plan(plan_repo, PlanTier.STARTER)
    await service.subscribe(merchant.id, PlanTier.STARTER, BillingInterval.MONTHLY)

    canceled = await service.cancel(merchant.id, at_period_end=True)
    assert canceled.cancel_at_period_end is True
    assert canceled.is_usable() is True


async def test_cancel_immediately_makes_subscription_unusable(service, merchant_repo, plan_repo):
    merchant = await _seed_merchant(merchant_repo)
    await _seed_plan(plan_repo, PlanTier.STARTER)
    await service.subscribe(merchant.id, PlanTier.STARTER, BillingInterval.MONTHLY)

    canceled = await service.cancel(merchant.id, at_period_end=False)
    assert canceled.is_usable() is False


async def test_reactivate_reverses_scheduled_cancellation(service, merchant_repo, plan_repo):
    merchant = await _seed_merchant(merchant_repo)
    await _seed_plan(plan_repo, PlanTier.STARTER)
    await service.subscribe(merchant.id, PlanTier.STARTER, BillingInterval.MONTHLY)
    await service.cancel(merchant.id, at_period_end=True)

    reactivated = await service.reactivate(merchant.id)
    assert reactivated.cancel_at_period_end is False
    assert reactivated.is_usable() is True


async def test_reactivate_raises_without_any_subscription(service, merchant_repo):
    merchant = await _seed_merchant(merchant_repo)
    with pytest.raises(NoActiveSubscriptionError):
        await service.reactivate(merchant.id)


async def test_audit_log_entries_are_recorded_for_lifecycle_actions(
    service, merchant_repo, plan_repo, audit_repo
):
    merchant = await _seed_merchant(merchant_repo)
    await _seed_plan(plan_repo, PlanTier.STARTER)

    await service.subscribe(merchant.id, PlanTier.STARTER, BillingInterval.MONTHLY)
    await service.cancel(merchant.id, at_period_end=True)
    await service.reactivate(merchant.id)

    actions = [entry.action for entry in audit_repo.saved]
    assert "subscription.created" in actions
    assert "subscription.canceled" in actions
    assert "subscription.reactivated" in actions
