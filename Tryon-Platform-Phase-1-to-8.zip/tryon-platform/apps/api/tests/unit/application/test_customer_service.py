import pytest

from src.application.services.customer_service import CustomerService
from src.domain.entities.merchant import Merchant
from src.domain.exceptions.base import EntityNotFoundError
from src.domain.value_objects.identifiers import MerchantId
from tests.unit.application.fake_payment_gateway import FakePaymentGateway
from tests.unit.application.fakes import FakeMerchantRepository


@pytest.fixture
def merchant_repo() -> FakeMerchantRepository:
    return FakeMerchantRepository()


@pytest.fixture
def gateway() -> FakePaymentGateway:
    return FakePaymentGateway()


@pytest.fixture
def service(merchant_repo, gateway) -> CustomerService:
    return CustomerService(merchant_repo, gateway)


async def _seed_merchant(merchant_repo: FakeMerchantRepository) -> Merchant:
    merchant = Merchant.register("Acme", "acme.com", "a@acme.com")
    await merchant_repo.save(merchant)
    return merchant


async def test_ensure_stripe_customer_creates_on_first_call(service, merchant_repo, gateway):
    merchant = await _seed_merchant(merchant_repo)

    updated = await service.ensure_stripe_customer(merchant.id)

    assert updated.stripe_customer_id is not None
    assert updated.stripe_customer_id in gateway.customers


async def test_ensure_stripe_customer_is_idempotent(service, merchant_repo, gateway):
    merchant = await _seed_merchant(merchant_repo)

    first = await service.ensure_stripe_customer(merchant.id)
    second = await service.ensure_stripe_customer(merchant.id)

    assert first.stripe_customer_id == second.stripe_customer_id
    assert len(gateway.customers) == 1


async def test_ensure_stripe_customer_raises_for_unknown_merchant(service):
    with pytest.raises(EntityNotFoundError):
        await service.ensure_stripe_customer(MerchantId.new())


async def test_sync_customer_metadata_pushes_current_details(service, merchant_repo):
    merchant = await _seed_merchant(merchant_repo)
    synced = await service.sync_customer_metadata(merchant.id)
    assert synced.stripe_customer_id is not None
