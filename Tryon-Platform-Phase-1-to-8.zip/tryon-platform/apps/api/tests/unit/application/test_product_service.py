import pytest

from src.application.services.product_service import ProductService
from src.domain.exceptions.base import (
    EntityAlreadyExistsError,
    EntityNotFoundError,
    NotAMemberError,
)
from src.domain.value_objects.identifiers import MerchantId, ProductId
from tests.unit.application.fakes import FakeProductRepository


@pytest.fixture
def service() -> ProductService:
    return ProductService(FakeProductRepository())


async def test_create_product_succeeds(service):
    merchant_id = MerchantId.new()
    product = await service.create_product(
        merchant_id,
        external_id="SKU-1",
        title="Blue Sneakers",
        product_url="https://shop.example/p/1",
        image_url="https://shop.example/img/1.png",
    )
    assert product.merchant_id == merchant_id
    assert product.external_id == "SKU-1"


async def test_create_product_rejects_duplicate_external_id(service):
    merchant_id = MerchantId.new()
    await service.create_product(
        merchant_id, external_id="SKU-1", title="A", product_url="https://x", image_url="https://y"
    )
    with pytest.raises(EntityAlreadyExistsError):
        await service.create_product(
            merchant_id,
            external_id="SKU-1",
            title="B",
            product_url="https://x2",
            image_url="https://y2",
        )


async def test_same_external_id_is_independent_per_merchant(service):
    product_a = await service.create_product(
        MerchantId.new(),
        external_id="SKU-1",
        title="A",
        product_url="https://x",
        image_url="https://y",
    )
    product_b = await service.create_product(
        MerchantId.new(),
        external_id="SKU-1",
        title="B",
        product_url="https://x2",
        image_url="https://y2",
    )
    assert product_a.id != product_b.id


async def test_upsert_creates_on_first_sight_then_updates(service):
    merchant_id = MerchantId.new()
    first = await service.upsert_by_external_id(
        merchant_id,
        external_id="SKU-1",
        title="Original Title",
        product_url="https://x",
        image_url="https://y",
    )
    second = await service.upsert_by_external_id(
        merchant_id,
        external_id="SKU-1",
        title="Updated Title",
        product_url="https://x2",
        image_url="https://y2",
    )
    assert first.id == second.id
    assert second.title == "Updated Title"
    assert second.product_url == "https://x2"


async def test_get_product_raises_not_found(service):
    with pytest.raises(EntityNotFoundError):
        await service.get_product(MerchantId.new(), ProductId.new())


async def test_get_product_raises_not_a_member_for_wrong_merchant(service):
    merchant_id = MerchantId.new()
    product = await service.create_product(
        merchant_id, external_id="SKU-1", title="A", product_url="https://x", image_url="https://y"
    )
    with pytest.raises(NotAMemberError):
        await service.get_product(MerchantId.new(), product.id)


async def test_update_product_applies_changes(service):
    merchant_id = MerchantId.new()
    product = await service.create_product(
        merchant_id, external_id="SKU-1", title="A", product_url="https://x", image_url="https://y"
    )
    updated = await service.update_product(
        merchant_id,
        product.id,
        title="New Title",
        product_url="https://x2",
        image_url="https://y2",
        category="Shoes",
    )
    assert updated.title == "New Title"
    assert updated.category == "Shoes"


async def test_set_try_on_eligible(service):
    merchant_id = MerchantId.new()
    product = await service.create_product(
        merchant_id, external_id="SKU-1", title="A", product_url="https://x", image_url="https://y"
    )
    updated = await service.set_try_on_eligible(merchant_id, product.id, False)
    assert updated.is_try_on_eligible is False


async def test_delete_product_removes_it(service):
    merchant_id = MerchantId.new()
    product = await service.create_product(
        merchant_id, external_id="SKU-1", title="A", product_url="https://x", image_url="https://y"
    )
    await service.delete_product(merchant_id, product.id)
    with pytest.raises(EntityNotFoundError):
        await service.get_product(merchant_id, product.id)


async def test_delete_product_requires_ownership(service):
    merchant_id = MerchantId.new()
    product = await service.create_product(
        merchant_id, external_id="SKU-1", title="A", product_url="https://x", image_url="https://y"
    )
    with pytest.raises(NotAMemberError):
        await service.delete_product(MerchantId.new(), product.id)


async def test_list_products_scopes_to_merchant(service):
    merchant_a = MerchantId.new()
    merchant_b = MerchantId.new()
    await service.create_product(
        merchant_a, external_id="SKU-1", title="A", product_url="https://x", image_url="https://y"
    )
    await service.create_product(
        merchant_b, external_id="SKU-2", title="B", product_url="https://x2", image_url="https://y2"
    )

    products = await service.list_products(merchant_a)
    assert len(products) == 1
    assert products[0].merchant_id == merchant_a
