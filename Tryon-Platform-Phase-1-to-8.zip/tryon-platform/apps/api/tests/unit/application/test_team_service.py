import pytest

from src.application.services.team_service import TeamService
from src.domain.entities.merchant import Merchant
from src.domain.entities.role import Role
from src.domain.entities.user import User
from src.domain.exceptions.base import EntityAlreadyExistsError, EntityNotFoundError
from src.domain.value_objects.identifiers import MerchantId, RoleId, UserId
from tests.unit.application.fakes import (
    FakeMerchantRepository,
    FakeRoleRepository,
    FakeTeamMembershipRepository,
    FakeUserRepository,
)


@pytest.fixture
async def setup():
    users = FakeUserRepository()
    roles = FakeRoleRepository()
    memberships = FakeTeamMembershipRepository()

    user = User.create("clerk_1", "a@acme.com", "Ada")
    await users.save(user)
    role = Role.create("member", None, ["widget:view"])
    await roles.save(role)
    other_role = Role.create("admin", None, ["widget:view", "widget:edit"])
    await roles.save(other_role)

    service = TeamService(memberships, users, roles)
    return service, user, role, other_role, users


async def test_add_member_succeeds(setup):
    service, user, role, _, _users = setup
    merchant_id = MerchantId.new()

    membership = await service.add_member(merchant_id, user.id, role.id)

    assert membership.merchant_id == merchant_id
    assert membership.user_id == user.id
    assert membership.role_id == role.id


async def test_add_member_fails_for_unknown_user(setup):
    service, _, role, _, _users = setup
    with pytest.raises(EntityNotFoundError):
        await service.add_member(MerchantId.new(), UserId.new(), role.id)


async def test_add_member_fails_for_unknown_role(setup):
    service, user, _, _, _users = setup
    with pytest.raises(EntityNotFoundError):
        await service.add_member(MerchantId.new(), user.id, RoleId.new())


async def test_add_member_rejects_duplicate_membership(setup):
    service, user, role, _, _users = setup
    merchant_id = MerchantId.new()
    await service.add_member(merchant_id, user.id, role.id)

    with pytest.raises(EntityAlreadyExistsError):
        await service.add_member(merchant_id, user.id, role.id)


async def test_change_role_updates_membership(setup):
    service, user, role, other_role, _users = setup
    merchant_id = MerchantId.new()
    await service.add_member(merchant_id, user.id, role.id)

    updated = await service.change_role(merchant_id, user.id, other_role.id)
    assert updated.role_id == other_role.id


async def test_change_role_fails_for_nonexistent_membership(setup):
    service, user, _, other_role, _users = setup
    with pytest.raises(EntityNotFoundError):
        await service.change_role(MerchantId.new(), user.id, other_role.id)


async def test_remove_member_deletes_membership(setup):
    service, user, role, _, _users = setup
    merchant_id = MerchantId.new()
    await service.add_member(merchant_id, user.id, role.id)

    await service.remove_member(merchant_id, user.id)

    with pytest.raises(EntityNotFoundError):
        await service.remove_member(merchant_id, user.id)


async def test_list_members_scopes_to_merchant(setup):
    service, user, role, _, users = setup
    merchant_a = MerchantId.new()
    merchant_b = MerchantId.new()

    user_b = User.create("clerk_2", "b@acme.com", "Bea")
    await users.save(user_b)

    await service.add_member(merchant_a, user.id, role.id)
    await service.add_member(merchant_b, user_b.id, role.id)

    members_a = await service.list_members(merchant_a)
    assert len(members_a) == 1
    assert members_a[0].user_id == user.id


@pytest.fixture
async def setup_with_merchants():
    users = FakeUserRepository()
    roles = FakeRoleRepository()
    memberships = FakeTeamMembershipRepository()
    merchants = FakeMerchantRepository()

    role = Role.create("member", None, ["widget:view"])
    await roles.save(role)

    service = TeamService(memberships, users, roles, merchant_repository=merchants)
    return service, users, memberships, merchants, role


async def test_list_merchants_for_user_returns_only_that_users_merchants(setup_with_merchants):
    service, users, memberships, merchants, role = setup_with_merchants

    user = User.create("clerk_1", "a@acme.com", "Ada")
    await users.save(user)
    other_user = User.create("clerk_2", "b@acme.com", "Bea")
    await users.save(other_user)

    merchant_a = Merchant.register("Acme", "acme-a.com", "a@acme.com")
    merchant_b = Merchant.register("Beta", "acme-b.com", "b@acme.com")
    await merchants.save(merchant_a)
    await merchants.save(merchant_b)

    await service.add_member(merchant_a.id, user.id, role.id)
    await service.add_member(merchant_b.id, other_user.id, role.id)

    result = await service.list_merchants_for_user(user.id)

    assert len(result) == 1
    assert result[0].id == merchant_a.id


async def test_list_merchants_for_user_supports_multiple_memberships(setup_with_merchants):
    service, users, memberships, merchants, role = setup_with_merchants

    user = User.create("clerk_1", "a@acme.com", "Ada")
    await users.save(user)

    merchant_a = Merchant.register("Acme", "acme-a2.com", "a@acme.com")
    merchant_b = Merchant.register("Beta", "acme-b2.com", "b@acme.com")
    await merchants.save(merchant_a)
    await merchants.save(merchant_b)

    await service.add_member(merchant_a.id, user.id, role.id)
    await service.add_member(merchant_b.id, user.id, role.id)

    result = await service.list_merchants_for_user(user.id)
    assert {m.id for m in result} == {merchant_a.id, merchant_b.id}


async def test_list_merchants_for_user_returns_empty_for_user_with_no_memberships(
    setup_with_merchants,
):
    service, users, memberships, merchants, role = setup_with_merchants

    user = User.create("clerk_1", "a@acme.com", "Ada")
    await users.save(user)

    result = await service.list_merchants_for_user(user.id)
    assert result == []


async def test_list_merchants_for_user_raises_when_repository_not_configured():
    memberships = FakeTeamMembershipRepository()
    users = FakeUserRepository()
    roles = FakeRoleRepository()
    service = TeamService(memberships, users, roles)  # no merchant_repository

    with pytest.raises(EntityNotFoundError):
        await service.list_merchants_for_user(UserId.new())
