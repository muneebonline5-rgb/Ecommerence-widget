"""
In-memory fakes implementing the domain repository ports.

Using fakes (not mocks) for application-service tests means we exercise real
lookup/uniqueness semantics (e.g. get_by_domain, get_by_prefix) without a
database, keeping these tests fast while still catching real bugs in the
service layer's orchestration logic.
"""

from __future__ import annotations

from src.domain.entities.ai_request import AIRequest
from src.domain.entities.analytics_event import AnalyticsEvent
from src.domain.entities.api_key import ApiKey
from src.domain.entities.audit_log import AuditLog
from src.domain.entities.credit_note import CreditNote
from src.domain.entities.invoice import Invoice
from src.domain.entities.merchant import Merchant
from src.domain.entities.plan import Plan
from src.domain.entities.product import Product
from src.domain.entities.role import Role
from src.domain.entities.subscription import Subscription
from src.domain.entities.team_membership import TeamMembership
from src.domain.entities.tryon import TryOn
from src.domain.entities.tryon_session import TryOnSession
from src.domain.entities.usage_record import UsageRecord
from src.domain.entities.user import User
from src.domain.entities.webhook_event import WebhookEventRecord
from src.domain.entities.widget_settings import WidgetSettings
from src.domain.repositories.interfaces import (
    AIRequestRepository,
    AnalyticsEventRepository,
    ApiKeyRepository,
    AuditLogRepository,
    CreditNoteRepository,
    InvoiceRepository,
    MerchantRepository,
    PlanRepository,
    ProductRepository,
    RoleRepository,
    SubscriptionRepository,
    TeamMembershipRepository,
    TryOnRepository,
    TryOnSessionRepository,
    UsageRecordRepository,
    UserRepository,
    WebhookEventRepository,
    WidgetSettingsRepository,
)
from src.domain.value_objects.billing import PlanTier
from src.domain.value_objects.identifiers import (
    AIRequestId,
    ApiKeyId,
    CreditNoteId,
    InvoiceId,
    MerchantId,
    PlanId,
    ProductId,
    RoleId,
    SubscriptionId,
    TeamMembershipId,
    TryOnId,
    TryOnSessionId,
    UsageRecordId,
    UserId,
    WidgetSettingsId,
)


class FakeMerchantRepository(MerchantRepository):
    def __init__(self) -> None:
        self._store: dict[MerchantId, Merchant] = {}

    async def save(self, merchant: Merchant) -> None:
        self._store[merchant.id] = merchant

    async def get_by_id(self, merchant_id: MerchantId) -> Merchant | None:
        return self._store.get(merchant_id)

    async def get_by_domain(self, domain: str) -> Merchant | None:
        domain = domain.strip().lower()
        return next((m for m in self._store.values() if m.domain == domain), None)

    async def list_all(self, *, limit: int = 50, offset: int = 0) -> list[Merchant]:
        items = sorted(self._store.values(), key=lambda m: m.created_at, reverse=True)
        return items[offset : offset + limit]

    async def list_by_ids(self, merchant_ids: list[MerchantId]) -> list[Merchant]:
        wanted = set(merchant_ids)
        return [m for m in self._store.values() if m.id in wanted]


class FakeApiKeyRepository(ApiKeyRepository):
    def __init__(self) -> None:
        self._store: dict[ApiKeyId, ApiKey] = {}

    async def save(self, api_key: ApiKey) -> None:
        self._store[api_key.id] = api_key

    async def get_by_id(self, api_key_id: ApiKeyId) -> ApiKey | None:
        return self._store.get(api_key_id)

    async def get_by_prefix(self, prefix: str) -> ApiKey | None:
        return next((k for k in self._store.values() if k.key_hash.prefix == prefix), None)

    async def list_for_merchant(self, merchant_id: MerchantId) -> list[ApiKey]:
        return [k for k in self._store.values() if k.merchant_id == merchant_id]


class FakeWidgetSettingsRepository(WidgetSettingsRepository):
    def __init__(self) -> None:
        self._store: dict[WidgetSettingsId, WidgetSettings] = {}

    async def save(self, settings: WidgetSettings) -> None:
        self._store[settings.id] = settings

    async def get_by_id(self, settings_id: WidgetSettingsId) -> WidgetSettings | None:
        return self._store.get(settings_id)

    async def get_by_merchant_id(self, merchant_id: MerchantId) -> WidgetSettings | None:
        return next((s for s in self._store.values() if s.merchant_id == merchant_id), None)


class FakeUserRepository(UserRepository):
    def __init__(self) -> None:
        self._store: dict[UserId, User] = {}

    async def save(self, user: User) -> None:
        self._store[user.id] = user

    async def get_by_id(self, user_id: UserId) -> User | None:
        return self._store.get(user_id)

    async def get_by_clerk_user_id(self, clerk_user_id: str) -> User | None:
        return next((u for u in self._store.values() if u.clerk_user_id == clerk_user_id), None)


class FakeRoleRepository(RoleRepository):
    def __init__(self) -> None:
        self._store: dict[RoleId, Role] = {}

    async def save(self, role: Role) -> None:
        self._store[role.id] = role

    async def get_by_id(self, role_id: RoleId) -> Role | None:
        return self._store.get(role_id)

    async def get_by_name(self, name: str) -> Role | None:
        return next((r for r in self._store.values() if r.name == name.strip()), None)

    async def list_all(self) -> list[Role]:
        return list(self._store.values())


class FakeTeamMembershipRepository(TeamMembershipRepository):
    def __init__(self) -> None:
        self._store: dict[TeamMembershipId, TeamMembership] = {}

    async def save(self, membership: TeamMembership) -> None:
        self._store[membership.id] = membership

    async def get_by_id(self, membership_id: TeamMembershipId) -> TeamMembership | None:
        return self._store.get(membership_id)

    async def get_for_merchant_and_user(
        self, merchant_id: MerchantId, user_id: UserId
    ) -> TeamMembership | None:
        return next(
            (
                m
                for m in self._store.values()
                if m.merchant_id == merchant_id and m.user_id == user_id
            ),
            None,
        )

    async def list_for_merchant(self, merchant_id: MerchantId) -> list[TeamMembership]:
        return [m for m in self._store.values() if m.merchant_id == merchant_id]

    async def list_for_user(self, user_id: UserId) -> list[TeamMembership]:
        return [m for m in self._store.values() if m.user_id == user_id]

    async def delete(self, membership_id: TeamMembershipId) -> None:
        self._store.pop(membership_id, None)


class FakeTryOnSessionRepository(TryOnSessionRepository):
    def __init__(self) -> None:
        self._store: dict[TryOnSessionId, TryOnSession] = {}

    async def save(self, session: TryOnSession) -> None:
        self._store[session.id] = session

    async def get_by_id(self, session_id: TryOnSessionId) -> TryOnSession | None:
        return self._store.get(session_id)


class FakeTryOnRepository(TryOnRepository):
    def __init__(self) -> None:
        self._store: dict[TryOnId, TryOn] = {}

    async def save(self, tryon: TryOn) -> None:
        self._store[tryon.id] = tryon

    async def get_by_id(self, tryon_id: TryOnId) -> TryOn | None:
        return self._store.get(tryon_id)

    async def list_for_session(self, session_id: TryOnSessionId) -> list[TryOn]:
        return [t for t in self._store.values() if t.session_id == session_id]


class FakeAIRequestRepository(AIRequestRepository):
    def __init__(self) -> None:
        self._store: dict[AIRequestId, AIRequest] = {}

    async def save(self, ai_request: AIRequest) -> None:
        self._store[ai_request.id] = ai_request

    async def get_by_id(self, ai_request_id: AIRequestId) -> AIRequest | None:
        return self._store.get(ai_request_id)

    async def get_by_idempotency_key(
        self, merchant_id: MerchantId, idempotency_key: str
    ) -> AIRequest | None:
        return next(
            (
                r
                for r in self._store.values()
                if r.merchant_id == merchant_id and r.idempotency_key == idempotency_key
            ),
            None,
        )

    async def get_by_tryon_id(self, tryon_id: TryOnId) -> AIRequest | None:
        return next((r for r in self._store.values() if r.tryon_id == tryon_id), None)


class FakeProductRepository(ProductRepository):
    def __init__(self) -> None:
        self._store: dict[ProductId, Product] = {}

    async def save(self, product: Product) -> None:
        self._store[product.id] = product

    async def get_by_id(self, product_id: ProductId) -> Product | None:
        return self._store.get(product_id)

    async def get_by_external_id(self, merchant_id: MerchantId, external_id: str) -> Product | None:
        return next(
            (
                p
                for p in self._store.values()
                if p.merchant_id == merchant_id and p.external_id == external_id
            ),
            None,
        )

    async def list_for_merchant(
        self, merchant_id: MerchantId, *, limit: int = 50, offset: int = 0
    ) -> list[Product]:
        items = [p for p in self._store.values() if p.merchant_id == merchant_id]
        items.sort(key=lambda p: p.created_at, reverse=True)
        return items[offset : offset + limit]

    async def delete(self, product_id: ProductId) -> None:
        self._store.pop(product_id, None)


class FakeAnalyticsEventRepository(AnalyticsEventRepository):
    def __init__(self) -> None:
        self.saved: list[AnalyticsEvent] = []

    async def save_batch(self, events: list[AnalyticsEvent]) -> None:
        self.saved.extend(events)

    async def count_by_type(self, merchant_id: MerchantId, *, start, end) -> dict[str, int]:
        counts: dict[str, int] = {}
        for event in self.saved:
            if event.merchant_id != merchant_id:
                continue
            if not (start <= event.created_at < end):
                continue
            counts[event.event_type.value] = counts.get(event.event_type.value, 0) + 1
        return counts


class FakePlanRepository(PlanRepository):
    def __init__(self) -> None:
        self._store: dict[PlanId, Plan] = {}

    async def save(self, plan: Plan) -> None:
        self._store[plan.id] = plan

    async def get_by_id(self, plan_id: PlanId) -> Plan | None:
        return self._store.get(plan_id)

    async def get_by_tier(self, tier: PlanTier) -> Plan | None:
        return next((p for p in self._store.values() if p.tier == tier), None)

    async def list_active(self) -> list[Plan]:
        return [p for p in self._store.values() if p.is_active]


class FakeSubscriptionRepository(SubscriptionRepository):
    def __init__(self) -> None:
        self._store: dict[SubscriptionId, Subscription] = {}

    async def save(self, subscription: Subscription) -> None:
        self._store[subscription.id] = subscription

    async def get_by_id(self, subscription_id: SubscriptionId) -> Subscription | None:
        return self._store.get(subscription_id)

    async def get_by_merchant_id(self, merchant_id: MerchantId) -> Subscription | None:
        return next((s for s in self._store.values() if s.merchant_id == merchant_id), None)

    async def get_by_stripe_subscription_id(
        self, stripe_subscription_id: str
    ) -> Subscription | None:
        return next(
            (s for s in self._store.values() if s.stripe_subscription_id == stripe_subscription_id),
            None,
        )


class FakeInvoiceRepository(InvoiceRepository):
    def __init__(self) -> None:
        self._store: dict[InvoiceId, Invoice] = {}

    async def save(self, invoice: Invoice) -> None:
        self._store[invoice.id] = invoice

    async def get_by_id(self, invoice_id: InvoiceId) -> Invoice | None:
        return self._store.get(invoice_id)

    async def get_by_stripe_invoice_id(self, stripe_invoice_id: str) -> Invoice | None:
        return next(
            (i for i in self._store.values() if i.stripe_invoice_id == stripe_invoice_id), None
        )

    async def list_for_merchant(
        self, merchant_id: MerchantId, *, limit: int = 50, offset: int = 0
    ) -> list[Invoice]:
        items = [i for i in self._store.values() if i.merchant_id == merchant_id]
        items.sort(key=lambda i: i.created_at, reverse=True)
        return items[offset : offset + limit]


class FakeUsageRecordRepository(UsageRecordRepository):
    def __init__(self) -> None:
        self._store: dict[UsageRecordId, UsageRecord] = {}

    async def save(self, usage_record: UsageRecord) -> None:
        self._store[usage_record.id] = usage_record

    async def get_by_id(self, usage_record_id: UsageRecordId) -> UsageRecord | None:
        return self._store.get(usage_record_id)

    async def get_for_merchant_and_date(self, merchant_id: MerchantId, usage_date):
        return next(
            (
                r
                for r in self._store.values()
                if r.merchant_id == merchant_id and r.usage_date == usage_date
            ),
            None,
        )

    async def list_for_merchant_in_range(self, merchant_id: MerchantId, *, start, end):
        return [
            r
            for r in self._store.values()
            if r.merchant_id == merchant_id and start <= r.usage_date <= end
        ]


class FakeCreditNoteRepository(CreditNoteRepository):
    def __init__(self) -> None:
        self._store: dict[CreditNoteId, CreditNote] = {}

    async def save(self, credit_note: CreditNote) -> None:
        self._store[credit_note.id] = credit_note

    async def list_for_invoice(self, invoice_id: InvoiceId) -> list[CreditNote]:
        return [c for c in self._store.values() if c.invoice_id == invoice_id]


class FakeWebhookEventRepository(WebhookEventRepository):
    def __init__(self) -> None:
        self._store: dict[str, WebhookEventRecord] = {}

    async def get_by_stripe_event_id(self, stripe_event_id: str) -> WebhookEventRecord | None:
        return self._store.get(stripe_event_id)

    async def save(self, record: WebhookEventRecord) -> None:
        self._store[record.stripe_event_id] = record


class FakeAuditLogRepository(AuditLogRepository):
    def __init__(self) -> None:
        self.saved: list[AuditLog] = []

    async def save(self, entry: AuditLog) -> None:
        self.saved.append(entry)

    async def list_for_merchant(
        self, merchant_id: MerchantId, *, limit: int = 50, offset: int = 0
    ) -> list[AuditLog]:
        items = [e for e in self.saved if e.merchant_id == merchant_id]
        return items[offset : offset + limit]
