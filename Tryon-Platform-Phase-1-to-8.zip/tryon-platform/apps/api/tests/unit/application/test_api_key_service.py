import pytest

from src.application.services.api_key_service import ApiKeyService
from src.domain.entities.merchant import Merchant
from src.domain.exceptions.base import ApiKeyInvalidError, EntityNotFoundError
from src.domain.value_objects.api_key import ApiKeyEnvironment
from src.domain.value_objects.identifiers import ApiKeyId, MerchantId
from tests.unit.application.fakes import FakeApiKeyRepository, FakeMerchantRepository

PEPPER = "unit-test-pepper"


@pytest.fixture
async def merchant_repo() -> FakeMerchantRepository:
    repo = FakeMerchantRepository()
    return repo


@pytest.fixture
async def service(merchant_repo) -> ApiKeyService:
    return ApiKeyService(FakeApiKeyRepository(), merchant_repo, pepper=PEPPER)


async def _seed_merchant(merchant_repo: FakeMerchantRepository) -> Merchant:
    merchant = Merchant.register("Acme", "acme.com", "a@acme.com")
    await merchant_repo.save(merchant)
    return merchant


async def test_issue_key_returns_plaintext_exactly_once(service, merchant_repo):
    merchant = await _seed_merchant(merchant_repo)
    issued = await service.issue_key(merchant.id, "Production key", ApiKeyEnvironment.LIVE)

    assert issued.plaintext.startswith("tk_live_")
    assert issued.api_key.merchant_id == merchant.id
    # The stored entity itself never carries the plaintext.
    assert issued.plaintext != issued.api_key.key_hash.hash_value


async def test_issue_key_fails_for_unknown_merchant(service):
    with pytest.raises(EntityNotFoundError):
        await service.issue_key(MerchantId.new(), "orphan key", ApiKeyEnvironment.LIVE)


async def test_authenticate_succeeds_with_valid_key_and_records_usage(service, merchant_repo):
    merchant = await _seed_merchant(merchant_repo)
    issued = await service.issue_key(merchant.id, "Prod", ApiKeyEnvironment.LIVE)

    authenticated = await service.authenticate(issued.plaintext)

    assert authenticated.id == issued.api_key.id
    assert authenticated.last_used_at is not None


async def test_authenticate_is_reliable_across_many_generated_keys(service, merchant_repo):
    """
    Regression test: secrets.token_urlsafe() can itself emit '_' characters
    in the random portion of the key. Prefix extraction must not rely on
    splitting the key by '_', or authentication becomes flaky whenever a
    generated key happens to contain an extra underscore. Run many
    iterations since the failure only manifested for specific random draws.
    """
    merchant = await _seed_merchant(merchant_repo)
    for _ in range(200):
        issued = await service.issue_key(merchant.id, "Prod", ApiKeyEnvironment.LIVE)
        authenticated = await service.authenticate(issued.plaintext)
        assert authenticated.id == issued.api_key.id


async def test_authenticate_rejects_garbage_input(service):
    with pytest.raises(ApiKeyInvalidError):
        await service.authenticate("not-a-real-key")


async def test_authenticate_rejects_revoked_key(service, merchant_repo):
    merchant = await _seed_merchant(merchant_repo)
    issued = await service.issue_key(merchant.id, "Prod", ApiKeyEnvironment.LIVE)
    await service.revoke_key(issued.api_key.id)

    with pytest.raises(ApiKeyInvalidError):
        await service.authenticate(issued.plaintext)


async def test_revoke_unknown_key_raises_not_found(service):
    with pytest.raises(EntityNotFoundError):
        await service.revoke_key(ApiKeyId.new())


async def test_list_keys_for_merchant_scopes_correctly(service, merchant_repo):
    merchant_a = await _seed_merchant(merchant_repo)
    merchant_b = Merchant.register("Other", "other.com", "b@other.com")
    await merchant_repo.save(merchant_b)

    await service.issue_key(merchant_a.id, "A key 1", ApiKeyEnvironment.LIVE)
    await service.issue_key(merchant_a.id, "A key 2", ApiKeyEnvironment.TEST)
    await service.issue_key(merchant_b.id, "B key", ApiKeyEnvironment.LIVE)

    keys_for_a = await service.list_keys_for_merchant(merchant_a.id)
    assert len(keys_for_a) == 2
    assert all(k.merchant_id == merchant_a.id for k in keys_for_a)
