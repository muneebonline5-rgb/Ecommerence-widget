"""
FastAPI dependency-injection graph.

This is the ONLY place that wires concrete infrastructure (SQLAlchemy repos)
to application services. Routers depend on the service abstractions returned
here — never on repositories or ORM models directly.
"""

from __future__ import annotations

from collections.abc import AsyncGenerator
from functools import lru_cache

import httpx
from fastapi import Depends, Header, Request
from redis.asyncio import Redis
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker

from src.application.services.analytics_service import AnalyticsService
from src.application.services.api_key_service import ApiKeyService
from src.application.services.auth_service import AuthService
from src.application.services.customer_service import CustomerService
from src.application.services.invoice_service import InvoiceService
from src.application.services.merchant_service import MerchantOnboardingService
from src.application.services.plan_service import PlanService
from src.application.services.product_service import ProductService
from src.application.services.subscription_service import SubscriptionService
from src.application.services.team_service import TeamService
from src.application.services.tryon_generation_service import TryOnGenerationService
from src.application.services.usage_service import UsageService
from src.application.services.webhook_service import WebhookService
from src.application.services.widget_settings_service import WidgetSettingsService
from src.config.settings import Settings, get_settings
from src.domain.entities.api_key import ApiKey
from src.domain.entities.user import User
from src.domain.exceptions.base import (
    ApiKeyInvalidError,
    InsufficientPermissionError,
    InvalidTokenError,
    RateLimitExceededError,
)
from src.domain.repositories.payment_gateway import PaymentGateway
from src.domain.repositories.rate_limiter import RateLimiter
from src.domain.repositories.storage import SignedUrlProvider
from src.domain.value_objects.identifiers import MerchantId
from src.infrastructure.billing.stripe_gateway import StripeGateway
from src.infrastructure.cache.redis_client import create_redis_client
from src.infrastructure.cache.redis_rate_limiter import RedisRateLimiter
from src.infrastructure.db.repositories.ai_request_repository import SqlAlchemyAIRequestRepository
from src.infrastructure.db.repositories.analytics_event_repository import (
    SqlAlchemyAnalyticsEventRepository,
)
from src.infrastructure.db.repositories.api_key_repository import SqlAlchemyApiKeyRepository
from src.infrastructure.db.repositories.audit_log_repository import SqlAlchemyAuditLogRepository
from src.infrastructure.db.repositories.credit_note_repository import SqlAlchemyCreditNoteRepository
from src.infrastructure.db.repositories.invoice_repository import SqlAlchemyInvoiceRepository
from src.infrastructure.db.repositories.merchant_repository import SqlAlchemyMerchantRepository
from src.infrastructure.db.repositories.plan_repository import SqlAlchemyPlanRepository
from src.infrastructure.db.repositories.product_repository import SqlAlchemyProductRepository
from src.infrastructure.db.repositories.role_repository import SqlAlchemyRoleRepository
from src.infrastructure.db.repositories.subscription_repository import (
    SqlAlchemySubscriptionRepository,
)
from src.infrastructure.db.repositories.team_membership_repository import (
    SqlAlchemyTeamMembershipRepository,
)
from src.infrastructure.db.repositories.tryon_repository import SqlAlchemyTryOnRepository
from src.infrastructure.db.repositories.tryon_session_repository import (
    SqlAlchemyTryOnSessionRepository,
)
from src.infrastructure.db.repositories.usage_record_repository import (
    SqlAlchemyUsageRecordRepository,
)
from src.infrastructure.db.repositories.user_repository import SqlAlchemyUserRepository
from src.infrastructure.db.repositories.webhook_event_repository import (
    SqlAlchemyWebhookEventRepository,
)
from src.infrastructure.db.repositories.widget_settings_repository import (
    SqlAlchemyWidgetSettingsRepository,
)
from src.infrastructure.db.session import create_engine, create_session_factory
from src.infrastructure.security.clerk_jwt import ClerkJWTVerifier
from src.infrastructure.security.jwks_http_fetcher import make_http_jwks_fetcher
from src.infrastructure.storage.s3_signed_url_provider import S3SignedUrlProvider


@lru_cache
def get_engine() -> AsyncEngine:
    return create_engine(get_settings())


@lru_cache
def get_session_factory() -> async_sessionmaker[AsyncSession]:
    return create_session_factory(get_engine())


async def get_db_session(
    session_factory: async_sessionmaker[AsyncSession] = Depends(get_session_factory),
) -> AsyncGenerator[AsyncSession, None]:
    """Per-request session; commits on success, rolls back on unhandled error."""
    async with session_factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


def get_merchant_service(
    session: AsyncSession = Depends(get_db_session),
) -> MerchantOnboardingService:
    return MerchantOnboardingService(
        merchant_repository=SqlAlchemyMerchantRepository(session),
        widget_settings_repository=SqlAlchemyWidgetSettingsRepository(session),
    )


def get_widget_settings_service(
    session: AsyncSession = Depends(get_db_session),
) -> WidgetSettingsService:
    return WidgetSettingsService(SqlAlchemyWidgetSettingsRepository(session))


def get_api_key_service(
    session: AsyncSession = Depends(get_db_session),
    settings: Settings = Depends(get_settings),
) -> ApiKeyService:
    return ApiKeyService(
        api_key_repository=SqlAlchemyApiKeyRepository(session),
        merchant_repository=SqlAlchemyMerchantRepository(session),
        pepper=settings.api_key_pepper,
    )


async def require_api_key(
    x_api_key: str | None = Header(default=None, alias="X-API-Key"),
    api_key_service: ApiKeyService = Depends(get_api_key_service),
) -> ApiKey:
    """
    Authenticates widget/server-to-server calls via the X-API-Key header.
    Used by public widget endpoints instead of the Clerk-issued JWT used by
    the merchant/admin dashboards (see `require_dashboard_user`, Phase 2).
    """
    if not x_api_key:
        raise ApiKeyInvalidError()
    return await api_key_service.authenticate(x_api_key)


async def require_active_merchant(api_key: ApiKey = Depends(require_api_key)) -> ApiKey:
    """Layered on top of require_api_key for endpoints that must reject suspended tenants."""
    # Deliberately re-fetches nothing extra here: ApiKeyService.authenticate already
    # loaded/verified the key; merchant status is checked at the use-case level
    # where the operation (e.g. AI generation) actually happens, to avoid an
    # extra query on every single authenticated request regardless of cost.
    return api_key


# ---------------------------------------------------------------------------
# Phase 2: Clerk auth, RBAC, and rate limiting
# ---------------------------------------------------------------------------


@lru_cache
def get_redis_client() -> Redis:
    return create_redis_client(get_settings())


@lru_cache
def get_http_client() -> httpx.AsyncClient:
    return httpx.AsyncClient()


@lru_cache
def get_jwt_verifier() -> ClerkJWTVerifier:
    settings = get_settings()
    fetcher = make_http_jwks_fetcher(settings.clerk_jwks_url, get_http_client())
    return ClerkJWTVerifier(jwks_fetcher=fetcher)


@lru_cache
def get_rate_limiter() -> RateLimiter:
    return RedisRateLimiter(get_redis_client())


def get_auth_service(
    session: AsyncSession = Depends(get_db_session),
    jwt_verifier: ClerkJWTVerifier = Depends(get_jwt_verifier),
) -> AuthService:
    return AuthService(
        jwt_verifier=jwt_verifier,
        user_repository=SqlAlchemyUserRepository(session),
        role_repository=SqlAlchemyRoleRepository(session),
        team_membership_repository=SqlAlchemyTeamMembershipRepository(session),
    )


def get_team_service(session: AsyncSession = Depends(get_db_session)) -> TeamService:
    return TeamService(
        team_membership_repository=SqlAlchemyTeamMembershipRepository(session),
        user_repository=SqlAlchemyUserRepository(session),
        role_repository=SqlAlchemyRoleRepository(session),
        merchant_repository=SqlAlchemyMerchantRepository(session),
    )


async def require_dashboard_user(
    authorization: str | None = Header(default=None),
    auth_service: AuthService = Depends(get_auth_service),
) -> User:
    """
    Authenticates a merchant/admin dashboard request via a Clerk-issued
    session JWT in the `Authorization: Bearer <token>` header. This is a
    distinct trust boundary from `require_api_key`: dashboard endpoints
    represent a logged-in human acting on their own team's data, whereas
    the API-key path represents an anonymous storefront visitor's browser
    talking to the widget config endpoint.
    """
    if not authorization or not authorization.lower().startswith("bearer "):
        raise InvalidTokenError("Missing 'Authorization: Bearer <token>' header.")
    token = authorization.split(" ", 1)[1].strip()
    if not token:
        raise InvalidTokenError("Bearer token is empty.")
    return await auth_service.authenticate(token)


async def require_platform_admin(user: User = Depends(require_dashboard_user)) -> User:
    """
    Restricts an endpoint to platform (Anthropic/internal) admins — distinct
    from a merchant's own `owner`/`admin` team roles, which only govern
    access within that one merchant's tenant.
    """
    if not user.is_platform_admin:
        raise InsufficientPermissionError("platform:admin")
    return user


async def require_merchant_member(
    merchant_id: str,
    user: User = Depends(require_dashboard_user),
    auth_service: AuthService = Depends(get_auth_service),
) -> User:
    """
    Verifies the caller belongs to the merchant in the path, without
    requiring any specific permission code.

    Used for reads that every team member legitimately needs regardless of
    role (e.g. their own merchant's name/status). A platform admin is also
    allowed through, since admin tooling reads arbitrary merchants and
    admins are not members of every tenant's team.

    Deliberately distinct from `require_merchant_permission`: inventing a
    "merchant:view" permission would have required a migration to backfill
    it onto every already-seeded role, for no security gain over a plain
    membership check.
    """
    if user.is_platform_admin:
        return user
    await auth_service.get_membership(MerchantId.from_string(merchant_id), user.id)
    return user


def require_merchant_permission(permission_code: str):
    """
    Dependency factory: returns a dependency that verifies the current
    dashboard user is a member of the merchant in the path with a role that
    grants `permission_code`, e.g.:

        @router.put(..., dependencies=[Depends(require_merchant_permission("widget:edit"))])
    """

    async def _check(
        merchant_id: str,
        user: User = Depends(require_dashboard_user),
        auth_service: AuthService = Depends(get_auth_service),
    ) -> User:
        await auth_service.require_permission(
            MerchantId.from_string(merchant_id), user.id, permission_code
        )
        return user

    return _check


def rate_limit(scope: str, limit: int, window_seconds: int = 60):
    """
    Dependency factory enforcing a rate limit scoped by client identity.
    Identity is the caller's API key prefix when present (widget/server
    traffic), falling back to client IP (dashboard/browser traffic) — never
    a shared bucket across all callers, which would let one abusive
    merchant degrade service for everyone else.

    Usage: `dependencies=[Depends(rate_limit("widget_config", limit=120))]`
    on the route, using the appropriate limit from Settings for that route's
    traffic profile (see `rate_limit_default_per_minute` vs
    `rate_limit_ai_generation_per_minute`).
    """

    async def _enforce(
        request: Request,
        limiter: RateLimiter = Depends(get_rate_limiter),
    ) -> None:
        api_key_header = request.headers.get("X-API-Key")
        identity = (
            api_key_header[:24]
            if api_key_header
            else (request.client.host if request.client else "unknown")
        )
        key = f"{scope}:{identity}"

        result = await limiter.check(key, limit=limit, window_seconds=window_seconds)
        if not result.allowed:
            raise RateLimitExceededError(
                limit=result.limit,
                window_seconds=window_seconds,
                retry_after_seconds=result.retry_after_seconds,
            )

    return _enforce


# ---------------------------------------------------------------------------
# Phase 4: AI provider pipeline (storage + try-on generation)
# ---------------------------------------------------------------------------


@lru_cache
def get_storage_provider() -> SignedUrlProvider:
    settings = get_settings()
    return S3SignedUrlProvider(
        bucket_name=settings.storage_bucket_name,
        endpoint_url=settings.storage_endpoint_url,
        access_key_id=settings.storage_access_key_id,
        secret_access_key=settings.storage_secret_access_key,
        default_upload_ttl_seconds=settings.storage_signed_url_ttl_seconds,
    )


def _enqueue_generation(ai_request_id: str) -> None:
    """
    Dispatches by task NAME rather than importing the task function
    directly — this keeps the FastAPI process from needing to import the
    worker's provider adapters/httpx clients just to enqueue a job, and is
    the standard Celery producer-side pattern for a decoupled API/worker
    deployment.
    """
    from src.worker.celery_app import celery_app

    celery_app.send_task(
        "src.worker.tasks.generate_tryon_task.generate_tryon",
        args=[ai_request_id],
        queue="tryon_generation",
    )


def get_tryon_generation_service(
    session: AsyncSession = Depends(get_db_session),
) -> TryOnGenerationService:
    return TryOnGenerationService(
        session_repository=SqlAlchemyTryOnSessionRepository(session),
        tryon_repository=SqlAlchemyTryOnRepository(session),
        ai_request_repository=SqlAlchemyAIRequestRepository(session),
        enqueue_generation=_enqueue_generation,
        product_repository=SqlAlchemyProductRepository(session),
    )


def get_product_service(session: AsyncSession = Depends(get_db_session)) -> ProductService:
    return ProductService(SqlAlchemyProductRepository(session))


def get_analytics_service(session: AsyncSession = Depends(get_db_session)) -> AnalyticsService:
    return AnalyticsService(SqlAlchemyAnalyticsEventRepository(session))


# ---------------------------------------------------------------------------
# Phase 6: Stripe billing
# ---------------------------------------------------------------------------


@lru_cache
def get_payment_gateway() -> PaymentGateway:
    settings = get_settings()
    return StripeGateway(settings.stripe_secret_key, settings.stripe_webhook_secret)


def get_plan_service(session: AsyncSession = Depends(get_db_session)) -> PlanService:
    return PlanService(SqlAlchemyPlanRepository(session))


def get_customer_service(
    session: AsyncSession = Depends(get_db_session),
    gateway: PaymentGateway = Depends(get_payment_gateway),
) -> CustomerService:
    return CustomerService(SqlAlchemyMerchantRepository(session), gateway)


def get_subscription_service(
    session: AsyncSession = Depends(get_db_session),
    gateway: PaymentGateway = Depends(get_payment_gateway),
    customer_service: CustomerService = Depends(get_customer_service),
) -> SubscriptionService:
    return SubscriptionService(
        subscription_repository=SqlAlchemySubscriptionRepository(session),
        plan_repository=SqlAlchemyPlanRepository(session),
        merchant_repository=SqlAlchemyMerchantRepository(session),
        audit_log_repository=SqlAlchemyAuditLogRepository(session),
        customer_service=customer_service,
        gateway=gateway,
    )


def get_usage_service(session: AsyncSession = Depends(get_db_session)) -> UsageService:
    return UsageService(
        usage_repository=SqlAlchemyUsageRecordRepository(session),
        subscription_repository=SqlAlchemySubscriptionRepository(session),
        plan_repository=SqlAlchemyPlanRepository(session),
    )


def get_invoice_service(
    session: AsyncSession = Depends(get_db_session),
    gateway: PaymentGateway = Depends(get_payment_gateway),
) -> InvoiceService:
    return InvoiceService(
        invoice_repository=SqlAlchemyInvoiceRepository(session),
        credit_note_repository=SqlAlchemyCreditNoteRepository(session),
        audit_log_repository=SqlAlchemyAuditLogRepository(session),
        gateway=gateway,
    )


def get_webhook_service(
    session: AsyncSession = Depends(get_db_session),
    gateway: PaymentGateway = Depends(get_payment_gateway),
) -> WebhookService:
    return WebhookService(
        webhook_event_repository=SqlAlchemyWebhookEventRepository(session),
        subscription_repository=SqlAlchemySubscriptionRepository(session),
        invoice_repository=SqlAlchemyInvoiceRepository(session),
        audit_log_repository=SqlAlchemyAuditLogRepository(session),
        gateway=gateway,
    )
