from __future__ import annotations

from fastapi import APIRouter, Depends, status

from src.application.services.merchant_service import MerchantOnboardingService
from src.domain.entities.user import User
from src.domain.value_objects.identifiers import MerchantId
from src.interfaces.api.dependencies import (
    get_merchant_service,
    rate_limit,
    require_merchant_member,
    require_platform_admin,
)
from src.interfaces.api.v1.schemas.merchant import (
    ChangeMerchantTierRequest,
    MerchantResponse,
    RegisterMerchantRequest,
    SuspendMerchantRequest,
)

router = APIRouter(prefix="/merchants", tags=["merchants"])


@router.post(
    "",
    response_model=MerchantResponse,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(rate_limit("merchant_registration", limit=10, window_seconds=3600))],
)
async def register_merchant(
    payload: RegisterMerchantRequest,
    service: MerchantOnboardingService = Depends(get_merchant_service),
) -> MerchantResponse:
    """
    Registers a new merchant tenant and provisions default widget settings
    in the same transaction. The merchant starts in `pending` status; use
    the (Phase-2, admin-only) activation endpoint or automated domain
    verification to move it to `active`.
    """
    merchant = await service.register_merchant(
        name=payload.name, domain=payload.domain, contact_email=payload.contact_email
    )
    return MerchantResponse.from_entity(merchant)


@router.get("", response_model=list[MerchantResponse])
async def list_merchants(
    limit: int = 50,
    offset: int = 0,
    service: MerchantOnboardingService = Depends(get_merchant_service),
    _admin: User = Depends(require_platform_admin),
) -> list[MerchantResponse]:
    """Platform-admin only: every tenant on the platform, for the admin dashboard."""
    merchants = await service.list_merchants(limit=limit, offset=offset)
    return [MerchantResponse.from_entity(m) for m in merchants]


@router.get("/{merchant_id}", response_model=MerchantResponse)
async def get_merchant(
    merchant_id: str,
    service: MerchantOnboardingService = Depends(get_merchant_service),
    _member: User = Depends(require_merchant_member),
) -> MerchantResponse:
    """Readable by any member of this merchant's team, or by a platform admin."""
    merchant = await service.get_merchant(MerchantId.from_string(merchant_id))
    return MerchantResponse.from_entity(merchant)


@router.post("/{merchant_id}/suspend", response_model=MerchantResponse)
async def suspend_merchant(
    merchant_id: str,
    payload: SuspendMerchantRequest,
    service: MerchantOnboardingService = Depends(get_merchant_service),
    _admin: User = Depends(require_platform_admin),
) -> MerchantResponse:
    """Platform-admin only: suspends any merchant tenant (billing failure, ToS violation, etc.)."""
    merchant = await service.suspend_merchant(MerchantId.from_string(merchant_id), payload.reason)
    return MerchantResponse.from_entity(merchant)


@router.post("/{merchant_id}/activate", response_model=MerchantResponse)
async def activate_merchant(
    merchant_id: str,
    service: MerchantOnboardingService = Depends(get_merchant_service),
    _admin: User = Depends(require_platform_admin),
) -> MerchantResponse:
    """Platform-admin only."""
    merchant = await service.activate_merchant(MerchantId.from_string(merchant_id))
    return MerchantResponse.from_entity(merchant)


@router.post("/{merchant_id}/tier", response_model=MerchantResponse)
async def change_merchant_tier(
    merchant_id: str,
    payload: ChangeMerchantTierRequest,
    service: MerchantOnboardingService = Depends(get_merchant_service),
    _admin: User = Depends(require_platform_admin),
) -> MerchantResponse:
    """Platform-admin only. Tier changes normally flow from Stripe webhooks; this overrides."""
    merchant = await service.change_tier(MerchantId.from_string(merchant_id), payload.tier)
    return MerchantResponse.from_entity(merchant)
