from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field

from src.application.services.api_key_service import IssuedApiKey
from src.domain.entities.api_key import ApiKey, ApiKeyStatus
from src.domain.value_objects.api_key import ApiKeyEnvironment


class IssueApiKeyRequest(BaseModel):
    label: str = Field(..., min_length=1, max_length=255, examples=["Production widget key"])
    environment: ApiKeyEnvironment = ApiKeyEnvironment.LIVE


class ApiKeyResponse(BaseModel):
    id: UUID
    label: str
    environment: ApiKeyEnvironment
    key_prefix: str
    status: ApiKeyStatus
    last_used_at: datetime | None
    created_at: datetime
    revoked_at: datetime | None

    @staticmethod
    def from_entity(api_key: ApiKey) -> ApiKeyResponse:
        return ApiKeyResponse(
            id=api_key.id.value,
            label=api_key.label,
            environment=api_key.environment,
            key_prefix=api_key.key_hash.prefix,
            status=api_key.status,
            last_used_at=api_key.last_used_at,
            created_at=api_key.created_at,
            revoked_at=api_key.revoked_at,
        )


class IssuedApiKeyResponse(ApiKeyResponse):
    # `plaintext_key` is present ONLY in this one response, exactly once,
    # at issuance time. It is never returned by any GET/list endpoint.
    plaintext_key: str = Field(
        ..., description="Full secret key. Store it now — it will never be shown again."
    )

    @staticmethod
    def from_issued(issued: IssuedApiKey) -> IssuedApiKeyResponse:
        base = ApiKeyResponse.from_entity(issued.api_key)
        return IssuedApiKeyResponse(**base.model_dump(), plaintext_key=issued.plaintext)
