from __future__ import annotations

from datetime import UTC, date, datetime

from fastapi import APIRouter, Depends, Query, status

from src.application.services.customer_service import CustomerService
from src.application.services.invoice_service import InvoiceService
from src.application.services.plan_service import PlanService
from src.application.services.subscription_service import SubscriptionService
from src.application.services.usage_service import UsageService
from src.domain.value_objects.identifiers import InvoiceId, MerchantId
from src.interfaces.api.dependencies import (
    get_customer_service,
    get_invoice_service,
    get_plan_service,
    get_subscription_service,
    get_usage_service,
    rate_limit,
    require_merchant_permission,
    require_platform_admin,
)
from src.interfaces.api.v1.schemas.billing import (
    CancelSubscriptionRequest,
    ChangePlanRequest,
    CreatePlanRequest,
    CreditNoteResponse,
    InvoiceResponse,
    IssueCreditNoteRequest,
    IssueRefundRequest,
    PlanResponse,
    SubscribeRequest,
    SubscriptionResponse,
    UsageSummaryResponse,
)

router = APIRouter(
    prefix="/billing", tags=["billing"], dependencies=[Depends(rate_limit("billing", limit=60))]
)


# --- Plan catalog ---


@router.get("/plans", response_model=list[PlanResponse])
async def list_plans(service: PlanService = Depends(get_plan_service)) -> list[PlanResponse]:
    """Public plan catalog — used by pricing pages; no merchant-specific or sensitive data."""
    plans = await service.list_active_plans()
    return [PlanResponse.from_entity(p) for p in plans]


@router.post(
    "/plans",
    response_model=PlanResponse,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(require_platform_admin)],
)
async def create_plan(
    payload: CreatePlanRequest, service: PlanService = Depends(get_plan_service)
) -> PlanResponse:
    """Platform-admin only. Create the Stripe Product/Price first — see docs/stripe-setup.md."""
    plan = await service.create_plan(
        payload.tier,
        payload.name,
        monthly_price_usd=payload.monthly_price_usd,
        monthly_stripe_price_id=payload.monthly_stripe_price_id,
        included_generations=payload.included_generations,
        overage_price_usd=payload.overage_price_usd,
        yearly_price_usd=payload.yearly_price_usd,
        yearly_stripe_price_id=payload.yearly_stripe_price_id,
    )
    return PlanResponse.from_entity(plan)


# --- Customer sync ---


@router.post(
    "/merchants/{merchant_id}/customer",
    response_model=dict,
    dependencies=[Depends(require_merchant_permission("billing:edit"))],
)
async def ensure_customer(
    merchant_id: str, service: CustomerService = Depends(get_customer_service)
) -> dict:
    """Idempotent: creates the Stripe Customer on first call, no-ops thereafter."""
    merchant = await service.ensure_stripe_customer(MerchantId.from_string(merchant_id))
    return {"stripe_customer_id": merchant.stripe_customer_id}


# --- Subscription lifecycle ---


@router.post(
    "/merchants/{merchant_id}/subscribe",
    response_model=SubscriptionResponse,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(require_merchant_permission("billing:edit"))],
)
async def subscribe(
    merchant_id: str,
    payload: SubscribeRequest,
    service: SubscriptionService = Depends(get_subscription_service),
) -> SubscriptionResponse:
    subscription = await service.subscribe(
        MerchantId.from_string(merchant_id),
        payload.tier,
        payload.interval,
        trial_days=payload.trial_days,
    )
    return SubscriptionResponse.from_entity(subscription)


@router.get(
    "/merchants/{merchant_id}/subscription",
    response_model=SubscriptionResponse,
    dependencies=[Depends(require_merchant_permission("billing:view"))],
)
async def get_subscription(
    merchant_id: str, service: SubscriptionService = Depends(get_subscription_service)
) -> SubscriptionResponse:
    subscription = await service.get_for_merchant(MerchantId.from_string(merchant_id))
    return SubscriptionResponse.from_entity(subscription)


@router.put(
    "/merchants/{merchant_id}/subscription",
    response_model=SubscriptionResponse,
    dependencies=[Depends(require_merchant_permission("billing:edit"))],
)
async def change_plan(
    merchant_id: str,
    payload: ChangePlanRequest,
    service: SubscriptionService = Depends(get_subscription_service),
) -> SubscriptionResponse:
    """Upgrade or downgrade — Stripe computes proration automatically."""
    subscription = await service.change_plan(
        MerchantId.from_string(merchant_id), payload.tier, payload.interval
    )
    return SubscriptionResponse.from_entity(subscription)


@router.post(
    "/merchants/{merchant_id}/subscription/cancel",
    response_model=SubscriptionResponse,
    dependencies=[Depends(require_merchant_permission("billing:edit"))],
)
async def cancel_subscription(
    merchant_id: str,
    payload: CancelSubscriptionRequest,
    service: SubscriptionService = Depends(get_subscription_service),
) -> SubscriptionResponse:
    subscription = await service.cancel(
        MerchantId.from_string(merchant_id), at_period_end=payload.at_period_end
    )
    return SubscriptionResponse.from_entity(subscription)


@router.post(
    "/merchants/{merchant_id}/subscription/reactivate",
    response_model=SubscriptionResponse,
    dependencies=[Depends(require_merchant_permission("billing:edit"))],
)
async def reactivate_subscription(
    merchant_id: str, service: SubscriptionService = Depends(get_subscription_service)
) -> SubscriptionResponse:
    subscription = await service.reactivate(MerchantId.from_string(merchant_id))
    return SubscriptionResponse.from_entity(subscription)


# --- Invoices ---


@router.get(
    "/merchants/{merchant_id}/invoices",
    response_model=list[InvoiceResponse],
    dependencies=[Depends(require_merchant_permission("billing:view"))],
)
async def list_invoices(
    merchant_id: str,
    limit: int = 50,
    offset: int = 0,
    service: InvoiceService = Depends(get_invoice_service),
) -> list[InvoiceResponse]:
    invoices = await service.list_invoices(
        MerchantId.from_string(merchant_id), limit=limit, offset=offset
    )
    return [InvoiceResponse.from_entity(i) for i in invoices]


@router.get(
    "/merchants/{merchant_id}/invoices/{invoice_id}",
    response_model=InvoiceResponse,
    dependencies=[Depends(require_merchant_permission("billing:view"))],
)
async def get_invoice(
    merchant_id: str, invoice_id: str, service: InvoiceService = Depends(get_invoice_service)
) -> InvoiceResponse:
    invoice = await service.get_invoice(
        MerchantId.from_string(merchant_id), InvoiceId.from_string(invoice_id)
    )
    return InvoiceResponse.from_entity(invoice)


@router.post(
    "/merchants/{merchant_id}/invoices/{invoice_id}/refund",
    response_model=dict,
    dependencies=[Depends(require_merchant_permission("billing:edit"))],
)
async def issue_refund(
    merchant_id: str,
    invoice_id: str,
    payload: IssueRefundRequest,
    service: InvoiceService = Depends(get_invoice_service),
) -> dict:
    refund = await service.issue_refund(
        MerchantId.from_string(merchant_id),
        InvoiceId.from_string(invoice_id),
        payload.stripe_charge_id,
        amount_usd=payload.amount_usd,
        reason=payload.reason,
    )
    return {
        "stripe_refund_id": refund.stripe_refund_id,
        "amount_usd": refund.amount_usd,
        "status": refund.status,
    }


@router.post(
    "/merchants/{merchant_id}/invoices/{invoice_id}/credit-note",
    response_model=CreditNoteResponse,
    dependencies=[Depends(require_merchant_permission("billing:edit"))],
)
async def issue_credit_note(
    merchant_id: str,
    invoice_id: str,
    payload: IssueCreditNoteRequest,
    service: InvoiceService = Depends(get_invoice_service),
) -> CreditNoteResponse:
    credit_note = await service.issue_credit_note(
        MerchantId.from_string(merchant_id),
        InvoiceId.from_string(invoice_id),
        payload.amount_usd,
        payload.reason,
    )
    return CreditNoteResponse(
        stripe_credit_note_id=credit_note.stripe_credit_note_id, amount_usd=credit_note.amount_usd
    )


# --- Usage ---


@router.get(
    "/merchants/{merchant_id}/usage",
    response_model=UsageSummaryResponse,
    dependencies=[Depends(require_merchant_permission("billing:view"))],
)
async def get_usage_summary(
    merchant_id: str,
    period_start: date | None = Query(default=None),
    period_end: date | None = Query(default=None),
    service: UsageService = Depends(get_usage_service),
) -> UsageSummaryResponse:
    """Defaults to the current calendar month if no explicit range is given."""
    if period_start is None or period_end is None:
        today = datetime.now(UTC).date()
        period_start = period_start or today.replace(day=1)
        period_end = period_end or today

    summary = await service.get_usage_summary(
        MerchantId.from_string(merchant_id), period_start=period_start, period_end=period_end
    )
    return UsageSummaryResponse.from_summary(summary)
