from __future__ import annotations

from fastapi import APIRouter, Depends, Header, status

from src.application.services.tryon_generation_service import TryOnGenerationService
from src.config.settings import Settings, get_settings
from src.domain.entities.api_key import ApiKey
from src.domain.repositories.storage import SignedUrlProvider
from src.domain.value_objects.ai_provider import AIProviderName
from src.domain.value_objects.identifiers import ProductId, TryOnId
from src.interfaces.api.dependencies import (
    get_storage_provider,
    get_tryon_generation_service,
    rate_limit,
    require_api_key,
)
from src.interfaces.api.v1.schemas.tryon import (
    CreateUploadUrlRequest,
    CreateUploadUrlResponse,
    GenerateTryOnRequest,
    GenerateTryOnResponse,
    TryOnStatusResponse,
)

router = APIRouter(prefix="/tryon", tags=["tryon"])


@router.post(
    "/upload-url",
    response_model=CreateUploadUrlResponse,
    dependencies=[Depends(rate_limit("tryon_upload_url", limit=30))],
)
async def create_upload_url(
    payload: CreateUploadUrlRequest,
    api_key: ApiKey = Depends(require_api_key),
    storage: SignedUrlProvider = Depends(get_storage_provider),
) -> CreateUploadUrlResponse:
    """
    Returns a time-limited URL the customer's browser can PUT their photo to
    directly, so the image never transits our own API servers. The widget
    SDK calls this before `POST /tryon/generate`.
    """
    signed = storage.create_upload_url(
        merchant_id=str(api_key.merchant_id), content_type=payload.content_type
    )
    return CreateUploadUrlResponse(
        upload_url=signed.upload_url,
        object_key=signed.object_key,
        expires_in_seconds=signed.expires_in_seconds,
    )


@router.post(
    "/generate",
    response_model=GenerateTryOnResponse,
    status_code=status.HTTP_202_ACCEPTED,
    dependencies=[
        Depends(
            rate_limit("tryon_generate", limit=get_settings().rate_limit_ai_generation_per_minute)
        )
    ],
)
async def generate_tryon(
    payload: GenerateTryOnRequest,
    idempotency_key: str = Header(..., alias="Idempotency-Key"),
    api_key: ApiKey = Depends(require_api_key),
    service: TryOnGenerationService = Depends(get_tryon_generation_service),
    settings: Settings = Depends(get_settings),
) -> GenerateTryOnResponse:
    """
    Enqueues a try-on generation job and returns immediately (202 Accepted)
    — the actual AI provider call happens asynchronously in the Celery
    pipeline (see apps/api/src/worker). Poll `GET /tryon/{tryon_id}` for
    the result.

    Requires an `Idempotency-Key` header: retrying this request with the
    same key (e.g. after a client-side network timeout) returns the
    original request's result rather than creating a duplicate — and,
    critically, never triggers a second call to the (paid) AI provider.
    """
    provider = payload.provider or AIProviderName(settings.default_ai_provider)

    result = await service.request_generation(
        merchant_id=api_key.merchant_id,
        anonymous_visitor_id=payload.anonymous_visitor_id,
        customer_image_key=payload.customer_image_key,
        product_id=ProductId(payload.product_id) if payload.product_id else None,
        product_image_url=payload.product_image_url,
        provider=provider,
        idempotency_key=idempotency_key,
        country=payload.country,
        device_type=payload.device_type,
        browser=payload.browser,
    )
    return GenerateTryOnResponse.from_result(result)


@router.get("/{tryon_id}", response_model=TryOnStatusResponse)
async def get_tryon_status(
    tryon_id: str,
    api_key: ApiKey = Depends(require_api_key),
    service: TryOnGenerationService = Depends(get_tryon_generation_service),
    storage: SignedUrlProvider = Depends(get_storage_provider),
) -> TryOnStatusResponse:
    """Polled by the widget SDK's modal while a generation job is in progress."""
    view = await service.get_status(TryOnId.from_string(tryon_id), api_key.merchant_id)

    result_image_url = (
        storage.get_object_url(view.tryon.result_image_key) if view.tryon.result_image_key else None
    )
    return TryOnStatusResponse.from_view(view, result_image_url=result_image_url)


@router.post("/{tryon_id}/downloaded", response_model=TryOnStatusResponse)
async def mark_tryon_downloaded(
    tryon_id: str,
    api_key: ApiKey = Depends(require_api_key),
    service: TryOnGenerationService = Depends(get_tryon_generation_service),
    storage: SignedUrlProvider = Depends(get_storage_provider),
) -> TryOnStatusResponse:
    """Records the 'result_downloaded' analytics milestone (see Phase 5 analytics ingestion)."""
    await service.mark_downloaded(TryOnId.from_string(tryon_id), api_key.merchant_id)
    view = await service.get_status(TryOnId.from_string(tryon_id), api_key.merchant_id)
    result_image_url = (
        storage.get_object_url(view.tryon.result_image_key) if view.tryon.result_image_key else None
    )
    return TryOnStatusResponse.from_view(view, result_image_url=result_image_url)
