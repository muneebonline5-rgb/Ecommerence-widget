from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, EmailStr, Field

from src.domain.entities.merchant import Merchant, MerchantStatus, MerchantTier


class RegisterMerchantRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    domain: str = Field(..., min_length=3, max_length=255)
    contact_email: EmailStr


class MerchantResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    name: str
    domain: str
    contact_email: str
    status: MerchantStatus
    tier: MerchantTier
    suspended_reason: str | None
    created_at: datetime
    updated_at: datetime

    @staticmethod
    def from_entity(merchant: Merchant) -> MerchantResponse:
        return MerchantResponse(
            id=merchant.id.value,
            name=merchant.name,
            domain=merchant.domain,
            contact_email=merchant.contact_email,
            status=merchant.status,
            tier=merchant.tier,
            suspended_reason=merchant.suspended_reason,
            created_at=merchant.created_at,
            updated_at=merchant.updated_at,
        )


class SuspendMerchantRequest(BaseModel):
    reason: str = Field(..., min_length=1, max_length=500)


class ChangeMerchantTierRequest(BaseModel):
    tier: MerchantTier
