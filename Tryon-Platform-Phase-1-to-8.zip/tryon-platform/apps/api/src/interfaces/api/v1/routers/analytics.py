from __future__ import annotations

from datetime import UTC, datetime, timedelta

from fastapi import APIRouter, Depends, Query

from src.application.services.analytics_service import AnalyticsService
from src.domain.entities.api_key import ApiKey
from src.domain.value_objects.identifiers import MerchantId
from src.interfaces.api.dependencies import (
    get_analytics_service,
    rate_limit,
    require_api_key,
    require_merchant_permission,
)
from src.interfaces.api.v1.schemas.analytics import (
    AnalyticsSummaryResponse,
    IngestAnalyticsEventsRequest,
    IngestAnalyticsEventsResponse,
)

router = APIRouter(prefix="/analytics", tags=["analytics"])


@router.post(
    "/events",
    response_model=IngestAnalyticsEventsResponse,
    dependencies=[Depends(rate_limit("analytics_ingest", limit=120))],
)
async def ingest_events(
    payload: IngestAnalyticsEventsRequest,
    api_key: ApiKey = Depends(require_api_key),
    service: AnalyticsService = Depends(get_analytics_service),
) -> IngestAnalyticsEventsResponse:
    """
    Ingests a batch of widget analytics events (see EventTracker in
    apps/widget-sdk). Authenticated by API key, matching the widget's other
    public endpoints — the caller is an anonymous storefront visitor's
    browser, not a logged-in dashboard user. Malformed individual events are
    dropped rather than failing the whole batch (see AnalyticsService).
    """
    raw_events = [event.model_dump() for event in payload.events]
    accepted = await service.ingest_batch(api_key.merchant_id, raw_events)
    return IngestAnalyticsEventsResponse(accepted=accepted, received=len(payload.events))


@router.get(
    "/merchants/{merchant_id}/summary",
    response_model=AnalyticsSummaryResponse,
    dependencies=[Depends(require_merchant_permission("analytics:view"))],
)
async def get_analytics_summary(
    merchant_id: str,
    days: int = Query(default=7, ge=1, le=90),
    service: AnalyticsService = Depends(get_analytics_service),
) -> AnalyticsSummaryResponse:
    """Event-type counts for the trailing `days` days — the basic merchant-dashboard funnel view."""
    end = datetime.now(UTC)
    start = end - timedelta(days=days)
    counts = await service.get_event_counts(
        MerchantId.from_string(merchant_id), start=start, end=end
    )
    return AnalyticsSummaryResponse(start=start, end=end, counts_by_event_type=counts)
