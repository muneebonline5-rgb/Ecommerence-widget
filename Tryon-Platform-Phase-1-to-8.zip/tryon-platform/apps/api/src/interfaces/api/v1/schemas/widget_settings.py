from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field

from src.domain.entities.widget_settings import (
    WidgetButtonShape,
    WidgetPosition,
    WidgetSettings,
)


class ThemeSchema(BaseModel):
    primary_color: str = Field(default="#111827", pattern=r"^#(?:[0-9a-fA-F]{3}){1,2}$")
    accent_color: str = Field(default="#6366F1", pattern=r"^#(?:[0-9a-fA-F]{3}){1,2}$")
    text_color: str = Field(default="#FFFFFF", pattern=r"^#(?:[0-9a-fA-F]{3}){1,2}$")
    font_family: str = Field(default="Inter, system-ui, sans-serif", max_length=255)
    button_shape: WidgetButtonShape = WidgetButtonShape.CIRCLE
    border_radius_px: int = Field(default=16, ge=0, le=999)


class WidgetSettingsResponse(BaseModel):
    id: UUID
    merchant_id: UUID
    is_enabled: bool
    position: WidgetPosition
    theme: ThemeSchema
    button_label: str
    allowed_origins: list[str]
    sdk_version_pin: str | None
    updated_at: datetime

    @staticmethod
    def from_entity(settings: WidgetSettings) -> WidgetSettingsResponse:
        return WidgetSettingsResponse(
            id=settings.id.value,
            merchant_id=settings.merchant_id.value,
            is_enabled=settings.is_enabled,
            position=settings.position,
            theme=ThemeSchema(
                primary_color=settings.theme.primary_color,
                accent_color=settings.theme.accent_color,
                text_color=settings.theme.text_color,
                font_family=settings.theme.font_family,
                button_shape=settings.theme.button_shape,
                border_radius_px=settings.theme.border_radius_px,
            ),
            button_label=settings.button_label,
            allowed_origins=settings.allowed_origins,
            sdk_version_pin=settings.sdk_version_pin,
            updated_at=settings.updated_at,
        )


class UpdateThemeRequest(ThemeSchema):
    pass


class UpdatePositionRequest(BaseModel):
    position: WidgetPosition


class UpdateAllowedOriginsRequest(BaseModel):
    origins: list[str] = Field(default_factory=list)


class SetEnabledRequest(BaseModel):
    is_enabled: bool
