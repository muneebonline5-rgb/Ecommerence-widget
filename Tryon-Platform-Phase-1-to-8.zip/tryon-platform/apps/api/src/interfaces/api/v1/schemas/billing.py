from __future__ import annotations

from datetime import date, datetime
from uuid import UUID

from pydantic import BaseModel, Field

from src.application.services.usage_service import UsageSummary
from src.domain.entities.invoice import Invoice
from src.domain.entities.plan import Plan
from src.domain.entities.subscription import Subscription
from src.domain.value_objects.billing import (
    BillingInterval,
    InvoiceStatus,
    PlanTier,
    SubscriptionStatus,
)


class PlanResponse(BaseModel):
    id: UUID
    tier: PlanTier
    name: str
    monthly_price_usd: float
    yearly_price_usd: float | None
    included_generations: int
    overage_price_usd: float
    is_active: bool

    @staticmethod
    def from_entity(plan: Plan) -> PlanResponse:
        return PlanResponse(
            id=plan.id.value,
            tier=plan.tier,
            name=plan.name,
            monthly_price_usd=plan.monthly_price_usd,
            yearly_price_usd=plan.yearly_price_usd,
            included_generations=plan.included_generations,
            overage_price_usd=plan.overage_price_usd,
            is_active=plan.is_active,
        )


class CreatePlanRequest(BaseModel):
    tier: PlanTier
    name: str = Field(..., min_length=1, max_length=64)
    monthly_price_usd: float = Field(..., ge=0)
    monthly_stripe_price_id: str = Field(..., min_length=1)
    included_generations: int = Field(..., ge=0)
    overage_price_usd: float = Field(..., ge=0)
    yearly_price_usd: float | None = Field(default=None, ge=0)
    yearly_stripe_price_id: str | None = None


class SubscribeRequest(BaseModel):
    tier: PlanTier
    interval: BillingInterval = BillingInterval.MONTHLY
    trial_days: int | None = Field(default=None, ge=0, le=365)


class ChangePlanRequest(BaseModel):
    tier: PlanTier
    interval: BillingInterval | None = None


class CancelSubscriptionRequest(BaseModel):
    at_period_end: bool = True


class SubscriptionResponse(BaseModel):
    id: UUID
    merchant_id: UUID
    plan_id: UUID
    status: SubscriptionStatus
    billing_interval: BillingInterval
    current_period_start: datetime
    current_period_end: datetime
    cancel_at_period_end: bool
    trial_end: datetime | None

    @staticmethod
    def from_entity(subscription: Subscription) -> SubscriptionResponse:
        return SubscriptionResponse(
            id=subscription.id.value,
            merchant_id=subscription.merchant_id.value,
            plan_id=subscription.plan_id.value,
            status=subscription.status,
            billing_interval=subscription.billing_interval,
            current_period_start=subscription.current_period_start,
            current_period_end=subscription.current_period_end,
            cancel_at_period_end=subscription.cancel_at_period_end,
            trial_end=subscription.trial_end,
        )


class InvoiceResponse(BaseModel):
    id: UUID
    stripe_invoice_id: str
    status: InvoiceStatus
    amount_due_usd: float
    amount_paid_usd: float
    period_start: date
    period_end: date
    hosted_invoice_url: str | None

    @staticmethod
    def from_entity(invoice: Invoice) -> InvoiceResponse:
        return InvoiceResponse(
            id=invoice.id.value,
            stripe_invoice_id=invoice.stripe_invoice_id,
            status=invoice.status,
            amount_due_usd=invoice.amount_due_usd,
            amount_paid_usd=invoice.amount_paid_usd,
            period_start=invoice.period_start,
            period_end=invoice.period_end,
            hosted_invoice_url=invoice.hosted_invoice_url,
        )


class IssueRefundRequest(BaseModel):
    stripe_charge_id: str = Field(..., min_length=1)
    amount_usd: float | None = Field(default=None, gt=0)
    reason: str = Field(default="requested_by_customer", max_length=255)


class IssueCreditNoteRequest(BaseModel):
    amount_usd: float = Field(..., gt=0)
    reason: str = Field(..., min_length=1, max_length=255)


class CreditNoteResponse(BaseModel):
    stripe_credit_note_id: str
    amount_usd: float


class UsageSummaryResponse(BaseModel):
    period_start: date
    period_end: date
    included_generations: int
    used_generations: int
    overage_generations: int
    overage_cost_usd: float
    breakdown_by_provider: dict

    @staticmethod
    def from_summary(summary: UsageSummary) -> UsageSummaryResponse:
        return UsageSummaryResponse(
            period_start=summary.period_start,
            period_end=summary.period_end,
            included_generations=summary.included_generations,
            used_generations=summary.used_generations,
            overage_generations=summary.overage_generations,
            overage_cost_usd=summary.overage_cost_usd,
            breakdown_by_provider=summary.breakdown_by_provider,
        )
