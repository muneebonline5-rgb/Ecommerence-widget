from __future__ import annotations

from fastapi import APIRouter, Depends, status

from src.application.services.api_key_service import ApiKeyService
from src.domain.value_objects.identifiers import ApiKeyId, MerchantId
from src.interfaces.api.dependencies import (
    get_api_key_service,
    rate_limit,
    require_merchant_permission,
)
from src.interfaces.api.v1.schemas.api_key import (
    ApiKeyResponse,
    IssueApiKeyRequest,
    IssuedApiKeyResponse,
)

router = APIRouter(
    prefix="/merchants/{merchant_id}/api-keys",
    tags=["api-keys"],
    dependencies=[Depends(rate_limit("dashboard_api_keys", limit=30))],
)


@router.post(
    "",
    response_model=IssuedApiKeyResponse,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(require_merchant_permission("api_keys:manage"))],
)
async def issue_api_key(
    merchant_id: str,
    payload: IssueApiKeyRequest,
    service: ApiKeyService = Depends(get_api_key_service),
) -> IssuedApiKeyResponse:
    """
    Issues a new API key for the merchant. The plaintext secret is returned
    exactly once in this response and cannot be retrieved again — only its
    prefix and metadata are stored for later display.
    """
    issued = await service.issue_key(
        MerchantId.from_string(merchant_id), payload.label, payload.environment
    )
    return IssuedApiKeyResponse.from_issued(issued)


@router.get(
    "",
    response_model=list[ApiKeyResponse],
    dependencies=[Depends(require_merchant_permission("api_keys:view"))],
)
async def list_api_keys(
    merchant_id: str,
    service: ApiKeyService = Depends(get_api_key_service),
) -> list[ApiKeyResponse]:
    keys = await service.list_keys_for_merchant(MerchantId.from_string(merchant_id))
    return [ApiKeyResponse.from_entity(k) for k in keys]


@router.delete(
    "/{api_key_id}",
    response_model=ApiKeyResponse,
    dependencies=[Depends(require_merchant_permission("api_keys:manage"))],
)
async def revoke_api_key(
    merchant_id: str,
    api_key_id: str,
    service: ApiKeyService = Depends(get_api_key_service),
) -> ApiKeyResponse:
    revoked = await service.revoke_key(ApiKeyId.from_string(api_key_id))
    return ApiKeyResponse.from_entity(revoked)
