"""
Liveness and readiness probes.

The distinction matters for orchestrators (ECS/Kubernetes) and is a real
availability concern, not ceremony:

- `/healthz` (liveness) answers "is this process alive?" and must NOT check
  downstream dependencies. If it did, a brief database blip would make every
  replica fail liveness simultaneously and get killed and restarted — turning
  a recoverable dependency outage into a full outage.
- `/readyz` (readiness) answers "can this process serve traffic right now?"
  and DOES check Postgres and Redis. A failing replica is pulled from the
  load balancer but left running, so it rejoins automatically once the
  dependency recovers.
"""

from __future__ import annotations

import asyncio

import structlog
from fastapi import APIRouter, Depends, Response, status
from redis.asyncio import Redis
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from src.interfaces.api.dependencies import get_db_session, get_redis_client

logger = structlog.get_logger(__name__)

router = APIRouter(tags=["health"])

_DEPENDENCY_TIMEOUT_SECONDS = 3.0


@router.get("/healthz")
async def liveness() -> dict[str, str]:
    """Liveness: process is up. Deliberately checks nothing downstream."""
    return {"status": "ok"}


@router.get("/readyz")
async def readiness(
    response: Response,
    session: AsyncSession = Depends(get_db_session),
    redis: Redis = Depends(get_redis_client),
) -> dict[str, object]:
    """
    Readiness: verifies this replica can actually reach Postgres and Redis.

    Each check is individually timeout-bounded so a hung connection can't
    make the probe itself hang — an unbounded readiness check that never
    returns is indistinguishable from a crashed process to most
    orchestrators, and gets handled far more harshly.
    """
    checks: dict[str, str] = {}

    async def check_postgres() -> None:
        await session.execute(text("SELECT 1"))

    async def check_redis() -> None:
        await redis.ping()

    for name, probe in (("postgres", check_postgres), ("redis", check_redis)):
        try:
            await asyncio.wait_for(probe(), timeout=_DEPENDENCY_TIMEOUT_SECONDS)
            checks[name] = "ok"
        except TimeoutError:
            checks[name] = f"timeout after {_DEPENDENCY_TIMEOUT_SECONDS}s"
        except Exception as exc:  # noqa: BLE001 - probe must report, never raise
            checks[name] = f"error: {type(exc).__name__}"

    all_ok = all(v == "ok" for v in checks.values())
    if not all_ok:
        response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
        logger.warning("readiness.degraded", checks=checks)

    return {"status": "ready" if all_ok else "degraded", "checks": checks}
