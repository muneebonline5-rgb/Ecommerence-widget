from __future__ import annotations

from fastapi import APIRouter, Depends

from src.application.services.widget_settings_service import WidgetSettingsService
from src.config.settings import get_settings
from src.domain.entities.api_key import ApiKey
from src.domain.value_objects.identifiers import MerchantId
from src.interfaces.api.dependencies import (
    get_widget_settings_service,
    rate_limit,
    require_api_key,
    require_merchant_permission,
)
from src.interfaces.api.v1.schemas.widget_settings import (
    SetEnabledRequest,
    UpdateAllowedOriginsRequest,
    UpdatePositionRequest,
    UpdateThemeRequest,
    WidgetSettingsResponse,
)

router = APIRouter(tags=["widget-settings"])

# --- Dashboard-facing management endpoints (merchant_id in path) ---
dashboard_router = APIRouter(
    prefix="/merchants/{merchant_id}/widget-settings",
    tags=["widget-settings"],
    dependencies=[Depends(rate_limit("dashboard_widget_settings", limit=60))],
)


@dashboard_router.get(
    "",
    response_model=WidgetSettingsResponse,
    dependencies=[Depends(require_merchant_permission("widget:view"))],
)
async def get_widget_settings(
    merchant_id: str,
    service: WidgetSettingsService = Depends(get_widget_settings_service),
) -> WidgetSettingsResponse:
    settings = await service.get_for_merchant(MerchantId.from_string(merchant_id))
    return WidgetSettingsResponse.from_entity(settings)


@dashboard_router.put(
    "/theme",
    response_model=WidgetSettingsResponse,
    dependencies=[Depends(require_merchant_permission("widget:edit"))],
)
async def update_theme(
    merchant_id: str,
    payload: UpdateThemeRequest,
    service: WidgetSettingsService = Depends(get_widget_settings_service),
) -> WidgetSettingsResponse:
    settings = await service.update_theme(
        MerchantId.from_string(merchant_id),
        primary_color=payload.primary_color,
        accent_color=payload.accent_color,
        text_color=payload.text_color,
        font_family=payload.font_family,
        button_shape=payload.button_shape,
        border_radius_px=payload.border_radius_px,
    )
    return WidgetSettingsResponse.from_entity(settings)


@dashboard_router.put(
    "/position",
    response_model=WidgetSettingsResponse,
    dependencies=[Depends(require_merchant_permission("widget:edit"))],
)
async def update_position(
    merchant_id: str,
    payload: UpdatePositionRequest,
    service: WidgetSettingsService = Depends(get_widget_settings_service),
) -> WidgetSettingsResponse:
    settings = await service.update_position(MerchantId.from_string(merchant_id), payload.position)
    return WidgetSettingsResponse.from_entity(settings)


@dashboard_router.put(
    "/allowed-origins",
    response_model=WidgetSettingsResponse,
    dependencies=[Depends(require_merchant_permission("widget:edit"))],
)
async def update_allowed_origins(
    merchant_id: str,
    payload: UpdateAllowedOriginsRequest,
    service: WidgetSettingsService = Depends(get_widget_settings_service),
) -> WidgetSettingsResponse:
    settings = await service.set_allowed_origins(
        MerchantId.from_string(merchant_id), payload.origins
    )
    return WidgetSettingsResponse.from_entity(settings)


@dashboard_router.put(
    "/enabled",
    response_model=WidgetSettingsResponse,
    dependencies=[Depends(require_merchant_permission("widget:edit"))],
)
async def set_enabled(
    merchant_id: str,
    payload: SetEnabledRequest,
    service: WidgetSettingsService = Depends(get_widget_settings_service),
) -> WidgetSettingsResponse:
    settings = await service.set_enabled(MerchantId.from_string(merchant_id), payload.is_enabled)
    return WidgetSettingsResponse.from_entity(settings)


# --- Public, API-key-authenticated endpoint the widget SDK calls on init ---
@router.get(
    "/widget/config",
    response_model=WidgetSettingsResponse,
    dependencies=[
        Depends(
            rate_limit(
                "public_widget_config",
                limit=get_settings().rate_limit_default_per_minute,
            )
        )
    ],
)
async def get_public_widget_config(
    api_key: ApiKey = Depends(require_api_key),
    service: WidgetSettingsService = Depends(get_widget_settings_service),
) -> WidgetSettingsResponse:
    """
    Called by the embedded widget SDK on every page load (cached aggressively
    at the CDN edge — see docs/widget-sdk.md). Authenticated by API key
    rather than a dashboard session, since the caller is an anonymous
    storefront visitor's browser, not a logged-in merchant user. Rate
    limited per-API-key-prefix so one compromised or misbehaving widget
    embed can't degrade the endpoint for other merchants.
    """
    settings = await service.get_for_merchant(api_key.merchant_id)
    return WidgetSettingsResponse.from_entity(settings)
