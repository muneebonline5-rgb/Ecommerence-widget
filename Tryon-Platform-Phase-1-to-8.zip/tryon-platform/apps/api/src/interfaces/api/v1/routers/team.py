from __future__ import annotations

from fastapi import APIRouter, Depends, status

from src.application.services.team_service import TeamService
from src.domain.entities.user import User
from src.domain.value_objects.identifiers import MerchantId, RoleId, UserId
from src.interfaces.api.dependencies import (
    get_team_service,
    rate_limit,
    require_dashboard_user,
    require_merchant_permission,
)
from src.interfaces.api.v1.schemas.merchant import MerchantResponse
from src.interfaces.api.v1.schemas.team import (
    AddTeamMemberRequest,
    ChangeTeamMemberRoleRequest,
    CurrentUserResponse,
    TeamMembershipResponse,
)

router = APIRouter(
    tags=["team"], dependencies=[Depends(rate_limit("dashboard_default", limit=120))]
)

team_router = APIRouter(prefix="/merchants/{merchant_id}/team", tags=["team"])


@router.get("/auth/me", response_model=CurrentUserResponse)
async def get_current_user(user: User = Depends(require_dashboard_user)) -> CurrentUserResponse:
    """Resolves the caller's identity from their Clerk session token."""
    return CurrentUserResponse(
        id=user.id.value,
        email=user.email,
        full_name=user.full_name,
        is_platform_admin=user.is_platform_admin,
    )


@router.get("/auth/my-merchants", response_model=list[MerchantResponse])
async def list_my_merchants(
    user: User = Depends(require_dashboard_user),
    service: TeamService = Depends(get_team_service),
) -> list[MerchantResponse]:
    """
    Resolves which merchant(s) the signed-in user belongs to. Every other
    merchant-scoped endpoint requires already knowing the merchant_id — this
    is the one entry point that doesn't, so the dashboard has somewhere to
    start immediately after a fresh sign-in.
    """
    merchants = await service.list_merchants_for_user(user.id)
    return [MerchantResponse.from_entity(m) for m in merchants]


@team_router.get(
    "",
    response_model=list[TeamMembershipResponse],
    dependencies=[Depends(require_merchant_permission("team:view"))],
)
async def list_team_members(
    merchant_id: str,
    service: TeamService = Depends(get_team_service),
) -> list[TeamMembershipResponse]:
    members = await service.list_members(MerchantId.from_string(merchant_id))
    return [TeamMembershipResponse.from_entity(m) for m in members]


@team_router.post(
    "",
    response_model=TeamMembershipResponse,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(require_merchant_permission("team:manage"))],
)
async def add_team_member(
    merchant_id: str,
    payload: AddTeamMemberRequest,
    service: TeamService = Depends(get_team_service),
) -> TeamMembershipResponse:
    membership = await service.add_member(
        MerchantId.from_string(merchant_id),
        UserId(payload.user_id),
        RoleId(payload.role_id),
    )
    return TeamMembershipResponse.from_entity(membership)


@team_router.put(
    "/{user_id}/role",
    response_model=TeamMembershipResponse,
    dependencies=[Depends(require_merchant_permission("team:manage"))],
)
async def change_team_member_role(
    merchant_id: str,
    user_id: str,
    payload: ChangeTeamMemberRoleRequest,
    service: TeamService = Depends(get_team_service),
) -> TeamMembershipResponse:
    membership = await service.change_role(
        MerchantId.from_string(merchant_id),
        UserId.from_string(user_id),
        RoleId(payload.role_id),
    )
    return TeamMembershipResponse.from_entity(membership)


@team_router.delete(
    "/{user_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    response_model=None,
    dependencies=[Depends(require_merchant_permission("team:manage"))],
)
async def remove_team_member(
    merchant_id: str,
    user_id: str,
    service: TeamService = Depends(get_team_service),
) -> None:
    await service.remove_member(MerchantId.from_string(merchant_id), UserId.from_string(user_id))
