from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field

from src.domain.entities.product import Product


class CreateProductRequest(BaseModel):
    external_id: str = Field(..., min_length=1, max_length=255)
    title: str = Field(..., min_length=1, max_length=500)
    product_url: str = Field(..., min_length=1, max_length=2048)
    image_url: str = Field(..., min_length=1, max_length=2048)
    category: str | None = Field(default=None, max_length=128)
    is_try_on_eligible: bool = True
    metadata: dict = Field(default_factory=dict)


class UpdateProductRequest(BaseModel):
    title: str = Field(..., min_length=1, max_length=500)
    product_url: str = Field(..., min_length=1, max_length=2048)
    image_url: str = Field(..., min_length=1, max_length=2048)
    category: str | None = Field(default=None, max_length=128)
    metadata: dict | None = None


class SetTryOnEligibleRequest(BaseModel):
    is_try_on_eligible: bool


class ProductResponse(BaseModel):
    id: UUID
    merchant_id: UUID
    external_id: str
    title: str
    product_url: str
    image_url: str
    category: str | None
    is_try_on_eligible: bool
    metadata: dict
    created_at: datetime
    updated_at: datetime

    @staticmethod
    def from_entity(product: Product) -> ProductResponse:
        return ProductResponse(
            id=product.id.value,
            merchant_id=product.merchant_id.value,
            external_id=product.external_id,
            title=product.title,
            product_url=product.product_url,
            image_url=product.image_url,
            category=product.category,
            is_try_on_eligible=product.is_try_on_eligible,
            metadata=product.metadata,
            created_at=product.created_at,
            updated_at=product.updated_at,
        )
