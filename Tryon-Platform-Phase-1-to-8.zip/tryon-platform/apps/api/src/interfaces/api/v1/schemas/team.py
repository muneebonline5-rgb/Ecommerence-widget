from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel

from src.domain.entities.team_membership import TeamMembership


class AddTeamMemberRequest(BaseModel):
    user_id: UUID
    role_id: UUID


class ChangeTeamMemberRoleRequest(BaseModel):
    role_id: UUID


class TeamMembershipResponse(BaseModel):
    id: UUID
    merchant_id: UUID
    user_id: UUID
    role_id: UUID
    created_at: datetime
    updated_at: datetime

    @staticmethod
    def from_entity(membership: TeamMembership) -> TeamMembershipResponse:
        return TeamMembershipResponse(
            id=membership.id.value,
            merchant_id=membership.merchant_id.value,
            user_id=membership.user_id.value,
            role_id=membership.role_id.value,
            created_at=membership.created_at,
            updated_at=membership.updated_at,
        )


class CurrentUserResponse(BaseModel):
    id: UUID
    email: str
    full_name: str | None
    is_platform_admin: bool
