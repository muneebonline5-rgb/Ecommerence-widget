from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field

from src.application.services.tryon_generation_service import TryOnGenerationResult, TryOnStatusView
from src.domain.value_objects.ai_provider import AIProviderName, ProviderRequestStatus


class CreateUploadUrlRequest(BaseModel):
    content_type: str = Field(
        ..., pattern=r"^image/(png|jpe?g|webp)$", examples=["image/png", "image/jpeg"]
    )


class CreateUploadUrlResponse(BaseModel):
    upload_url: str
    object_key: str
    expires_in_seconds: int


class GenerateTryOnRequest(BaseModel):
    customer_image_key: str = Field(..., min_length=1, max_length=1024)
    product_id: UUID | None = Field(
        default=None,
        description="A catalog product's ID. Mutually exclusive with product_image_url.",
    )
    product_image_url: str | None = Field(
        default=None,
        min_length=1,
        max_length=2048,
        description="Direct product image URL, used when no catalog product_id is available.",
    )
    provider: AIProviderName | None = Field(
        default=None, description="Overrides the merchant's default provider for this request."
    )
    anonymous_visitor_id: str = Field(..., min_length=1, max_length=128)
    country: str | None = Field(default=None, min_length=2, max_length=2)
    device_type: str | None = Field(default=None, max_length=32)
    browser: str | None = Field(default=None, max_length=64)


class GenerateTryOnResponse(BaseModel):
    tryon_id: UUID
    ai_request_id: UUID
    status: ProviderRequestStatus
    was_deduplicated: bool

    @staticmethod
    def from_result(result: TryOnGenerationResult) -> GenerateTryOnResponse:
        return GenerateTryOnResponse(
            tryon_id=result.tryon.id.value,
            ai_request_id=result.ai_request.id.value,
            status=result.ai_request.status,
            was_deduplicated=result.was_deduplicated,
        )


class TryOnStatusResponse(BaseModel):
    tryon_id: UUID
    tryon_status: str
    provider_status: ProviderRequestStatus | None
    result_image_url: str | None
    error_message: str | None
    updated_at: datetime

    @staticmethod
    def from_view(view: TryOnStatusView, *, result_image_url: str | None) -> TryOnStatusResponse:
        return TryOnStatusResponse(
            tryon_id=view.tryon.id.value,
            tryon_status=view.tryon.status.value,
            provider_status=view.ai_request.status if view.ai_request else None,
            result_image_url=result_image_url,
            error_message=view.tryon.error_message,
            updated_at=view.tryon.updated_at,
        )
