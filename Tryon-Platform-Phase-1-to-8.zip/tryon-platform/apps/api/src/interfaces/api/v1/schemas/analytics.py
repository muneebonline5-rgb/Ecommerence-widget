from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field


class AnalyticsEventPayload(BaseModel):
    """
    Mirrors the widget SDK's WidgetEvent type exactly (see
    apps/widget-sdk/src/types.ts) — kept intentionally loose (raw dicts, not
    a strict enum) at the transport boundary since `AnalyticsService`
    validates and normalizes each event individually and best-effort-skips
    malformed ones rather than rejecting an entire batch over one bad entry.
    """

    type: str
    properties: dict = Field(default_factory=dict)
    timestamp: str | None = None


class IngestAnalyticsEventsRequest(BaseModel):
    events: list[AnalyticsEventPayload] = Field(..., min_length=1, max_length=100)


class IngestAnalyticsEventsResponse(BaseModel):
    accepted: int
    received: int


class AnalyticsSummaryResponse(BaseModel):
    start: datetime
    end: datetime
    counts_by_event_type: dict[str, int]
