from __future__ import annotations

from fastapi import APIRouter, Depends, status

from src.application.services.product_service import ProductService
from src.domain.value_objects.identifiers import MerchantId, ProductId
from src.interfaces.api.dependencies import (
    get_product_service,
    rate_limit,
    require_merchant_permission,
)
from src.interfaces.api.v1.schemas.product import (
    CreateProductRequest,
    ProductResponse,
    SetTryOnEligibleRequest,
    UpdateProductRequest,
)

router = APIRouter(
    prefix="/merchants/{merchant_id}/products",
    tags=["products"],
    dependencies=[Depends(rate_limit("dashboard_products", limit=120))],
)


@router.post(
    "",
    response_model=ProductResponse,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(require_merchant_permission("products:edit"))],
)
async def create_product(
    merchant_id: str,
    payload: CreateProductRequest,
    service: ProductService = Depends(get_product_service),
) -> ProductResponse:
    product = await service.create_product(
        MerchantId.from_string(merchant_id),
        external_id=payload.external_id,
        title=payload.title,
        product_url=payload.product_url,
        image_url=payload.image_url,
        category=payload.category,
        is_try_on_eligible=payload.is_try_on_eligible,
        metadata=payload.metadata,
    )
    return ProductResponse.from_entity(product)


@router.get(
    "",
    response_model=list[ProductResponse],
    dependencies=[Depends(require_merchant_permission("products:view"))],
)
async def list_products(
    merchant_id: str,
    limit: int = 50,
    offset: int = 0,
    service: ProductService = Depends(get_product_service),
) -> list[ProductResponse]:
    products = await service.list_products(
        MerchantId.from_string(merchant_id), limit=limit, offset=offset
    )
    return [ProductResponse.from_entity(p) for p in products]


@router.get(
    "/{product_id}",
    response_model=ProductResponse,
    dependencies=[Depends(require_merchant_permission("products:view"))],
)
async def get_product(
    merchant_id: str,
    product_id: str,
    service: ProductService = Depends(get_product_service),
) -> ProductResponse:
    product = await service.get_product(
        MerchantId.from_string(merchant_id), ProductId.from_string(product_id)
    )
    return ProductResponse.from_entity(product)


@router.put(
    "/{product_id}",
    response_model=ProductResponse,
    dependencies=[Depends(require_merchant_permission("products:edit"))],
)
async def update_product(
    merchant_id: str,
    product_id: str,
    payload: UpdateProductRequest,
    service: ProductService = Depends(get_product_service),
) -> ProductResponse:
    product = await service.update_product(
        MerchantId.from_string(merchant_id),
        ProductId.from_string(product_id),
        title=payload.title,
        product_url=payload.product_url,
        image_url=payload.image_url,
        category=payload.category,
        metadata=payload.metadata,
    )
    return ProductResponse.from_entity(product)


@router.put(
    "/{product_id}/try-on-eligible",
    response_model=ProductResponse,
    dependencies=[Depends(require_merchant_permission("products:edit"))],
)
async def set_try_on_eligible(
    merchant_id: str,
    product_id: str,
    payload: SetTryOnEligibleRequest,
    service: ProductService = Depends(get_product_service),
) -> ProductResponse:
    product = await service.set_try_on_eligible(
        MerchantId.from_string(merchant_id),
        ProductId.from_string(product_id),
        payload.is_try_on_eligible,
    )
    return ProductResponse.from_entity(product)


@router.delete(
    "/{product_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    response_model=None,
    dependencies=[Depends(require_merchant_permission("products:edit"))],
)
async def delete_product(
    merchant_id: str,
    product_id: str,
    service: ProductService = Depends(get_product_service),
) -> None:
    await service.delete_product(
        MerchantId.from_string(merchant_id), ProductId.from_string(product_id)
    )
