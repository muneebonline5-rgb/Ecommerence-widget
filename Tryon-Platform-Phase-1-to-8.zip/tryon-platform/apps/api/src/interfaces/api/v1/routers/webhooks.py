from __future__ import annotations

from fastapi import APIRouter, Depends, Header, Request

from src.application.services.webhook_service import WebhookService
from src.interfaces.api.dependencies import get_webhook_service
from src.interfaces.api.middleware.metrics import WEBHOOK_TOTAL

router = APIRouter(prefix="/webhooks", tags=["webhooks"])


@router.post("/stripe")
async def stripe_webhook(
    request: Request,
    stripe_signature: str = Header(..., alias="Stripe-Signature"),
    service: WebhookService = Depends(get_webhook_service),
) -> dict:
    """
    Receives Stripe webhook events. Deliberately has NO API-key or JWT
    dependency — Stripe cannot present either — trust comes entirely from
    HMAC signature verification against the raw request body (which is why
    this reads `request.body()` directly rather than a Pydantic model:
    signature verification requires the exact, unparsed bytes Stripe
    signed, not a re-serialized version of them).

    Idempotent and retry-safe: `WebhookService.handle` checks a persisted
    ledger of already-processed event IDs before running any side effect,
    so Stripe redelivering the same event (its documented at-least-once
    guarantee) is always safe.
    """
    raw_body = await request.body()
    result = await service.handle(raw_body, stripe_signature)

    # Recorded here, not inside WebhookService: metrics are an interfaces-layer
    # concern, and importing a Prometheus counter into the application layer
    # would reintroduce the Dependency Inversion violation the readiness
    # audit fixed. The service's return value is a sufficient seam.
    WEBHOOK_TOTAL.labels(request.headers.get("stripe-event-type", "unknown"), result).inc()
    return {"status": result}
