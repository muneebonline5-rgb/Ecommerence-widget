"""
Prometheus metrics.

The critical design decision here is using the route *template*
(`/api/v1/merchants/{merchant_id}`) as the label rather than the actual
path (`/api/v1/merchants/a1b2c3.../`). Labelling by raw path would create a
new time series per merchant ID — unbounded cardinality that reliably melts
a Prometheus server. Starlette exposes the matched route on the request
scope, which is what makes the safe version possible.
"""

from __future__ import annotations

import time
from collections.abc import Awaitable, Callable

from prometheus_client import CONTENT_TYPE_LATEST, Counter, Gauge, Histogram, generate_latest
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

REQUEST_COUNT = Counter(
    "tryon_http_requests_total",
    "Total HTTP requests.",
    ["method", "route", "status_code"],
)

REQUEST_LATENCY = Histogram(
    "tryon_http_request_duration_seconds",
    "HTTP request latency.",
    ["method", "route"],
    # Buckets tuned for this API's actual shape: most endpoints are simple
    # DB reads (sub-100ms), but the Stripe- and provider-backed ones make
    # outbound calls, so the tail extends to 10s.
    buckets=(0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0),
)

IN_FLIGHT = Gauge(
    "tryon_http_requests_in_flight",
    "HTTP requests currently being processed.",
)

# Business metrics — these are what an on-call engineer actually alerts on;
# HTTP 200s tell you the API is up, not that generations are succeeding.
# NOTE: generation counters are deliberately NOT defined here. Generations
# complete inside the Celery worker, a separate process — a Counter
# incremented there would never appear on this API process's /metrics
# scrape. Exporting worker metrics correctly needs either a Pushgateway or
# a per-worker exporter endpoint; see docs/observability.md. Defining a
# counter here that silently stays at zero would be worse than omitting it.

WEBHOOK_TOTAL = Counter(
    "tryon_stripe_webhooks_total",
    "Stripe webhooks by event type and outcome.",
    ["event_type", "outcome"],
)


def _route_template(request: Request) -> str:
    """
    Resolves the matched route's path template. Falls back to a constant
    rather than the raw path — an unmatched request (404 scan, bad probe)
    must never mint a new label value.
    """
    route = request.scope.get("route")
    path_format = getattr(route, "path_format", None) or getattr(route, "path", None)
    return path_format or "unmatched"


class MetricsMiddleware(BaseHTTPMiddleware):
    async def dispatch(
        self, request: Request, call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        if request.url.path == "/metrics":
            return await call_next(request)

        IN_FLIGHT.inc()
        started = time.perf_counter()
        status_code = 500
        try:
            response = await call_next(request)
            status_code = response.status_code
            return response
        finally:
            duration = time.perf_counter() - started
            IN_FLIGHT.dec()
            route = _route_template(request)
            REQUEST_COUNT.labels(request.method, route, str(status_code)).inc()
            REQUEST_LATENCY.labels(request.method, route).observe(duration)


def metrics_endpoint() -> Response:
    return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)
