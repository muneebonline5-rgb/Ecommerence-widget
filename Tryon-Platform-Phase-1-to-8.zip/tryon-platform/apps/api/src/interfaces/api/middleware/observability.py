"""
Request-scoped observability middleware.

Binds a request ID into structlog's contextvars so every log line emitted
while handling a request — including from deep inside application services
that know nothing about HTTP — carries the same correlation ID. The ID is
echoed back as `X-Request-ID`, so a user reporting an error can hand over a
value that finds every related log line.

An inbound `X-Request-ID` is honored rather than overwritten, which is what
lets a trace span a load balancer or an upstream gateway.
"""

from __future__ import annotations

import time
import uuid
from collections.abc import Awaitable, Callable

import structlog
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

logger = structlog.get_logger(__name__)

REQUEST_ID_HEADER = "X-Request-ID"


class RequestContextMiddleware(BaseHTTPMiddleware):
    async def dispatch(
        self, request: Request, call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        request_id = request.headers.get(REQUEST_ID_HEADER) or str(uuid.uuid4())

        structlog.contextvars.clear_contextvars()
        structlog.contextvars.bind_contextvars(
            request_id=request_id,
            method=request.method,
            path=request.url.path,
        )

        started = time.perf_counter()
        try:
            response = await call_next(request)
        except Exception:
            # Logged here (with full request context bound) and re-raised so
            # the app's own exception handlers still produce the response.
            logger.exception(
                "request.unhandled_exception",
                duration_ms=round((time.perf_counter() - started) * 1000, 2),
            )
            raise

        duration_ms = round((time.perf_counter() - started) * 1000, 2)
        response.headers[REQUEST_ID_HEADER] = request_id

        # Health probes fire constantly; logging them would bury real traffic.
        if request.url.path not in ("/healthz", "/readyz", "/metrics"):
            logger.info(
                "request.completed",
                status_code=response.status_code,
                duration_ms=duration_ms,
            )

        return response
