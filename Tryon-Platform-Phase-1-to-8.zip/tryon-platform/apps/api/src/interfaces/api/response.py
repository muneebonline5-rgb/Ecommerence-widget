"""
Consistent API response conventions.

Every success response is the resource itself (kept simple for REST
consumers); every error response follows the same envelope, mapped from
domain exceptions so callers get stable, documented error codes instead of
raw tracebacks.
"""

from __future__ import annotations

from typing import Any

from fastapi import Request
from fastapi.responses import JSONResponse

from src.domain.exceptions.base import (
    ApiKeyInvalidError,
    AuthenticationError,
    AuthorizationError,
    DomainError,
    EntityAlreadyExistsError,
    EntityNotFoundError,
    InsufficientPermissionError,
    InvalidTokenError,
    MerchantSuspendedError,
    NotAMemberError,
    RateLimitExceededError,
    ValidationError,
)

_STATUS_BY_EXCEPTION: dict[type[DomainError], int] = {
    EntityNotFoundError: 404,
    EntityAlreadyExistsError: 409,
    ValidationError: 422,
    AuthorizationError: 403,
    AuthenticationError: 401,
    InvalidTokenError: 401,
    InsufficientPermissionError: 403,
    NotAMemberError: 403,
    ApiKeyInvalidError: 401,
    MerchantSuspendedError: 403,
    RateLimitExceededError: 429,
}


def error_envelope(
    code: str, message: str, details: dict[str, Any] | None = None
) -> dict[str, Any]:
    return {"error": {"code": code, "message": message, "details": details or {}}}


async def domain_error_handler(request: Request, exc: DomainError) -> JSONResponse:
    status_code = _STATUS_BY_EXCEPTION.get(type(exc), 400)
    response = JSONResponse(
        status_code=status_code,
        content=error_envelope(exc.code, exc.message, exc.details),
    )
    retry_after = exc.details.get("retry_after_seconds")
    if retry_after is not None:
        response.headers["Retry-After"] = str(retry_after)
    return response


async def unhandled_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    # Structured log emitted by logging middleware; this handler's only job
    # is to guarantee we never leak a raw stack trace to API consumers.
    return JSONResponse(
        status_code=500,
        content=error_envelope("internal_server_error", "An unexpected error occurred."),
    )
