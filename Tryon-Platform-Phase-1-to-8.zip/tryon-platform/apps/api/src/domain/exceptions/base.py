"""
Domain-level exceptions.

These carry no HTTP knowledge whatsoever — the `interfaces/api` layer is
responsible for mapping them to status codes. This keeps the domain testable
without spinning up FastAPI and keeps error semantics consistent across
REST, workers, and future gRPC/GraphQL surfaces.
"""

from __future__ import annotations


class DomainError(Exception):
    """Base class for all domain-layer errors."""

    code: str = "domain_error"

    def __init__(self, message: str, *, details: dict | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.details = details or {}


class EntityNotFoundError(DomainError):
    code = "entity_not_found"

    def __init__(self, entity_name: str, entity_id: str) -> None:
        super().__init__(
            f"{entity_name} with id '{entity_id}' was not found.",
            details={"entity": entity_name, "id": entity_id},
        )


class EntityAlreadyExistsError(DomainError):
    code = "entity_already_exists"

    def __init__(self, entity_name: str, conflicting_field: str, value: str) -> None:
        super().__init__(
            f"{entity_name} with {conflicting_field} '{value}' already exists.",
            details={"entity": entity_name, "field": conflicting_field, "value": value},
        )


class ValidationError(DomainError):
    code = "validation_error"


class AuthorizationError(DomainError):
    code = "authorization_error"


class AuthenticationError(DomainError):
    code = "authentication_error"


class InvalidTokenError(AuthenticationError):
    code = "invalid_token"

    def __init__(self, reason: str = "The provided token is invalid or expired.") -> None:
        super().__init__(reason)


class InsufficientPermissionError(AuthorizationError):
    code = "insufficient_permission"

    def __init__(self, required_permission: str) -> None:
        super().__init__(
            f"This action requires the '{required_permission}' permission.",
            details={"required_permission": required_permission},
        )


class NotAMemberError(AuthorizationError):
    code = "not_a_member"

    def __init__(self, merchant_id: str) -> None:
        super().__init__(
            f"You are not a member of merchant '{merchant_id}'.",
            details={"merchant_id": merchant_id},
        )


class ProviderError(DomainError):
    """Base class for AI provider adapter failures."""

    code = "provider_error"


class ProviderTransientError(ProviderError):
    """A failure the caller should retry (network blip, provider 5xx, rate limit)."""

    code = "provider_transient_error"


class ProviderPermanentError(ProviderError):
    """A failure retrying can never fix (bad input image, unsupported op, bad credentials)."""

    code = "provider_permanent_error"


class ProviderTimeoutError(ProviderTransientError):
    code = "provider_timeout"

    def __init__(self, provider: str, timeout_seconds: float) -> None:
        super().__init__(
            f"Provider '{provider}' did not respond within {timeout_seconds}s.",
            details={"provider": provider, "timeout_seconds": timeout_seconds},
        )


class IdempotencyConflictError(DomainError):
    code = "idempotency_conflict"

    def __init__(self, idempotency_key: str) -> None:
        super().__init__(
            f"A request with idempotency key '{idempotency_key}' is already being processed "
            "with different parameters.",
            details={"idempotency_key": idempotency_key},
        )


class TryOnStateError(ValidationError):
    """Raised when an operation is attempted against a TryOn/AIRequest in an incompatible state."""

    code = "tryon_state_error"


class BillingError(DomainError):
    """Base class for billing-domain failures."""

    code = "billing_error"


class PaymentGatewayError(BillingError):
    """A failure communicating with the payment gateway (Stripe)."""

    code = "payment_gateway_error"


class SubscriptionStateError(BillingError):
    """Raised when a subscription operation is attempted against an incompatible state."""

    code = "subscription_state_error"


class NoActiveSubscriptionError(BillingError):
    code = "no_active_subscription"

    def __init__(self, merchant_id: str) -> None:
        super().__init__(
            f"Merchant '{merchant_id}' has no active subscription.",
            details={"merchant_id": merchant_id},
        )


class WebhookSignatureError(BillingError):
    code = "webhook_signature_invalid"

    def __init__(self) -> None:
        super().__init__("The webhook signature could not be verified.")


class ApiKeyInvalidError(DomainError):
    code = "api_key_invalid"

    def __init__(self) -> None:
        super().__init__("The provided API key is invalid or has been revoked.")


class MerchantSuspendedError(DomainError):
    code = "merchant_suspended"

    def __init__(self, merchant_id: str) -> None:
        super().__init__(
            f"Merchant '{merchant_id}' is suspended and cannot perform this action.",
            details={"merchant_id": merchant_id},
        )


class RateLimitExceededError(DomainError):
    code = "rate_limit_exceeded"

    def __init__(self, limit: int, window_seconds: int, retry_after_seconds: int = 0) -> None:
        super().__init__(
            f"Rate limit of {limit} requests per {window_seconds}s exceeded.",
            details={
                "limit": limit,
                "window_seconds": window_seconds,
                "retry_after_seconds": retry_after_seconds,
            },
        )
