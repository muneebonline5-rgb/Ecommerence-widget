"""
UsageRecord entity — a daily rollup of billable generation usage per
merchant, populated incrementally as `AIRequest`s complete (see the Celery
task's `_finalize`, Phase 4) rather than computed on demand from raw
`AIRequest` rows — keeping billing queries O(days) rather than O(requests)
as volume grows, matching Phase 1's original design intent for this table.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, date, datetime

from src.domain.exceptions.base import ValidationError
from src.domain.value_objects.identifiers import MerchantId, UsageRecordId


@dataclass(slots=True)
class UsageRecord:
    id: UsageRecordId
    merchant_id: MerchantId
    usage_date: date
    generations_count: int
    created_at: datetime
    updated_at: datetime
    breakdown_by_provider: dict = field(default_factory=dict)

    @staticmethod
    def start_for_day(merchant_id: MerchantId, usage_date: date) -> UsageRecord:
        now = datetime.now(UTC)
        return UsageRecord(
            id=UsageRecordId.new(),
            merchant_id=merchant_id,
            usage_date=usage_date,
            generations_count=0,
            breakdown_by_provider={},
            created_at=now,
            updated_at=now,
        )

    def add_usage(self, provider: str, cost_usd: float) -> None:
        if cost_usd < 0:
            raise ValidationError("cost_usd cannot be negative.")

        self.generations_count += 1

        bucket = self.breakdown_by_provider.get(provider, {"count": 0, "cost_usd": 0.0})
        bucket["count"] += 1
        bucket["cost_usd"] = round(bucket["cost_usd"] + cost_usd, 6)
        self.breakdown_by_provider[provider] = bucket

        self.updated_at = datetime.now(UTC)

    def total_cost_usd(self) -> float:
        return round(sum(b["cost_usd"] for b in self.breakdown_by_provider.values()), 6)
