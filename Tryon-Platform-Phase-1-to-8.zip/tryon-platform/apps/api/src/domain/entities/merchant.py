"""
Merchant entity — the tenant root in this multi-tenant SaaS.

Every other tenant-scoped entity (products, try-ons, widget settings, API
keys, billing) references a MerchantId. Business invariants that protect
tenant isolation and lifecycle live here, not in the API layer.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum

from src.domain.exceptions.base import ValidationError
from src.domain.value_objects.identifiers import MerchantId


class MerchantStatus(str, Enum):
    PENDING = "pending"  # Signed up, email/domain not yet verified
    ACTIVE = "active"
    SUSPENDED = "suspended"  # Billing failure, ToS violation, manual action
    CHURNED = "churned"  # Cancelled, retained for data-export window


class MerchantTier(str, Enum):
    FREE = "free"
    STARTER = "starter"
    GROWTH = "growth"
    ENTERPRISE = "enterprise"


@dataclass(slots=True)
class Merchant:
    id: MerchantId
    name: str
    domain: str
    contact_email: str
    status: MerchantStatus
    tier: MerchantTier
    created_at: datetime
    updated_at: datetime
    suspended_reason: str | None = field(default=None)
    stripe_customer_id: str | None = field(default=None)

    @staticmethod
    def register(name: str, domain: str, contact_email: str) -> Merchant:
        """Factory enforcing invariants at creation time."""
        name = name.strip()
        domain = domain.strip().lower()
        contact_email = contact_email.strip().lower()

        if not name:
            raise ValidationError("Merchant name cannot be empty.")
        if not domain or "." not in domain:
            raise ValidationError(f"'{domain}' is not a valid domain.")
        if "@" not in contact_email:
            raise ValidationError(f"'{contact_email}' is not a valid email.")

        now = datetime.now(UTC)
        return Merchant(
            id=MerchantId.new(),
            name=name,
            domain=domain,
            contact_email=contact_email,
            status=MerchantStatus.PENDING,
            tier=MerchantTier.FREE,
            created_at=now,
            updated_at=now,
        )

    def activate(self) -> None:
        if self.status == MerchantStatus.CHURNED:
            raise ValidationError(
                "A churned merchant cannot be reactivated directly; use reinstate()."
            )
        self.status = MerchantStatus.ACTIVE
        self.suspended_reason = None
        self._touch()

    def suspend(self, reason: str) -> None:
        if not reason.strip():
            raise ValidationError("A suspension reason is required.")
        self.status = MerchantStatus.SUSPENDED
        self.suspended_reason = reason.strip()
        self._touch()

    def churn(self) -> None:
        self.status = MerchantStatus.CHURNED
        self._touch()

    def change_tier(self, tier: MerchantTier) -> None:
        self.tier = tier
        self._touch()

    def attach_stripe_customer(self, stripe_customer_id: str) -> None:
        if not stripe_customer_id.strip():
            raise ValidationError("stripe_customer_id cannot be empty.")
        self.stripe_customer_id = stripe_customer_id.strip()
        self._touch()

    def is_operational(self) -> bool:
        """Whether this merchant may serve widget traffic / make AI requests."""
        return self.status == MerchantStatus.ACTIVE

    def _touch(self) -> None:
        self.updated_at = datetime.now(UTC)
