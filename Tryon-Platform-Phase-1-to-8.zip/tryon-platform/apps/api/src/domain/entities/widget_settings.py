"""
WidgetSettings entity — per-merchant widget appearance & behavior config,
served to the widget SDK at init time via a public, cacheable endpoint.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum

from src.domain.exceptions.base import ValidationError
from src.domain.value_objects.identifiers import MerchantId, WidgetSettingsId

_HEX_COLOR_RE = re.compile(r"^#(?:[0-9a-fA-F]{3}){1,2}$")


class WidgetPosition(str, Enum):
    BOTTOM_RIGHT = "bottom_right"
    BOTTOM_LEFT = "bottom_left"
    TOP_RIGHT = "top_right"
    TOP_LEFT = "top_left"


class WidgetButtonShape(str, Enum):
    CIRCLE = "circle"
    PILL = "pill"
    SQUARE = "square"


@dataclass(slots=True)
class WidgetTheme:
    primary_color: str = "#111827"
    accent_color: str = "#6366F1"
    text_color: str = "#FFFFFF"
    font_family: str = "Inter, system-ui, sans-serif"
    button_shape: WidgetButtonShape = WidgetButtonShape.CIRCLE
    border_radius_px: int = 16

    def __post_init__(self) -> None:
        for name, value in (
            ("primary_color", self.primary_color),
            ("accent_color", self.accent_color),
            ("text_color", self.text_color),
        ):
            if not _HEX_COLOR_RE.match(value):
                raise ValidationError(f"'{name}' must be a valid hex color, got '{value}'.")
        if not (0 <= self.border_radius_px <= 999):
            raise ValidationError("border_radius_px must be between 0 and 999.")


@dataclass(slots=True)
class WidgetSettings:
    id: WidgetSettingsId
    merchant_id: MerchantId
    is_enabled: bool
    position: WidgetPosition
    theme: WidgetTheme
    button_label: str
    allowed_origins: list[str]
    sdk_version_pin: str | None  # None => always latest
    created_at: datetime
    updated_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    @staticmethod
    def default_for(merchant_id: MerchantId) -> WidgetSettings:
        now = datetime.now(UTC)
        return WidgetSettings(
            id=WidgetSettingsId.new(),
            merchant_id=merchant_id,
            is_enabled=True,
            position=WidgetPosition.BOTTOM_RIGHT,
            theme=WidgetTheme(),
            button_label="Try It On",
            allowed_origins=[],
            sdk_version_pin=None,
            created_at=now,
            updated_at=now,
        )

    def update_theme(self, theme: WidgetTheme) -> None:
        self.theme = theme
        self._touch()

    def update_position(self, position: WidgetPosition) -> None:
        self.position = position
        self._touch()

    def set_allowed_origins(self, origins: list[str]) -> None:
        cleaned = [o.strip().lower() for o in origins if o.strip()]
        for origin in cleaned:
            if not (origin.startswith("http://") or origin.startswith("https://") or origin == "*"):
                raise ValidationError(
                    f"Origin '{origin}' must include a scheme (https://) or be '*'."
                )
        self.allowed_origins = cleaned
        self._touch()

    def is_origin_allowed(self, origin: str) -> bool:
        if not self.allowed_origins:
            return True  # No allowlist configured => open (dev-friendly default)
        return "*" in self.allowed_origins or origin.strip().lower() in self.allowed_origins

    def disable(self) -> None:
        self.is_enabled = False
        self._touch()

    def enable(self) -> None:
        self.is_enabled = True
        self._touch()

    def _touch(self) -> None:
        self.updated_at = datetime.now(UTC)
