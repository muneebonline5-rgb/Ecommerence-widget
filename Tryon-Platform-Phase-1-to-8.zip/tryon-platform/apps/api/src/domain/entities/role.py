"""
Role entity — a named, reusable bundle of permission codes.

Permission codes follow a `resource:action` convention (e.g. "widget:edit",
"billing:view", "team:manage") so new permissions are just new strings, not
schema changes. The four built-in roles below cover the merchant-dashboard
use case; platform-admin authorization is handled separately via
`User.is_platform_admin`, since platform admins operate across tenants
rather than within a single merchant's team.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum

from src.domain.exceptions.base import ValidationError
from src.domain.value_objects.identifiers import RoleId


class BuiltInRole(str, Enum):
    OWNER = "owner"
    ADMIN = "admin"
    MEMBER = "member"
    VIEWER = "viewer"


# Centralized so the seeding migration and any in-process role bootstrapping
# (tests, local dev) both derive from one definition instead of drifting.
BUILT_IN_ROLE_PERMISSIONS: dict[BuiltInRole, tuple[str, ...]] = {
    BuiltInRole.OWNER: (
        "widget:view",
        "widget:edit",
        "products:view",
        "products:edit",
        "analytics:view",
        "billing:view",
        "billing:edit",
        "api_keys:view",
        "api_keys:manage",
        "team:view",
        "team:manage",
    ),
    BuiltInRole.ADMIN: (
        "widget:view",
        "widget:edit",
        "products:view",
        "products:edit",
        "analytics:view",
        "billing:view",
        "api_keys:view",
        "api_keys:manage",
        "team:view",
    ),
    BuiltInRole.MEMBER: (
        "widget:view",
        "widget:edit",
        "products:view",
        "products:edit",
        "analytics:view",
    ),
    BuiltInRole.VIEWER: (
        "widget:view",
        "products:view",
        "analytics:view",
    ),
}


@dataclass(slots=True)
class Role:
    id: RoleId
    name: str
    description: str | None
    permission_codes: list[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    @staticmethod
    def create(name: str, description: str | None, permission_codes: list[str]) -> Role:
        name = name.strip()
        if not name:
            raise ValidationError("Role name cannot be empty.")
        cleaned_codes = sorted({c.strip() for c in permission_codes if c.strip()})
        now = datetime.now(UTC)
        return Role(
            id=RoleId.new(),
            name=name,
            description=description.strip() if description else None,
            permission_codes=cleaned_codes,
            created_at=now,
            updated_at=now,
        )

    @staticmethod
    def built_in(role: BuiltInRole) -> Role:
        return Role.create(
            name=role.value,
            description=f"Built-in '{role.value}' role.",
            permission_codes=list(BUILT_IN_ROLE_PERMISSIONS[role]),
        )

    def has_permission(self, code: str) -> bool:
        return code in self.permission_codes
