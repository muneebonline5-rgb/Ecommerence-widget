"""
TeamMembership entity — the join between a User and a Merchant, carrying
the Role that governs what that user may do within that merchant's tenant.

A single Clerk user can be a member of multiple merchants (e.g. an agency
managing several brands' widgets), each with an independent role, which is
why this is its own aggregate rather than a field on User or Merchant.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime

from src.domain.value_objects.identifiers import MerchantId, RoleId, TeamMembershipId, UserId


@dataclass(slots=True)
class TeamMembership:
    id: TeamMembershipId
    merchant_id: MerchantId
    user_id: UserId
    role_id: RoleId
    created_at: datetime
    updated_at: datetime

    @staticmethod
    def create(merchant_id: MerchantId, user_id: UserId, role_id: RoleId) -> TeamMembership:
        now = datetime.now(UTC)
        return TeamMembership(
            id=TeamMembershipId.new(),
            merchant_id=merchant_id,
            user_id=user_id,
            role_id=role_id,
            created_at=now,
            updated_at=now,
        )

    def change_role(self, role_id: RoleId) -> None:
        self.role_id = role_id
        self.updated_at = datetime.now(UTC)
