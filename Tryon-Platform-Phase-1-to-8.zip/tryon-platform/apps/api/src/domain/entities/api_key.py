"""
ApiKey entity — credential a merchant uses to authenticate widget/server calls.

Note: this entity stores only the ApiKeyHash (see value_objects/api_key.py),
never plaintext. Revocation is soft (status flag + timestamp) to preserve
audit trails.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from enum import Enum

from src.domain.exceptions.base import AuthorizationError, ValidationError
from src.domain.value_objects.api_key import ApiKeyEnvironment, ApiKeyHash
from src.domain.value_objects.identifiers import ApiKeyId, MerchantId


class ApiKeyStatus(str, Enum):
    ACTIVE = "active"
    REVOKED = "revoked"


@dataclass(slots=True)
class ApiKey:
    id: ApiKeyId
    merchant_id: MerchantId
    label: str
    environment: ApiKeyEnvironment
    key_hash: ApiKeyHash
    status: ApiKeyStatus
    created_at: datetime
    last_used_at: datetime | None
    revoked_at: datetime | None

    @staticmethod
    def issue(
        merchant_id: MerchantId,
        label: str,
        key_hash: ApiKeyHash,
        environment: ApiKeyEnvironment,
    ) -> ApiKey:
        if not label.strip():
            raise ValidationError("API key label cannot be empty.")
        return ApiKey(
            id=ApiKeyId.new(),
            merchant_id=merchant_id,
            label=label.strip(),
            environment=environment,
            key_hash=key_hash,
            status=ApiKeyStatus.ACTIVE,
            created_at=datetime.now(UTC),
            last_used_at=None,
            revoked_at=None,
        )

    def revoke(self) -> None:
        if self.status == ApiKeyStatus.REVOKED:
            return  # idempotent
        self.status = ApiKeyStatus.REVOKED
        self.revoked_at = datetime.now(UTC)

    def record_usage(self) -> None:
        if self.status != ApiKeyStatus.ACTIVE:
            raise AuthorizationError("Cannot use a revoked API key.")
        self.last_used_at = datetime.now(UTC)

    def verify(self, plaintext_candidate: str, pepper: str) -> bool:
        if self.status != ApiKeyStatus.ACTIVE:
            return False
        return self.key_hash.matches(plaintext_candidate, pepper)
