"""
AuditLog entity — an immutable record of a sensitive action, built on
Phase 1's `audit_logs` table (which had a schema but no domain layer until
now). Used in this phase for billing-relevant actions: subscription
created/changed/canceled/reactivated, refund issued, credit note issued.
Never updated or deleted after creation — enforced by convention (no
update/delete method exists on this entity or its repository).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime

from src.domain.exceptions.base import ValidationError
from src.domain.value_objects.identifiers import AuditLogId, MerchantId, UserId


@dataclass(slots=True)
class AuditLog:
    id: AuditLogId
    action: str
    resource_type: str
    resource_id: str
    created_at: datetime
    merchant_id: MerchantId | None = None
    actor_user_id: UserId | None = None
    actor_type: str = "user"
    metadata: dict = field(default_factory=dict)
    ip_address: str | None = None

    @staticmethod
    def record(
        action: str,
        resource_type: str,
        resource_id: str,
        *,
        merchant_id: MerchantId | None = None,
        actor_user_id: UserId | None = None,
        actor_type: str = "user",
        metadata: dict | None = None,
        ip_address: str | None = None,
    ) -> AuditLog:
        if not action.strip():
            raise ValidationError("action is required.")
        if not resource_type.strip():
            raise ValidationError("resource_type is required.")
        if not resource_id.strip():
            raise ValidationError("resource_id is required.")

        return AuditLog(
            id=AuditLogId.new(),
            action=action.strip(),
            resource_type=resource_type.strip(),
            resource_id=resource_id.strip(),
            merchant_id=merchant_id,
            actor_user_id=actor_user_id,
            actor_type=actor_type,
            metadata=metadata or {},
            ip_address=ip_address,
            created_at=datetime.now(UTC),
        )
