"""
Invoice entity — mirrors a Stripe invoice. Stripe is the source of truth
for the invoice document itself (line items, tax, PDF); this entity tracks
just enough (status, amounts, hosted URL) for our own API/dashboard to
answer "what does this merchant owe / has paid" without a live Stripe call
on every read.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, date, datetime

from src.domain.exceptions.base import SubscriptionStateError, ValidationError
from src.domain.value_objects.billing import InvoiceStatus
from src.domain.value_objects.identifiers import InvoiceId, MerchantId

_ALLOWED_TRANSITIONS: dict[InvoiceStatus, set[InvoiceStatus]] = {
    InvoiceStatus.DRAFT: {InvoiceStatus.OPEN, InvoiceStatus.VOID},
    InvoiceStatus.OPEN: {InvoiceStatus.PAID, InvoiceStatus.VOID, InvoiceStatus.UNCOLLECTIBLE},
    InvoiceStatus.PAID: set(),
    InvoiceStatus.VOID: set(),
    InvoiceStatus.UNCOLLECTIBLE: {InvoiceStatus.PAID},  # a late/manual payment can still land
}


@dataclass(slots=True)
class Invoice:
    id: InvoiceId
    merchant_id: MerchantId
    stripe_invoice_id: str
    status: InvoiceStatus
    amount_due_usd: float
    amount_paid_usd: float
    period_start: date
    period_end: date
    created_at: datetime
    updated_at: datetime
    hosted_invoice_url: str | None = None

    @staticmethod
    def create(
        merchant_id: MerchantId,
        stripe_invoice_id: str,
        status: InvoiceStatus,
        amount_due_usd: float,
        period_start: date,
        period_end: date,
        *,
        amount_paid_usd: float = 0.0,
        hosted_invoice_url: str | None = None,
    ) -> Invoice:
        if not stripe_invoice_id.strip():
            raise ValidationError("stripe_invoice_id is required.")
        if amount_due_usd < 0 or amount_paid_usd < 0:
            raise ValidationError("Invoice amounts cannot be negative.")
        if period_end <= period_start:
            raise ValidationError("period_end must be after period_start.")

        now = datetime.now(UTC)
        return Invoice(
            id=InvoiceId.new(),
            merchant_id=merchant_id,
            stripe_invoice_id=stripe_invoice_id.strip(),
            status=status,
            amount_due_usd=amount_due_usd,
            amount_paid_usd=amount_paid_usd,
            period_start=period_start,
            period_end=period_end,
            hosted_invoice_url=hosted_invoice_url,
            created_at=now,
            updated_at=now,
        )

    def mark_paid(self, amount_paid_usd: float) -> None:
        if amount_paid_usd < 0:
            raise ValidationError("amount_paid_usd cannot be negative.")
        self._transition_to(InvoiceStatus.PAID)
        self.amount_paid_usd = amount_paid_usd

    def mark_open(self) -> None:
        self._transition_to(InvoiceStatus.OPEN)

    def void(self) -> None:
        self._transition_to(InvoiceStatus.VOID)

    def mark_uncollectible(self) -> None:
        self._transition_to(InvoiceStatus.UNCOLLECTIBLE)

    def _transition_to(self, new_status: InvoiceStatus) -> None:
        allowed = _ALLOWED_TRANSITIONS.get(self.status, set())
        if new_status not in allowed:
            raise SubscriptionStateError(
                f"Cannot transition invoice from '{self.status.value}' to '{new_status.value}'."
            )
        self.status = new_status
        self.updated_at = datetime.now(UTC)
