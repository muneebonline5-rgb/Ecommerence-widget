"""
Product entity — a merchant's catalog item, as known to the try-on widget.

Populated either via this Products API (merchant push, e.g. a Shopify app
syncing their catalog) or upserted by the widget SDK's product-page
auto-detection on first view (`external_id` is the merchant's own SKU/product
ID, used as the natural key for that upsert — see the unique index on
(merchant_id, external_id) from the Phase 1 schema).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime

from src.domain.exceptions.base import ValidationError
from src.domain.value_objects.identifiers import MerchantId, ProductId


@dataclass(slots=True)
class Product:
    id: ProductId
    merchant_id: MerchantId
    external_id: str
    title: str
    product_url: str
    image_url: str
    created_at: datetime
    updated_at: datetime
    category: str | None = None
    is_try_on_eligible: bool = True
    metadata: dict = field(default_factory=dict)

    @staticmethod
    def create(
        merchant_id: MerchantId,
        external_id: str,
        title: str,
        product_url: str,
        image_url: str,
        *,
        category: str | None = None,
        is_try_on_eligible: bool = True,
        metadata: dict | None = None,
    ) -> Product:
        external_id = external_id.strip()
        title = title.strip()
        product_url = product_url.strip()
        image_url = image_url.strip()

        if not external_id:
            raise ValidationError("external_id cannot be empty.")
        if not title:
            raise ValidationError("title cannot be empty.")
        if not product_url:
            raise ValidationError("product_url cannot be empty.")
        if not image_url:
            raise ValidationError("image_url cannot be empty.")

        now = datetime.now(UTC)
        return Product(
            id=ProductId.new(),
            merchant_id=merchant_id,
            external_id=external_id,
            title=title,
            product_url=product_url,
            image_url=image_url,
            category=category.strip() if category else None,
            is_try_on_eligible=is_try_on_eligible,
            metadata=metadata or {},
            created_at=now,
            updated_at=now,
        )

    def update_details(
        self,
        *,
        title: str,
        product_url: str,
        image_url: str,
        category: str | None,
        metadata: dict | None = None,
    ) -> None:
        title = title.strip()
        product_url = product_url.strip()
        image_url = image_url.strip()
        if not title:
            raise ValidationError("title cannot be empty.")
        if not product_url:
            raise ValidationError("product_url cannot be empty.")
        if not image_url:
            raise ValidationError("image_url cannot be empty.")

        self.title = title
        self.product_url = product_url
        self.image_url = image_url
        self.category = category.strip() if category else None
        if metadata is not None:
            self.metadata = metadata
        self._touch()

    def set_try_on_eligible(self, eligible: bool) -> None:
        self.is_try_on_eligible = eligible
        self._touch()

    def _touch(self) -> None:
        self.updated_at = datetime.now(UTC)
