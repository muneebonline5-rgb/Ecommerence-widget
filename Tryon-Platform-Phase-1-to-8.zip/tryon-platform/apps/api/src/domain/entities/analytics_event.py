"""
AnalyticsEvent entity — one entry in the append-only widget event stream
(widget_loaded, button_clicked, modal_opened, image_uploaded,
generation_started/completed/failed, result_downloaded, conversion — see
WidgetEventType in the widget SDK, which this mirrors exactly).

Deliberately has no mutation methods beyond creation: analytics events are
immutable facts about something that already happened, not aggregates with
a lifecycle.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum

from src.domain.exceptions.base import ValidationError
from src.domain.value_objects.identifiers import AnalyticsEventId, MerchantId, TryOnSessionId


class AnalyticsEventType(str, Enum):
    WIDGET_LOADED = "widget_loaded"
    BUTTON_CLICKED = "button_clicked"
    MODAL_OPENED = "modal_opened"
    MODAL_CLOSED = "modal_closed"
    IMAGE_UPLOADED = "image_uploaded"
    GENERATION_STARTED = "generation_started"
    GENERATION_COMPLETED = "generation_completed"
    GENERATION_FAILED = "generation_failed"
    RESULT_DOWNLOADED = "result_downloaded"
    CONVERSION = "conversion"


@dataclass(slots=True)
class AnalyticsEvent:
    id: AnalyticsEventId
    merchant_id: MerchantId
    event_type: AnalyticsEventType
    created_at: datetime
    session_id: TryOnSessionId | None = None
    properties: dict = field(default_factory=dict)

    @staticmethod
    def create(
        merchant_id: MerchantId,
        event_type: AnalyticsEventType,
        *,
        session_id: TryOnSessionId | None = None,
        properties: dict | None = None,
        occurred_at: datetime | None = None,
    ) -> AnalyticsEvent:
        return AnalyticsEvent(
            id=AnalyticsEventId.new(),
            merchant_id=merchant_id,
            event_type=event_type,
            session_id=session_id,
            properties=properties or {},
            created_at=occurred_at or datetime.now(UTC),
        )

    @staticmethod
    def parse_event_type(raw: str) -> AnalyticsEventType:
        try:
            return AnalyticsEventType(raw)
        except ValueError as exc:
            raise ValidationError(f"Unknown analytics event type: '{raw}'.") from exc
