"""
CreditNote entity — records a credit issued against an invoice (partial or
full refund credited rather than cash-refunded, or a goodwill adjustment).
Stripe's Credit Notes API is the actual mechanism; this entity is our
durable record of that action for the merchant's billing history and for
audit purposes.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime

from src.domain.exceptions.base import ValidationError
from src.domain.value_objects.identifiers import CreditNoteId, InvoiceId, MerchantId


@dataclass(slots=True)
class CreditNote:
    id: CreditNoteId
    merchant_id: MerchantId
    invoice_id: InvoiceId
    stripe_credit_note_id: str
    amount_usd: float
    reason: str
    created_at: datetime

    @staticmethod
    def create(
        merchant_id: MerchantId,
        invoice_id: InvoiceId,
        stripe_credit_note_id: str,
        amount_usd: float,
        reason: str,
    ) -> CreditNote:
        if amount_usd <= 0:
            raise ValidationError("amount_usd must be positive.")
        if not stripe_credit_note_id.strip():
            raise ValidationError("stripe_credit_note_id is required.")
        if not reason.strip():
            raise ValidationError("A reason is required for a credit note.")

        return CreditNote(
            id=CreditNoteId.new(),
            merchant_id=merchant_id,
            invoice_id=invoice_id,
            stripe_credit_note_id=stripe_credit_note_id.strip(),
            amount_usd=amount_usd,
            reason=reason.strip(),
            created_at=datetime.now(UTC),
        )
