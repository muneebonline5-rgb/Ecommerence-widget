"""
Subscription entity — a merchant's subscription to a Plan, mirroring the
Stripe subscription it's backed by. The state machine here governs what our
own domain considers a valid transition; the Stripe side of truth is
reconciled via webhooks (see application/services/webhook_service.py).
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime

from src.domain.exceptions.base import SubscriptionStateError, ValidationError
from src.domain.value_objects.billing import BillingInterval, SubscriptionStatus
from src.domain.value_objects.identifiers import MerchantId, PlanId, SubscriptionId

_ALLOWED_TRANSITIONS: dict[SubscriptionStatus, set[SubscriptionStatus]] = {
    SubscriptionStatus.TRIALING: {SubscriptionStatus.ACTIVE, SubscriptionStatus.CANCELED},
    SubscriptionStatus.ACTIVE: {SubscriptionStatus.PAST_DUE, SubscriptionStatus.CANCELED},
    SubscriptionStatus.PAST_DUE: {SubscriptionStatus.ACTIVE, SubscriptionStatus.CANCELED},
    SubscriptionStatus.CANCELED: {SubscriptionStatus.ACTIVE},  # reactivation
}


@dataclass(slots=True)
class Subscription:
    id: SubscriptionId
    merchant_id: MerchantId
    plan_id: PlanId
    stripe_subscription_id: str
    status: SubscriptionStatus
    billing_interval: BillingInterval
    current_period_start: datetime
    current_period_end: datetime
    created_at: datetime
    updated_at: datetime
    cancel_at_period_end: bool = False
    trial_end: datetime | None = None

    @staticmethod
    def start(
        merchant_id: MerchantId,
        plan_id: PlanId,
        stripe_subscription_id: str,
        billing_interval: BillingInterval,
        current_period_start: datetime,
        current_period_end: datetime,
        *,
        trial_end: datetime | None = None,
    ) -> Subscription:
        if not stripe_subscription_id.strip():
            raise ValidationError("stripe_subscription_id is required.")
        if current_period_end <= current_period_start:
            raise ValidationError("current_period_end must be after current_period_start.")

        now = datetime.now(UTC)
        return Subscription(
            id=SubscriptionId.new(),
            merchant_id=merchant_id,
            plan_id=plan_id,
            stripe_subscription_id=stripe_subscription_id.strip(),
            status=SubscriptionStatus.TRIALING if trial_end else SubscriptionStatus.ACTIVE,
            billing_interval=billing_interval,
            current_period_start=current_period_start,
            current_period_end=current_period_end,
            trial_end=trial_end,
            created_at=now,
            updated_at=now,
        )

    def change_plan(self, new_plan_id: PlanId, new_interval: BillingInterval | None = None) -> None:
        """
        Upgrade or downgrade to a different plan (and optionally a
        different billing interval). Proration is handled entirely on the
        Stripe side (see StripeGateway.update_subscription); this method
        only updates our own record of which plan is active once Stripe
        confirms the change.
        """
        if self.status == SubscriptionStatus.CANCELED:
            raise SubscriptionStateError("Cannot change the plan of a canceled subscription.")
        self.plan_id = new_plan_id
        if new_interval is not None:
            self.billing_interval = new_interval
        self._touch()

    def renew_period(self, period_start: datetime, period_end: datetime) -> None:
        if period_end <= period_start:
            raise ValidationError("period_end must be after period_start.")
        self.current_period_start = period_start
        self.current_period_end = period_end
        self._touch()

    def mark_past_due(self) -> None:
        self._transition_to(SubscriptionStatus.PAST_DUE)

    def mark_active(self) -> None:
        self._transition_to(SubscriptionStatus.ACTIVE)

    def schedule_cancellation(self) -> None:
        """Cancel at period end — the subscription stays active/usable until then."""
        if self.status == SubscriptionStatus.CANCELED:
            raise SubscriptionStateError("Subscription is already canceled.")
        self.cancel_at_period_end = True
        self._touch()

    def cancel_immediately(self) -> None:
        self._transition_to(SubscriptionStatus.CANCELED)
        self.cancel_at_period_end = False

    def reactivate(self) -> None:
        if self.status != SubscriptionStatus.CANCELED:
            if self.cancel_at_period_end:
                # Reversing a scheduled (not-yet-effective) cancellation.
                self.cancel_at_period_end = False
                self._touch()
                return
            raise SubscriptionStateError(
                f"Cannot reactivate a subscription in status '{self.status.value}'."
            )
        self._transition_to(SubscriptionStatus.ACTIVE)

    def is_usable(self) -> bool:
        """Whether the merchant should currently be able to use paid features."""
        return self.status in (SubscriptionStatus.TRIALING, SubscriptionStatus.ACTIVE)

    def _transition_to(self, new_status: SubscriptionStatus) -> None:
        allowed = _ALLOWED_TRANSITIONS.get(self.status, set())
        if new_status not in allowed:
            raise SubscriptionStateError(
                f"Cannot transition subscription from '{self.status.value}' "
                f"to '{new_status.value}'."
            )
        self.status = new_status
        self._touch()

    def _touch(self) -> None:
        self.updated_at = datetime.now(UTC)
