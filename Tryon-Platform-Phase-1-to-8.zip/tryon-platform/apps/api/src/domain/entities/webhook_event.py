"""
WebhookEventRecord entity — the durable idempotency ledger for inbound
Stripe webhooks. Stripe's delivery guarantee is at-least-once (the same
event can be redelivered after a timeout or a non-2xx response), so this
table — checked before any side effect runs — is what makes webhook
processing safe to retry, mirroring Phase 4's `ai_requests.idempotency_key`
pattern exactly.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime

from src.domain.exceptions.base import ValidationError
from src.domain.value_objects.identifiers import WebhookEventId


@dataclass(slots=True)
class WebhookEventRecord:
    id: WebhookEventId
    stripe_event_id: str
    event_type: str
    received_at: datetime
    processed_at: datetime | None = None

    @staticmethod
    def receive(stripe_event_id: str, event_type: str) -> WebhookEventRecord:
        if not stripe_event_id.strip():
            raise ValidationError("stripe_event_id is required.")
        if not event_type.strip():
            raise ValidationError("event_type is required.")
        return WebhookEventRecord(
            id=WebhookEventId.new(),
            stripe_event_id=stripe_event_id.strip(),
            event_type=event_type.strip(),
            received_at=datetime.now(UTC),
        )

    def mark_processed(self) -> None:
        self.processed_at = datetime.now(UTC)

    def is_processed(self) -> bool:
        return self.processed_at is not None
