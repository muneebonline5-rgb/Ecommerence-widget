"""
TryOn entity — one try-on attempt: one customer photo -> one generated
result. A session may have several of these (retries with a different
photo, trying a different product).
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from enum import Enum

from src.domain.exceptions.base import TryOnStateError, ValidationError
from src.domain.value_objects.identifiers import TryOnId, TryOnSessionId


class TryOnStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


# Valid forward transitions. Anything not listed here is rejected — a
# TryOn's lifecycle must never move backward (e.g. completed -> pending) or
# skip states in a way that would leave analytics/billing inconsistent.
_ALLOWED_TRANSITIONS: dict[TryOnStatus, set[TryOnStatus]] = {
    TryOnStatus.PENDING: {TryOnStatus.PROCESSING, TryOnStatus.FAILED},
    TryOnStatus.PROCESSING: {TryOnStatus.COMPLETED, TryOnStatus.FAILED},
    TryOnStatus.COMPLETED: set(),
    TryOnStatus.FAILED: set(),
}


@dataclass(slots=True)
class TryOn:
    id: TryOnId
    session_id: TryOnSessionId
    customer_image_key: str
    status: TryOnStatus
    created_at: datetime
    updated_at: datetime
    result_image_key: str | None = None
    error_message: str | None = None
    was_downloaded: bool = False

    @staticmethod
    def create(session_id: TryOnSessionId, customer_image_key: str) -> TryOn:
        if not customer_image_key.strip():
            raise ValidationError("customer_image_key cannot be empty.")

        now = datetime.now(UTC)
        return TryOn(
            id=TryOnId.new(),
            session_id=session_id,
            customer_image_key=customer_image_key.strip(),
            status=TryOnStatus.PENDING,
            created_at=now,
            updated_at=now,
        )

    def start_processing(self) -> None:
        self._transition_to(TryOnStatus.PROCESSING)

    def complete(self, result_image_key: str) -> None:
        if not result_image_key.strip():
            raise ValidationError("result_image_key cannot be empty.")
        self._transition_to(TryOnStatus.COMPLETED)
        self.result_image_key = result_image_key.strip()

    def fail(self, error_message: str) -> None:
        self._transition_to(TryOnStatus.FAILED)
        self.error_message = error_message.strip() or "Unknown error"

    def mark_downloaded(self) -> None:
        if self.status != TryOnStatus.COMPLETED:
            raise TryOnStateError(
                f"Cannot mark a TryOn as downloaded while in status '{self.status.value}'; "
                "only a completed result can be downloaded."
            )
        self.was_downloaded = True
        self._touch()

    def _transition_to(self, new_status: TryOnStatus) -> None:
        allowed = _ALLOWED_TRANSITIONS.get(self.status, set())
        if new_status not in allowed:
            raise TryOnStateError(
                f"Cannot transition TryOn from '{self.status.value}' to '{new_status.value}'."
            )
        self.status = new_status
        self._touch()

    def _touch(self) -> None:
        self.updated_at = datetime.now(UTC)
