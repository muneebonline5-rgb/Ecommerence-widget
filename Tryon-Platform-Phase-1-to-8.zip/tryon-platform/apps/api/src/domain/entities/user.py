"""
User entity — a dashboard user's local record.

Clerk is the source of truth for identity (password, MFA, sessions); this
entity exists only so we can foreign-key team memberships, audit logs, and
notifications without calling out to Clerk's API on every request. It is
created/updated lazily the first time a valid Clerk JWT is seen for a given
`clerk_user_id` (see AuthService.sync_user_from_claims) rather than via a
webhook, so the system keeps working even if a Clerk webhook is missed.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime

from src.domain.exceptions.base import ValidationError
from src.domain.value_objects.identifiers import UserId


@dataclass(slots=True)
class User:
    id: UserId
    clerk_user_id: str
    email: str
    full_name: str | None
    is_platform_admin: bool
    created_at: datetime
    updated_at: datetime

    @staticmethod
    def create(clerk_user_id: str, email: str, full_name: str | None = None) -> User:
        clerk_user_id = clerk_user_id.strip()
        email = email.strip().lower()
        if not clerk_user_id:
            raise ValidationError("clerk_user_id cannot be empty.")
        if "@" not in email:
            raise ValidationError(f"'{email}' is not a valid email.")

        now = datetime.now(UTC)
        return User(
            id=UserId.new(),
            clerk_user_id=clerk_user_id,
            email=email,
            full_name=full_name.strip() if full_name else None,
            is_platform_admin=False,
            created_at=now,
            updated_at=now,
        )

    def update_profile(self, email: str, full_name: str | None) -> None:
        email = email.strip().lower()
        if "@" not in email:
            raise ValidationError(f"'{email}' is not a valid email.")
        self.email = email
        self.full_name = full_name.strip() if full_name else None
        self.updated_at = datetime.now(UTC)

    def grant_platform_admin(self) -> None:
        self.is_platform_admin = True
        self.updated_at = datetime.now(UTC)

    def revoke_platform_admin(self) -> None:
        self.is_platform_admin = False
        self.updated_at = datetime.now(UTC)
