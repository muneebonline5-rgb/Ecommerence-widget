"""
TryOnSession entity — one customer visit to the widget on a given product
page. Groups the analytics funnel and 1..N TryOn attempts together.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime

from src.domain.exceptions.base import ValidationError
from src.domain.value_objects.identifiers import MerchantId, ProductId, TryOnSessionId


@dataclass(slots=True)
class TryOnSession:
    id: TryOnSessionId
    merchant_id: MerchantId
    anonymous_visitor_id: str
    product_id: ProductId | None
    country: str | None
    device_type: str | None
    browser: str | None
    created_at: datetime
    updated_at: datetime
    ended_at: datetime | None

    @staticmethod
    def start(
        merchant_id: MerchantId,
        anonymous_visitor_id: str,
        *,
        product_id: ProductId | None = None,
        country: str | None = None,
        device_type: str | None = None,
        browser: str | None = None,
    ) -> TryOnSession:
        if not anonymous_visitor_id.strip():
            raise ValidationError("anonymous_visitor_id cannot be empty.")

        now = datetime.now(UTC)
        return TryOnSession(
            id=TryOnSessionId.new(),
            merchant_id=merchant_id,
            anonymous_visitor_id=anonymous_visitor_id.strip(),
            product_id=product_id,
            country=country,
            device_type=device_type,
            browser=browser,
            created_at=now,
            updated_at=now,
            ended_at=None,
        )

    def end(self) -> None:
        if self.ended_at is not None:
            return  # idempotent
        self.ended_at = datetime.now(UTC)
        self.updated_at = self.ended_at

    def is_active(self) -> bool:
        return self.ended_at is None
