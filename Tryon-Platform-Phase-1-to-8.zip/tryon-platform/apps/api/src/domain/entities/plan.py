"""
Plan entity — a billing tier (Free/Starter/Pro/Enterprise) with both
monthly and yearly Stripe prices attached, plus the usage allowance and
overage rate that `UsageService` uses to compute overage cost.

See domain/value_objects/billing.py for why `PlanTier` is a separate enum
from Phase 1's `MerchantTier`.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime

from src.domain.exceptions.base import ValidationError
from src.domain.value_objects.billing import BillingInterval, PlanTier
from src.domain.value_objects.identifiers import PlanId


@dataclass(slots=True)
class Plan:
    id: PlanId
    tier: PlanTier
    name: str
    monthly_price_usd: float
    monthly_stripe_price_id: str
    yearly_price_usd: float | None
    yearly_stripe_price_id: str | None
    included_generations: int
    overage_price_usd: float
    is_active: bool
    created_at: datetime
    updated_at: datetime

    @staticmethod
    def create(
        tier: PlanTier,
        name: str,
        *,
        monthly_price_usd: float,
        monthly_stripe_price_id: str,
        included_generations: int,
        overage_price_usd: float,
        yearly_price_usd: float | None = None,
        yearly_stripe_price_id: str | None = None,
    ) -> Plan:
        name = name.strip()
        if not name:
            raise ValidationError("Plan name cannot be empty.")
        if monthly_price_usd < 0:
            raise ValidationError("monthly_price_usd cannot be negative.")
        if included_generations < 0:
            raise ValidationError("included_generations cannot be negative.")
        if overage_price_usd < 0:
            raise ValidationError("overage_price_usd cannot be negative.")
        if not monthly_stripe_price_id.strip():
            raise ValidationError("monthly_stripe_price_id is required.")
        if (yearly_price_usd is None) != (yearly_stripe_price_id is None):
            raise ValidationError(
                "yearly_price_usd and yearly_stripe_price_id must be provided together."
            )

        now = datetime.now(UTC)
        return Plan(
            id=PlanId.new(),
            tier=tier,
            name=name,
            monthly_price_usd=monthly_price_usd,
            monthly_stripe_price_id=monthly_stripe_price_id.strip(),
            yearly_price_usd=yearly_price_usd,
            yearly_stripe_price_id=(
                yearly_stripe_price_id.strip() if yearly_stripe_price_id else None
            ),
            included_generations=included_generations,
            overage_price_usd=overage_price_usd,
            is_active=True,
            created_at=now,
            updated_at=now,
        )

    def stripe_price_id_for(self, interval: BillingInterval) -> str:
        if interval == BillingInterval.MONTHLY:
            return self.monthly_stripe_price_id
        if self.yearly_stripe_price_id is None:
            raise ValidationError(f"Plan '{self.name}' does not offer yearly billing.")
        return self.yearly_stripe_price_id

    def supports_interval(self, interval: BillingInterval) -> bool:
        if interval == BillingInterval.MONTHLY:
            return True
        return self.yearly_stripe_price_id is not None

    def deactivate(self) -> None:
        self.is_active = False
        self._touch()

    def activate(self) -> None:
        self.is_active = True
        self._touch()

    def _touch(self) -> None:
        self.updated_at = datetime.now(UTC)
