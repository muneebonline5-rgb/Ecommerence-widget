"""
AIRequest entity — a single request made to an upstream AI provider for a
given TryOn. Kept separate from TryOn because a try-on attempt could in
principle be retried across providers, and this is the source of truth for
AI-usage billing (Phase 6) as well as idempotent request handling.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime

from src.domain.exceptions.base import TryOnStateError
from src.domain.value_objects.ai_provider import AIProviderName, ProviderRequestStatus
from src.domain.value_objects.identifiers import AIRequestId, MerchantId, TryOnId

_ALLOWED_TRANSITIONS: dict[ProviderRequestStatus, set[ProviderRequestStatus]] = {
    ProviderRequestStatus.QUEUED: {ProviderRequestStatus.PROCESSING, ProviderRequestStatus.FAILED},
    ProviderRequestStatus.PROCESSING: {
        ProviderRequestStatus.COMPLETED,
        ProviderRequestStatus.FAILED,
    },
    ProviderRequestStatus.COMPLETED: set(),
    ProviderRequestStatus.FAILED: set(),
}


@dataclass(slots=True)
class AIRequest:
    id: AIRequestId
    tryon_id: TryOnId
    merchant_id: MerchantId
    provider: AIProviderName
    idempotency_key: str
    status: ProviderRequestStatus
    created_at: datetime
    updated_at: datetime
    provider_request_id: str | None = None
    latency_ms: int | None = None
    cost_usd: float | None = None
    request_payload: dict = field(default_factory=dict)
    response_payload: dict = field(default_factory=dict)

    @staticmethod
    def create(
        tryon_id: TryOnId,
        merchant_id: MerchantId,
        provider: AIProviderName,
        idempotency_key: str,
        request_payload: dict | None = None,
    ) -> AIRequest:
        now = datetime.now(UTC)
        return AIRequest(
            id=AIRequestId.new(),
            tryon_id=tryon_id,
            merchant_id=merchant_id,
            provider=provider,
            idempotency_key=idempotency_key,
            status=ProviderRequestStatus.QUEUED,
            created_at=now,
            updated_at=now,
            request_payload=request_payload or {},
        )

    def mark_submitted(self, provider_request_id: str) -> None:
        self._transition_to(ProviderRequestStatus.PROCESSING)
        self.provider_request_id = provider_request_id

    def mark_completed(
        self,
        response_payload: dict,
        *,
        latency_ms: int | None = None,
        cost_usd: float | None = None,
    ) -> None:
        self._transition_to(ProviderRequestStatus.COMPLETED)
        self.response_payload = response_payload
        if latency_ms is not None:
            self.latency_ms = latency_ms
        if cost_usd is not None:
            self.cost_usd = cost_usd

    def mark_failed(self, error_message: str, *, latency_ms: int | None = None) -> None:
        self._transition_to(ProviderRequestStatus.FAILED)
        self.response_payload = {**self.response_payload, "error": error_message}
        if latency_ms is not None:
            self.latency_ms = latency_ms

    def is_terminal(self) -> bool:
        return self.status in (ProviderRequestStatus.COMPLETED, ProviderRequestStatus.FAILED)

    def _transition_to(self, new_status: ProviderRequestStatus) -> None:
        allowed = _ALLOWED_TRANSITIONS.get(self.status, set())
        if new_status not in allowed:
            raise TryOnStateError(
                f"Cannot transition AIRequest from '{self.status.value}' to '{new_status.value}'."
            )
        self.status = new_status
        self.updated_at = datetime.now(UTC)
