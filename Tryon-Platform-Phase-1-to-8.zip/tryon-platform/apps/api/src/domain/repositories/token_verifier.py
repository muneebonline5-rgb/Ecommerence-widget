"""
TokenVerifier port.

Same pattern as the `AIProvider` (Phase 4) and `PaymentGateway` (Phase 6)
ports: an interface with no framework or vendor imports, so the
application layer depends on an abstraction rather than a concrete
implementation.

This closes a real Dependency Inversion violation found in the Phase 8
readiness audit — `AuthService` previously imported
`infrastructure.security.clerk_jwt.ClerkJWTVerifier` directly, meaning the
application layer knew about a specific identity provider. With this port,
swapping Clerk for another IdP (or stubbing it in tests) requires no change
to `AuthService` at all.
"""

from __future__ import annotations

from abc import ABC, abstractmethod


class TokenVerifier(ABC):
    @abstractmethod
    async def verify(self, token: str) -> dict:
        """
        Verifies a signed identity token and returns its claim set.

        Implementations must raise `InvalidTokenError` for any failure
        (bad signature, expiry, unknown signing key, malformed input)
        rather than returning None or a partial result, so callers never
        have to distinguish "invalid" from "unverifiable".
        """
        ...
