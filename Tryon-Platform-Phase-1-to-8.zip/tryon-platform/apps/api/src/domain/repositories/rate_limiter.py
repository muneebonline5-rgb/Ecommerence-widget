"""
RateLimiter port.

Rate limiting is a business rule (protect the platform and its merchants
from abuse/runaway integrations), not a Redis implementation detail — so
the interface lives in the domain layer, same as the repository ports. The
concrete fixed-window Redis implementation lives in
`infrastructure/cache/redis_rate_limiter.py`.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class RateLimitResult:
    allowed: bool
    limit: int
    remaining: int
    retry_after_seconds: int


class RateLimiter(ABC):
    @abstractmethod
    async def check(self, key: str, *, limit: int, window_seconds: int) -> RateLimitResult:
        """
        Records one attempt under `key` and reports whether it's within
        `limit` for the current `window_seconds`-long window. Does not raise
        on its own — callers (typically a FastAPI dependency) decide whether
        to enforce by raising RateLimitExceededError.
        """
        ...
