"""
Repository interfaces (ports).

Defined in the domain layer per the Dependency Inversion Principle: the
application layer depends on these abstractions, and infrastructure provides
concrete implementations (SQLAlchemy today; could be swapped for anything
else without touching business logic).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import date, datetime

from src.domain.entities.ai_request import AIRequest
from src.domain.entities.analytics_event import AnalyticsEvent
from src.domain.entities.api_key import ApiKey
from src.domain.entities.audit_log import AuditLog
from src.domain.entities.credit_note import CreditNote
from src.domain.entities.invoice import Invoice
from src.domain.entities.merchant import Merchant
from src.domain.entities.plan import Plan
from src.domain.entities.product import Product
from src.domain.entities.role import Role
from src.domain.entities.subscription import Subscription
from src.domain.entities.team_membership import TeamMembership
from src.domain.entities.tryon import TryOn
from src.domain.entities.tryon_session import TryOnSession
from src.domain.entities.usage_record import UsageRecord
from src.domain.entities.user import User
from src.domain.entities.webhook_event import WebhookEventRecord
from src.domain.entities.widget_settings import WidgetSettings
from src.domain.value_objects.billing import PlanTier
from src.domain.value_objects.identifiers import (
    AIRequestId,
    ApiKeyId,
    InvoiceId,
    MerchantId,
    PlanId,
    ProductId,
    RoleId,
    SubscriptionId,
    TeamMembershipId,
    TryOnId,
    TryOnSessionId,
    UsageRecordId,
    UserId,
    WidgetSettingsId,
)


class MerchantRepository(ABC):
    @abstractmethod
    async def save(self, merchant: Merchant) -> None: ...

    @abstractmethod
    async def get_by_id(self, merchant_id: MerchantId) -> Merchant | None: ...

    @abstractmethod
    async def get_by_domain(self, domain: str) -> Merchant | None: ...

    @abstractmethod
    async def list_all(self, *, limit: int = 50, offset: int = 0) -> list[Merchant]: ...

    @abstractmethod
    async def list_by_ids(self, merchant_ids: list[MerchantId]) -> list[Merchant]:
        """
        Batch lookup, so callers resolving many merchants at once (e.g. a
        user's team memberships) issue one query instead of N.
        """
        ...


class ApiKeyRepository(ABC):
    @abstractmethod
    async def save(self, api_key: ApiKey) -> None: ...

    @abstractmethod
    async def get_by_id(self, api_key_id: ApiKeyId) -> ApiKey | None: ...

    @abstractmethod
    async def get_by_prefix(self, prefix: str) -> ApiKey | None:
        """Used to look up the candidate key row before verifying the hash."""
        ...

    @abstractmethod
    async def list_for_merchant(self, merchant_id: MerchantId) -> list[ApiKey]: ...


class WidgetSettingsRepository(ABC):
    @abstractmethod
    async def save(self, settings: WidgetSettings) -> None: ...

    @abstractmethod
    async def get_by_id(self, settings_id: WidgetSettingsId) -> WidgetSettings | None: ...

    @abstractmethod
    async def get_by_merchant_id(self, merchant_id: MerchantId) -> WidgetSettings | None: ...


class UserRepository(ABC):
    @abstractmethod
    async def save(self, user: User) -> None: ...

    @abstractmethod
    async def get_by_id(self, user_id: UserId) -> User | None: ...

    @abstractmethod
    async def get_by_clerk_user_id(self, clerk_user_id: str) -> User | None: ...


class RoleRepository(ABC):
    @abstractmethod
    async def save(self, role: Role) -> None: ...

    @abstractmethod
    async def get_by_id(self, role_id: RoleId) -> Role | None: ...

    @abstractmethod
    async def get_by_name(self, name: str) -> Role | None: ...

    @abstractmethod
    async def list_all(self) -> list[Role]: ...


class TeamMembershipRepository(ABC):
    @abstractmethod
    async def save(self, membership: TeamMembership) -> None: ...

    @abstractmethod
    async def get_by_id(self, membership_id: TeamMembershipId) -> TeamMembership | None: ...

    @abstractmethod
    async def get_for_merchant_and_user(
        self, merchant_id: MerchantId, user_id: UserId
    ) -> TeamMembership | None: ...

    @abstractmethod
    async def list_for_merchant(self, merchant_id: MerchantId) -> list[TeamMembership]: ...

    @abstractmethod
    async def list_for_user(self, user_id: UserId) -> list[TeamMembership]:
        """
        Used so a signed-in dashboard user can discover which merchant(s)
        they belong to — every other endpoint requires already knowing the
        merchant_id, which a freshly-authenticated user has no way to learn
        otherwise.
        """
        ...

    @abstractmethod
    async def delete(self, membership_id: TeamMembershipId) -> None: ...


class TryOnSessionRepository(ABC):
    @abstractmethod
    async def save(self, session: TryOnSession) -> None: ...

    @abstractmethod
    async def get_by_id(self, session_id: TryOnSessionId) -> TryOnSession | None: ...


class TryOnRepository(ABC):
    @abstractmethod
    async def save(self, tryon: TryOn) -> None: ...

    @abstractmethod
    async def get_by_id(self, tryon_id: TryOnId) -> TryOn | None: ...

    @abstractmethod
    async def list_for_session(self, session_id: TryOnSessionId) -> list[TryOn]: ...


class AIRequestRepository(ABC):
    @abstractmethod
    async def save(self, ai_request: AIRequest) -> None: ...

    @abstractmethod
    async def get_by_id(self, ai_request_id: AIRequestId) -> AIRequest | None: ...

    @abstractmethod
    async def get_by_idempotency_key(
        self, merchant_id: MerchantId, idempotency_key: str
    ) -> AIRequest | None: ...

    @abstractmethod
    async def get_by_tryon_id(self, tryon_id: TryOnId) -> AIRequest | None: ...


class ProductRepository(ABC):
    @abstractmethod
    async def save(self, product: Product) -> None: ...

    @abstractmethod
    async def get_by_id(self, product_id: ProductId) -> Product | None: ...

    @abstractmethod
    async def get_by_external_id(
        self, merchant_id: MerchantId, external_id: str
    ) -> Product | None: ...

    @abstractmethod
    async def list_for_merchant(
        self, merchant_id: MerchantId, *, limit: int = 50, offset: int = 0
    ) -> list[Product]: ...

    @abstractmethod
    async def delete(self, product_id: ProductId) -> None: ...


class AnalyticsEventRepository(ABC):
    @abstractmethod
    async def save_batch(self, events: list[AnalyticsEvent]) -> None: ...

    @abstractmethod
    async def count_by_type(
        self,
        merchant_id: MerchantId,
        *,
        start: datetime,
        end: datetime,
    ) -> dict[str, int]:
        """Returns {event_type: count} for the given merchant within [start, end)."""
        ...


class PlanRepository(ABC):
    @abstractmethod
    async def save(self, plan: Plan) -> None: ...

    @abstractmethod
    async def get_by_id(self, plan_id: PlanId) -> Plan | None: ...

    @abstractmethod
    async def get_by_tier(self, tier: PlanTier) -> Plan | None: ...

    @abstractmethod
    async def list_active(self) -> list[Plan]: ...


class SubscriptionRepository(ABC):
    @abstractmethod
    async def save(self, subscription: Subscription) -> None: ...

    @abstractmethod
    async def get_by_id(self, subscription_id: SubscriptionId) -> Subscription | None: ...

    @abstractmethod
    async def get_by_merchant_id(self, merchant_id: MerchantId) -> Subscription | None: ...

    @abstractmethod
    async def get_by_stripe_subscription_id(
        self, stripe_subscription_id: str
    ) -> Subscription | None: ...


class InvoiceRepository(ABC):
    @abstractmethod
    async def save(self, invoice: Invoice) -> None: ...

    @abstractmethod
    async def get_by_id(self, invoice_id: InvoiceId) -> Invoice | None: ...

    @abstractmethod
    async def get_by_stripe_invoice_id(self, stripe_invoice_id: str) -> Invoice | None: ...

    @abstractmethod
    async def list_for_merchant(
        self, merchant_id: MerchantId, *, limit: int = 50, offset: int = 0
    ) -> list[Invoice]: ...


class UsageRecordRepository(ABC):
    @abstractmethod
    async def save(self, usage_record: UsageRecord) -> None: ...

    @abstractmethod
    async def get_by_id(self, usage_record_id: UsageRecordId) -> UsageRecord | None: ...

    @abstractmethod
    async def get_for_merchant_and_date(
        self, merchant_id: MerchantId, usage_date: date
    ) -> UsageRecord | None: ...

    @abstractmethod
    async def list_for_merchant_in_range(
        self, merchant_id: MerchantId, *, start: date, end: date
    ) -> list[UsageRecord]: ...


class CreditNoteRepository(ABC):
    @abstractmethod
    async def save(self, credit_note: CreditNote) -> None: ...

    @abstractmethod
    async def list_for_invoice(self, invoice_id: InvoiceId) -> list[CreditNote]: ...


class WebhookEventRepository(ABC):
    @abstractmethod
    async def get_by_stripe_event_id(self, stripe_event_id: str) -> WebhookEventRecord | None: ...

    @abstractmethod
    async def save(self, record: WebhookEventRecord) -> None: ...


class AuditLogRepository(ABC):
    @abstractmethod
    async def save(self, entry: AuditLog) -> None: ...

    @abstractmethod
    async def list_for_merchant(
        self, merchant_id: MerchantId, *, limit: int = 50, offset: int = 0
    ) -> list[AuditLog]: ...
