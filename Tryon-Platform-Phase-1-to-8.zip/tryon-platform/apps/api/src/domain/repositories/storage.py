"""
Storage port for signed URLs.

Kept deliberately narrow — the domain only needs "give me a URL a customer's
browser can PUT an image to, and a URL an AI provider can GET it from,"
not a general-purpose file storage API. The concrete implementation
(infrastructure/storage/s3_signed_url_provider.py) targets S3-compatible
storage (AWS S3 or Cloudflare R2 per the project's tech stack), but nothing
in application code depends on that.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class SignedUploadUrl:
    upload_url: str
    object_key: str
    expires_in_seconds: int


class SignedUrlProvider(ABC):
    @abstractmethod
    def create_upload_url(self, *, merchant_id: str, content_type: str) -> SignedUploadUrl:
        """Generates a time-limited URL the customer's browser can PUT an image directly to."""
        ...

    @abstractmethod
    def get_object_url(self, object_key: str, *, expires_in_seconds: int = 3600) -> str:
        """Generates a time-limited GET URL for an already-uploaded object (e.g. for a provider)."""
        ...

    @abstractmethod
    def upload_bytes(self, *, key_prefix: str, data: bytes, content_type: str) -> str:
        """
        Uploads bytes directly and returns the resulting object key. Used by
        synchronous AI providers (e.g. OpenAI's image-edit endpoint, which
        returns a result immediately rather than a job to poll) that must
        persist a result to durable storage themselves rather than handing
        back a provider-hosted URL to poll later.
        """
        ...
