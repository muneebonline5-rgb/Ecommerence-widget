"""
PaymentGateway port.

Same pattern as Phase 4's `AIProvider` port: an interface with zero Stripe
SDK imports, so `SubscriptionService`, `WebhookService`, etc. depend only on
this contract. The concrete `StripeGateway` adapter (infrastructure/billing/)
wraps the `stripe` Python SDK; nothing else in the codebase imports it.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime


@dataclass(frozen=True, slots=True)
class GatewayCustomer:
    stripe_customer_id: str
    email: str


@dataclass(frozen=True, slots=True)
class GatewaySubscription:
    stripe_subscription_id: str
    stripe_price_id: str
    status: str
    current_period_start: datetime
    current_period_end: datetime
    cancel_at_period_end: bool
    trial_end: datetime | None = None


@dataclass(frozen=True, slots=True)
class GatewayInvoice:
    stripe_invoice_id: str
    status: str
    amount_due_usd: float
    amount_paid_usd: float
    period_start: datetime
    period_end: datetime
    hosted_invoice_url: str | None = None


@dataclass(frozen=True, slots=True)
class GatewayRefund:
    stripe_refund_id: str
    amount_usd: float
    status: str


@dataclass(frozen=True, slots=True)
class GatewayCreditNote:
    stripe_credit_note_id: str
    amount_usd: float


@dataclass(frozen=True, slots=True)
class GatewayWebhookEvent:
    stripe_event_id: str
    event_type: str
    data: dict = field(default_factory=dict)


class PaymentGateway(ABC):
    @abstractmethod
    async def create_customer(
        self, *, email: str, name: str, metadata: dict[str, str]
    ) -> GatewayCustomer: ...

    @abstractmethod
    async def update_customer_metadata(
        self, stripe_customer_id: str, metadata: dict[str, str]
    ) -> None: ...

    @abstractmethod
    async def get_customer(self, stripe_customer_id: str) -> GatewayCustomer: ...

    @abstractmethod
    async def create_subscription(
        self,
        *,
        stripe_customer_id: str,
        stripe_price_id: str,
        trial_days: int | None = None,
    ) -> GatewaySubscription: ...

    @abstractmethod
    async def update_subscription(
        self,
        stripe_subscription_id: str,
        *,
        new_stripe_price_id: str,
        proration: bool = True,
    ) -> GatewaySubscription:
        """Changes the subscription's price (upgrade/downgrade), with Stripe-computed proration."""
        ...

    @abstractmethod
    async def cancel_subscription(
        self, stripe_subscription_id: str, *, at_period_end: bool
    ) -> GatewaySubscription: ...

    @abstractmethod
    async def reactivate_subscription(self, stripe_subscription_id: str) -> GatewaySubscription:
        """Reverses a scheduled (not-yet-effective) cancel-at-period-end."""
        ...

    @abstractmethod
    async def list_invoices(
        self, stripe_customer_id: str, *, limit: int = 20
    ) -> list[GatewayInvoice]: ...

    @abstractmethod
    async def get_invoice(self, stripe_invoice_id: str) -> GatewayInvoice: ...

    @abstractmethod
    async def issue_refund(
        self, *, stripe_charge_id: str, amount_usd: float | None = None
    ) -> GatewayRefund:
        """A full refund is issued when amount_usd is None."""
        ...

    @abstractmethod
    async def create_credit_note(
        self, *, stripe_invoice_id: str, amount_usd: float, reason: str
    ) -> GatewayCreditNote: ...

    @abstractmethod
    async def report_usage(
        self, stripe_subscription_item_id: str, quantity: int, *, timestamp: datetime
    ) -> None:
        """Reports metered overage usage to Stripe for the current billing period."""
        ...

    @abstractmethod
    def construct_webhook_event(self, payload: bytes, signature_header: str) -> GatewayWebhookEvent:
        """
        Verifies the webhook's HMAC signature and parses it. Synchronous —
        purely local cryptographic verification, no network call. Raises
        `WebhookSignatureError` on a bad/missing signature.
        """
        ...
