"""
AIProvider port.

Every vendor integration (FASHN, OpenAI, Flux, Kling) implements this same
interface. Application code (TryOnGenerationService, the Celery task) talks
only to this contract — switching providers, adding a new one, or running
different providers for different merchants is entirely a matter of which
concrete adapter the factory returns, never a change to business logic.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from src.domain.value_objects.ai_provider import (
    AIProviderName,
    ProviderJobHandle,
    ProviderJobResult,
    TryOnGenerationRequest,
)


class AIProvider(ABC):
    @property
    @abstractmethod
    def name(self) -> AIProviderName: ...

    @abstractmethod
    async def generate_tryon(self, request: TryOnGenerationRequest) -> ProviderJobHandle:
        """
        Submits a generation job. Must raise `ProviderTransientError` for
        retryable failures (timeouts, 5xx, rate limits) and
        `ProviderPermanentError` for failures retrying can never fix
        (rejected image, invalid credentials) — the Celery task's retry
        policy depends on this distinction.
        """
        ...

    @abstractmethod
    async def check_status(self, provider_request_id: str) -> ProviderJobResult: ...

    @abstractmethod
    async def cancel(self, provider_request_id: str) -> None:
        """
        Best-effort cancellation. Providers that don't support cancelling
        an in-flight job (e.g. a provider that only exposes a synchronous
        generate call) should raise `ProviderPermanentError` rather than
        silently no-op, so callers know cancellation didn't actually happen.
        """
        ...


class AIProviderFactory(ABC):
    @abstractmethod
    def get_provider(self, name: AIProviderName) -> AIProvider: ...
