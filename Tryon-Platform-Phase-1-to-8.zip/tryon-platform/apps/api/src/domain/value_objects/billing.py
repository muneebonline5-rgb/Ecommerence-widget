"""
Value objects for the billing domain.

`PlanTier` is deliberately a NEW, separate enum from Phase 1's
`MerchantTier` (FREE/STARTER/GROWTH/ENTERPRISE) rather than a rename of it.
The task calls for "Free, Starter, Pro, Enterprise" billing plans, but
`MerchantTier.GROWTH` is already referenced by existing Phase 1 tests and
persisted data — renaming it to PRO would violate "don't break existing
functionality" for a naming preference alone. `map_plan_tier_to_merchant_tier`
below is the single, explicit place that reconciles the two.
"""

from __future__ import annotations

from enum import Enum


class PlanTier(str, Enum):
    FREE = "free"
    STARTER = "starter"
    PRO = "pro"
    ENTERPRISE = "enterprise"


class BillingInterval(str, Enum):
    MONTHLY = "monthly"
    YEARLY = "yearly"


class SubscriptionStatus(str, Enum):
    TRIALING = "trialing"
    ACTIVE = "active"
    PAST_DUE = "past_due"
    CANCELED = "canceled"


class InvoiceStatus(str, Enum):
    DRAFT = "draft"
    OPEN = "open"
    PAID = "paid"
    VOID = "void"
    UNCOLLECTIBLE = "uncollectible"


def map_plan_tier_to_merchant_tier(plan_tier: PlanTier) -> str:
    """
    The one explicit reconciliation point between the new billing-facing
    `PlanTier` and Phase 1's pre-existing `MerchantTier` string values
    stored on `Merchant.tier`. Returns a raw string (not a `MerchantTier`
    member) so this module has no import dependency on `domain.entities.merchant`.
    """
    return {
        PlanTier.FREE: "free",
        PlanTier.STARTER: "starter",
        PlanTier.PRO: "growth",
        PlanTier.ENTERPRISE: "enterprise",
    }[plan_tier]
