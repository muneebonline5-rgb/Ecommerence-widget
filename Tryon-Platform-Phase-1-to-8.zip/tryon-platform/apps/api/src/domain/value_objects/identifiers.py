"""
Strongly-typed identifier value objects.

Using dedicated types instead of raw UUID/str prevents accidentally passing a
MerchantId where a UserId is expected — a common source of bugs in
multi-tenant systems. All identifiers are UUIDv4 under the hood.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class EntityId:
    """Base class for all typed identifiers. Immutable and hashable."""

    value: uuid.UUID

    @classmethod
    def new(cls) -> EntityId:
        return cls(uuid.uuid4())

    @classmethod
    def from_string(cls, raw: str) -> EntityId:
        try:
            return cls(uuid.UUID(raw))
        except (ValueError, AttributeError, TypeError) as exc:
            raise ValueError(f"Invalid identifier format: {raw!r}") from exc

    def __str__(self) -> str:
        return str(self.value)


class MerchantId(EntityId):
    """Identifies a tenant (ecommerce brand) in the platform."""


class UserId(EntityId):
    """Identifies a dashboard user (may belong to a merchant's team)."""


class ApiKeyId(EntityId):
    """Identifies an issued API key."""


class WidgetSettingsId(EntityId):
    """Identifies a merchant's widget configuration."""


class ProductId(EntityId):
    """Identifies a merchant's product."""


class TryOnSessionId(EntityId):
    """Identifies a customer try-on session."""


class TryOnId(EntityId):
    """Identifies a single try-on attempt (one photo -> one generated result)."""


class AIRequestId(EntityId):
    """Identifies a single request made to an AI provider."""


class PlanId(EntityId):
    """Identifies a billing plan."""


class SubscriptionId(EntityId):
    """Identifies a merchant's subscription to a plan."""


class InvoiceId(EntityId):
    """Identifies a billing invoice."""


class UsageRecordId(EntityId):
    """Identifies a daily usage rollup record."""


class CreditNoteId(EntityId):
    """Identifies a credit note issued against an invoice."""


class WebhookEventId(EntityId):
    """Identifies a processed (or in-flight) inbound Stripe webhook event."""


class RoleId(EntityId):
    """Identifies an RBAC role."""


class AuditLogId(EntityId):
    """Identifies an audit log entry."""


class AnalyticsEventId(EntityId):
    """Identifies a single analytics event."""


class TeamMembershipId(EntityId):
    """Identifies a user's membership on a merchant's team."""


class NotificationId(EntityId):
    """Identifies a notification."""
