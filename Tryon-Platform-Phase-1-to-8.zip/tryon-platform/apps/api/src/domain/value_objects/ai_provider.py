"""
Value objects for the AI provider abstraction.

These are the vocabulary every `AIProvider` adapter speaks, regardless of
which vendor is behind it — the whole point of the abstraction (see
domain/repositories/ai_provider.py) is that application code never touches
a vendor-specific request/response shape directly.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class AIProviderName(str, Enum):
    FASHN = "fashn"
    OPENAI = "openai"
    FLUX = "flux"
    KLING = "kling"


class ProviderRequestStatus(str, Enum):
    """Normalized status vocabulary — each adapter maps its vendor's own status strings to this."""

    QUEUED = "queued"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass(frozen=True, slots=True)
class TryOnGenerationRequest:
    """
    Everything an adapter needs to kick off a generation job. Image
    references are URLs (signed, time-limited S3/R2 URLs — see
    domain/repositories/storage.py) rather than raw bytes, so this object
    stays small and provider adapters never need to buffer image data
    in-process.
    """

    customer_image_url: str
    product_image_url: str
    merchant_reference: str  # opaque string the provider may echo back in webhooks/logs


@dataclass(frozen=True, slots=True)
class ProviderJobHandle:
    """Returned immediately after a generation request is accepted by the provider."""

    provider_request_id: str
    status: ProviderRequestStatus


@dataclass(frozen=True, slots=True)
class ProviderJobResult:
    """Returned from a status check — may still be in progress."""

    status: ProviderRequestStatus
    result_image_url: str | None = None
    error_message: str | None = None
