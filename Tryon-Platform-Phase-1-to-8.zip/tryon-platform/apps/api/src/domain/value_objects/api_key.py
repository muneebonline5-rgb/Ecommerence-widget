"""
API key value object.

Design decision: the *plaintext* key is only ever generated once and returned
to the merchant at creation time. Only a salted hash + a short, non-secret
"prefix" (for display/lookup, e.g. `tk_live_ab12`) are persisted. This mirrors
Stripe's key design and means a database leak alone cannot expose live keys.
"""

from __future__ import annotations

import hashlib
import hmac
import secrets
from dataclasses import dataclass
from enum import Enum


class ApiKeyEnvironment(str, Enum):
    LIVE = "live"
    TEST = "test"


# "tk_" + 4-char environment + "_" + 8-char prefix body = fixed-width prefix.
# Fixed width matters: secrets.token_urlsafe() can itself emit "_" or "-",
# so a prefix cannot be safely recovered by splitting the full key on "_" —
# it must be sliced by this known, constant length instead.
_PREFIX_LENGTH = len("tk_") + 4 + len("_") + 8


@dataclass(frozen=True, slots=True)
class PlaintextApiKey:
    """
    The full, secret key material. Exists transiently in memory only —
    never persisted, logged, or serialized as part of an entity.
    """

    full_key: str
    prefix: str
    environment: ApiKeyEnvironment

    @staticmethod
    def generate(environment: ApiKeyEnvironment) -> PlaintextApiKey:
        # 32 bytes of CSPRNG entropy, url-safe encoded.
        random_part = secrets.token_urlsafe(32)
        prefix = f"tk_{environment.value}_{random_part[:8]}"
        full_key = f"{prefix}_{random_part[8:]}"
        return PlaintextApiKey(full_key=full_key, prefix=prefix, environment=environment)

    @staticmethod
    def extract_prefix(candidate: str) -> str | None:
        """
        Recovers the lookup prefix from a full key using a fixed slice
        length rather than splitting on "_", which is unsafe because the
        random portion of the key can itself contain "_" characters.
        """
        if len(candidate) <= _PREFIX_LENGTH or not candidate.startswith("tk_"):
            return None
        if candidate[_PREFIX_LENGTH] != "_":
            return None
        return candidate[:_PREFIX_LENGTH]


@dataclass(frozen=True, slots=True)
class ApiKeyHash:
    """Persisted representation: irreversible hash + lookup prefix."""

    hash_value: str
    prefix: str

    @staticmethod
    def from_plaintext(plaintext: PlaintextApiKey, pepper: str) -> ApiKeyHash:
        """
        `pepper` is a server-side secret (from environment config, never in DB)
        combined with the key via HMAC-SHA256, so a stolen DB dump is
        insufficient to brute-force or replay keys even offline.
        """
        digest = hmac.new(
            key=pepper.encode("utf-8"),
            msg=plaintext.full_key.encode("utf-8"),
            digestmod=hashlib.sha256,
        ).hexdigest()
        return ApiKeyHash(hash_value=digest, prefix=plaintext.prefix)

    def matches(self, candidate: str, pepper: str) -> bool:
        candidate_digest = hmac.new(
            key=pepper.encode("utf-8"),
            msg=candidate.encode("utf-8"),
            digestmod=hashlib.sha256,
        ).hexdigest()
        # Constant-time comparison to prevent timing attacks.
        return hmac.compare_digest(candidate_digest, self.hash_value)
