"""
Flux (Black Forest Labs) adapter.

Implements BFL's documented async job pattern: POST /v1/flux-kontext-pro
submits an image-editing job and returns a polling URL; GET that URL is
polled until the job reaches a terminal state. See https://docs.bfl.ai/ —
reconcile field names against BFL's current API reference before a
production cutover (see the note in fashn_provider.py re: this
environment's network egress restrictions).
"""

from __future__ import annotations

import httpx

from src.domain.exceptions.base import ProviderPermanentError
from src.domain.repositories.ai_provider import AIProvider
from src.domain.value_objects.ai_provider import (
    AIProviderName,
    ProviderJobHandle,
    ProviderJobResult,
    ProviderRequestStatus,
    TryOnGenerationRequest,
)
from src.infrastructure.ai_providers.base import BaseHttpProviderAdapter

_STATUS_MAP = {
    "Task not found": ProviderRequestStatus.FAILED,
    "Pending": ProviderRequestStatus.QUEUED,
    "Request Moderated": ProviderRequestStatus.FAILED,
    "Content Moderated": ProviderRequestStatus.FAILED,
    "Ready": ProviderRequestStatus.COMPLETED,
    "Error": ProviderRequestStatus.FAILED,
}


class FluxProviderAdapter(BaseHttpProviderAdapter, AIProvider):
    def __init__(self, client: httpx.AsyncClient, *, api_key: str, base_url: str) -> None:
        super().__init__(client, base_url=base_url)
        self._api_key = api_key

    @property
    def name(self) -> AIProviderName:
        return AIProviderName.FLUX

    def _headers(self) -> dict:
        return {"x-key": self._api_key}

    async def generate_tryon(self, request: TryOnGenerationRequest) -> ProviderJobHandle:
        body = await self._request(
            "POST",
            "/v1/flux-kontext-pro",
            provider_name="flux",
            headers=self._headers(),
            json={
                "prompt": (
                    "Photorealistic virtual try-on: dress the person in the reference photo "
                    "with the garment shown in the product image, preserving pose and background."
                ),
                "input_image": request.customer_image_url,
                "input_image_2": request.product_image_url,
            },
        )

        job_id = body.get("id")
        if not job_id:
            raise ProviderPermanentError(
                "flux: response did not include a job id.", details={"provider": "flux"}
            )

        return ProviderJobHandle(provider_request_id=job_id, status=ProviderRequestStatus.QUEUED)

    async def check_status(self, provider_request_id: str) -> ProviderJobResult:
        body = await self._request(
            "GET",
            "/v1/get_result",
            provider_name="flux",
            headers=self._headers(),
            params={"id": provider_request_id},
        )

        raw_status = body.get("status", "")
        status = _STATUS_MAP.get(raw_status)
        if status is None:
            raise ProviderPermanentError(
                f"flux: unrecognized status '{raw_status}'.",
                details={"provider": "flux", "status": raw_status},
            )

        if status == ProviderRequestStatus.COMPLETED:
            result = body.get("result") or {}
            result_url = result.get("sample")
            return ProviderJobResult(status=status, result_image_url=result_url)

        if status == ProviderRequestStatus.FAILED:
            return ProviderJobResult(status=status, error_message=raw_status)

        return ProviderJobResult(status=status)

    async def cancel(self, provider_request_id: str) -> None:
        raise ProviderPermanentError(
            "flux: cancellation is not supported by this provider.",
            details={"provider": "flux"},
        )
