"""
Kling AI adapter.

Implements Kling's documented virtual try-on endpoint and its JWT-bearer
authentication scheme: a short-lived HS256 JWT is signed from an access
key/secret pair (not a static bearer token) and sent as the Authorization
header on every request. Reconcile field names and the exact JWT claim set
against Kling's current API docs before a production cutover (see the note
in fashn_provider.py re: this environment's network egress restrictions).
"""

from __future__ import annotations

import time

import httpx
import jwt as pyjwt

from src.domain.exceptions.base import ProviderPermanentError
from src.domain.repositories.ai_provider import AIProvider
from src.domain.value_objects.ai_provider import (
    AIProviderName,
    ProviderJobHandle,
    ProviderJobResult,
    ProviderRequestStatus,
    TryOnGenerationRequest,
)
from src.infrastructure.ai_providers.base import BaseHttpProviderAdapter

_STATUS_MAP = {
    "submitted": ProviderRequestStatus.QUEUED,
    "processing": ProviderRequestStatus.PROCESSING,
    "succeed": ProviderRequestStatus.COMPLETED,
    "failed": ProviderRequestStatus.FAILED,
}

_TOKEN_TTL_SECONDS = 1800  # Kling requires short-lived tokens; 30 minutes is their documented max.


class KlingProviderAdapter(BaseHttpProviderAdapter, AIProvider):
    def __init__(
        self, client: httpx.AsyncClient, *, access_key: str, secret_key: str, base_url: str
    ) -> None:
        super().__init__(client, base_url=base_url)
        self._access_key = access_key
        self._secret_key = secret_key

    @property
    def name(self) -> AIProviderName:
        return AIProviderName.KLING

    def _headers(self) -> dict:
        return {"Authorization": f"Bearer {self._build_jwt()}"}

    def _build_jwt(self) -> str:
        now = int(time.time())
        claims = {
            "iss": self._access_key,
            "exp": now + _TOKEN_TTL_SECONDS,
            "nbf": now - 5,  # small clock-skew allowance
        }
        return pyjwt.encode(claims, self._secret_key, algorithm="HS256")

    async def generate_tryon(self, request: TryOnGenerationRequest) -> ProviderJobHandle:
        body = await self._request(
            "POST",
            "/v1/images/kolors-virtual-try-on",
            provider_name="kling",
            headers=self._headers(),
            json={
                "model_name": "kolors-virtual-try-on-v1",
                "human_image": request.customer_image_url,
                "cloth_image": request.product_image_url,
            },
        )

        data = body.get("data") or {}
        task_id = data.get("task_id")
        if not task_id:
            raise ProviderPermanentError(
                "kling: response did not include a task_id.", details={"provider": "kling"}
            )

        return ProviderJobHandle(provider_request_id=task_id, status=ProviderRequestStatus.QUEUED)

    async def check_status(self, provider_request_id: str) -> ProviderJobResult:
        body = await self._request(
            "GET",
            f"/v1/images/kolors-virtual-try-on/{provider_request_id}",
            provider_name="kling",
            headers=self._headers(),
        )

        data = body.get("data") or {}
        raw_status = data.get("task_status", "")
        status = _STATUS_MAP.get(raw_status)
        if status is None:
            raise ProviderPermanentError(
                f"kling: unrecognized status '{raw_status}'.",
                details={"provider": "kling", "status": raw_status},
            )

        if status == ProviderRequestStatus.COMPLETED:
            result = data.get("task_result") or {}
            images = result.get("images") or []
            result_url = images[0].get("url") if images else None
            return ProviderJobResult(status=status, result_image_url=result_url)

        if status == ProviderRequestStatus.FAILED:
            message = data.get("task_status_msg", "Kling job failed.")
            return ProviderJobResult(status=status, error_message=message)

        return ProviderJobResult(status=status)

    async def cancel(self, provider_request_id: str) -> None:
        raise ProviderPermanentError(
            "kling: cancellation is not supported by this provider.",
            details={"provider": "kling"},
        )
