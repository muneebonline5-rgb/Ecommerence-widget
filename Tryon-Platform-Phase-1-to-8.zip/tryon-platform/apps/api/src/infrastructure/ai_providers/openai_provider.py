"""
OpenAI adapter.

Unlike the other three providers, OpenAI's image-edit endpoint is
synchronous — it returns the generated image in the same response, with no
job id to poll. To keep this adapter honest to the shared `AIProvider`
interface (submit -> poll) without inventing a fake polling delay, this
adapter does the full round trip inside `generate_tryon` itself and
persists the result to our own storage immediately, returning the storage
object key as the "provider_request_id". `check_status` on that same key is
then just a storage lookup — no second network call, no fake "processing"
state to simulate.

This does mean `generate_tryon` takes noticeably longer for this provider
than for the async ones (it's doing the full generation before returning),
which is a real, load-bearing difference the Celery task's timeout
configuration must account for per-provider (see apps/worker/tasks).
"""

from __future__ import annotations

import base64

import httpx

from src.domain.exceptions.base import ProviderPermanentError, ProviderTransientError
from src.domain.repositories.ai_provider import AIProvider
from src.domain.repositories.storage import SignedUrlProvider
from src.domain.value_objects.ai_provider import (
    AIProviderName,
    ProviderJobHandle,
    ProviderJobResult,
    ProviderRequestStatus,
    TryOnGenerationRequest,
)
from src.infrastructure.ai_providers.base import BaseHttpProviderAdapter


class OpenAIProviderAdapter(BaseHttpProviderAdapter, AIProvider):
    def __init__(
        self,
        client: httpx.AsyncClient,
        storage: SignedUrlProvider,
        *,
        api_key: str,
        base_url: str = "https://api.openai.com",
    ) -> None:
        super().__init__(client, base_url=base_url, timeout_seconds=90.0)
        self._storage = storage
        self._api_key = api_key

    @property
    def name(self) -> AIProviderName:
        return AIProviderName.OPENAI

    async def generate_tryon(self, request: TryOnGenerationRequest) -> ProviderJobHandle:
        customer_image_bytes = await self._fetch_bytes(request.customer_image_url)

        prompt = (
            "Edit this photo of a person so they are wearing the garment shown in the "
            "reference product image, keeping their pose, body, and the background "
            "unchanged. Photorealistic result."
        )

        response = await self._client.post(
            f"{self._base_url}/v1/images/edits",
            headers={"Authorization": f"Bearer {self._api_key}"},
            files={"image": ("customer.png", customer_image_bytes, "image/png")},
            data={"prompt": prompt, "model": "gpt-image-1", "n": "1", "size": "1024x1024"},
            timeout=self._timeout_seconds,
        )

        if response.status_code == 429 or response.status_code >= 500:
            raise ProviderTransientError(
                f"openai returned {response.status_code}", details={"provider": "openai"}
            )
        if response.status_code >= 400:
            raise ProviderPermanentError(
                f"openai rejected the request with {response.status_code}: {response.text[:500]}",
                details={"provider": "openai", "status_code": response.status_code},
            )

        body = response.json()
        images = body.get("data") or []
        if not images or "b64_json" not in images[0]:
            raise ProviderPermanentError(
                "openai: response did not include image data.", details={"provider": "openai"}
            )

        result_bytes = base64.b64decode(images[0]["b64_json"])
        object_key = self._storage.upload_bytes(
            key_prefix="tryon-results/openai", data=result_bytes, content_type="image/png"
        )

        # Already done — see module docstring for why this returns COMPLETED
        # immediately rather than a pollable in-progress state.
        return ProviderJobHandle(
            provider_request_id=object_key, status=ProviderRequestStatus.COMPLETED
        )

    async def check_status(self, provider_request_id: str) -> ProviderJobResult:
        # provider_request_id is our own storage object key at this point
        # (see generate_tryon) — the result already exists, this just
        # resolves a fresh signed URL for it rather than polling OpenAI.
        result_url = self._storage.get_object_url(provider_request_id)
        return ProviderJobResult(
            status=ProviderRequestStatus.COMPLETED, result_image_url=result_url
        )

    async def cancel(self, provider_request_id: str) -> None:
        raise ProviderPermanentError(
            "openai: cancellation is not supported — generation completes synchronously "
            "before a job id ever exists.",
            details={"provider": "openai"},
        )

    async def _fetch_bytes(self, url: str) -> bytes:
        try:
            response = await self._client.get(url, timeout=self._timeout_seconds)
            response.raise_for_status()
        except httpx.HTTPError as exc:
            raise ProviderTransientError(
                f"openai: failed to download source image ({exc})",
                details={"provider": "openai"},
            ) from exc
        return response.content
