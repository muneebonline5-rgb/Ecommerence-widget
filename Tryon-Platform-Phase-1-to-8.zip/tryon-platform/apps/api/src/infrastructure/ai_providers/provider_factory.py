"""
Concrete AIProviderFactory.

A thin registry over already-constructed adapter instances — construction
(API keys, base URLs, HTTP client) happens once at wiring time (see
interfaces/api/dependencies.py and apps/worker/celery_app.py), not per
request, so switching a merchant from one provider to another is purely a
matter of which `AIProviderName` gets passed to `get_provider`, never a
change to how adapters are built.
"""

from __future__ import annotations

from src.domain.exceptions.base import ValidationError
from src.domain.repositories.ai_provider import AIProvider, AIProviderFactory
from src.domain.value_objects.ai_provider import AIProviderName


class RegistryAIProviderFactory(AIProviderFactory):
    def __init__(self, providers: dict[AIProviderName, AIProvider]) -> None:
        self._providers = providers

    def get_provider(self, name: AIProviderName) -> AIProvider:
        provider = self._providers.get(name)
        if provider is None:
            raise ValidationError(
                f"No AI provider is configured for '{name.value}'.",
                details={
                    "provider": name.value,
                    "available": [p.value for p in self._providers],
                },
            )
        return provider
