"""
Shared base for HTTP-backed AI provider adapters.

Every vendor adapter (FASHN, OpenAI, Flux, Kling) needs the same plumbing:
an authenticated httpx client, a timeout, and a mapping from "what went
wrong with this HTTP call" to the domain's ProviderTransientError vs
ProviderPermanentError distinction. Centralizing that here means each
adapter's own file is just "what does this vendor's request/response JSON
look like" — the interesting, vendor-specific part — not another copy of
retry-classification logic.
"""

from __future__ import annotations

import httpx

from src.domain.exceptions.base import (
    ProviderPermanentError,
    ProviderTimeoutError,
    ProviderTransientError,
)


class BaseHttpProviderAdapter:
    def __init__(
        self, client: httpx.AsyncClient, *, base_url: str, timeout_seconds: float = 30.0
    ) -> None:
        self._client = client
        self._base_url = base_url.rstrip("/")
        self._timeout_seconds = timeout_seconds

    async def _request(
        self,
        method: str,
        path: str,
        *,
        provider_name: str,
        json: dict | None = None,
        params: dict | None = None,
        headers: dict | None = None,
    ) -> dict:
        """
        Performs the HTTP call and raises the correctly-classified domain
        exception on failure, so every adapter gets consistent retry
        behavior for free rather than reimplementing this classification.
        """
        url = f"{self._base_url}{path}"
        try:
            response = await self._client.request(
                method,
                url,
                json=json,
                params=params,
                headers=headers,
                timeout=self._timeout_seconds,
            )
        except httpx.TimeoutException as exc:
            raise ProviderTimeoutError(provider_name, self._timeout_seconds) from exc
        except httpx.ConnectError as exc:
            raise ProviderTransientError(
                f"{provider_name}: could not connect ({exc})", details={"provider": provider_name}
            ) from exc
        except httpx.HTTPError as exc:
            raise ProviderTransientError(
                f"{provider_name}: request failed ({exc})", details={"provider": provider_name}
            ) from exc

        if response.status_code == 429 or response.status_code >= 500:
            raise ProviderTransientError(
                f"{provider_name} returned {response.status_code}: {_safe_body(response)}",
                details={"provider": provider_name, "status_code": response.status_code},
            )

        if response.status_code >= 400:
            raise ProviderPermanentError(
                f"{provider_name} rejected the request with {response.status_code}: "
                f"{_safe_body(response)}",
                details={"provider": provider_name, "status_code": response.status_code},
            )

        try:
            return response.json()
        except ValueError as exc:
            raise ProviderTransientError(
                f"{provider_name} returned a non-JSON response.",
                details={"provider": provider_name},
            ) from exc


def _safe_body(response: httpx.Response) -> str:
    try:
        return response.text[:500]
    except Exception:  # noqa: BLE001 - purely defensive, this is for an error message
        return "<unreadable response body>"
