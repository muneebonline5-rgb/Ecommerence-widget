"""
FASHN AI adapter.

Implements FASHN's documented async job pattern: POST /v1/run submits a job
and returns immediately with an id; GET /v1/status/{id} is polled until the
job reaches a terminal state. See https://docs.fashn.ai/ — reconcile field
names against FASHN's current API reference before a production cutover;
this adapter's HTTP contract is verified in tests against mocked responses
matching that documented shape, not against FASHN's live API (this
environment's network egress does not permit calls to third-party APIs).
"""

from __future__ import annotations

import httpx

from src.domain.exceptions.base import ProviderPermanentError
from src.domain.repositories.ai_provider import AIProvider
from src.domain.value_objects.ai_provider import (
    AIProviderName,
    ProviderJobHandle,
    ProviderJobResult,
    ProviderRequestStatus,
    TryOnGenerationRequest,
)
from src.infrastructure.ai_providers.base import BaseHttpProviderAdapter

_STATUS_MAP = {
    "starting": ProviderRequestStatus.QUEUED,
    "in_queue": ProviderRequestStatus.QUEUED,
    "processing": ProviderRequestStatus.PROCESSING,
    "completed": ProviderRequestStatus.COMPLETED,
    "failed": ProviderRequestStatus.FAILED,
}


class FashnProviderAdapter(BaseHttpProviderAdapter, AIProvider):
    def __init__(self, client: httpx.AsyncClient, *, api_key: str, base_url: str) -> None:
        super().__init__(client, base_url=base_url)
        self._api_key = api_key

    @property
    def name(self) -> AIProviderName:
        return AIProviderName.FASHN

    def _headers(self) -> dict:
        return {"Authorization": f"Bearer {self._api_key}"}

    async def generate_tryon(self, request: TryOnGenerationRequest) -> ProviderJobHandle:
        body = await self._request(
            "POST",
            "/v1/run",
            provider_name="fashn",
            headers=self._headers(),
            json={
                "model_name": "tryon-v1.6",
                "inputs": {
                    "model_image": request.customer_image_url,
                    "garment_image": request.product_image_url,
                },
            },
        )

        job_id = body.get("id")
        if not job_id:
            raise ProviderPermanentError(
                "fashn: response did not include a job id.", details={"provider": "fashn"}
            )

        return ProviderJobHandle(provider_request_id=job_id, status=ProviderRequestStatus.QUEUED)

    async def check_status(self, provider_request_id: str) -> ProviderJobResult:
        body = await self._request(
            "GET",
            f"/v1/status/{provider_request_id}",
            provider_name="fashn",
            headers=self._headers(),
        )

        raw_status = body.get("status", "")
        status = _STATUS_MAP.get(raw_status)
        if status is None:
            raise ProviderPermanentError(
                f"fashn: unrecognized status '{raw_status}'.",
                details={"provider": "fashn", "status": raw_status},
            )

        if status == ProviderRequestStatus.COMPLETED:
            output = body.get("output") or []
            result_url = output[0] if output else None
            return ProviderJobResult(status=status, result_image_url=result_url)

        if status == ProviderRequestStatus.FAILED:
            error = body.get("error", {})
            message = error.get("message") if isinstance(error, dict) else str(error)
            return ProviderJobResult(status=status, error_message=message or "FASHN job failed.")

        return ProviderJobResult(status=status)

    async def cancel(self, provider_request_id: str) -> None:
        # FASHN's public API does not expose a cancel endpoint as of this
        # writing — an in-flight job runs to completion regardless.
        raise ProviderPermanentError(
            "fashn: cancellation is not supported by this provider.",
            details={"provider": "fashn"},
        )
