"""
Stripe adapter implementing the PaymentGateway port.

This is the ONLY module in the codebase that imports the `stripe` SDK
directly — everything else (SubscriptionService, WebhookService, etc.)
depends solely on the `PaymentGateway` interface. Uses stripe-python's
`_async` method variants throughout so this stays consistent with the rest
of the async codebase rather than blocking the event loop on synchronous
HTTP calls.
"""

from __future__ import annotations

from datetime import UTC, datetime

import stripe

from src.domain.exceptions.base import PaymentGatewayError, WebhookSignatureError
from src.domain.repositories.payment_gateway import (
    GatewayCreditNote,
    GatewayCustomer,
    GatewayInvoice,
    GatewayRefund,
    GatewaySubscription,
    GatewayWebhookEvent,
    PaymentGateway,
)

_VALID_CREDIT_NOTE_REASONS = {
    "duplicate",
    "fraudulent",
    "order_change",
    "product_unsatisfactory",
}


class StripeGateway(PaymentGateway):
    def __init__(self, api_key: str, webhook_secret: str) -> None:
        self._client = stripe.StripeClient(api_key)
        self._webhook_secret = webhook_secret

    async def create_customer(
        self, *, email: str, name: str, metadata: dict[str, str]
    ) -> GatewayCustomer:
        try:
            customer = await self._client.customers.create_async(
                {"email": email, "name": name, "metadata": metadata}
            )
        except stripe.StripeError as exc:
            raise PaymentGatewayError(f"Failed to create Stripe customer: {exc}") from exc
        return GatewayCustomer(stripe_customer_id=customer.id, email=customer.email or email)

    async def update_customer_metadata(
        self, stripe_customer_id: str, metadata: dict[str, str]
    ) -> None:
        try:
            await self._client.customers.update_async(stripe_customer_id, {"metadata": metadata})
        except stripe.StripeError as exc:
            raise PaymentGatewayError(f"Failed to update Stripe customer: {exc}") from exc

    async def get_customer(self, stripe_customer_id: str) -> GatewayCustomer:
        try:
            customer = await self._client.customers.retrieve_async(stripe_customer_id)
        except stripe.StripeError as exc:
            raise PaymentGatewayError(f"Failed to retrieve Stripe customer: {exc}") from exc
        return GatewayCustomer(stripe_customer_id=customer.id, email=customer.email or "")

    async def create_subscription(
        self,
        *,
        stripe_customer_id: str,
        stripe_price_id: str,
        trial_days: int | None = None,
    ) -> GatewaySubscription:
        params: dict = {
            "customer": stripe_customer_id,
            "items": [{"price": stripe_price_id}],
            "expand": ["latest_invoice.payment_intent"],
        }
        if trial_days is not None and trial_days > 0:
            params["trial_period_days"] = trial_days

        try:
            subscription = await self._client.subscriptions.create_async(params)
        except stripe.StripeError as exc:
            raise PaymentGatewayError(f"Failed to create Stripe subscription: {exc}") from exc
        return self._to_gateway_subscription(subscription, stripe_price_id)

    async def update_subscription(
        self,
        stripe_subscription_id: str,
        *,
        new_stripe_price_id: str,
        proration: bool = True,
    ) -> GatewaySubscription:
        try:
            subscription = await self._client.subscriptions.retrieve_async(stripe_subscription_id)
            item_id = subscription["items"]["data"][0]["id"]
            updated = await self._client.subscriptions.update_async(
                stripe_subscription_id,
                {
                    "items": [{"id": item_id, "price": new_stripe_price_id}],
                    "proration_behavior": "create_prorations" if proration else "none",
                },
            )
        except stripe.StripeError as exc:
            raise PaymentGatewayError(f"Failed to update Stripe subscription: {exc}") from exc
        return self._to_gateway_subscription(updated, new_stripe_price_id)

    async def cancel_subscription(
        self, stripe_subscription_id: str, *, at_period_end: bool
    ) -> GatewaySubscription:
        try:
            if at_period_end:
                subscription = await self._client.subscriptions.update_async(
                    stripe_subscription_id, {"cancel_at_period_end": True}
                )
            else:
                subscription = await self._client.subscriptions.cancel_async(stripe_subscription_id)
        except stripe.StripeError as exc:
            raise PaymentGatewayError(f"Failed to cancel Stripe subscription: {exc}") from exc
        price_id = subscription["items"]["data"][0]["price"]["id"]
        return self._to_gateway_subscription(subscription, price_id)

    async def reactivate_subscription(self, stripe_subscription_id: str) -> GatewaySubscription:
        try:
            subscription = await self._client.subscriptions.update_async(
                stripe_subscription_id, {"cancel_at_period_end": False}
            )
        except stripe.StripeError as exc:
            raise PaymentGatewayError(f"Failed to reactivate Stripe subscription: {exc}") from exc
        price_id = subscription["items"]["data"][0]["price"]["id"]
        return self._to_gateway_subscription(subscription, price_id)

    async def list_invoices(
        self, stripe_customer_id: str, *, limit: int = 20
    ) -> list[GatewayInvoice]:
        try:
            invoices = await self._client.invoices.list_async(
                {"customer": stripe_customer_id, "limit": limit}
            )
        except stripe.StripeError as exc:
            raise PaymentGatewayError(f"Failed to list Stripe invoices: {exc}") from exc
        return [self._to_gateway_invoice(inv) for inv in invoices.data]

    async def get_invoice(self, stripe_invoice_id: str) -> GatewayInvoice:
        try:
            invoice = await self._client.invoices.retrieve_async(stripe_invoice_id)
        except stripe.StripeError as exc:
            raise PaymentGatewayError(f"Failed to retrieve Stripe invoice: {exc}") from exc
        return self._to_gateway_invoice(invoice)

    async def issue_refund(
        self, *, stripe_charge_id: str, amount_usd: float | None = None
    ) -> GatewayRefund:
        params: dict = {"charge": stripe_charge_id}
        if amount_usd is not None:
            params["amount"] = round(amount_usd * 100)
        try:
            refund = await self._client.refunds.create_async(params)
        except stripe.StripeError as exc:
            raise PaymentGatewayError(f"Failed to issue Stripe refund: {exc}") from exc
        return GatewayRefund(
            stripe_refund_id=refund.id, amount_usd=refund.amount / 100, status=refund.status
        )

    async def create_credit_note(
        self, *, stripe_invoice_id: str, amount_usd: float, reason: str
    ) -> GatewayCreditNote:
        normalized_reason = reason.strip().lower().replace(" ", "_")
        stripe_reason = (
            normalized_reason if normalized_reason in _VALID_CREDIT_NOTE_REASONS else "order_change"
        )
        try:
            credit_note = await self._client.credit_notes.create_async(
                {
                    "invoice": stripe_invoice_id,
                    "amount": round(amount_usd * 100),
                    "reason": stripe_reason,
                }
            )
        except stripe.StripeError as exc:
            raise PaymentGatewayError(f"Failed to create Stripe credit note: {exc}") from exc
        return GatewayCreditNote(
            stripe_credit_note_id=credit_note.id, amount_usd=credit_note.amount / 100
        )

    async def report_usage(
        self, stripe_subscription_item_id: str, quantity: int, *, timestamp: datetime
    ) -> None:
        try:
            await self._client.subscription_items.usage_records.create_async(
                stripe_subscription_item_id,
                {
                    "quantity": quantity,
                    "timestamp": int(timestamp.timestamp()),
                    "action": "increment",
                },
            )
        except stripe.StripeError as exc:
            raise PaymentGatewayError(f"Failed to report usage to Stripe: {exc}") from exc

    def construct_webhook_event(self, payload: bytes, signature_header: str) -> GatewayWebhookEvent:
        try:
            event = stripe.Webhook.construct_event(payload, signature_header, self._webhook_secret)
        except (ValueError, stripe.SignatureVerificationError) as exc:
            raise WebhookSignatureError() from exc
        return GatewayWebhookEvent(
            stripe_event_id=event["id"], event_type=event["type"], data=event["data"]["object"]
        )

    @staticmethod
    def _to_gateway_subscription(subscription, price_id: str) -> GatewaySubscription:
        return GatewaySubscription(
            stripe_subscription_id=subscription["id"],
            stripe_price_id=price_id,
            status=subscription["status"],
            current_period_start=datetime.fromtimestamp(
                subscription["current_period_start"], tz=UTC
            ),
            current_period_end=datetime.fromtimestamp(subscription["current_period_end"], tz=UTC),
            cancel_at_period_end=subscription["cancel_at_period_end"],
            trial_end=(
                datetime.fromtimestamp(subscription["trial_end"], tz=UTC)
                if subscription.get("trial_end")
                else None
            ),
        )

    @staticmethod
    def _to_gateway_invoice(invoice) -> GatewayInvoice:
        return GatewayInvoice(
            stripe_invoice_id=invoice["id"],
            status=invoice["status"] or "draft",
            amount_due_usd=invoice["amount_due"] / 100,
            amount_paid_usd=invoice["amount_paid"] / 100,
            period_start=datetime.fromtimestamp(invoice["period_start"], tz=UTC),
            period_end=datetime.fromtimestamp(invoice["period_end"], tz=UTC),
            hosted_invoice_url=invoice.get("hosted_invoice_url"),
        )
