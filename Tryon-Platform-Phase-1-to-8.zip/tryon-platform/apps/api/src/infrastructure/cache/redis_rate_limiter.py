"""
Fixed-window rate limiter backed by Redis.

Algorithm: fixed window counter, not sliding window/log. Trade-off, stated
plainly: a client can burst up to ~2x the limit across a window boundary
(e.g. the last request of one window and the first of the next both landing
within a short real-world interval). This is the standard, well-understood
trade-off fixed-window counters make in exchange for O(1) memory per key and
a single round trip per check — appropriate for protecting against sustained
abuse, which is what Phase 2 needs. A sliding-window-log implementation can
replace this later behind the same `RateLimiter` port with zero changes to
any caller, if bursty edge cases become a real problem in production.

INCR and EXPIRE are combined into one Lua script so they execute atomically
on the Redis server — without this, a process crash between the two calls
would leave a counter key with no expiry, leaking memory and permanently
locking out that key.
"""

from __future__ import annotations

import time

from redis.asyncio import Redis

from src.domain.repositories.rate_limiter import RateLimiter, RateLimitResult

_INCR_AND_EXPIRE_SCRIPT = """
local current = redis.call('INCR', KEYS[1])
if current == 1 then
    redis.call('EXPIRE', KEYS[1], ARGV[1])
end
return current
"""


class RedisRateLimiter(RateLimiter):
    def __init__(self, redis: Redis) -> None:
        self._redis = redis
        self._script = redis.register_script(_INCR_AND_EXPIRE_SCRIPT)

    async def check(self, key: str, *, limit: int, window_seconds: int) -> RateLimitResult:
        now = time.time()
        window_index = int(now // window_seconds)
        redis_key = f"rate_limit:{key}:{window_index}"

        current_count = await self._script(keys=[redis_key], args=[window_seconds])

        remaining = max(0, limit - current_count)
        seconds_into_window = now % window_seconds
        retry_after = max(0, int(window_seconds - seconds_into_window))

        return RateLimitResult(
            allowed=current_count <= limit,
            limit=limit,
            remaining=remaining,
            retry_after_seconds=retry_after,
        )
