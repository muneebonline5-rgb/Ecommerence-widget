"""
Redis distributed lock, used by the Celery task to guarantee only one
worker process is ever actively processing a given AIRequest at a time.

This matters because message brokers (including Redis-as-broker, used
here) provide at-least-once delivery: a task can be redelivered and run
concurrently with an earlier, still-running attempt (e.g. after a visibility
timeout during a slow provider call). Without this lock, two workers could
both call a paid AI provider for the same AIRequest simultaneously — the DB
status check alone isn't sufficient protection against that race, since
both workers could read "not yet submitted" before either writes back.
"""

from __future__ import annotations

import uuid

from redis.asyncio import Redis

_UNLOCK_SCRIPT = """
if redis.call("get", KEYS[1]) == ARGV[1] then
    return redis.call("del", KEYS[1])
else
    return 0
end
"""


class RedisLock:
    def __init__(self, redis: Redis, key: str, ttl_seconds: int) -> None:
        self._redis = redis
        self._key = f"lock:{key}"
        self._ttl_seconds = ttl_seconds
        self._token = str(uuid.uuid4())

    async def acquire(self) -> bool:
        # NX+EX in one call: atomically "set only if not already set, with an
        # expiry" — the expiry is the failure-recovery mechanism itself: if
        # a worker crashes mid-task, the lock self-releases after ttl rather
        # than deadlocking that AIRequest forever.
        acquired = await self._redis.set(self._key, self._token, nx=True, ex=self._ttl_seconds)
        return bool(acquired)

    async def release(self) -> None:
        # Only releases the lock if it still holds OUR token — protects
        # against releasing a lock that expired and was re-acquired by a
        # different worker in the meantime.
        script = self._redis.register_script(_UNLOCK_SCRIPT)
        await script(keys=[self._key], args=[self._token])
