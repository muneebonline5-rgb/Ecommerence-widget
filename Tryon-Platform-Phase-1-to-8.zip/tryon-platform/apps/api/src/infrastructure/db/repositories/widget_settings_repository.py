from __future__ import annotations

from dataclasses import asdict

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.domain.entities.widget_settings import (
    WidgetButtonShape,
    WidgetPosition,
    WidgetSettings,
    WidgetTheme,
)
from src.domain.repositories.interfaces import WidgetSettingsRepository
from src.domain.value_objects.identifiers import MerchantId, WidgetSettingsId
from src.infrastructure.db.models.widget import WidgetSettingsModel


class SqlAlchemyWidgetSettingsRepository(WidgetSettingsRepository):
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def save(self, settings: WidgetSettings) -> None:
        model = await self._session.get(WidgetSettingsModel, settings.id.value)
        if model is None:
            model = WidgetSettingsModel(
                id=settings.id.value, merchant_id=settings.merchant_id.value
            )
            self._session.add(model)

        model.is_enabled = settings.is_enabled
        model.position = settings.position.value
        model.button_label = settings.button_label
        model.allowed_origins = settings.allowed_origins
        model.sdk_version_pin = settings.sdk_version_pin
        theme_dict = asdict(settings.theme)
        theme_dict["button_shape"] = settings.theme.button_shape.value
        model.theme = theme_dict
        await self._session.flush()

    async def get_by_id(self, settings_id: WidgetSettingsId) -> WidgetSettings | None:
        model = await self._session.get(WidgetSettingsModel, settings_id.value)
        return self._to_entity(model) if model else None

    async def get_by_merchant_id(self, merchant_id: MerchantId) -> WidgetSettings | None:
        stmt = select(WidgetSettingsModel).where(
            WidgetSettingsModel.merchant_id == merchant_id.value
        )
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()
        return self._to_entity(model) if model else None

    @staticmethod
    def _to_entity(model: WidgetSettingsModel) -> WidgetSettings:
        theme_data = dict(model.theme)
        button_shape = WidgetButtonShape(theme_data.pop("button_shape", "circle"))
        theme = WidgetTheme(button_shape=button_shape, **theme_data)
        return WidgetSettings(
            id=WidgetSettingsId(model.id),
            merchant_id=MerchantId(model.merchant_id),
            is_enabled=model.is_enabled,
            position=WidgetPosition(model.position),
            theme=theme,
            button_label=model.button_label,
            allowed_origins=list(model.allowed_origins or []),
            sdk_version_pin=model.sdk_version_pin,
            created_at=model.created_at,
            updated_at=model.updated_at,
        )
