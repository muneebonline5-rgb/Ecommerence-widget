from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.domain.entities.api_key import ApiKey, ApiKeyStatus
from src.domain.repositories.interfaces import ApiKeyRepository
from src.domain.value_objects.api_key import ApiKeyEnvironment, ApiKeyHash
from src.domain.value_objects.identifiers import ApiKeyId, MerchantId
from src.infrastructure.db.models.tenancy import ApiKeyModel


class SqlAlchemyApiKeyRepository(ApiKeyRepository):
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def save(self, api_key: ApiKey) -> None:
        model = await self._session.get(ApiKeyModel, api_key.id.value)
        if model is None:
            model = ApiKeyModel(id=api_key.id.value, merchant_id=api_key.merchant_id.value)
            self._session.add(model)

        model.label = api_key.label
        model.environment = api_key.environment.value
        model.key_prefix = api_key.key_hash.prefix
        model.key_hash = api_key.key_hash.hash_value
        model.status = api_key.status.value
        model.last_used_at = api_key.last_used_at
        model.revoked_at = api_key.revoked_at
        await self._session.flush()

    async def get_by_id(self, api_key_id: ApiKeyId) -> ApiKey | None:
        model = await self._session.get(ApiKeyModel, api_key_id.value)
        return self._to_entity(model) if model else None

    async def get_by_prefix(self, prefix: str) -> ApiKey | None:
        stmt = select(ApiKeyModel).where(ApiKeyModel.key_prefix == prefix)
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()
        return self._to_entity(model) if model else None

    async def list_for_merchant(self, merchant_id: MerchantId) -> list[ApiKey]:
        stmt = (
            select(ApiKeyModel)
            .where(ApiKeyModel.merchant_id == merchant_id.value)
            .order_by(ApiKeyModel.created_at.desc())
        )
        result = await self._session.execute(stmt)
        return [self._to_entity(m) for m in result.scalars().all()]

    @staticmethod
    def _to_entity(model: ApiKeyModel) -> ApiKey:
        return ApiKey(
            id=ApiKeyId(model.id),
            merchant_id=MerchantId(model.merchant_id),
            label=model.label,
            environment=ApiKeyEnvironment(model.environment),
            key_hash=ApiKeyHash(hash_value=model.key_hash, prefix=model.key_prefix),
            status=ApiKeyStatus(model.status),
            created_at=model.created_at,
            last_used_at=model.last_used_at,
            revoked_at=model.revoked_at,
        )
