from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.domain.entities.tryon import TryOn, TryOnStatus
from src.domain.repositories.interfaces import TryOnRepository
from src.domain.value_objects.identifiers import TryOnId, TryOnSessionId
from src.infrastructure.db.models.tryon import TryOnModel


class SqlAlchemyTryOnRepository(TryOnRepository):
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def save(self, tryon: TryOn) -> None:
        model = await self._session.get(TryOnModel, tryon.id.value)
        if model is None:
            model = TryOnModel(
                id=tryon.id.value,
                session_id=tryon.session_id.value,
                customer_image_key=tryon.customer_image_key,
            )
            self._session.add(model)

        model.result_image_key = tryon.result_image_key
        model.status = tryon.status.value
        model.error_message = tryon.error_message
        model.was_downloaded = tryon.was_downloaded
        await self._session.flush()

    async def get_by_id(self, tryon_id: TryOnId) -> TryOn | None:
        model = await self._session.get(TryOnModel, tryon_id.value)
        return self._to_entity(model) if model else None

    async def list_for_session(self, session_id: TryOnSessionId) -> list[TryOn]:
        stmt = select(TryOnModel).where(TryOnModel.session_id == session_id.value)
        result = await self._session.execute(stmt)
        return [self._to_entity(m) for m in result.scalars().all()]

    @staticmethod
    def _to_entity(model: TryOnModel) -> TryOn:
        return TryOn(
            id=TryOnId(model.id),
            session_id=TryOnSessionId(model.session_id),
            customer_image_key=model.customer_image_key,
            status=TryOnStatus(model.status),
            created_at=model.created_at,
            updated_at=model.updated_at,
            result_image_key=model.result_image_key,
            error_message=model.error_message,
            was_downloaded=model.was_downloaded,
        )
