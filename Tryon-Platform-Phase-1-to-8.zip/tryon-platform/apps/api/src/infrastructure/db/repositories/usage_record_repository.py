from __future__ import annotations

from datetime import date

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.domain.entities.usage_record import UsageRecord
from src.domain.repositories.interfaces import UsageRecordRepository
from src.domain.value_objects.identifiers import MerchantId, UsageRecordId
from src.infrastructure.db.models.billing import UsageRecordModel


class SqlAlchemyUsageRecordRepository(UsageRecordRepository):
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def save(self, usage_record: UsageRecord) -> None:
        model = await self._session.get(UsageRecordModel, usage_record.id.value)
        if model is None:
            model = UsageRecordModel(
                id=usage_record.id.value,
                merchant_id=usage_record.merchant_id.value,
                usage_date=usage_record.usage_date,
            )
            self._session.add(model)

        model.generations_count = usage_record.generations_count
        model.breakdown_by_provider = usage_record.breakdown_by_provider
        await self._session.flush()

    async def get_by_id(self, usage_record_id: UsageRecordId) -> UsageRecord | None:
        model = await self._session.get(UsageRecordModel, usage_record_id.value)
        return self._to_entity(model) if model else None

    async def get_for_merchant_and_date(
        self, merchant_id: MerchantId, usage_date: date
    ) -> UsageRecord | None:
        stmt = select(UsageRecordModel).where(
            UsageRecordModel.merchant_id == merchant_id.value,
            UsageRecordModel.usage_date == usage_date,
        )
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()
        return self._to_entity(model) if model else None

    async def list_for_merchant_in_range(
        self, merchant_id: MerchantId, *, start: date, end: date
    ) -> list[UsageRecord]:
        stmt = (
            select(UsageRecordModel)
            .where(
                UsageRecordModel.merchant_id == merchant_id.value,
                UsageRecordModel.usage_date >= start,
                UsageRecordModel.usage_date <= end,
            )
            .order_by(UsageRecordModel.usage_date)
        )
        result = await self._session.execute(stmt)
        return [self._to_entity(m) for m in result.scalars().all()]

    @staticmethod
    def _to_entity(model: UsageRecordModel) -> UsageRecord:
        return UsageRecord(
            id=UsageRecordId(model.id),
            merchant_id=MerchantId(model.merchant_id),
            usage_date=model.usage_date,
            generations_count=model.generations_count,
            breakdown_by_provider=dict(model.breakdown_by_provider or {}),
            created_at=model.created_at,
            updated_at=model.updated_at,
        )
