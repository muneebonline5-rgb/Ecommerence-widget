from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.domain.entities.invoice import Invoice
from src.domain.repositories.interfaces import InvoiceRepository
from src.domain.value_objects.billing import InvoiceStatus
from src.domain.value_objects.identifiers import InvoiceId, MerchantId
from src.infrastructure.db.models.billing import InvoiceModel


class SqlAlchemyInvoiceRepository(InvoiceRepository):
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def save(self, invoice: Invoice) -> None:
        model = await self._session.get(InvoiceModel, invoice.id.value)
        if model is None:
            model = InvoiceModel(id=invoice.id.value, merchant_id=invoice.merchant_id.value)
            self._session.add(model)

        model.stripe_invoice_id = invoice.stripe_invoice_id
        model.status = invoice.status.value
        model.amount_due_usd = invoice.amount_due_usd
        model.amount_paid_usd = invoice.amount_paid_usd
        model.hosted_invoice_url = invoice.hosted_invoice_url
        model.period_start = invoice.period_start
        model.period_end = invoice.period_end
        await self._session.flush()

    async def get_by_id(self, invoice_id: InvoiceId) -> Invoice | None:
        model = await self._session.get(InvoiceModel, invoice_id.value)
        return self._to_entity(model) if model else None

    async def get_by_stripe_invoice_id(self, stripe_invoice_id: str) -> Invoice | None:
        stmt = select(InvoiceModel).where(InvoiceModel.stripe_invoice_id == stripe_invoice_id)
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()
        return self._to_entity(model) if model else None

    async def list_for_merchant(
        self, merchant_id: MerchantId, *, limit: int = 50, offset: int = 0
    ) -> list[Invoice]:
        stmt = (
            select(InvoiceModel)
            .where(InvoiceModel.merchant_id == merchant_id.value)
            .order_by(InvoiceModel.created_at.desc())
            .limit(limit)
            .offset(offset)
        )
        result = await self._session.execute(stmt)
        return [self._to_entity(m) for m in result.scalars().all()]

    @staticmethod
    def _to_entity(model: InvoiceModel) -> Invoice:
        return Invoice(
            id=InvoiceId(model.id),
            merchant_id=MerchantId(model.merchant_id),
            stripe_invoice_id=model.stripe_invoice_id,
            status=InvoiceStatus(model.status),
            amount_due_usd=float(model.amount_due_usd),
            amount_paid_usd=float(model.amount_paid_usd),
            period_start=model.period_start,
            period_end=model.period_end,
            hosted_invoice_url=model.hosted_invoice_url,
            created_at=model.created_at,
            updated_at=model.updated_at,
        )
