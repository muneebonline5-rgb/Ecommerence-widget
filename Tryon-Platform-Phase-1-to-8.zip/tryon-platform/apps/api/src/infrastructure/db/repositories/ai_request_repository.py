from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.domain.entities.ai_request import AIRequest
from src.domain.repositories.interfaces import AIRequestRepository
from src.domain.value_objects.ai_provider import AIProviderName, ProviderRequestStatus
from src.domain.value_objects.identifiers import AIRequestId, MerchantId, TryOnId
from src.infrastructure.db.models.tryon import AIRequestModel


class SqlAlchemyAIRequestRepository(AIRequestRepository):
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def save(self, ai_request: AIRequest) -> None:
        model = await self._session.get(AIRequestModel, ai_request.id.value)
        if model is None:
            model = AIRequestModel(
                id=ai_request.id.value,
                tryon_id=ai_request.tryon_id.value,
                merchant_id=ai_request.merchant_id.value,
                idempotency_key=ai_request.idempotency_key,
            )
            self._session.add(model)

        model.provider = ai_request.provider.value
        model.provider_request_id = ai_request.provider_request_id
        model.status = ai_request.status.value
        model.latency_ms = ai_request.latency_ms
        model.cost_usd = ai_request.cost_usd
        model.request_payload = ai_request.request_payload
        model.response_payload = ai_request.response_payload
        await self._session.flush()

    async def get_by_id(self, ai_request_id: AIRequestId) -> AIRequest | None:
        model = await self._session.get(AIRequestModel, ai_request_id.value)
        return self._to_entity(model) if model else None

    async def get_by_idempotency_key(
        self, merchant_id: MerchantId, idempotency_key: str
    ) -> AIRequest | None:
        stmt = select(AIRequestModel).where(
            AIRequestModel.merchant_id == merchant_id.value,
            AIRequestModel.idempotency_key == idempotency_key,
        )
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()
        return self._to_entity(model) if model else None

    async def get_by_tryon_id(self, tryon_id: TryOnId) -> AIRequest | None:
        stmt = select(AIRequestModel).where(AIRequestModel.tryon_id == tryon_id.value)
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()
        return self._to_entity(model) if model else None

    @staticmethod
    def _to_entity(model: AIRequestModel) -> AIRequest:
        return AIRequest(
            id=AIRequestId(model.id),
            tryon_id=TryOnId(model.tryon_id),
            merchant_id=MerchantId(model.merchant_id),
            provider=AIProviderName(model.provider),
            idempotency_key=model.idempotency_key,
            status=ProviderRequestStatus(model.status),
            created_at=model.created_at,
            updated_at=model.updated_at,
            provider_request_id=model.provider_request_id,
            latency_ms=model.latency_ms,
            cost_usd=float(model.cost_usd) if model.cost_usd is not None else None,
            request_payload=dict(model.request_payload or {}),
            response_payload=dict(model.response_payload or {}),
        )
