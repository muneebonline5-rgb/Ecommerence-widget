from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.domain.entities.role import Role
from src.domain.repositories.interfaces import RoleRepository
from src.domain.value_objects.identifiers import RoleId
from src.infrastructure.db.models.tenancy import RoleModel


class SqlAlchemyRoleRepository(RoleRepository):
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def save(self, role: Role) -> None:
        model = await self._session.get(RoleModel, role.id.value)
        if model is None:
            model = RoleModel(id=role.id.value)
            self._session.add(model)

        model.name = role.name
        model.description = role.description
        model.permission_codes = list(role.permission_codes)
        await self._session.flush()

    async def get_by_id(self, role_id: RoleId) -> Role | None:
        model = await self._session.get(RoleModel, role_id.value)
        return self._to_entity(model) if model else None

    async def get_by_name(self, name: str) -> Role | None:
        stmt = select(RoleModel).where(RoleModel.name == name.strip())
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()
        return self._to_entity(model) if model else None

    async def list_all(self) -> list[Role]:
        stmt = select(RoleModel).order_by(RoleModel.name)
        result = await self._session.execute(stmt)
        return [self._to_entity(m) for m in result.scalars().all()]

    @staticmethod
    def _to_entity(model: RoleModel) -> Role:
        return Role(
            id=RoleId(model.id),
            name=model.name,
            description=model.description,
            permission_codes=list(model.permission_codes or []),
            created_at=model.created_at,
            updated_at=model.updated_at,
        )
