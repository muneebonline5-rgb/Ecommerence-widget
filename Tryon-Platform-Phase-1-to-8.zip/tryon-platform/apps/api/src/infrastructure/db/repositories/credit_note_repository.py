from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.domain.entities.credit_note import CreditNote
from src.domain.repositories.interfaces import CreditNoteRepository
from src.domain.value_objects.identifiers import CreditNoteId, InvoiceId, MerchantId
from src.infrastructure.db.models.billing import CreditNoteModel


class SqlAlchemyCreditNoteRepository(CreditNoteRepository):
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def save(self, credit_note: CreditNote) -> None:
        model = await self._session.get(CreditNoteModel, credit_note.id.value)
        if model is None:
            model = CreditNoteModel(
                id=credit_note.id.value,
                merchant_id=credit_note.merchant_id.value,
                invoice_id=credit_note.invoice_id.value,
                stripe_credit_note_id=credit_note.stripe_credit_note_id,
                amount_usd=credit_note.amount_usd,
                reason=credit_note.reason,
                created_at=credit_note.created_at,
            )
            self._session.add(model)
        await self._session.flush()

    async def list_for_invoice(self, invoice_id: InvoiceId) -> list[CreditNote]:
        stmt = select(CreditNoteModel).where(CreditNoteModel.invoice_id == invoice_id.value)
        result = await self._session.execute(stmt)
        return [self._to_entity(m) for m in result.scalars().all()]

    @staticmethod
    def _to_entity(model: CreditNoteModel) -> CreditNote:
        return CreditNote(
            id=CreditNoteId(model.id),
            merchant_id=MerchantId(model.merchant_id),
            invoice_id=InvoiceId(model.invoice_id),
            stripe_credit_note_id=model.stripe_credit_note_id,
            amount_usd=float(model.amount_usd),
            reason=model.reason,
            created_at=model.created_at,
        )
