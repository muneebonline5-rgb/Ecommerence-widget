from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.domain.entities.product import Product
from src.domain.repositories.interfaces import ProductRepository
from src.domain.value_objects.identifiers import MerchantId, ProductId
from src.infrastructure.db.models.catalog import ProductModel


class SqlAlchemyProductRepository(ProductRepository):
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def save(self, product: Product) -> None:
        model = await self._session.get(ProductModel, product.id.value)
        if model is None:
            model = ProductModel(
                id=product.id.value,
                merchant_id=product.merchant_id.value,
                external_id=product.external_id,
            )
            self._session.add(model)

        model.title = product.title
        model.product_url = product.product_url
        model.image_url = product.image_url
        model.category = product.category
        model.is_try_on_eligible = product.is_try_on_eligible
        model.metadata_json = product.metadata
        await self._session.flush()

    async def get_by_id(self, product_id: ProductId) -> Product | None:
        model = await self._session.get(ProductModel, product_id.value)
        return self._to_entity(model) if model else None

    async def get_by_external_id(self, merchant_id: MerchantId, external_id: str) -> Product | None:
        stmt = select(ProductModel).where(
            ProductModel.merchant_id == merchant_id.value,
            ProductModel.external_id == external_id,
        )
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()
        return self._to_entity(model) if model else None

    async def list_for_merchant(
        self, merchant_id: MerchantId, *, limit: int = 50, offset: int = 0
    ) -> list[Product]:
        stmt = (
            select(ProductModel)
            .where(ProductModel.merchant_id == merchant_id.value)
            .order_by(ProductModel.created_at.desc())
            .limit(limit)
            .offset(offset)
        )
        result = await self._session.execute(stmt)
        return [self._to_entity(m) for m in result.scalars().all()]

    async def delete(self, product_id: ProductId) -> None:
        model = await self._session.get(ProductModel, product_id.value)
        if model is not None:
            await self._session.delete(model)
            await self._session.flush()

    @staticmethod
    def _to_entity(model: ProductModel) -> Product:
        return Product(
            id=ProductId(model.id),
            merchant_id=MerchantId(model.merchant_id),
            external_id=model.external_id,
            title=model.title,
            product_url=model.product_url,
            image_url=model.image_url,
            category=model.category,
            is_try_on_eligible=model.is_try_on_eligible,
            metadata=dict(model.metadata_json or {}),
            created_at=model.created_at,
            updated_at=model.updated_at,
        )
