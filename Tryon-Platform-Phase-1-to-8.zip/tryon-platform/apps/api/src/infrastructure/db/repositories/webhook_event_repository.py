from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.domain.entities.webhook_event import WebhookEventRecord
from src.domain.repositories.interfaces import WebhookEventRepository
from src.domain.value_objects.identifiers import WebhookEventId
from src.infrastructure.db.models.billing import StripeWebhookEventModel


class SqlAlchemyWebhookEventRepository(WebhookEventRepository):
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def get_by_stripe_event_id(self, stripe_event_id: str) -> WebhookEventRecord | None:
        stmt = select(StripeWebhookEventModel).where(
            StripeWebhookEventModel.stripe_event_id == stripe_event_id
        )
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()
        return self._to_entity(model) if model else None

    async def save(self, record: WebhookEventRecord) -> None:
        model = await self._session.get(StripeWebhookEventModel, record.id.value)
        if model is None:
            model = StripeWebhookEventModel(
                id=record.id.value,
                stripe_event_id=record.stripe_event_id,
                event_type=record.event_type,
                received_at=record.received_at,
            )
            self._session.add(model)

        model.processed_at = record.processed_at
        await self._session.flush()

    @staticmethod
    def _to_entity(model: StripeWebhookEventModel) -> WebhookEventRecord:
        return WebhookEventRecord(
            id=WebhookEventId(model.id),
            stripe_event_id=model.stripe_event_id,
            event_type=model.event_type,
            received_at=model.received_at,
            processed_at=model.processed_at,
        )
