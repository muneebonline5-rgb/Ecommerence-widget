from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.domain.entities.audit_log import AuditLog
from src.domain.repositories.interfaces import AuditLogRepository
from src.domain.value_objects.identifiers import AuditLogId, MerchantId, UserId
from src.infrastructure.db.models.platform import AuditLogModel


class SqlAlchemyAuditLogRepository(AuditLogRepository):
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def save(self, entry: AuditLog) -> None:
        model = await self._session.get(AuditLogModel, entry.id.value)
        if model is None:
            model = AuditLogModel(
                id=entry.id.value,
                merchant_id=entry.merchant_id.value if entry.merchant_id else None,
                actor_user_id=entry.actor_user_id.value if entry.actor_user_id else None,
                actor_type=entry.actor_type,
                action=entry.action,
                resource_type=entry.resource_type,
                resource_id=entry.resource_id,
                metadata_json=entry.metadata,
                ip_address=entry.ip_address,
            )
            self._session.add(model)
        await self._session.flush()

    async def list_for_merchant(
        self, merchant_id: MerchantId, *, limit: int = 50, offset: int = 0
    ) -> list[AuditLog]:
        stmt = (
            select(AuditLogModel)
            .where(AuditLogModel.merchant_id == merchant_id.value)
            .order_by(AuditLogModel.created_at.desc())
            .limit(limit)
            .offset(offset)
        )
        result = await self._session.execute(stmt)
        return [self._to_entity(m) for m in result.scalars().all()]

    @staticmethod
    def _to_entity(model: AuditLogModel) -> AuditLog:
        return AuditLog(
            id=AuditLogId(model.id),
            action=model.action,
            resource_type=model.resource_type,
            resource_id=model.resource_id,
            merchant_id=MerchantId(model.merchant_id) if model.merchant_id else None,
            actor_user_id=UserId(model.actor_user_id) if model.actor_user_id else None,
            actor_type=model.actor_type,
            metadata=dict(model.metadata_json or {}),
            ip_address=model.ip_address,
            created_at=model.created_at,
        )
