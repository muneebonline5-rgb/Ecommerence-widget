from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.domain.entities.subscription import Subscription
from src.domain.repositories.interfaces import SubscriptionRepository
from src.domain.value_objects.billing import BillingInterval, SubscriptionStatus
from src.domain.value_objects.identifiers import MerchantId, PlanId, SubscriptionId
from src.infrastructure.db.models.billing import SubscriptionModel


class SqlAlchemySubscriptionRepository(SubscriptionRepository):
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def save(self, subscription: Subscription) -> None:
        model = await self._session.get(SubscriptionModel, subscription.id.value)
        if model is None:
            model = SubscriptionModel(
                id=subscription.id.value, merchant_id=subscription.merchant_id.value
            )
            self._session.add(model)

        model.plan_id = subscription.plan_id.value
        model.stripe_subscription_id = subscription.stripe_subscription_id
        model.status = subscription.status.value
        model.billing_interval = subscription.billing_interval.value
        model.current_period_start = subscription.current_period_start
        model.current_period_end = subscription.current_period_end
        model.trial_end = subscription.trial_end
        model.cancel_at_period_end = subscription.cancel_at_period_end
        await self._session.flush()

    async def get_by_id(self, subscription_id: SubscriptionId) -> Subscription | None:
        model = await self._session.get(SubscriptionModel, subscription_id.value)
        return self._to_entity(model) if model else None

    async def get_by_merchant_id(self, merchant_id: MerchantId) -> Subscription | None:
        stmt = select(SubscriptionModel).where(SubscriptionModel.merchant_id == merchant_id.value)
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()
        return self._to_entity(model) if model else None

    async def get_by_stripe_subscription_id(
        self, stripe_subscription_id: str
    ) -> Subscription | None:
        stmt = select(SubscriptionModel).where(
            SubscriptionModel.stripe_subscription_id == stripe_subscription_id
        )
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()
        return self._to_entity(model) if model else None

    @staticmethod
    def _to_entity(model: SubscriptionModel) -> Subscription:
        return Subscription(
            id=SubscriptionId(model.id),
            merchant_id=MerchantId(model.merchant_id),
            plan_id=PlanId(model.plan_id),
            stripe_subscription_id=model.stripe_subscription_id,
            status=SubscriptionStatus(model.status),
            billing_interval=BillingInterval(model.billing_interval),
            current_period_start=model.current_period_start,
            current_period_end=model.current_period_end,
            trial_end=model.trial_end,
            cancel_at_period_end=model.cancel_at_period_end,
            created_at=model.created_at,
            updated_at=model.updated_at,
        )
