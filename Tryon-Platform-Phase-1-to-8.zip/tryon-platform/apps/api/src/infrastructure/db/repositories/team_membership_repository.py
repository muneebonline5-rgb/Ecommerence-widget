from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.domain.entities.team_membership import TeamMembership
from src.domain.repositories.interfaces import TeamMembershipRepository
from src.domain.value_objects.identifiers import MerchantId, RoleId, TeamMembershipId, UserId
from src.infrastructure.db.models.tenancy import TeamMembershipModel


class SqlAlchemyTeamMembershipRepository(TeamMembershipRepository):
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def save(self, membership: TeamMembership) -> None:
        model = await self._session.get(TeamMembershipModel, membership.id.value)
        if model is None:
            model = TeamMembershipModel(
                id=membership.id.value,
                merchant_id=membership.merchant_id.value,
                user_id=membership.user_id.value,
            )
            self._session.add(model)

        model.role_id = membership.role_id.value
        await self._session.flush()

    async def get_by_id(self, membership_id: TeamMembershipId) -> TeamMembership | None:
        model = await self._session.get(TeamMembershipModel, membership_id.value)
        return self._to_entity(model) if model else None

    async def get_for_merchant_and_user(
        self, merchant_id: MerchantId, user_id: UserId
    ) -> TeamMembership | None:
        stmt = select(TeamMembershipModel).where(
            TeamMembershipModel.merchant_id == merchant_id.value,
            TeamMembershipModel.user_id == user_id.value,
        )
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()
        return self._to_entity(model) if model else None

    async def list_for_merchant(self, merchant_id: MerchantId) -> list[TeamMembership]:
        stmt = select(TeamMembershipModel).where(
            TeamMembershipModel.merchant_id == merchant_id.value
        )
        result = await self._session.execute(stmt)
        return [self._to_entity(m) for m in result.scalars().all()]

    async def list_for_user(self, user_id: UserId) -> list[TeamMembership]:
        stmt = select(TeamMembershipModel).where(TeamMembershipModel.user_id == user_id.value)
        result = await self._session.execute(stmt)
        return [self._to_entity(m) for m in result.scalars().all()]

    async def delete(self, membership_id: TeamMembershipId) -> None:
        model = await self._session.get(TeamMembershipModel, membership_id.value)
        if model is not None:
            await self._session.delete(model)
            await self._session.flush()

    @staticmethod
    def _to_entity(model: TeamMembershipModel) -> TeamMembership:
        return TeamMembership(
            id=TeamMembershipId(model.id),
            merchant_id=MerchantId(model.merchant_id),
            user_id=UserId(model.user_id),
            role_id=RoleId(model.role_id),
            created_at=model.created_at,
            updated_at=model.updated_at,
        )
