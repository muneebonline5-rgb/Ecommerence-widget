from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.domain.entities.plan import Plan
from src.domain.repositories.interfaces import PlanRepository
from src.domain.value_objects.billing import PlanTier
from src.domain.value_objects.identifiers import PlanId
from src.infrastructure.db.models.billing import PlanModel


class SqlAlchemyPlanRepository(PlanRepository):
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def save(self, plan: Plan) -> None:
        model = await self._session.get(PlanModel, plan.id.value)
        if model is None:
            model = PlanModel(id=plan.id.value, tier=plan.tier.value)
            self._session.add(model)

        model.name = plan.name
        model.monthly_stripe_price_id = plan.monthly_stripe_price_id
        model.monthly_price_usd = plan.monthly_price_usd
        model.yearly_stripe_price_id = plan.yearly_stripe_price_id
        model.yearly_price_usd = plan.yearly_price_usd
        model.included_generations = plan.included_generations
        model.overage_price_usd = plan.overage_price_usd
        model.is_active = plan.is_active
        await self._session.flush()

    async def get_by_id(self, plan_id: PlanId) -> Plan | None:
        model = await self._session.get(PlanModel, plan_id.value)
        return self._to_entity(model) if model else None

    async def get_by_tier(self, tier: PlanTier) -> Plan | None:
        stmt = select(PlanModel).where(PlanModel.tier == tier.value)
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()
        return self._to_entity(model) if model else None

    async def list_active(self) -> list[Plan]:
        stmt = (
            select(PlanModel)
            .where(PlanModel.is_active.is_(True))
            .order_by(PlanModel.monthly_price_usd)
        )
        result = await self._session.execute(stmt)
        return [self._to_entity(m) for m in result.scalars().all()]

    @staticmethod
    def _to_entity(model: PlanModel) -> Plan:
        return Plan(
            id=PlanId(model.id),
            tier=PlanTier(model.tier),
            name=model.name,
            monthly_price_usd=float(model.monthly_price_usd),
            monthly_stripe_price_id=model.monthly_stripe_price_id,
            yearly_price_usd=(
                float(model.yearly_price_usd) if model.yearly_price_usd is not None else None
            ),
            yearly_stripe_price_id=model.yearly_stripe_price_id,
            included_generations=model.included_generations,
            overage_price_usd=float(model.overage_price_usd),
            is_active=model.is_active,
            created_at=model.created_at,
            updated_at=model.updated_at,
        )
