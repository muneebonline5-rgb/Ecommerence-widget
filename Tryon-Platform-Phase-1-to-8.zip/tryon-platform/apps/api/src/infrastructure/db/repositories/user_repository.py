from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.domain.entities.user import User
from src.domain.repositories.interfaces import UserRepository
from src.domain.value_objects.identifiers import UserId
from src.infrastructure.db.models.tenancy import UserModel


class SqlAlchemyUserRepository(UserRepository):
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def save(self, user: User) -> None:
        model = await self._session.get(UserModel, user.id.value)
        if model is None:
            model = UserModel(id=user.id.value)
            self._session.add(model)

        model.clerk_user_id = user.clerk_user_id
        model.email = user.email
        model.full_name = user.full_name
        model.is_platform_admin = user.is_platform_admin
        await self._session.flush()

    async def get_by_id(self, user_id: UserId) -> User | None:
        model = await self._session.get(UserModel, user_id.value)
        return self._to_entity(model) if model else None

    async def get_by_clerk_user_id(self, clerk_user_id: str) -> User | None:
        stmt = select(UserModel).where(UserModel.clerk_user_id == clerk_user_id)
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()
        return self._to_entity(model) if model else None

    @staticmethod
    def _to_entity(model: UserModel) -> User:
        return User(
            id=UserId(model.id),
            clerk_user_id=model.clerk_user_id,
            email=model.email,
            full_name=model.full_name,
            is_platform_admin=model.is_platform_admin,
            created_at=model.created_at,
            updated_at=model.updated_at,
        )
