from __future__ import annotations

from datetime import datetime

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from src.domain.entities.analytics_event import AnalyticsEvent
from src.domain.repositories.interfaces import AnalyticsEventRepository
from src.domain.value_objects.identifiers import MerchantId
from src.infrastructure.db.models.analytics import AnalyticsEventModel


class SqlAlchemyAnalyticsEventRepository(AnalyticsEventRepository):
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def save_batch(self, events: list[AnalyticsEvent]) -> None:
        if not events:
            return
        models = [
            AnalyticsEventModel(
                id=event.id.value,
                merchant_id=event.merchant_id.value,
                session_id=event.session_id.value if event.session_id else None,
                event_type=event.event_type.value,
                properties=event.properties,
                created_at=event.created_at,
            )
            for event in events
        ]
        self._session.add_all(models)
        await self._session.flush()

    async def count_by_type(
        self, merchant_id: MerchantId, *, start: datetime, end: datetime
    ) -> dict[str, int]:
        stmt = (
            select(AnalyticsEventModel.event_type, func.count())
            .where(
                AnalyticsEventModel.merchant_id == merchant_id.value,
                AnalyticsEventModel.created_at >= start,
                AnalyticsEventModel.created_at < end,
            )
            .group_by(AnalyticsEventModel.event_type)
        )
        result = await self._session.execute(stmt)
        return {event_type: count for event_type, count in result.all()}
