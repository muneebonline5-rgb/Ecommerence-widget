from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.domain.entities.merchant import Merchant, MerchantStatus, MerchantTier
from src.domain.repositories.interfaces import MerchantRepository
from src.domain.value_objects.identifiers import MerchantId
from src.infrastructure.db.models.tenancy import MerchantModel


class SqlAlchemyMerchantRepository(MerchantRepository):
    """
    Concrete adapter implementing the domain's MerchantRepository port.
    Responsible for ALL translation between the ORM row (MerchantModel) and
    the domain entity (Merchant) — no other layer knows MerchantModel exists.
    """

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def save(self, merchant: Merchant) -> None:
        model = await self._session.get(MerchantModel, merchant.id.value)
        if model is None:
            model = MerchantModel(id=merchant.id.value)
            self._session.add(model)

        model.name = merchant.name
        model.domain = merchant.domain
        model.contact_email = merchant.contact_email
        model.status = merchant.status.value
        model.tier = merchant.tier.value
        model.suspended_reason = merchant.suspended_reason
        model.stripe_customer_id = merchant.stripe_customer_id
        await self._session.flush()

    async def get_by_id(self, merchant_id: MerchantId) -> Merchant | None:
        model = await self._session.get(MerchantModel, merchant_id.value)
        return self._to_entity(model) if model else None

    async def get_by_domain(self, domain: str) -> Merchant | None:
        stmt = select(MerchantModel).where(MerchantModel.domain == domain.strip().lower())
        result = await self._session.execute(stmt)
        model = result.scalar_one_or_none()
        return self._to_entity(model) if model else None

    async def list_all(self, *, limit: int = 50, offset: int = 0) -> list[Merchant]:
        stmt = (
            select(MerchantModel)
            .order_by(MerchantModel.created_at.desc())
            .limit(limit)
            .offset(offset)
        )
        result = await self._session.execute(stmt)
        return [self._to_entity(m) for m in result.scalars().all()]

    async def list_by_ids(self, merchant_ids: list[MerchantId]) -> list[Merchant]:
        if not merchant_ids:
            return []
        stmt = select(MerchantModel).where(MerchantModel.id.in_([m.value for m in merchant_ids]))
        result = await self._session.execute(stmt)
        return [self._to_entity(m) for m in result.scalars().all()]

    @staticmethod
    def _to_entity(model: MerchantModel) -> Merchant:
        return Merchant(
            id=MerchantId(model.id),
            name=model.name,
            domain=model.domain,
            contact_email=model.contact_email,
            status=MerchantStatus(model.status),
            tier=MerchantTier(model.tier),
            created_at=model.created_at,
            updated_at=model.updated_at,
            suspended_reason=model.suspended_reason,
            stripe_customer_id=model.stripe_customer_id,
        )
