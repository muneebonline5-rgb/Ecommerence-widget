from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.domain.entities.tryon_session import TryOnSession
from src.domain.repositories.interfaces import TryOnSessionRepository
from src.domain.value_objects.identifiers import MerchantId, ProductId, TryOnSessionId
from src.infrastructure.db.models.tryon import TryOnSessionModel


class SqlAlchemyTryOnSessionRepository(TryOnSessionRepository):
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def save(self, tryon_session: TryOnSession) -> None:
        model = await self._session.get(TryOnSessionModel, tryon_session.id.value)
        if model is None:
            model = TryOnSessionModel(
                id=tryon_session.id.value,
                merchant_id=tryon_session.merchant_id.value,
            )
            self._session.add(model)

        model.product_id = tryon_session.product_id.value if tryon_session.product_id else None
        model.anonymous_visitor_id = tryon_session.anonymous_visitor_id
        model.country = tryon_session.country
        model.device_type = tryon_session.device_type
        model.browser = tryon_session.browser
        model.ended_at = tryon_session.ended_at
        await self._session.flush()

    async def get_by_id(self, session_id: TryOnSessionId) -> TryOnSession | None:
        model = await self._session.get(TryOnSessionModel, session_id.value)
        return self._to_entity(model) if model else None

    @staticmethod
    def _to_entity(model: TryOnSessionModel) -> TryOnSession:
        return TryOnSession(
            id=TryOnSessionId(model.id),
            merchant_id=MerchantId(model.merchant_id),
            anonymous_visitor_id=model.anonymous_visitor_id,
            product_id=ProductId(model.product_id) if model.product_id else None,
            country=model.country,
            device_type=model.device_type,
            browser=model.browser,
            created_at=model.created_at,
            updated_at=model.updated_at,
            ended_at=model.ended_at,
        )
