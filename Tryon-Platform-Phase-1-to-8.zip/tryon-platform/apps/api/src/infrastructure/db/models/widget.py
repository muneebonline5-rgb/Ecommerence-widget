from __future__ import annotations

import uuid

from sqlalchemy import ForeignKey, String
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from src.infrastructure.db.models.base import Base, TimestampMixin, UUIDPrimaryKeyMixin


class WidgetSettingsModel(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "widget_settings"

    merchant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("merchants.id", ondelete="CASCADE"),
        nullable=False,
        unique=True,
        index=True,
    )
    is_enabled: Mapped[bool] = mapped_column(default=True, nullable=False)
    position: Mapped[str] = mapped_column(String(32), nullable=False, default="bottom_right")
    button_label: Mapped[str] = mapped_column(String(64), nullable=False, default="Try It On")
    allowed_origins: Mapped[list[str]] = mapped_column(ARRAY(String), default=list)
    sdk_version_pin: Mapped[str | None] = mapped_column(String(32), nullable=True)
    # Theme is a small, evolving bag of presentational properties — JSONB
    # avoids a migration for every new cosmetic field while remaining
    # queryable if needed (e.g. `theme ->> 'primary_color'`).
    theme: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
