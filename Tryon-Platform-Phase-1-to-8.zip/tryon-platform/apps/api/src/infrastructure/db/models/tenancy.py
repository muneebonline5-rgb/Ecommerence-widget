"""
Tenancy schema: Merchant (tenant root), Users, Roles, Permissions, ApiKeys.

RBAC model: Role <-> Permission is many-to-many; User <-> Merchant is
many-to-many through TeamMembershipModel so a single Clerk user can belong
to multiple merchant teams (e.g. agencies managing several brands), each
membership carrying its own role.
"""

from __future__ import annotations

import uuid
from datetime import datetime

import sqlalchemy as sa
from sqlalchemy import ForeignKey, String, UniqueConstraint
from sqlalchemy.dialects.postgresql import ARRAY, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from src.infrastructure.db.models.base import Base, TimestampMixin, UUIDPrimaryKeyMixin


class MerchantModel(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "merchants"

    name: Mapped[str] = mapped_column(String(255), nullable=False)
    domain: Mapped[str] = mapped_column(String(255), nullable=False, unique=True, index=True)
    contact_email: Mapped[str] = mapped_column(String(255), nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="pending", index=True)
    tier: Mapped[str] = mapped_column(String(32), nullable=False, default="free")
    suspended_reason: Mapped[str | None] = mapped_column(String(500), nullable=True)
    stripe_customer_id: Mapped[str | None] = mapped_column(
        String(255), nullable=True, unique=True, index=True
    )

    team_memberships: Mapped[list[TeamMembershipModel]] = relationship(
        back_populates="merchant", cascade="all, delete-orphan"
    )
    api_keys: Mapped[list[ApiKeyModel]] = relationship(
        back_populates="merchant", cascade="all, delete-orphan"
    )


class UserModel(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    """
    Mirrors the Clerk user identity. `clerk_user_id` is the source of truth;
    this row exists so we can foreign-key team memberships, audit logs, etc.
    without calling out to Clerk on every query.
    """

    __tablename__ = "users"

    clerk_user_id: Mapped[str] = mapped_column(String(255), nullable=False, unique=True, index=True)
    email: Mapped[str] = mapped_column(String(255), nullable=False, unique=True, index=True)
    full_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    is_platform_admin: Mapped[bool] = mapped_column(default=False, nullable=False)

    team_memberships: Mapped[list[TeamMembershipModel]] = relationship(
        back_populates="user", cascade="all, delete-orphan"
    )


class RoleModel(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "roles"

    name: Mapped[str] = mapped_column(String(64), nullable=False, unique=True)
    description: Mapped[str | None] = mapped_column(String(500), nullable=True)
    # Denormalized permission-code array for fast in-process checks;
    # PermissionModel remains the normalized source of truth for admin UI.
    permission_codes: Mapped[list[str]] = mapped_column(ARRAY(String), default=list)


class PermissionModel(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "permissions"

    code: Mapped[str] = mapped_column(
        String(128), nullable=False, unique=True
    )  # e.g. "widget:edit"
    description: Mapped[str | None] = mapped_column(String(500), nullable=True)


class TeamMembershipModel(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "team_memberships"
    __table_args__ = (
        UniqueConstraint("merchant_id", "user_id", name="uq_membership_merchant_user"),
    )

    merchant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("merchants.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    role_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("roles.id", ondelete="RESTRICT"), nullable=False
    )

    merchant: Mapped[MerchantModel] = relationship(back_populates="team_memberships")
    user: Mapped[UserModel] = relationship(back_populates="team_memberships")
    role: Mapped[RoleModel] = relationship()


class ApiKeyModel(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "api_keys"

    merchant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("merchants.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    label: Mapped[str] = mapped_column(String(255), nullable=False)
    environment: Mapped[str] = mapped_column(String(16), nullable=False)  # live | test
    key_prefix: Mapped[str] = mapped_column(String(32), nullable=False, unique=True, index=True)
    key_hash: Mapped[str] = mapped_column(String(128), nullable=False)
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="active")
    last_used_at: Mapped[datetime | None] = mapped_column(sa.DateTime(timezone=True), nullable=True)
    revoked_at: Mapped[datetime | None] = mapped_column(sa.DateTime(timezone=True), nullable=True)

    merchant: Mapped[MerchantModel] = relationship(back_populates="api_keys")
