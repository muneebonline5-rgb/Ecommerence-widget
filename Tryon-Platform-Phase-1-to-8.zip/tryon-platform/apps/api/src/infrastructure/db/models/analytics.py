from __future__ import annotations

import uuid

from sqlalchemy import ForeignKey, Index, String
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from src.infrastructure.db.models.base import Base, TimestampMixin, UUIDPrimaryKeyMixin


class AnalyticsEventModel(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    """
    Append-only widget event stream: widget_loaded, button_clicked,
    modal_opened, image_uploaded, generation_started, generation_completed,
    result_downloaded, conversion. Mirrored to PostHog asynchronously; this
    table is the durable, queryable source of truth for in-dashboard charts.
    """

    __tablename__ = "analytics_events"
    __table_args__ = (
        Index("ix_analytics_merchant_type_created", "merchant_id", "event_type", "created_at"),
    )

    merchant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("merchants.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    session_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("tryon_sessions.id", ondelete="SET NULL"), nullable=True
    )
    event_type: Mapped[str] = mapped_column(String(64), nullable=False)
    properties: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
