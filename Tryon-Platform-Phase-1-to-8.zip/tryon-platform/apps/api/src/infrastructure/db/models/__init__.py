"""
Importing every model module here guarantees Base.metadata is fully
populated before Alembic's `env.py` calls `target_metadata = Base.metadata`
for autogenerate — a common source of "missing table in migration" bugs
when models are only imported lazily inside repositories.
"""

from src.infrastructure.db.models.analytics import AnalyticsEventModel  # noqa: F401
from src.infrastructure.db.models.base import Base  # noqa: F401
from src.infrastructure.db.models.billing import (  # noqa: F401
    CreditNoteModel,
    InvoiceModel,
    PlanModel,
    StripeWebhookEventModel,
    SubscriptionModel,
    UsageRecordModel,
)
from src.infrastructure.db.models.catalog import ProductModel  # noqa: F401
from src.infrastructure.db.models.platform import (  # noqa: F401
    AuditLogModel,
    NotificationModel,
    SystemLogModel,
)
from src.infrastructure.db.models.tenancy import (  # noqa: F401
    ApiKeyModel,
    MerchantModel,
    PermissionModel,
    RoleModel,
    TeamMembershipModel,
    UserModel,
)
from src.infrastructure.db.models.tryon import (  # noqa: F401
    AIRequestModel,
    TryOnModel,
    TryOnSessionModel,
)
from src.infrastructure.db.models.widget import WidgetSettingsModel  # noqa: F401

__all__ = [
    "Base",
    "MerchantModel",
    "UserModel",
    "RoleModel",
    "PermissionModel",
    "TeamMembershipModel",
    "ApiKeyModel",
    "WidgetSettingsModel",
    "ProductModel",
    "TryOnSessionModel",
    "TryOnModel",
    "AIRequestModel",
    "PlanModel",
    "SubscriptionModel",
    "InvoiceModel",
    "UsageRecordModel",
    "CreditNoteModel",
    "StripeWebhookEventModel",
    "AnalyticsEventModel",
    "SystemLogModel",
    "NotificationModel",
    "AuditLogModel",
]
