from __future__ import annotations

import uuid

from sqlalchemy import ForeignKey, String
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from src.infrastructure.db.models.base import Base, TimestampMixin, UUIDPrimaryKeyMixin


class SystemLogModel(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    """
    Structured application log entries persisted for admin-dashboard search.
    High-volume operational logs (request/response) live in Grafana/Loki
    instead — this table is reserved for business-significant log lines
    (provider failures, webhook errors, worker dead-letters) worth querying
    from the admin UI without a Grafana login.
    """

    __tablename__ = "system_logs"

    level: Mapped[str] = mapped_column(
        String(16), nullable=False, index=True
    )  # info|warning|error|critical
    source: Mapped[str] = mapped_column(
        String(64), nullable=False, index=True
    )  # api|worker|webhook|billing
    message: Mapped[str] = mapped_column(String(2000), nullable=False)
    merchant_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("merchants.id", ondelete="SET NULL"), nullable=True
    )
    context: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)


class NotificationModel(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "notifications"

    merchant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("merchants.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    user_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    type: Mapped[str] = mapped_column(
        String(64), nullable=False
    )  # billing|usage_limit|system|security
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    body: Mapped[str] = mapped_column(String(2000), nullable=False)
    is_read: Mapped[bool] = mapped_column(default=False, nullable=False)


class AuditLogModel(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    """
    Immutable record of who-did-what, required for SOC2/enterprise merchants.
    Never updated or deleted after insert (enforced at the repository layer,
    not just convention).
    """

    __tablename__ = "audit_logs"

    merchant_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("merchants.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )
    actor_user_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    actor_type: Mapped[str] = mapped_column(
        String(32), nullable=False, default="user"
    )  # user|system|api_key
    action: Mapped[str] = mapped_column(
        String(128), nullable=False
    )  # e.g. "widget_settings.updated"
    resource_type: Mapped[str] = mapped_column(String(64), nullable=False)
    resource_id: Mapped[str] = mapped_column(String(128), nullable=False)
    metadata_json: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    ip_address: Mapped[str | None] = mapped_column(String(64), nullable=True)
