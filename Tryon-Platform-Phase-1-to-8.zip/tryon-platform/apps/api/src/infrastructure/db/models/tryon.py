from __future__ import annotations

import uuid
from datetime import datetime

import sqlalchemy as sa
from sqlalchemy import ForeignKey, Index, Numeric, String
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from src.infrastructure.db.models.base import Base, TimestampMixin, UUIDPrimaryKeyMixin


class TryOnSessionModel(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    """
    One customer visit to the widget on a given product page. Groups
    together the analytics funnel (loaded -> opened -> uploaded -> generated
    -> downloaded) and 1..N TryOnModel attempts.
    """

    __tablename__ = "tryon_sessions"

    merchant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("merchants.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    product_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("products.id", ondelete="SET NULL"), nullable=True
    )
    anonymous_visitor_id: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    country: Mapped[str | None] = mapped_column(String(2), nullable=True)
    device_type: Mapped[str | None] = mapped_column(String(32), nullable=True)
    browser: Mapped[str | None] = mapped_column(String(64), nullable=True)
    ended_at: Mapped[datetime | None] = mapped_column(sa.DateTime(timezone=True), nullable=True)


class TryOnModel(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    """A single try-on attempt (one customer photo -> one generated result)."""

    __tablename__ = "tryons"

    session_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("tryon_sessions.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    customer_image_key: Mapped[str] = mapped_column(
        String(1024), nullable=False
    )  # S3/R2 object key
    result_image_key: Mapped[str | None] = mapped_column(String(1024), nullable=True)
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="pending", index=True)
    error_message: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    was_downloaded: Mapped[bool] = mapped_column(default=False, nullable=False)


class AIRequestModel(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    """
    Record of a single call made to an upstream AI provider for a given
    TryOn. Kept separate from TryOnModel because a single try-on may be
    retried across providers/attempts, and this table is the source of truth
    for AI-usage billing.
    """

    __tablename__ = "ai_requests"
    __table_args__ = (
        Index(
            "ix_ai_requests_merchant_idempotency_key",
            "merchant_id",
            "idempotency_key",
            unique=True,
        ),
    )

    tryon_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("tryons.id", ondelete="CASCADE"), nullable=False, index=True
    )
    merchant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("merchants.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    provider: Mapped[str] = mapped_column(
        String(32), nullable=False
    )  # fashn | openai | flux | kling
    idempotency_key: Mapped[str] = mapped_column(String(255), nullable=False)
    provider_request_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="queued")
    latency_ms: Mapped[int | None] = mapped_column(nullable=True)
    cost_usd: Mapped[float | None] = mapped_column(Numeric(10, 4), nullable=True)
    request_payload: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    response_payload: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
