from __future__ import annotations

import uuid
from datetime import date, datetime

import sqlalchemy as sa
from sqlalchemy import Date, ForeignKey, Integer, Numeric, String
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from src.infrastructure.db.models.base import Base, TimestampMixin, UUIDPrimaryKeyMixin


class PlanModel(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "plans"

    tier: Mapped[str] = mapped_column(String(32), nullable=False, unique=True, index=True)
    name: Mapped[str] = mapped_column(String(64), nullable=False, unique=True)
    monthly_stripe_price_id: Mapped[str] = mapped_column(String(128), nullable=False, unique=True)
    monthly_price_usd: Mapped[float] = mapped_column(Numeric(10, 2), nullable=False)
    yearly_stripe_price_id: Mapped[str | None] = mapped_column(
        String(128), nullable=True, unique=True
    )
    yearly_price_usd: Mapped[float | None] = mapped_column(Numeric(10, 2), nullable=True)
    included_generations: Mapped[int] = mapped_column(Integer, nullable=False)
    overage_price_usd: Mapped[float] = mapped_column(Numeric(10, 4), nullable=False)
    is_active: Mapped[bool] = mapped_column(default=True, nullable=False)


class SubscriptionModel(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "subscriptions"

    merchant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("merchants.id", ondelete="CASCADE"),
        nullable=False,
        unique=True,
        index=True,
    )
    plan_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("plans.id", ondelete="RESTRICT"), nullable=False
    )
    stripe_subscription_id: Mapped[str] = mapped_column(String(128), nullable=False, unique=True)
    status: Mapped[str] = mapped_column(
        String(32), nullable=False, default="active"
    )  # trialing|active|past_due|canceled
    billing_interval: Mapped[str] = mapped_column(
        String(16), nullable=False, default="monthly"
    )  # monthly|yearly
    current_period_start: Mapped[datetime] = mapped_column(
        sa.DateTime(timezone=True), nullable=False
    )
    current_period_end: Mapped[datetime] = mapped_column(sa.DateTime(timezone=True), nullable=False)
    trial_end: Mapped[datetime | None] = mapped_column(sa.DateTime(timezone=True), nullable=True)
    cancel_at_period_end: Mapped[bool] = mapped_column(default=False, nullable=False)


class InvoiceModel(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "invoices"

    merchant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("merchants.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    stripe_invoice_id: Mapped[str] = mapped_column(String(128), nullable=False, unique=True)
    amount_due_usd: Mapped[float] = mapped_column(Numeric(10, 2), nullable=False)
    amount_paid_usd: Mapped[float] = mapped_column(Numeric(10, 2), nullable=False, default=0)
    status: Mapped[str] = mapped_column(
        String(32), nullable=False
    )  # draft|open|paid|void|uncollectible
    hosted_invoice_url: Mapped[str | None] = mapped_column(String(2048), nullable=True)
    period_start: Mapped[date] = mapped_column(Date, nullable=False)
    period_end: Mapped[date] = mapped_column(Date, nullable=False)


class UsageRecordModel(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    """
    Daily rollup of billable usage per merchant, aggregated from AIRequestModel
    by a scheduled Celery task. Kept separate from raw AI requests so billing
    queries stay O(days) rather than O(requests) as volume grows.
    """

    __tablename__ = "usage_records"
    __table_args__ = ()

    merchant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("merchants.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    usage_date: Mapped[date] = mapped_column(Date, nullable=False)
    generations_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    breakdown_by_provider: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)


class CreditNoteModel(UUIDPrimaryKeyMixin, Base):
    __tablename__ = "credit_notes"

    merchant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("merchants.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    invoice_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("invoices.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    stripe_credit_note_id: Mapped[str] = mapped_column(String(128), nullable=False, unique=True)
    amount_usd: Mapped[float] = mapped_column(Numeric(10, 2), nullable=False)
    reason: Mapped[str] = mapped_column(String(500), nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
    )


class StripeWebhookEventModel(UUIDPrimaryKeyMixin, Base):
    """
    Idempotency ledger for inbound Stripe webhooks — see
    domain/entities/webhook_event.py for why this exists at all.
    """

    __tablename__ = "stripe_webhook_events"

    stripe_event_id: Mapped[str] = mapped_column(
        String(255), nullable=False, unique=True, index=True
    )
    event_type: Mapped[str] = mapped_column(String(128), nullable=False)
    received_at: Mapped[datetime] = mapped_column(sa.DateTime(timezone=True), nullable=False)
    processed_at: Mapped[datetime | None] = mapped_column(sa.DateTime(timezone=True), nullable=True)
