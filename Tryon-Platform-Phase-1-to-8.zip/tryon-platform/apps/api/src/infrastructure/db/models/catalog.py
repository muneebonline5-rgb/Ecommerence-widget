from __future__ import annotations

import uuid

from sqlalchemy import ForeignKey, Index, String
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from src.infrastructure.db.models.base import Base, TimestampMixin, UUIDPrimaryKeyMixin


class ProductModel(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    """
    A merchant's product, as known to the try-on widget. Populated either via
    the Products API (merchant push) or auto-detected from product-page
    metadata by the widget SDK on first view (upserted by external_id).
    """

    __tablename__ = "products"
    __table_args__ = (
        Index("ix_products_merchant_external", "merchant_id", "external_id", unique=True),
    )

    merchant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("merchants.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    external_id: Mapped[str] = mapped_column(
        String(255), nullable=False
    )  # merchant's own SKU/product ID
    title: Mapped[str] = mapped_column(String(500), nullable=False)
    product_url: Mapped[str] = mapped_column(String(2048), nullable=False)
    image_url: Mapped[str] = mapped_column(String(2048), nullable=False)
    category: Mapped[str | None] = mapped_column(String(128), nullable=True)
    is_try_on_eligible: Mapped[bool] = mapped_column(default=True, nullable=False)
    metadata_json: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
