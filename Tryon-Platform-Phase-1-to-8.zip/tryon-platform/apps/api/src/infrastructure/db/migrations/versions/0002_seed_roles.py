"""seed built-in roles

Revision ID: 0002_seed_roles
Revises: 0001_initial_schema
Create Date: 2026-07-26
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

from src.domain.entities.role import BUILT_IN_ROLE_PERMISSIONS, BuiltInRole

revision = "0002_seed_roles"
down_revision = "0001_initial_schema"
branch_labels = None
depends_on = None

# Lightweight, migration-local table handle — deliberately not importing the
# ORM model here, so this migration keeps working unchanged even if the
# RoleModel's Python class is refactored or removed in the future.
roles_table = sa.table(
    "roles",
    sa.column("id", postgresql.UUID(as_uuid=True)),
    sa.column("created_at", sa.DateTime(timezone=True)),
    sa.column("updated_at", sa.DateTime(timezone=True)),
    sa.column("name", sa.String()),
    sa.column("description", sa.String()),
    sa.column("permission_codes", postgresql.ARRAY(sa.String())),
)


def upgrade() -> None:
    # bulk_insert binds these as literal parameters, not inline SQL — so this
    # must be an actual datetime value, not a sa.func.now() expression object
    # (asyncpg's executemany rejects SQL-expression objects). The columns are
    # TIMESTAMP WITH TIME ZONE, matching every other timestamp in this
    # schema, so this must be tz-aware.
    now = datetime.now(UTC)
    op.bulk_insert(
        roles_table,
        [
            {
                "id": uuid.uuid4(),
                "created_at": now,
                "updated_at": now,
                "name": role.value,
                "description": f"Built-in '{role.value}' role.",
                "permission_codes": list(permissions),
            }
            for role, permissions in BUILT_IN_ROLE_PERMISSIONS.items()
        ],
    )


def downgrade() -> None:
    op.execute(
        roles_table.delete().where(roles_table.c.name.in_([role.value for role in BuiltInRole]))
    )
