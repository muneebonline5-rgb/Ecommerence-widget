"""billing: stripe customer, plan pricing, subscription trial/interval, credit notes, webhooks

Revision ID: 0004_billing_stripe
Revises: 0003_ai_request_idempotency
Create Date: 2026-07-27
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision = "0004_billing_stripe"
down_revision = "0003_ai_request_idempotency"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # --- merchants: link to a Stripe Customer ---
    op.add_column(
        "merchants", sa.Column("stripe_customer_id", sa.String(length=255), nullable=True)
    )
    op.create_index(
        "ix_merchants_stripe_customer_id", "merchants", ["stripe_customer_id"], unique=True
    )

    # --- plans: tier + monthly/yearly pricing split ---
    op.add_column(
        "plans",
        sa.Column("tier", sa.String(length=32), nullable=False, server_default="starter"),
    )
    op.alter_column("plans", "tier", server_default=None)
    op.create_index("ix_plans_tier", "plans", ["tier"], unique=True)

    op.alter_column("plans", "stripe_price_id", new_column_name="monthly_stripe_price_id")
    op.drop_constraint("uq_plans_stripe_price_id", "plans", type_="unique")
    op.create_unique_constraint(
        "uq_plans_monthly_stripe_price_id", "plans", ["monthly_stripe_price_id"]
    )
    op.add_column(
        "plans", sa.Column("yearly_stripe_price_id", sa.String(length=128), nullable=True)
    )
    op.add_column("plans", sa.Column("yearly_price_usd", sa.Numeric(10, 2), nullable=True))
    op.create_unique_constraint(
        "uq_plans_yearly_stripe_price_id", "plans", ["yearly_stripe_price_id"]
    )

    # --- subscriptions: billing interval + trial tracking ---
    op.add_column(
        "subscriptions",
        sa.Column(
            "billing_interval", sa.String(length=16), nullable=False, server_default="monthly"
        ),
    )
    op.alter_column("subscriptions", "billing_interval", server_default=None)
    op.add_column(
        "subscriptions", sa.Column("trial_end", sa.DateTime(timezone=True), nullable=True)
    )

    # --- credit_notes: new table ---
    op.create_table(
        "credit_notes",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "merchant_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("merchants.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "invoice_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("invoices.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("stripe_credit_note_id", sa.String(128), nullable=False),
        sa.Column("amount_usd", sa.Numeric(10, 2), nullable=False),
        sa.Column("reason", sa.String(500), nullable=False),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.UniqueConstraint("stripe_credit_note_id", name="uq_credit_notes_stripe_credit_note_id"),
    )
    op.create_index("ix_credit_notes_merchant_id", "credit_notes", ["merchant_id"])
    op.create_index("ix_credit_notes_invoice_id", "credit_notes", ["invoice_id"])

    # --- stripe_webhook_events: idempotency ledger ---
    op.create_table(
        "stripe_webhook_events",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("stripe_event_id", sa.String(255), nullable=False),
        sa.Column("event_type", sa.String(128), nullable=False),
        sa.Column("received_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("processed_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index(
        "ix_stripe_webhook_events_stripe_event_id",
        "stripe_webhook_events",
        ["stripe_event_id"],
        unique=True,
    )


def downgrade() -> None:
    op.drop_index("ix_stripe_webhook_events_stripe_event_id", table_name="stripe_webhook_events")
    op.drop_table("stripe_webhook_events")

    op.drop_index("ix_credit_notes_invoice_id", table_name="credit_notes")
    op.drop_index("ix_credit_notes_merchant_id", table_name="credit_notes")
    op.drop_table("credit_notes")

    op.drop_column("subscriptions", "trial_end")
    op.drop_column("subscriptions", "billing_interval")

    op.drop_constraint("uq_plans_yearly_stripe_price_id", "plans", type_="unique")
    op.drop_column("plans", "yearly_price_usd")
    op.drop_column("plans", "yearly_stripe_price_id")
    op.drop_constraint("uq_plans_monthly_stripe_price_id", "plans", type_="unique")
    op.alter_column("plans", "monthly_stripe_price_id", new_column_name="stripe_price_id")
    op.create_unique_constraint("uq_plans_stripe_price_id", "plans", ["stripe_price_id"])
    op.drop_index("ix_plans_tier", table_name="plans")
    op.drop_column("plans", "tier")

    op.drop_index("ix_merchants_stripe_customer_id", table_name="merchants")
    op.drop_column("merchants", "stripe_customer_id")
