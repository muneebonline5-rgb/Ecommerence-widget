"""add idempotency_key to ai_requests

Revision ID: 0003_ai_request_idempotency
Revises: 0002_seed_roles
Create Date: 2026-07-26
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0003_ai_request_idempotency"
down_revision = "0002_seed_roles"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "ai_requests",
        sa.Column("idempotency_key", sa.String(length=255), nullable=False, server_default=""),
    )
    # Drop the server_default immediately after backfilling existing rows —
    # it exists only to satisfy NOT NULL for any pre-existing rows during
    # this migration; new rows must always supply a real idempotency key
    # (enforced at the domain layer, not by a DB default).
    op.alter_column("ai_requests", "idempotency_key", server_default=None)

    op.create_index(
        "ix_ai_requests_merchant_idempotency_key",
        "ai_requests",
        ["merchant_id", "idempotency_key"],
        unique=True,
    )


def downgrade() -> None:
    op.drop_index("ix_ai_requests_merchant_idempotency_key", table_name="ai_requests")
    op.drop_column("ai_requests", "idempotency_key")
