"""
Observability wiring: structured logging and Sentry error reporting.

Kept in infrastructure (not `main.py`) so the Celery worker can initialize
identical logging/Sentry without importing the FastAPI app.
"""

from __future__ import annotations

import logging
import sys

import structlog

from src.config.settings import Settings

# Request headers that must never reach logs or Sentry. The API key and
# bearer token are live credentials; the Stripe signature is a valid HMAC
# for its payload and would help an attacker replay a webhook.
_REDACTED_HEADERS = {"authorization", "x-api-key", "stripe-signature", "cookie"}


def configure_logging(settings: Settings) -> None:
    """
    JSON logs in staging/production (machine-parseable for Grafana/Loki),
    human-readable console output in development.
    """
    logging.basicConfig(format="%(message)s", stream=sys.stdout, level=logging.INFO)

    processors: list = [
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
    ]
    processors.append(
        structlog.dev.ConsoleRenderer()
        if settings.environment == "development"
        else structlog.processors.JSONRenderer()
    )

    structlog.configure(
        processors=processors,
        wrapper_class=structlog.make_filtering_bound_logger(logging.INFO),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(),
        cache_logger_on_first_use=True,
    )


def _scrub_event(event: dict, _hint: dict) -> dict | None:
    """
    Strips credentials before anything leaves the process for Sentry.

    Sentry's own default scrubbing covers common field names, but our
    `X-API-Key` header is custom and would otherwise be sent verbatim — a
    live merchant credential leaving our infrastructure.
    """
    headers = event.get("request", {}).get("headers")
    if isinstance(headers, dict):
        for key in list(headers):
            if key.lower() in _REDACTED_HEADERS:
                headers[key] = "[redacted]"
    return event


def configure_sentry(settings: Settings, *, component: str) -> None:
    """No-ops when SENTRY_DSN is unset, so local development needs no Sentry account."""
    if not settings.sentry_dsn:
        return

    import sentry_sdk

    sentry_sdk.init(
        dsn=settings.sentry_dsn,
        environment=settings.environment,
        # Sampled rather than 1.0: full tracing on a widget endpoint that
        # every storefront pageview hits would be prohibitively expensive.
        traces_sample_rate=settings.sentry_traces_sample_rate,
        send_default_pii=False,
        before_send=_scrub_event,
    )
    sentry_sdk.set_tag("component", component)
