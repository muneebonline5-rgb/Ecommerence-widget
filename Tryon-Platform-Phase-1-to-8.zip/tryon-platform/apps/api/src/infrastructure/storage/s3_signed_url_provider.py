"""
S3-compatible signed URL provider.

Works against AWS S3 or Cloudflare R2 (R2 exposes an S3-compatible API,
which is exactly why the project's tech stack lists both interchangeably) —
selected purely by which `endpoint_url` is configured. boto3's presigned
URL generation is synchronous (no async S3 client exists that's worth
depending on), which is fine here: it's pure local computation (an HMAC
signature), not a network call.
"""

from __future__ import annotations

import uuid

import boto3
from botocore.client import Config as BotoConfig

from src.domain.repositories.storage import SignedUploadUrl, SignedUrlProvider


class S3SignedUrlProvider(SignedUrlProvider):
    def __init__(
        self,
        *,
        bucket_name: str,
        endpoint_url: str,
        access_key_id: str,
        secret_access_key: str,
        default_upload_ttl_seconds: int = 900,
    ) -> None:
        self._bucket_name = bucket_name
        self._default_upload_ttl_seconds = default_upload_ttl_seconds
        self._client = boto3.client(
            "s3",
            endpoint_url=endpoint_url or None,
            aws_access_key_id=access_key_id,
            aws_secret_access_key=secret_access_key,
            config=BotoConfig(signature_version="s3v4"),
        )

    def create_upload_url(self, *, merchant_id: str, content_type: str) -> SignedUploadUrl:
        extension = _extension_for_content_type(content_type)
        object_key = f"customer-uploads/{merchant_id}/{uuid.uuid4()}{extension}"

        upload_url = self._client.generate_presigned_url(
            "put_object",
            Params={"Bucket": self._bucket_name, "Key": object_key, "ContentType": content_type},
            ExpiresIn=self._default_upload_ttl_seconds,
        )

        return SignedUploadUrl(
            upload_url=upload_url,
            object_key=object_key,
            expires_in_seconds=self._default_upload_ttl_seconds,
        )

    def get_object_url(self, object_key: str, *, expires_in_seconds: int = 3600) -> str:
        return self._client.generate_presigned_url(
            "get_object",
            Params={"Bucket": self._bucket_name, "Key": object_key},
            ExpiresIn=expires_in_seconds,
        )

    def upload_bytes(self, *, key_prefix: str, data: bytes, content_type: str) -> str:
        extension = _extension_for_content_type(content_type)
        object_key = f"{key_prefix.strip('/')}/{uuid.uuid4()}{extension}"
        self._client.put_object(
            Bucket=self._bucket_name, Key=object_key, Body=data, ContentType=content_type
        )
        return object_key


def _extension_for_content_type(content_type: str) -> str:
    return {
        "image/png": ".png",
        "image/jpeg": ".jpg",
        "image/jpg": ".jpg",
        "image/webp": ".webp",
    }.get(content_type, "")
