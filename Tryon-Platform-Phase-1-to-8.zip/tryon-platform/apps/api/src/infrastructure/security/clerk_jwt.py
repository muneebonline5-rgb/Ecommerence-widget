"""
Clerk-issued session JWT verification.

Clerk signs dashboard-user session tokens with RS256 using a key from their
published JWKS endpoint. This verifier:

1. Caches the JWKS in memory (TTL-bound) so we don't fetch it on every
   request — Clerk's keys rotate rarely.
2. On a signing-key ('kid') we don't recognize, refreshes the JWKS ONCE and
   retries before failing — this is the standard way to handle a key
   rotation without every in-flight token failing during the rollover.
3. Never trusts the algorithm named in the token's own header for anything
   beyond looking up the matching JWK; the actual verification uses the
   algorithm declared on that JWK record, not attacker-controlled input.
   This closes the classic "alg confusion" JWT vulnerability class.

The JWKS fetch is injected as a plain async callable rather than binding
this class to httpx directly, so unit tests can substitute an in-memory JWKS
built from a locally generated keypair — no network calls, no Clerk
credentials required to test the actual verification logic.
"""

from __future__ import annotations

import time
from collections.abc import Awaitable, Callable

import jwt
from jwt.algorithms import RSAAlgorithm
from jwt.exceptions import ExpiredSignatureError, PyJWTError

from src.domain.exceptions.base import InvalidTokenError
from src.domain.repositories.token_verifier import TokenVerifier

JwksFetcher = Callable[[], Awaitable[dict]]


class ClerkJWTVerifier(TokenVerifier):
    def __init__(self, jwks_fetcher: JwksFetcher, cache_ttl_seconds: int = 3600) -> None:
        self._fetch_jwks = jwks_fetcher
        self._cache_ttl_seconds = cache_ttl_seconds
        self._cached_jwks: dict | None = None
        self._cache_expires_at: float = 0.0

    async def verify(self, token: str) -> dict:
        """Returns the verified claim set, or raises InvalidTokenError."""
        try:
            unverified_header = jwt.get_unverified_header(token)
        except PyJWTError as exc:
            raise InvalidTokenError("Malformed token header.") from exc

        kid = unverified_header.get("kid")
        if not kid:
            raise InvalidTokenError("Token header is missing 'kid'.")

        jwk = await self._find_signing_key(kid)
        if jwk is None:
            raise InvalidTokenError("Token was signed with an unrecognized key.")

        # PyJWT needs a key object, not a raw JWK dict. The algorithm is
        # taken from OUR fetched JWK record — never from the token's own
        # header — which is what closes the classic "alg confusion" attack
        # where an attacker downgrades RS256 to HS256 or "none".
        algorithm = jwk.get("alg", "RS256")
        if algorithm != "RS256":
            raise InvalidTokenError(f"Unsupported signing algorithm '{algorithm}'.")

        try:
            signing_key = RSAAlgorithm.from_jwk(jwk)
        except (PyJWTError, ValueError, KeyError, TypeError) as exc:
            raise InvalidTokenError("Signing key could not be parsed.") from exc

        try:
            claims = jwt.decode(
                token,
                signing_key,
                algorithms=[algorithm],
                options={"verify_aud": False},
            )
        except ExpiredSignatureError as exc:
            raise InvalidTokenError("Token has expired.") from exc
        except PyJWTError as exc:
            raise InvalidTokenError("Token signature verification failed.") from exc

        return claims

    async def _find_signing_key(self, kid: str) -> dict | None:
        jwks = await self._get_jwks()
        key = self._match_kid(jwks, kid)
        if key is not None:
            return key

        # Key not found in the cached set — could be a legitimate rotation.
        # Refresh once and retry before giving up.
        jwks = await self._get_jwks(force_refresh=True)
        return self._match_kid(jwks, kid)

    async def _get_jwks(self, *, force_refresh: bool = False) -> dict:
        now = time.time()
        if force_refresh or self._cached_jwks is None or now >= self._cache_expires_at:
            self._cached_jwks = await self._fetch_jwks()
            self._cache_expires_at = now + self._cache_ttl_seconds
        return self._cached_jwks

    @staticmethod
    def _match_kid(jwks: dict, kid: str) -> dict | None:
        for key in jwks.get("keys", []):
            if key.get("kid") == kid:
                return key
        return None
