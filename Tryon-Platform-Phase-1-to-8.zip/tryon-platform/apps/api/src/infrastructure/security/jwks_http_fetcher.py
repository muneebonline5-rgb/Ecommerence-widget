from __future__ import annotations

import httpx

from src.domain.exceptions.base import InvalidTokenError


def make_http_jwks_fetcher(jwks_url: str, client: httpx.AsyncClient):
    """
    Returns an async callable suitable for ClerkJWTVerifier's `jwks_fetcher`
    parameter, backed by a real HTTP call to Clerk's published JWKS URL.
    """

    async def _fetch() -> dict:
        try:
            response = await client.get(jwks_url, timeout=5.0)
            response.raise_for_status()
        except httpx.HTTPError as exc:
            raise InvalidTokenError("Unable to retrieve signing keys to verify token.") from exc
        return response.json()

    return _fetch
