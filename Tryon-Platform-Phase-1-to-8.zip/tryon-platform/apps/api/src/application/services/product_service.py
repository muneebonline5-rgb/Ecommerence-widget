from __future__ import annotations

from src.domain.entities.product import Product
from src.domain.exceptions.base import (
    EntityAlreadyExistsError,
    EntityNotFoundError,
    NotAMemberError,
)
from src.domain.repositories.interfaces import ProductRepository
from src.domain.value_objects.identifiers import MerchantId, ProductId


class ProductService:
    """
    Merchant-scoped product catalog CRUD. Every read/write is scoped to a
    merchant_id and re-validates ownership on fetch (`_get_owned`) rather
    than trusting a bare product_id, so one merchant can never read or
    mutate another merchant's catalog by guessing/enumerating IDs.
    """

    def __init__(self, product_repository: ProductRepository) -> None:
        self._products = product_repository

    async def create_product(
        self,
        merchant_id: MerchantId,
        *,
        external_id: str,
        title: str,
        product_url: str,
        image_url: str,
        category: str | None = None,
        is_try_on_eligible: bool = True,
        metadata: dict | None = None,
    ) -> Product:
        existing = await self._products.get_by_external_id(merchant_id, external_id)
        if existing is not None:
            raise EntityAlreadyExistsError("Product", "external_id", external_id)

        product = Product.create(
            merchant_id,
            external_id,
            title,
            product_url,
            image_url,
            category=category,
            is_try_on_eligible=is_try_on_eligible,
            metadata=metadata,
        )
        await self._products.save(product)
        return product

    async def upsert_by_external_id(
        self,
        merchant_id: MerchantId,
        *,
        external_id: str,
        title: str,
        product_url: str,
        image_url: str,
        category: str | None = None,
    ) -> Product:
        """
        Used by the widget SDK's product-page auto-detection path: creates
        the product on first sight, or refreshes its details if the
        merchant's storefront content has since changed.
        """
        existing = await self._products.get_by_external_id(merchant_id, external_id)
        if existing is None:
            return await self.create_product(
                merchant_id,
                external_id=external_id,
                title=title,
                product_url=product_url,
                image_url=image_url,
                category=category,
            )

        existing.update_details(
            title=title, product_url=product_url, image_url=image_url, category=category
        )
        await self._products.save(existing)
        return existing

    async def get_product(self, merchant_id: MerchantId, product_id: ProductId) -> Product:
        return await self._get_owned(merchant_id, product_id)

    async def update_product(
        self,
        merchant_id: MerchantId,
        product_id: ProductId,
        *,
        title: str,
        product_url: str,
        image_url: str,
        category: str | None,
        metadata: dict | None = None,
    ) -> Product:
        product = await self._get_owned(merchant_id, product_id)
        product.update_details(
            title=title,
            product_url=product_url,
            image_url=image_url,
            category=category,
            metadata=metadata,
        )
        await self._products.save(product)
        return product

    async def set_try_on_eligible(
        self, merchant_id: MerchantId, product_id: ProductId, eligible: bool
    ) -> Product:
        product = await self._get_owned(merchant_id, product_id)
        product.set_try_on_eligible(eligible)
        await self._products.save(product)
        return product

    async def delete_product(self, merchant_id: MerchantId, product_id: ProductId) -> None:
        await self._get_owned(merchant_id, product_id)  # ownership check
        await self._products.delete(product_id)

    async def list_products(
        self, merchant_id: MerchantId, *, limit: int = 50, offset: int = 0
    ) -> list[Product]:
        return await self._products.list_for_merchant(merchant_id, limit=limit, offset=offset)

    async def _get_owned(self, merchant_id: MerchantId, product_id: ProductId) -> Product:
        product = await self._products.get_by_id(product_id)
        if product is None:
            raise EntityNotFoundError("Product", str(product_id))
        if product.merchant_id != merchant_id:
            raise NotAMemberError(str(merchant_id))
        return product
