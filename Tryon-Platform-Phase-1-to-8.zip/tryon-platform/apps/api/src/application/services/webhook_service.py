from __future__ import annotations

from datetime import UTC, datetime

import structlog

from src.domain.entities.audit_log import AuditLog
from src.domain.entities.invoice import Invoice
from src.domain.entities.webhook_event import WebhookEventRecord
from src.domain.repositories.interfaces import (
    AuditLogRepository,
    InvoiceRepository,
    SubscriptionRepository,
    WebhookEventRepository,
)
from src.domain.repositories.payment_gateway import PaymentGateway
from src.domain.value_objects.billing import InvoiceStatus, SubscriptionStatus
from src.domain.value_objects.identifiers import MerchantId

logger = structlog.get_logger(__name__)

# Stripe's own subscription status strings map directly onto ours except
# "unpaid"/"incomplete_expired", which we fold into PAST_DUE / CANCELED
# respectively — our domain doesn't need Stripe's finer-grained states.
_STRIPE_SUBSCRIPTION_STATUS_MAP = {
    "trialing": SubscriptionStatus.TRIALING,
    "active": SubscriptionStatus.ACTIVE,
    "past_due": SubscriptionStatus.PAST_DUE,
    "unpaid": SubscriptionStatus.PAST_DUE,
    "canceled": SubscriptionStatus.CANCELED,
    "incomplete_expired": SubscriptionStatus.CANCELED,
}

_STRIPE_INVOICE_STATUS_MAP = {
    "draft": InvoiceStatus.DRAFT,
    "open": InvoiceStatus.OPEN,
    "paid": InvoiceStatus.PAID,
    "void": InvoiceStatus.VOID,
    "uncollectible": InvoiceStatus.UNCOLLECTIBLE,
}


class WebhookService:
    """
    Processes inbound Stripe webhooks with two layers of safety:

    1. Signature verification (`PaymentGateway.construct_webhook_event`) —
       the only thing that lets us trust this request came from Stripe at
       all, since this endpoint has no API-key/JWT auth (Stripe can't
       present either).
    2. An idempotency check against `WebhookEventRepository` BEFORE any
       side effect runs — Stripe's delivery guarantee is at-least-once, so
       the same event can arrive twice (e.g. after a slow response timed
       out on Stripe's end even though we'd already finished processing).
    """

    def __init__(
        self,
        webhook_event_repository: WebhookEventRepository,
        subscription_repository: SubscriptionRepository,
        invoice_repository: InvoiceRepository,
        audit_log_repository: AuditLogRepository,
        gateway: PaymentGateway,
    ) -> None:
        self._webhook_events = webhook_event_repository
        self._subscriptions = subscription_repository
        self._invoices = invoice_repository
        self._audit_logs = audit_log_repository
        self._gateway = gateway

    async def handle(self, payload: bytes, signature_header: str) -> str:
        """Returns a short status string for logging/response purposes."""
        event = self._gateway.construct_webhook_event(payload, signature_header)
        log = logger.bind(stripe_event_id=event.stripe_event_id, event_type=event.event_type)

        existing = await self._webhook_events.get_by_stripe_event_id(event.stripe_event_id)
        if existing is not None and existing.is_processed():
            log.info("webhook.duplicate_ignored")
            return "duplicate_ignored"

        record = existing or WebhookEventRecord.receive(event.stripe_event_id, event.event_type)
        await self._webhook_events.save(record)

        handler = self._HANDLERS.get(event.event_type)
        if handler is None:
            log.info("webhook.unhandled_event_type")
        else:
            await handler(self, event.data)
            log.info("webhook.processed")

        record.mark_processed()
        await self._webhook_events.save(record)
        return "processed"

    async def _handle_subscription_updated(self, data: dict) -> None:
        subscription = await self._subscriptions.get_by_stripe_subscription_id(data["id"])
        if subscription is None:
            return  # Not one of ours (or created out-of-band) — nothing to reconcile.

        new_status = _STRIPE_SUBSCRIPTION_STATUS_MAP.get(data["status"])
        if new_status is not None and new_status != subscription.status:
            if new_status == SubscriptionStatus.ACTIVE and subscription.status in (
                SubscriptionStatus.TRIALING,
                SubscriptionStatus.PAST_DUE,
            ):
                subscription.mark_active()
            elif new_status == SubscriptionStatus.PAST_DUE:
                subscription.mark_past_due()
            elif new_status == SubscriptionStatus.CANCELED:
                subscription.cancel_immediately()

        subscription.renew_period(
            datetime.fromtimestamp(data["current_period_start"], tz=UTC),
            datetime.fromtimestamp(data["current_period_end"], tz=UTC),
        )
        subscription.cancel_at_period_end = data.get("cancel_at_period_end", False)
        await self._subscriptions.save(subscription)
        await self._audit_subscription_event(subscription.merchant_id, "subscription.synced", data)

    async def _handle_subscription_deleted(self, data: dict) -> None:
        subscription = await self._subscriptions.get_by_stripe_subscription_id(data["id"])
        if subscription is None:
            return
        if subscription.status != SubscriptionStatus.CANCELED:
            subscription.cancel_immediately()
            await self._subscriptions.save(subscription)
        await self._audit_subscription_event(
            subscription.merchant_id, "subscription.deleted_via_webhook", data
        )

    async def _handle_invoice_event(self, data: dict) -> None:
        subscription_stripe_id = data.get("subscription")
        merchant_id: MerchantId | None = None
        if subscription_stripe_id:
            subscription = await self._subscriptions.get_by_stripe_subscription_id(
                subscription_stripe_id
            )
            if subscription is not None:
                merchant_id = subscription.merchant_id

        if merchant_id is None:
            return  # An invoice we have no merchant context for — nothing to reconcile.

        invoice = await self._invoices.get_by_stripe_invoice_id(data["id"])
        status = _STRIPE_INVOICE_STATUS_MAP.get(data["status"], InvoiceStatus.OPEN)
        period_start = datetime.fromtimestamp(data["period_start"], tz=UTC).date()
        period_end = datetime.fromtimestamp(data["period_end"], tz=UTC).date()

        if invoice is None:
            if period_end <= period_start:
                # Stripe can emit a zero-duration invoice line (e.g. a
                # one-off adjustment); Invoice requires end > start, so
                # widen it to a single day rather than dropping the event.
                from datetime import timedelta

                period_end = period_start + timedelta(days=1)
            invoice = Invoice.create(
                merchant_id,
                data["id"],
                status,
                data["amount_due"] / 100,
                period_start,
                period_end,
                amount_paid_usd=data["amount_paid"] / 100,
                hosted_invoice_url=data.get("hosted_invoice_url"),
            )
        else:
            if status == InvoiceStatus.PAID and invoice.status != InvoiceStatus.PAID:
                invoice.mark_paid(data["amount_paid"] / 100)
            elif status == InvoiceStatus.VOID and invoice.status != InvoiceStatus.VOID:
                invoice.void()
            elif status == InvoiceStatus.OPEN and invoice.status == InvoiceStatus.DRAFT:
                invoice.mark_open()

        await self._invoices.save(invoice)
        await self._audit_invoice_event(merchant_id, "invoice.synced", data)

    async def _handle_invoice_payment_failed(self, data: dict) -> None:
        await self._handle_invoice_event(data)
        subscription_stripe_id = data.get("subscription")
        if not subscription_stripe_id:
            return
        subscription = await self._subscriptions.get_by_stripe_subscription_id(
            subscription_stripe_id
        )
        if subscription is not None and subscription.status == SubscriptionStatus.ACTIVE:
            subscription.mark_past_due()
            await self._subscriptions.save(subscription)

    async def _audit_subscription_event(
        self, merchant_id: MerchantId, action: str, data: dict
    ) -> None:
        entry = AuditLog.record(
            action,
            "subscription",
            data["id"],
            merchant_id=merchant_id,
            actor_type="system",
            metadata={"stripe_status": data.get("status")},
        )
        await self._audit_logs.save(entry)

    async def _audit_invoice_event(self, merchant_id: MerchantId, action: str, data: dict) -> None:
        entry = AuditLog.record(
            action,
            "invoice",
            data["id"],
            merchant_id=merchant_id,
            actor_type="system",
            metadata={"stripe_status": data.get("status")},
        )
        await self._audit_logs.save(entry)

    _HANDLERS = {
        "customer.subscription.updated": _handle_subscription_updated,
        "customer.subscription.deleted": _handle_subscription_deleted,
        "invoice.paid": _handle_invoice_event,
        "invoice.finalized": _handle_invoice_event,
        "invoice.payment_failed": _handle_invoice_payment_failed,
    }
