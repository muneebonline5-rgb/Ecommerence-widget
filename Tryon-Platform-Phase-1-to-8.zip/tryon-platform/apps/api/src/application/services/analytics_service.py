from __future__ import annotations

from datetime import datetime

from src.domain.entities.analytics_event import AnalyticsEvent
from src.domain.exceptions.base import ValidationError
from src.domain.repositories.interfaces import AnalyticsEventRepository
from src.domain.value_objects.identifiers import MerchantId, TryOnSessionId

_MAX_BATCH_SIZE = 100


class AnalyticsService:
    """
    Ingests the widget SDK's batched analytics events (see
    EventTracker in apps/widget-sdk) and provides basic aggregation for the
    merchant dashboard. Ingestion is intentionally forgiving: a single
    malformed event in a batch is dropped rather than failing the entire
    batch, since the widget's delivery is best-effort and a partial batch is
    far more useful than none at all.
    """

    def __init__(self, repository: AnalyticsEventRepository) -> None:
        self._repository = repository

    async def ingest_batch(self, merchant_id: MerchantId, raw_events: list[dict]) -> int:
        if len(raw_events) > _MAX_BATCH_SIZE:
            raise ValidationError(
                f"A batch may contain at most {_MAX_BATCH_SIZE} events, got {len(raw_events)}."
            )

        events: list[AnalyticsEvent] = []
        for raw in raw_events:
            try:
                events.append(self._parse_event(merchant_id, raw))
            except (ValidationError, KeyError, ValueError, TypeError):
                continue  # best-effort: skip malformed entries, don't fail the whole batch

        await self._repository.save_batch(events)
        return len(events)

    async def get_event_counts(
        self, merchant_id: MerchantId, *, start: datetime, end: datetime
    ) -> dict[str, int]:
        if start >= end:
            raise ValidationError("start must be before end.")
        return await self._repository.count_by_type(merchant_id, start=start, end=end)

    @staticmethod
    def _parse_event(merchant_id: MerchantId, raw: dict) -> AnalyticsEvent:
        event_type = AnalyticsEvent.parse_event_type(raw["type"])
        properties = raw.get("properties") or {}
        if not isinstance(properties, dict):
            raise ValidationError("properties must be an object.")

        session_id = None
        session_id_raw = properties.get("session_id")
        if session_id_raw:
            session_id = TryOnSessionId.from_string(str(session_id_raw))

        occurred_at = None
        timestamp_raw = raw.get("timestamp")
        if timestamp_raw:
            occurred_at = datetime.fromisoformat(str(timestamp_raw).replace("Z", "+00:00"))

        return AnalyticsEvent.create(
            merchant_id,
            event_type,
            session_id=session_id,
            properties=properties,
            occurred_at=occurred_at,
        )
