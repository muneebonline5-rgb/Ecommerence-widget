from __future__ import annotations

from src.domain.entities.role import Role
from src.domain.entities.team_membership import TeamMembership
from src.domain.entities.user import User
from src.domain.exceptions.base import (
    InsufficientPermissionError,
    InvalidTokenError,
    NotAMemberError,
)
from src.domain.repositories.interfaces import (
    RoleRepository,
    TeamMembershipRepository,
    UserRepository,
)
from src.domain.repositories.token_verifier import TokenVerifier
from src.domain.value_objects.identifiers import MerchantId, RoleId, UserId


class AuthService:
    """
    Orchestrates the "who is this request from, and what can they do"
    question. Kept separate from the repository/JWT plumbing so routers
    depend on one clean surface: authenticate, get_membership, etc.
    """

    def __init__(
        self,
        jwt_verifier: TokenVerifier,
        user_repository: UserRepository,
        role_repository: RoleRepository,
        team_membership_repository: TeamMembershipRepository,
    ) -> None:
        self._jwt_verifier = jwt_verifier
        self._users = user_repository
        self._roles = role_repository
        self._memberships = team_membership_repository

    async def authenticate(self, bearer_token: str) -> User:
        """
        Verifies a Clerk session JWT and returns the corresponding local
        User, creating it on first sight. There is deliberately no separate
        "sign up" endpoint for dashboard users — Clerk owns that flow
        entirely; our side just needs to stay in sync.
        """
        claims = await self._jwt_verifier.verify(bearer_token)

        clerk_user_id = claims.get("sub")
        if not clerk_user_id:
            raise InvalidTokenError("Token is missing a subject claim.")

        email = claims.get("email")
        full_name = claims.get("name")

        existing = await self._users.get_by_clerk_user_id(clerk_user_id)
        if existing is not None:
            if email and (existing.email != email.lower() or existing.full_name != full_name):
                existing.update_profile(email=email, full_name=full_name)
                await self._users.save(existing)
            return existing

        if not email:
            # First-sight sync requires an email claim to satisfy User's
            # invariants; Clerk includes this by default, but fail loudly
            # and specifically if a custom Clerk template omits it.
            raise InvalidTokenError("Token is missing an email claim required for first sign-in.")

        new_user = User.create(clerk_user_id=clerk_user_id, email=email, full_name=full_name)
        await self._users.save(new_user)
        return new_user

    async def get_membership(self, merchant_id: MerchantId, user_id: UserId) -> TeamMembership:
        membership = await self._memberships.get_for_merchant_and_user(merchant_id, user_id)
        if membership is None:
            raise NotAMemberError(str(merchant_id))
        return membership

    async def get_role(self, role_id: RoleId) -> Role:
        role = await self._roles.get_by_id(role_id)
        if role is None:
            raise InvalidTokenError("Membership references a role that no longer exists.")
        return role

    async def require_permission(
        self, merchant_id: MerchantId, user_id: UserId, permission_code: str
    ) -> TeamMembership:
        """Raises NotAMemberError/InsufficientPermissionError; returns the membership on success."""
        membership = await self.get_membership(merchant_id, user_id)
        role = await self.get_role(membership.role_id)
        if not role.has_permission(permission_code):
            raise InsufficientPermissionError(permission_code)
        return membership
