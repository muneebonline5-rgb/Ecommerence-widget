from __future__ import annotations

from src.domain.entities.audit_log import AuditLog
from src.domain.entities.credit_note import CreditNote
from src.domain.entities.invoice import Invoice
from src.domain.exceptions.base import EntityNotFoundError, NotAMemberError
from src.domain.repositories.interfaces import (
    AuditLogRepository,
    CreditNoteRepository,
    InvoiceRepository,
)
from src.domain.repositories.payment_gateway import GatewayRefund, PaymentGateway
from src.domain.value_objects.identifiers import InvoiceId, MerchantId


class InvoiceService:
    """
    Invoice history is read from our own `InvoiceRepository` (kept in sync
    by `WebhookService` reacting to Stripe's `invoice.*` events) rather than
    calling Stripe live on every read — the merchant dashboard's billing
    history page should not depend on Stripe's API being up. Refunds and
    credit notes are actions that DO call Stripe directly, since they're
    infrequent, explicit, human-triggered operations.
    """

    def __init__(
        self,
        invoice_repository: InvoiceRepository,
        credit_note_repository: CreditNoteRepository,
        audit_log_repository: AuditLogRepository,
        gateway: PaymentGateway,
    ) -> None:
        self._invoices = invoice_repository
        self._credit_notes = credit_note_repository
        self._audit_logs = audit_log_repository
        self._gateway = gateway

    async def list_invoices(
        self, merchant_id: MerchantId, *, limit: int = 50, offset: int = 0
    ) -> list[Invoice]:
        return await self._invoices.list_for_merchant(merchant_id, limit=limit, offset=offset)

    async def get_invoice(self, merchant_id: MerchantId, invoice_id: InvoiceId) -> Invoice:
        return await self._get_owned(merchant_id, invoice_id)

    async def issue_refund(
        self,
        merchant_id: MerchantId,
        invoice_id: InvoiceId,
        stripe_charge_id: str,
        *,
        amount_usd: float | None = None,
        reason: str = "requested_by_customer",
    ) -> GatewayRefund:
        invoice = await self._get_owned(merchant_id, invoice_id)
        refund = await self._gateway.issue_refund(
            stripe_charge_id=stripe_charge_id, amount_usd=amount_usd
        )
        await self._audit(
            merchant_id,
            "invoice.refunded",
            invoice.id.value,
            {
                "stripe_refund_id": refund.stripe_refund_id,
                "amount_usd": refund.amount_usd,
                "reason": reason,
            },
        )
        return refund

    async def issue_credit_note(
        self, merchant_id: MerchantId, invoice_id: InvoiceId, amount_usd: float, reason: str
    ) -> CreditNote:
        invoice = await self._get_owned(merchant_id, invoice_id)

        gateway_credit_note = await self._gateway.create_credit_note(
            stripe_invoice_id=invoice.stripe_invoice_id, amount_usd=amount_usd, reason=reason
        )
        credit_note = CreditNote.create(
            merchant_id,
            invoice.id,
            gateway_credit_note.stripe_credit_note_id,
            gateway_credit_note.amount_usd,
            reason,
        )
        await self._credit_notes.save(credit_note)
        await self._audit(
            merchant_id,
            "invoice.credit_note_issued",
            invoice.id.value,
            {"amount_usd": credit_note.amount_usd, "reason": reason},
        )
        return credit_note

    async def _get_owned(self, merchant_id: MerchantId, invoice_id: InvoiceId) -> Invoice:
        invoice = await self._invoices.get_by_id(invoice_id)
        if invoice is None:
            raise EntityNotFoundError("Invoice", str(invoice_id))
        if invoice.merchant_id != merchant_id:
            raise NotAMemberError(str(merchant_id))
        return invoice

    async def _audit(
        self, merchant_id: MerchantId, action: str, resource_id, metadata: dict
    ) -> None:
        entry = AuditLog.record(
            action,
            "invoice",
            str(resource_id),
            merchant_id=merchant_id,
            actor_type="user",
            metadata=metadata,
        )
        await self._audit_logs.save(entry)
