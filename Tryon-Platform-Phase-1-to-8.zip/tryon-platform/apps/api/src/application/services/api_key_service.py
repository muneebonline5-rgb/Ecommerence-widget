from __future__ import annotations

from dataclasses import dataclass

from src.domain.entities.api_key import ApiKey
from src.domain.exceptions.base import ApiKeyInvalidError, EntityNotFoundError
from src.domain.repositories.interfaces import ApiKeyRepository, MerchantRepository
from src.domain.value_objects.api_key import ApiKeyEnvironment, ApiKeyHash, PlaintextApiKey
from src.domain.value_objects.identifiers import ApiKeyId, MerchantId


@dataclass(frozen=True, slots=True)
class IssuedApiKey:
    """
    DTO returned only at issuance time — the single moment the plaintext key
    is available. Callers must persist `plaintext` client-side immediately;
    it cannot be recovered afterward.
    """

    api_key: ApiKey
    plaintext: str


class ApiKeyService:
    def __init__(
        self,
        api_key_repository: ApiKeyRepository,
        merchant_repository: MerchantRepository,
        pepper: str,
    ) -> None:
        self._api_keys = api_key_repository
        self._merchants = merchant_repository
        self._pepper = pepper

    async def issue_key(
        self, merchant_id: MerchantId, label: str, environment: ApiKeyEnvironment
    ) -> IssuedApiKey:
        merchant = await self._merchants.get_by_id(merchant_id)
        if merchant is None:
            raise EntityNotFoundError("Merchant", str(merchant_id))

        plaintext = PlaintextApiKey.generate(environment)
        key_hash = ApiKeyHash.from_plaintext(plaintext, self._pepper)
        api_key = ApiKey.issue(merchant_id, label, key_hash, environment)
        await self._api_keys.save(api_key)

        return IssuedApiKey(api_key=api_key, plaintext=plaintext.full_key)

    async def authenticate(self, plaintext_key: str) -> ApiKey:
        """
        Verifies a plaintext key presented by a widget/server call and
        records usage. Raises ApiKeyInvalidError for any failure mode
        (unknown prefix, revoked, hash mismatch) — deliberately without
        distinguishing *why* in the response, to avoid leaking which part of
        a forged key was wrong.
        """
        prefix = PlaintextApiKey.extract_prefix(plaintext_key)
        if prefix is None:
            raise ApiKeyInvalidError()

        api_key = await self._api_keys.get_by_prefix(prefix)
        if api_key is None or not api_key.verify(plaintext_key, self._pepper):
            raise ApiKeyInvalidError()

        api_key.record_usage()
        await self._api_keys.save(api_key)
        return api_key

    async def revoke_key(self, api_key_id: ApiKeyId) -> ApiKey:
        api_key = await self._api_keys.get_by_id(api_key_id)
        if api_key is None:
            raise EntityNotFoundError("ApiKey", str(api_key_id))
        api_key.revoke()
        await self._api_keys.save(api_key)
        return api_key

    async def list_keys_for_merchant(self, merchant_id: MerchantId) -> list[ApiKey]:
        return await self._api_keys.list_for_merchant(merchant_id)
