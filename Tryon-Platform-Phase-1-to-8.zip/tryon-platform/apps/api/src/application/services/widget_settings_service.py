from __future__ import annotations

from src.domain.entities.widget_settings import (
    WidgetButtonShape,
    WidgetPosition,
    WidgetSettings,
    WidgetTheme,
)
from src.domain.exceptions.base import EntityNotFoundError
from src.domain.repositories.interfaces import WidgetSettingsRepository
from src.domain.value_objects.identifiers import MerchantId


class WidgetSettingsService:
    def __init__(self, repository: WidgetSettingsRepository) -> None:
        self._repository = repository

    async def get_for_merchant(self, merchant_id: MerchantId) -> WidgetSettings:
        settings = await self._repository.get_by_merchant_id(merchant_id)
        if settings is None:
            raise EntityNotFoundError("WidgetSettings", str(merchant_id))
        return settings

    async def update_theme(
        self,
        merchant_id: MerchantId,
        *,
        primary_color: str,
        accent_color: str,
        text_color: str,
        font_family: str,
        button_shape: WidgetButtonShape,
        border_radius_px: int,
    ) -> WidgetSettings:
        settings = await self.get_for_merchant(merchant_id)
        new_theme = WidgetTheme(
            primary_color=primary_color,
            accent_color=accent_color,
            text_color=text_color,
            font_family=font_family,
            button_shape=button_shape,
            border_radius_px=border_radius_px,
        )
        settings.update_theme(new_theme)
        await self._repository.save(settings)
        return settings

    async def update_position(
        self, merchant_id: MerchantId, position: WidgetPosition
    ) -> WidgetSettings:
        settings = await self.get_for_merchant(merchant_id)
        settings.update_position(position)
        await self._repository.save(settings)
        return settings

    async def set_allowed_origins(
        self, merchant_id: MerchantId, origins: list[str]
    ) -> WidgetSettings:
        settings = await self.get_for_merchant(merchant_id)
        settings.set_allowed_origins(origins)
        await self._repository.save(settings)
        return settings

    async def set_enabled(self, merchant_id: MerchantId, enabled: bool) -> WidgetSettings:
        settings = await self.get_for_merchant(merchant_id)
        settings.enable() if enabled else settings.disable()
        await self._repository.save(settings)
        return settings
