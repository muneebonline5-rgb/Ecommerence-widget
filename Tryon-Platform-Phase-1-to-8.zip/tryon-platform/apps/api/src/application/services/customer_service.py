from __future__ import annotations

from src.domain.entities.merchant import Merchant
from src.domain.exceptions.base import EntityNotFoundError
from src.domain.repositories.interfaces import MerchantRepository
from src.domain.repositories.payment_gateway import PaymentGateway
from src.domain.value_objects.identifiers import MerchantId


class CustomerService:
    """
    Ensures a 1:1 mapping between our `Merchant` and a Stripe Customer,
    created lazily the first time it's needed (e.g. when a merchant first
    subscribes) rather than eagerly for every merchant at signup — many
    merchants never leave the Free tier and never need a Stripe Customer
    object at all.
    """

    def __init__(self, merchant_repository: MerchantRepository, gateway: PaymentGateway) -> None:
        self._merchants = merchant_repository
        self._gateway = gateway

    async def ensure_stripe_customer(self, merchant_id: MerchantId) -> Merchant:
        merchant = await self._get_merchant(merchant_id)
        if merchant.stripe_customer_id:
            return merchant

        customer = await self._gateway.create_customer(
            email=merchant.contact_email,
            name=merchant.name,
            metadata={"merchant_id": str(merchant.id), "domain": merchant.domain},
        )
        merchant.attach_stripe_customer(customer.stripe_customer_id)
        await self._merchants.save(merchant)
        return merchant

    async def sync_customer_metadata(self, merchant_id: MerchantId) -> Merchant:
        """Re-pushes our current merchant details to Stripe (e.g. after a name/email change)."""
        merchant = await self.ensure_stripe_customer(merchant_id)
        await self._gateway.update_customer_metadata(
            merchant.stripe_customer_id,
            {"merchant_id": str(merchant.id), "domain": merchant.domain, "name": merchant.name},
        )
        return merchant

    async def _get_merchant(self, merchant_id: MerchantId) -> Merchant:
        merchant = await self._merchants.get_by_id(merchant_id)
        if merchant is None:
            raise EntityNotFoundError("Merchant", str(merchant_id))
        return merchant
