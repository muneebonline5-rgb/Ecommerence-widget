from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from src.domain.entities.ai_request import AIRequest
from src.domain.entities.tryon import TryOn
from src.domain.entities.tryon_session import TryOnSession
from src.domain.exceptions.base import EntityNotFoundError, NotAMemberError, ValidationError
from src.domain.repositories.interfaces import (
    AIRequestRepository,
    ProductRepository,
    TryOnRepository,
    TryOnSessionRepository,
)
from src.domain.value_objects.ai_provider import AIProviderName
from src.domain.value_objects.identifiers import MerchantId, ProductId, TryOnId


@dataclass(frozen=True, slots=True)
class TryOnGenerationResult:
    tryon: TryOn
    ai_request: AIRequest
    was_deduplicated: (
        bool  # True if an existing idempotency-key match was returned instead of a new one
    )


@dataclass(frozen=True, slots=True)
class TryOnStatusView:
    tryon: TryOn
    ai_request: AIRequest | None


class TryOnGenerationService:
    """
    Orchestrates the "customer wants a try-on generated" use case: creates
    the TryOnSession/TryOn/AIRequest aggregates, enforces idempotency, and
    hands off to the background pipeline. It does NOT call the AI provider
    directly — that happens in the Celery task (apps/worker), which is
    deliberate: an HTTP request handler should never block on a
    multi-second-to-multi-minute generation call.
    """

    def __init__(
        self,
        session_repository: TryOnSessionRepository,
        tryon_repository: TryOnRepository,
        ai_request_repository: AIRequestRepository,
        enqueue_generation: Callable[[str], None],
        product_repository: ProductRepository | None = None,
    ) -> None:
        self._sessions = session_repository
        self._tryons = tryon_repository
        self._ai_requests = ai_request_repository
        self._enqueue_generation = enqueue_generation
        self._products = product_repository

    async def request_generation(
        self,
        *,
        merchant_id: MerchantId,
        anonymous_visitor_id: str,
        customer_image_key: str,
        provider: AIProviderName,
        idempotency_key: str,
        product_id: ProductId | None = None,
        product_image_url: str | None = None,
        country: str | None = None,
        device_type: str | None = None,
        browser: str | None = None,
    ) -> TryOnGenerationResult:
        if not idempotency_key.strip():
            raise ValidationError("An Idempotency-Key is required to request a generation.")

        existing = await self._ai_requests.get_by_idempotency_key(merchant_id, idempotency_key)
        if existing is not None:
            tryon = await self._tryons.get_by_id(existing.tryon_id)
            if tryon is None:
                raise EntityNotFoundError("TryOn", str(existing.tryon_id))
            return TryOnGenerationResult(tryon=tryon, ai_request=existing, was_deduplicated=True)

        resolved_product_image_url = product_image_url
        if product_id is not None:
            if self._products is None:
                raise ValidationError("Product lookup is not available for this request.")
            product = await self._products.get_by_id(product_id)
            if product is None:
                raise EntityNotFoundError("Product", str(product_id))
            if product.merchant_id != merchant_id:
                raise NotAMemberError(str(merchant_id))
            resolved_product_image_url = product.image_url

        if not resolved_product_image_url or not resolved_product_image_url.strip():
            raise ValidationError("Either product_id or product_image_url is required.")

        session = TryOnSession.start(
            merchant_id,
            anonymous_visitor_id,
            product_id=product_id,
            country=country,
            device_type=device_type,
            browser=browser,
        )
        await self._sessions.save(session)

        tryon = TryOn.create(session.id, customer_image_key)
        await self._tryons.save(tryon)

        ai_request = AIRequest.create(
            tryon.id,
            merchant_id,
            provider,
            idempotency_key.strip(),
            request_payload={
                "customer_image_key": customer_image_key,
                "product_image_url": resolved_product_image_url.strip(),
            },
        )
        await self._ai_requests.save(ai_request)

        self._enqueue_generation(str(ai_request.id))

        return TryOnGenerationResult(tryon=tryon, ai_request=ai_request, was_deduplicated=False)

    async def get_status(self, tryon_id: TryOnId, merchant_id: MerchantId) -> TryOnStatusView:
        tryon = await self._tryons.get_by_id(tryon_id)
        if tryon is None:
            raise EntityNotFoundError("TryOn", str(tryon_id))

        session = await self._sessions.get_by_id(tryon.session_id)
        if session is None or session.merchant_id != merchant_id:
            raise NotAMemberError(str(merchant_id))

        ai_request = await self._ai_requests.get_by_tryon_id(tryon_id)
        return TryOnStatusView(tryon=tryon, ai_request=ai_request)

    async def mark_downloaded(self, tryon_id: TryOnId, merchant_id: MerchantId) -> TryOn:
        status_view = await self.get_status(tryon_id, merchant_id)
        status_view.tryon.mark_downloaded()
        await self._tryons.save(status_view.tryon)
        return status_view.tryon
