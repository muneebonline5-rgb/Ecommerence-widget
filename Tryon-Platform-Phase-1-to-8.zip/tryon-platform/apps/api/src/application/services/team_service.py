from __future__ import annotations

from src.domain.entities.merchant import Merchant
from src.domain.entities.team_membership import TeamMembership
from src.domain.exceptions.base import EntityAlreadyExistsError, EntityNotFoundError
from src.domain.repositories.interfaces import (
    MerchantRepository,
    RoleRepository,
    TeamMembershipRepository,
    UserRepository,
)
from src.domain.value_objects.identifiers import MerchantId, RoleId, UserId


class TeamService:
    """
    Manages who belongs to a merchant's team and with what role.

    Note on scope: this assumes the invited user already has a local User
    record, i.e. they have signed in via Clerk at least once. Inviting
    someone who has never signed in (by email, before any User row exists)
    requires integrating Clerk's Invitations API to actually create the
    Clerk-side account — that's out of scope for this phase and tracked for
    the dashboard-integration phase.
    """

    def __init__(
        self,
        team_membership_repository: TeamMembershipRepository,
        user_repository: UserRepository,
        role_repository: RoleRepository,
        merchant_repository: MerchantRepository | None = None,
    ) -> None:
        self._memberships = team_membership_repository
        self._users = user_repository
        self._roles = role_repository
        self._merchants = merchant_repository

    async def add_member(
        self, merchant_id: MerchantId, user_id: UserId, role_id: RoleId
    ) -> TeamMembership:
        user = await self._users.get_by_id(user_id)
        if user is None:
            raise EntityNotFoundError("User", str(user_id))

        role = await self._roles.get_by_id(role_id)
        if role is None:
            raise EntityNotFoundError("Role", str(role_id))

        existing = await self._memberships.get_for_merchant_and_user(merchant_id, user_id)
        if existing is not None:
            raise EntityAlreadyExistsError("TeamMembership", "user_id", str(user_id))

        membership = TeamMembership.create(merchant_id, user_id, role_id)
        await self._memberships.save(membership)
        return membership

    async def change_role(
        self, merchant_id: MerchantId, user_id: UserId, new_role_id: RoleId
    ) -> TeamMembership:
        membership = await self._memberships.get_for_merchant_and_user(merchant_id, user_id)
        if membership is None:
            raise EntityNotFoundError("TeamMembership", str(user_id))

        role = await self._roles.get_by_id(new_role_id)
        if role is None:
            raise EntityNotFoundError("Role", str(new_role_id))

        membership.change_role(new_role_id)
        await self._memberships.save(membership)
        return membership

    async def remove_member(self, merchant_id: MerchantId, user_id: UserId) -> None:
        membership = await self._memberships.get_for_merchant_and_user(merchant_id, user_id)
        if membership is None:
            raise EntityNotFoundError("TeamMembership", str(user_id))
        await self._memberships.delete(membership.id)

    async def list_members(self, merchant_id: MerchantId) -> list[TeamMembership]:
        return await self._memberships.list_for_merchant(merchant_id)

    async def list_merchants_for_user(self, user_id: UserId) -> list[Merchant]:
        """
        Resolves which merchant(s) a signed-in dashboard user belongs to —
        every other merchant-scoped endpoint requires already knowing the
        merchant_id, which a freshly-authenticated user has no other way to
        discover. Silently skips a membership whose merchant no longer
        exists rather than raising, since that's a data-consistency
        concern for an admin process, not something the signed-in user
        should see an error for.
        """
        if self._merchants is None:
            raise EntityNotFoundError("MerchantRepository", "not configured")

        memberships = await self._memberships.list_for_user(user_id)
        if not memberships:
            return []
        # One batched query rather than one per membership — the N+1 this
        # replaces was flagged in the Phase 8 readiness audit.
        return await self._merchants.list_by_ids([m.merchant_id for m in memberships])
