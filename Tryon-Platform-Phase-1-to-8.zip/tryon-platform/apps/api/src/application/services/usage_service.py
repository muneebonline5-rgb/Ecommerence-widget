from __future__ import annotations

from dataclasses import dataclass
from datetime import date

from src.domain.entities.usage_record import UsageRecord
from src.domain.exceptions.base import NoActiveSubscriptionError, ValidationError
from src.domain.repositories.interfaces import (
    PlanRepository,
    SubscriptionRepository,
    UsageRecordRepository,
)
from src.domain.value_objects.identifiers import MerchantId


@dataclass(frozen=True, slots=True)
class UsageSummary:
    period_start: date
    period_end: date
    included_generations: int
    used_generations: int
    overage_generations: int
    overage_cost_usd: float
    breakdown_by_provider: dict


class UsageService:
    """
    Records per-generation cost into daily `UsageRecord`s (called from the
    Celery pipeline's `_finalize`, Phase 4 — see
    worker/tasks/generate_tryon_task.py) and computes overage against a
    merchant's plan allowance.

    Note on scope: this computes overage cost server-side for display and
    future invoicing, but does not yet push metered usage records to a
    Stripe metered price via `PaymentGateway.report_usage` — that requires
    persisting the Stripe subscription item ID, which isn't modeled on
    `Subscription` yet. Tracked as follow-up work rather than implemented
    partially/incorrectly; see docs/architecture.md's Phase 6 section.
    """

    def __init__(
        self,
        usage_repository: UsageRecordRepository,
        subscription_repository: SubscriptionRepository,
        plan_repository: PlanRepository,
    ) -> None:
        self._usage = usage_repository
        self._subscriptions = subscription_repository
        self._plans = plan_repository

    async def record_usage(
        self, merchant_id: MerchantId, provider: str, cost_usd: float, *, occurred_on: date
    ) -> UsageRecord:
        record = await self._usage.get_for_merchant_and_date(merchant_id, occurred_on)
        if record is None:
            record = UsageRecord.start_for_day(merchant_id, occurred_on)
        record.add_usage(provider, cost_usd)
        await self._usage.save(record)
        return record

    async def get_usage_summary(
        self, merchant_id: MerchantId, *, period_start: date, period_end: date
    ) -> UsageSummary:
        if period_end < period_start:
            raise ValidationError("period_end must not be before period_start.")

        subscription = await self._subscriptions.get_by_merchant_id(merchant_id)
        if subscription is None:
            raise NoActiveSubscriptionError(str(merchant_id))

        plan = await self._plans.get_by_id(subscription.plan_id)
        records = await self._usage.list_for_merchant_in_range(
            merchant_id, start=period_start, end=period_end
        )

        used = sum(r.generations_count for r in records)
        overage = max(0, used - plan.included_generations)
        overage_cost = round(overage * plan.overage_price_usd, 2)

        breakdown: dict[str, dict[str, float | int]] = {}
        for record in records:
            for provider, stats in record.breakdown_by_provider.items():
                bucket = breakdown.setdefault(provider, {"count": 0, "cost_usd": 0.0})
                bucket["count"] += stats["count"]
                bucket["cost_usd"] = round(bucket["cost_usd"] + stats["cost_usd"], 6)

        return UsageSummary(
            period_start=period_start,
            period_end=period_end,
            included_generations=plan.included_generations,
            used_generations=used,
            overage_generations=overage,
            overage_cost_usd=overage_cost,
            breakdown_by_provider=breakdown,
        )
