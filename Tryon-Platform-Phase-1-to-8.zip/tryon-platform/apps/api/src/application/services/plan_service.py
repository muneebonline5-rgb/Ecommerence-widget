from __future__ import annotations

from src.domain.entities.plan import Plan
from src.domain.exceptions.base import EntityAlreadyExistsError, EntityNotFoundError
from src.domain.repositories.interfaces import PlanRepository
from src.domain.value_objects.billing import PlanTier
from src.domain.value_objects.identifiers import PlanId


class PlanService:
    """
    Manages the billing plan catalog. Plans are typically seeded once per
    environment (see the platform-admin-only `create_plan` use case, wired
    to /api/v1/billing/plans) after the corresponding Stripe Products/Prices
    have been created in the Stripe Dashboard or CLI — see docs/stripe-setup.md.
    """

    def __init__(self, plan_repository: PlanRepository) -> None:
        self._plans = plan_repository

    async def create_plan(
        self,
        tier: PlanTier,
        name: str,
        *,
        monthly_price_usd: float,
        monthly_stripe_price_id: str,
        included_generations: int,
        overage_price_usd: float,
        yearly_price_usd: float | None = None,
        yearly_stripe_price_id: str | None = None,
    ) -> Plan:
        existing = await self._plans.get_by_tier(tier)
        if existing is not None:
            raise EntityAlreadyExistsError("Plan", "tier", tier.value)

        plan = Plan.create(
            tier,
            name,
            monthly_price_usd=monthly_price_usd,
            monthly_stripe_price_id=monthly_stripe_price_id,
            included_generations=included_generations,
            overage_price_usd=overage_price_usd,
            yearly_price_usd=yearly_price_usd,
            yearly_stripe_price_id=yearly_stripe_price_id,
        )
        await self._plans.save(plan)
        return plan

    async def get_plan(self, plan_id: PlanId) -> Plan:
        plan = await self._plans.get_by_id(plan_id)
        if plan is None:
            raise EntityNotFoundError("Plan", str(plan_id))
        return plan

    async def get_by_tier(self, tier: PlanTier) -> Plan:
        plan = await self._plans.get_by_tier(tier)
        if plan is None:
            raise EntityNotFoundError("Plan", tier.value)
        return plan

    async def list_active_plans(self) -> list[Plan]:
        return await self._plans.list_active()

    async def deactivate_plan(self, plan_id: PlanId) -> Plan:
        plan = await self.get_plan(plan_id)
        plan.deactivate()
        await self._plans.save(plan)
        return plan

    async def activate_plan(self, plan_id: PlanId) -> Plan:
        plan = await self.get_plan(plan_id)
        plan.activate()
        await self._plans.save(plan)
        return plan
