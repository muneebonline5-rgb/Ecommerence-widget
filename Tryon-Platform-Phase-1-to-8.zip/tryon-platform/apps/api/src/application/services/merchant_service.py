from __future__ import annotations

from src.domain.entities.merchant import Merchant, MerchantTier
from src.domain.entities.widget_settings import WidgetSettings
from src.domain.exceptions.base import EntityAlreadyExistsError, EntityNotFoundError
from src.domain.repositories.interfaces import MerchantRepository, WidgetSettingsRepository
from src.domain.value_objects.identifiers import MerchantId


class MerchantOnboardingService:
    """
    Orchestrates merchant sign-up. Lives in the application layer because it
    coordinates two aggregates (Merchant + WidgetSettings) — that
    cross-aggregate choreography is a use case, not a domain-entity concern.
    """

    def __init__(
        self,
        merchant_repository: MerchantRepository,
        widget_settings_repository: WidgetSettingsRepository,
    ) -> None:
        self._merchants = merchant_repository
        self._widget_settings = widget_settings_repository

    async def register_merchant(self, name: str, domain: str, contact_email: str) -> Merchant:
        existing = await self._merchants.get_by_domain(domain)
        if existing is not None:
            raise EntityAlreadyExistsError("Merchant", "domain", domain)

        merchant = Merchant.register(name=name, domain=domain, contact_email=contact_email)
        await self._merchants.save(merchant)

        # Every merchant gets a working widget config out of the box —
        # there is no "unconfigured" state that could 500 the widget SDK.
        default_settings = WidgetSettings.default_for(merchant.id)
        await self._widget_settings.save(default_settings)

        return merchant

    async def get_merchant(self, merchant_id: MerchantId) -> Merchant:
        merchant = await self._merchants.get_by_id(merchant_id)
        if merchant is None:
            raise EntityNotFoundError("Merchant", str(merchant_id))
        return merchant

    async def list_merchants(self, *, limit: int = 50, offset: int = 0) -> list[Merchant]:
        """
        Platform-admin view of every tenant. `MerchantRepository.list_all`
        has existed since Phase 1 but had no caller until the admin
        dashboard needed it — this exposes it without changing the
        repository contract.
        """
        return await self._merchants.list_all(limit=limit, offset=offset)

    async def suspend_merchant(self, merchant_id: MerchantId, reason: str) -> Merchant:
        merchant = await self.get_merchant(merchant_id)
        merchant.suspend(reason)
        await self._merchants.save(merchant)
        return merchant

    async def activate_merchant(self, merchant_id: MerchantId) -> Merchant:
        merchant = await self.get_merchant(merchant_id)
        merchant.activate()
        await self._merchants.save(merchant)
        return merchant

    async def change_tier(self, merchant_id: MerchantId, tier: MerchantTier) -> Merchant:
        merchant = await self.get_merchant(merchant_id)
        merchant.change_tier(tier)
        await self._merchants.save(merchant)
        return merchant
