from __future__ import annotations

from src.application.services.customer_service import CustomerService
from src.domain.entities.audit_log import AuditLog
from src.domain.entities.merchant import MerchantTier
from src.domain.entities.subscription import Subscription
from src.domain.exceptions.base import (
    EntityNotFoundError,
    NoActiveSubscriptionError,
    ValidationError,
)
from src.domain.repositories.interfaces import (
    AuditLogRepository,
    MerchantRepository,
    PlanRepository,
    SubscriptionRepository,
)
from src.domain.repositories.payment_gateway import PaymentGateway
from src.domain.value_objects.billing import (
    BillingInterval,
    PlanTier,
    map_plan_tier_to_merchant_tier,
)
from src.domain.value_objects.identifiers import MerchantId


class SubscriptionService:
    """
    Orchestrates the subscription lifecycle. Stripe is the source of truth
    for billing state (proration math, payment collection, trial
    enforcement) — this service's job is to call the gateway correctly and
    keep our own `Subscription`/`Merchant.tier` records in sync with what
    Stripe confirms, plus write an audit trail for every action.
    """

    def __init__(
        self,
        subscription_repository: SubscriptionRepository,
        plan_repository: PlanRepository,
        merchant_repository: MerchantRepository,
        audit_log_repository: AuditLogRepository,
        customer_service: CustomerService,
        gateway: PaymentGateway,
    ) -> None:
        self._subscriptions = subscription_repository
        self._plans = plan_repository
        self._merchants = merchant_repository
        self._audit_logs = audit_log_repository
        self._customer_service = customer_service
        self._gateway = gateway

    async def subscribe(
        self,
        merchant_id: MerchantId,
        tier: PlanTier,
        interval: BillingInterval,
        *,
        trial_days: int | None = None,
    ) -> Subscription:
        existing = await self._subscriptions.get_by_merchant_id(merchant_id)
        if existing is not None and existing.is_usable():
            raise ValidationError(
                "Merchant already has an active subscription; use change_plan to switch plans."
            )

        plan = await self._plans.get_by_tier(tier)
        if plan is None:
            raise EntityNotFoundError("Plan", tier.value)
        if not plan.supports_interval(interval):
            raise ValidationError(f"Plan '{plan.name}' does not support {interval.value} billing.")

        merchant = await self._customer_service.ensure_stripe_customer(merchant_id)

        gateway_subscription = await self._gateway.create_subscription(
            stripe_customer_id=merchant.stripe_customer_id,
            stripe_price_id=plan.stripe_price_id_for(interval),
            trial_days=trial_days,
        )

        subscription = Subscription.start(
            merchant_id,
            plan.id,
            gateway_subscription.stripe_subscription_id,
            interval,
            gateway_subscription.current_period_start,
            gateway_subscription.current_period_end,
            trial_end=gateway_subscription.trial_end,
        )
        await self._subscriptions.save(subscription)
        await self._sync_merchant_tier(merchant_id, tier)
        await self._audit(
            merchant_id, "subscription.created", subscription.id.value, {"tier": tier.value}
        )
        return subscription

    async def change_plan(
        self,
        merchant_id: MerchantId,
        new_tier: PlanTier,
        new_interval: BillingInterval | None = None,
    ) -> Subscription:
        """Upgrade/downgrade — Stripe computes proration; see PaymentGateway.update_subscription."""
        subscription = await self._get_active_subscription(merchant_id)
        new_plan = await self._plans.get_by_tier(new_tier)
        if new_plan is None:
            raise EntityNotFoundError("Plan", new_tier.value)

        effective_interval = new_interval or subscription.billing_interval
        if not new_plan.supports_interval(effective_interval):
            raise ValidationError(
                f"Plan '{new_plan.name}' does not support {effective_interval.value} billing."
            )

        gateway_subscription = await self._gateway.update_subscription(
            subscription.stripe_subscription_id,
            new_stripe_price_id=new_plan.stripe_price_id_for(effective_interval),
            proration=True,
        )

        subscription.change_plan(new_plan.id, new_interval)
        subscription.renew_period(
            gateway_subscription.current_period_start, gateway_subscription.current_period_end
        )
        await self._subscriptions.save(subscription)
        await self._sync_merchant_tier(merchant_id, new_tier)
        await self._audit(
            merchant_id,
            "subscription.plan_changed",
            subscription.id.value,
            {"new_tier": new_tier.value, "new_interval": effective_interval.value},
        )
        return subscription

    async def cancel(self, merchant_id: MerchantId, *, at_period_end: bool = True) -> Subscription:
        subscription = await self._get_active_subscription(merchant_id)

        gateway_subscription = await self._gateway.cancel_subscription(
            subscription.stripe_subscription_id, at_period_end=at_period_end
        )

        if at_period_end:
            subscription.schedule_cancellation()
        else:
            subscription.cancel_immediately()
        subscription.cancel_at_period_end = gateway_subscription.cancel_at_period_end
        await self._subscriptions.save(subscription)
        await self._audit(
            merchant_id,
            "subscription.canceled",
            subscription.id.value,
            {"at_period_end": at_period_end},
        )
        return subscription

    async def reactivate(self, merchant_id: MerchantId) -> Subscription:
        subscription = await self._subscriptions.get_by_merchant_id(merchant_id)
        if subscription is None:
            raise NoActiveSubscriptionError(str(merchant_id))

        gateway_subscription = await self._gateway.reactivate_subscription(
            subscription.stripe_subscription_id
        )
        subscription.reactivate()
        subscription.current_period_start = gateway_subscription.current_period_start
        subscription.current_period_end = gateway_subscription.current_period_end
        await self._subscriptions.save(subscription)
        await self._audit(merchant_id, "subscription.reactivated", subscription.id.value, {})
        return subscription

    async def get_for_merchant(self, merchant_id: MerchantId) -> Subscription:
        return await self._get_active_subscription(merchant_id, require_usable=False)

    async def _get_active_subscription(
        self, merchant_id: MerchantId, *, require_usable: bool = True
    ) -> Subscription:
        subscription = await self._subscriptions.get_by_merchant_id(merchant_id)
        if subscription is None:
            raise NoActiveSubscriptionError(str(merchant_id))
        if require_usable and not subscription.is_usable():
            raise NoActiveSubscriptionError(str(merchant_id))
        return subscription

    async def _sync_merchant_tier(self, merchant_id: MerchantId, tier: PlanTier) -> None:
        merchant = await self._merchants.get_by_id(merchant_id)
        if merchant is None:
            return
        merchant.change_tier(MerchantTier(map_plan_tier_to_merchant_tier(tier)))
        await self._merchants.save(merchant)

    async def _audit(
        self, merchant_id: MerchantId, action: str, resource_id, metadata: dict
    ) -> None:
        entry = AuditLog.record(
            action,
            "subscription",
            str(resource_id),
            merchant_id=merchant_id,
            actor_type="system",
            metadata=metadata,
        )
        await self._audit_logs.save(entry)
