"""
Centralized configuration. All environment variables are declared here with
types and defaults — no `os.environ.get()` scattered through the codebase.
"""

from __future__ import annotations

from functools import lru_cache

from pydantic import Field, PostgresDsn, RedisDsn, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # --- Core ---
    environment: str = Field(default="development")  # development | staging | production
    debug: bool = Field(default=False)
    api_base_url: str = Field(default="http://localhost:8000")

    # --- Database ---
    database_url: PostgresDsn
    database_pool_size: int = Field(default=10)
    database_max_overflow: int = Field(default=20)

    # --- Redis / Celery ---
    redis_url: RedisDsn
    celery_broker_url: RedisDsn
    celery_result_backend: RedisDsn

    # --- Security ---
    api_key_pepper: str = Field(..., min_length=32)
    jwt_secret: str = Field(..., min_length=32)
    jwt_algorithm: str = Field(default="HS256")
    jwt_access_token_ttl_seconds: int = Field(default=900)

    # --- Clerk ---
    clerk_secret_key: str = Field(default="")
    clerk_publishable_key: str = Field(default="")
    clerk_jwks_url: str = Field(default="")

    # --- Stripe ---
    stripe_secret_key: str = Field(default="")
    stripe_webhook_secret: str = Field(default="")

    # --- Billing: per-provider cost used to meter usage (Phase 6) ---
    fashn_cost_per_generation_usd: float = Field(default=0.05)
    openai_cost_per_generation_usd: float = Field(default=0.08)
    flux_cost_per_generation_usd: float = Field(default=0.06)
    kling_cost_per_generation_usd: float = Field(default=0.07)

    # --- Billing: default plan catalog (used by the plan-seeding admin
    # endpoint — see docs/stripe-setup.md for how to create these Products
    # and Prices in the Stripe Dashboard/CLI first) ---
    billing_default_trial_days: int = Field(default=14)
    plan_starter_monthly_price_id: str = Field(default="")
    plan_starter_yearly_price_id: str = Field(default="")
    plan_pro_monthly_price_id: str = Field(default="")
    plan_pro_yearly_price_id: str = Field(default="")
    plan_enterprise_monthly_price_id: str = Field(default="")
    plan_enterprise_yearly_price_id: str = Field(default="")

    # --- Storage (S3 / Cloudflare R2) ---
    storage_bucket_name: str = Field(default="tryon-uploads")
    storage_endpoint_url: str = Field(default="")
    storage_access_key_id: str = Field(default="")
    storage_secret_access_key: str = Field(default="")
    storage_signed_url_ttl_seconds: int = Field(default=900)

    # --- Rate limiting ---
    rate_limit_default_per_minute: int = Field(default=120)
    rate_limit_ai_generation_per_minute: int = Field(default=10)

    # --- AI Providers ---
    default_ai_provider: str = Field(default="fashn")
    fashn_api_key: str = Field(default="")
    fashn_api_base_url: str = Field(default="https://api.fashn.ai")
    openai_api_key: str = Field(default="")
    openai_api_base_url: str = Field(default="https://api.openai.com")
    flux_api_key: str = Field(default="")
    flux_api_base_url: str = Field(default="https://api.bfl.ai")
    kling_access_key: str = Field(default="")
    kling_secret_key: str = Field(default="")
    kling_api_base_url: str = Field(default="https://api.klingai.com")

    # --- Celery worker pipeline ---
    tryon_generation_soft_time_limit_seconds: int = Field(default=60)
    tryon_generation_hard_time_limit_seconds: int = Field(default=90)
    tryon_status_poll_interval_seconds: int = Field(default=3)
    tryon_status_poll_max_attempts: int = Field(default=20)
    tryon_generation_max_retries: int = Field(default=3)
    idempotency_lock_ttl_seconds: int = Field(default=120)

    # --- Observability ---
    sentry_dsn: str = Field(default="")
    sentry_traces_sample_rate: float = Field(default=0.1, ge=0.0, le=1.0)
    posthog_api_key: str = Field(default="")
    posthog_host: str = Field(default="https://app.posthog.com")

    # --- CORS ---
    cors_allowed_origins: list[str] = Field(
        default_factory=lambda: ["http://localhost:3000", "http://localhost:3001"]
    )

    @field_validator("environment")
    @classmethod
    def _validate_environment(cls, value: str) -> str:
        allowed = {"development", "staging", "production"}
        if value not in allowed:
            raise ValueError(f"environment must be one of {allowed}, got '{value}'")
        return value

    @field_validator("default_ai_provider")
    @classmethod
    def _validate_default_ai_provider(cls, value: str) -> str:
        allowed = {"fashn", "openai", "flux", "kling"}
        if value not in allowed:
            raise ValueError(f"default_ai_provider must be one of {allowed}, got '{value}'")
        return value


@lru_cache
def get_settings() -> Settings:
    """Cached so `.env` is parsed once per process, not per request."""
    return Settings()  # type: ignore[call-arg]
