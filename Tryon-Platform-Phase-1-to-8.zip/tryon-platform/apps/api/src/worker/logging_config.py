"""
Structured logging for the worker process, via structlog.

Every log line in the generation task is emitted through a logger bound
with ai_request_id/provider/attempt context up front, so a single grep for
an AIRequest id reconstructs its entire processing history across retries
— submitted, polled N times, completed/failed — without manually
correlating free-text log lines.
"""

from __future__ import annotations

import logging
import sys

import structlog


def configure_worker_logging(*, json_output: bool = True) -> None:
    logging.basicConfig(format="%(message)s", stream=sys.stdout, level=logging.INFO)

    processors: list = [
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
    ]
    processors.append(
        structlog.processors.JSONRenderer() if json_output else structlog.dev.ConsoleRenderer()
    )

    structlog.configure(
        processors=processors,
        wrapper_class=structlog.make_filtering_bound_logger(logging.INFO),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(),
        cache_logger_on_first_use=True,
    )
