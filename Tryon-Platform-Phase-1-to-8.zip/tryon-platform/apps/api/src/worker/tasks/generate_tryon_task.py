"""
Celery task: generate_tryon.

Celery tasks are synchronous by nature; this task's body is a thin
sync-to-async bridge (`asyncio.run`) around `_execute`, where all the real
async logic (DB access, HTTP calls to the AI provider) lives. A fresh event
loop, DB engine, Redis client, and HTTP client are created per task
invocation and torn down at the end — see provider_wiring.py for why this
is correct rather than wasteful.

Every meaningful state change (submission, each poll that reaches a
terminal status, finalization) commits in its OWN short-lived transaction
via `transactional_session`, rather than holding one transaction open for
the task's entire lifetime. This matters concretely: the polling loop below
sleeps between provider status checks, and a job can take anywhere from a
few seconds to the full soft time limit — an idle-in-transaction connection
held that long is a real Postgres anti-pattern (connection pool pressure,
long-running-transaction alerts), not just a style preference.

Idempotency has two layers, deliberately:
1. A Redis lock (RedisLock) prevents two concurrent executions of the same
   AIRequest — protects against at-least-once delivery causing overlapping
   runs after a broker-visibility-timeout redelivery.
2. The AIRequest's own persisted state (`provider_request_id`, `status`) is
   checked on every execution — a redelivered task that finds the AIRequest
   already terminal is a no-op; one that finds a `provider_request_id`
   already set resumes polling instead of re-submitting to the (paid) AI
   provider.

Retry policy distinguishes `ProviderTransientError` (network blips,
provider 5xx/429, exhausted polling) — retried with exponential backoff —
from `ProviderPermanentError` (rejected input, unsupported operation),
which fails the AIRequest/TryOn immediately since retrying can never help.
"""

from __future__ import annotations

import asyncio
import time
from datetime import UTC, datetime

import httpx
import structlog
from celery.exceptions import SoftTimeLimitExceeded
from sqlalchemy.ext.asyncio import async_sessionmaker

from src.application.services.usage_service import UsageService
from src.config.settings import Settings, get_settings
from src.domain.exceptions.base import ProviderPermanentError, ProviderTransientError
from src.domain.repositories.storage import SignedUrlProvider
from src.domain.value_objects.ai_provider import (
    AIProviderName,
    ProviderJobResult,
    ProviderRequestStatus,
    TryOnGenerationRequest,
)
from src.domain.value_objects.identifiers import AIRequestId
from src.infrastructure.cache.redis_client import create_redis_client
from src.infrastructure.cache.redis_lock import RedisLock
from src.infrastructure.db.repositories.ai_request_repository import SqlAlchemyAIRequestRepository
from src.infrastructure.db.repositories.plan_repository import SqlAlchemyPlanRepository
from src.infrastructure.db.repositories.subscription_repository import (
    SqlAlchemySubscriptionRepository,
)
from src.infrastructure.db.repositories.tryon_repository import SqlAlchemyTryOnRepository
from src.infrastructure.db.repositories.usage_record_repository import (
    SqlAlchemyUsageRecordRepository,
)
from src.infrastructure.db.session import (
    create_engine,
    create_session_factory,
    transactional_session,
)
from src.worker.celery_app import celery_app
from src.worker.provider_wiring import build_provider_factory, build_storage_provider

logger = structlog.get_logger(__name__)

_settings_for_decorator = get_settings()


def _cost_per_generation(settings: Settings, provider: AIProviderName) -> float:
    return {
        AIProviderName.FASHN: settings.fashn_cost_per_generation_usd,
        AIProviderName.OPENAI: settings.openai_cost_per_generation_usd,
        AIProviderName.FLUX: settings.flux_cost_per_generation_usd,
        AIProviderName.KLING: settings.kling_cost_per_generation_usd,
    }[provider]


@celery_app.task(
    bind=True,
    name="src.worker.tasks.generate_tryon_task.generate_tryon",
    soft_time_limit=_settings_for_decorator.tryon_generation_soft_time_limit_seconds,
    time_limit=_settings_for_decorator.tryon_generation_hard_time_limit_seconds,
    max_retries=_settings_for_decorator.tryon_generation_max_retries,
)
def generate_tryon(self, ai_request_id: str) -> None:
    log = logger.bind(ai_request_id=ai_request_id, attempt=self.request.retries + 1)
    log.info("generation.task_started")

    try:
        asyncio.run(_execute(ai_request_id, log))
        log.info("generation.task_finished")
    except SoftTimeLimitExceeded as exc:
        log.warning("generation.soft_time_limit_exceeded")
        _handle_retryable(self, ai_request_id, log, exc)
    except ProviderTransientError as exc:
        log.warning("generation.transient_error", error=str(exc))
        _handle_retryable(self, ai_request_id, log, exc)
    except ProviderPermanentError as exc:
        log.error("generation.permanent_error", error=str(exc))
        asyncio.run(_mark_failed(ai_request_id, str(exc)))
    except Exception as exc:  # noqa: BLE001 - last-resort safety net; unknown errors are treated as retryable
        log.exception("generation.unexpected_error")
        _handle_retryable(self, ai_request_id, log, exc)


def _handle_retryable(self, ai_request_id: str, log, exc: Exception) -> None:
    settings = get_settings()
    if self.request.retries >= settings.tryon_generation_max_retries:
        log.error("generation.retries_exhausted", error=str(exc))
        asyncio.run(
            _mark_failed(ai_request_id, f"Failed after {self.request.retries + 1} attempts: {exc}")
        )
        return

    backoff_seconds = min(5 * (2**self.request.retries), 60)
    log.warning("generation.scheduling_retry", backoff_seconds=backoff_seconds, error=str(exc))
    raise self.retry(exc=exc, countdown=backoff_seconds)


async def _execute(ai_request_id: str, log) -> None:
    settings = get_settings()
    engine = create_engine(settings)
    session_factory = create_session_factory(engine)
    redis = create_redis_client(settings)
    http_client = httpx.AsyncClient()

    try:
        lock = RedisLock(
            redis,
            key=f"ai_request:{ai_request_id}",
            ttl_seconds=settings.idempotency_lock_ttl_seconds,
        )
        if not await lock.acquire():
            log.info("generation.already_in_progress_elsewhere")
            return

        try:
            await _process(ai_request_id, settings, session_factory, http_client, log)
        finally:
            await lock.release()
    finally:
        await http_client.aclose()
        await redis.aclose()
        await engine.dispose()


async def _process(
    ai_request_id: str,
    settings,
    session_factory: async_sessionmaker,
    http_client: httpx.AsyncClient,
    log,
) -> None:
    async with transactional_session(session_factory) as db_session:
        ai_repo = SqlAlchemyAIRequestRepository(db_session)
        tryon_repo = SqlAlchemyTryOnRepository(db_session)

        ai_request = await ai_repo.get_by_id(AIRequestId.from_string(ai_request_id))
        if ai_request is None:
            log.error("generation.ai_request_not_found")
            return

        if ai_request.is_terminal():
            log.info("generation.already_terminal", status=ai_request.status.value)
            return  # idempotency: a redelivered task after success/failure is a no-op

        tryon = await tryon_repo.get_by_id(ai_request.tryon_id)
        if tryon is None:
            log.error("generation.tryon_not_found")
            return

    # From here on, each step commits independently — see module docstring
    # for why the transaction is not held open across the polling sleeps.
    storage = build_storage_provider(settings)
    provider_factory = build_provider_factory(settings, http_client, storage)
    provider = provider_factory.get_provider(ai_request.provider)

    started_at = time.monotonic()
    provider_request_id = ai_request.provider_request_id

    if provider_request_id is None:
        customer_image_url = storage.get_object_url(
            ai_request.request_payload["customer_image_key"]
        )
        product_image_url = ai_request.request_payload["product_image_url"]

        if tryon.status.value == "pending":
            await _mark_processing(ai_request.tryon_id, session_factory)

        log.info("generation.submitting", provider=ai_request.provider.value)
        handle = await provider.generate_tryon(
            TryOnGenerationRequest(
                customer_image_url=customer_image_url,
                product_image_url=product_image_url,
                merchant_reference=str(ai_request.id),
            )
        )
        provider_request_id = handle.provider_request_id
        await _save_submission(ai_request.id, provider_request_id, session_factory)
        log.info("generation.submitted", provider_request_id=provider_request_id)

        if handle.status == ProviderRequestStatus.COMPLETED:
            # Synchronous provider (OpenAI) — already done, no polling needed.
            result = await provider.check_status(provider_request_id)
            await _finalize(
                ai_request.id,
                ai_request.provider,
                result,
                storage,
                started_at,
                session_factory,
                log,
            )
            return
    else:
        log.info("generation.resuming_poll", provider_request_id=provider_request_id)

    for attempt in range(settings.tryon_status_poll_max_attempts):
        await asyncio.sleep(settings.tryon_status_poll_interval_seconds)
        result = await provider.check_status(provider_request_id)
        log.info("generation.polled", status=result.status.value, poll_attempt=attempt + 1)

        if result.status == ProviderRequestStatus.COMPLETED:
            await _finalize(
                ai_request.id,
                ai_request.provider,
                result,
                storage,
                started_at,
                session_factory,
                log,
            )
            return

        if result.status == ProviderRequestStatus.FAILED:
            error_message = result.error_message or "Provider reported failure."
            latency_ms = int((time.monotonic() - started_at) * 1000)
            await _save_failure(ai_request.id, error_message, latency_ms, session_factory)
            log.error("generation.failed", error=error_message)
            return

    # Polling exhausted without a terminal status. Raising here (rather
    # than looping forever) lets Celery's retry/backoff take over — and
    # because provider_request_id is already persisted, the retry resumes
    # polling rather than re-submitting to the vendor.
    raise ProviderTransientError(
        f"Polling exhausted after {settings.tryon_status_poll_max_attempts} attempts "
        "without a terminal status.",
        details={"provider": ai_request.provider.value},
    )


async def _mark_processing(tryon_id, session_factory: async_sessionmaker) -> None:
    async with transactional_session(session_factory) as db_session:
        tryon_repo = SqlAlchemyTryOnRepository(db_session)
        tryon = await tryon_repo.get_by_id(tryon_id)
        if tryon is not None and tryon.status.value == "pending":
            tryon.start_processing()
            await tryon_repo.save(tryon)


async def _save_submission(
    ai_request_id, provider_request_id: str, session_factory: async_sessionmaker
) -> None:
    async with transactional_session(session_factory) as db_session:
        ai_repo = SqlAlchemyAIRequestRepository(db_session)
        ai_request = await ai_repo.get_by_id(ai_request_id)
        if ai_request is not None and ai_request.provider_request_id is None:
            ai_request.mark_submitted(provider_request_id)
            await ai_repo.save(ai_request)


async def _save_failure(
    ai_request_id, error_message: str, latency_ms: int, session_factory: async_sessionmaker
) -> None:
    async with transactional_session(session_factory) as db_session:
        ai_repo = SqlAlchemyAIRequestRepository(db_session)
        tryon_repo = SqlAlchemyTryOnRepository(db_session)

        ai_request = await ai_repo.get_by_id(ai_request_id)
        if ai_request is None or ai_request.is_terminal():
            return
        ai_request.mark_failed(error_message, latency_ms=latency_ms)
        await ai_repo.save(ai_request)

        tryon = await tryon_repo.get_by_id(ai_request.tryon_id)
        if tryon is not None and tryon.status.value in ("pending", "processing"):
            tryon.fail(error_message)
            await tryon_repo.save(tryon)


async def _finalize(
    ai_request_id,
    provider_name: AIProviderName,
    result: ProviderJobResult,
    storage: SignedUrlProvider,
    started_at: float,
    session_factory: async_sessionmaker,
    log,
) -> None:
    latency_ms = int((time.monotonic() - started_at) * 1000)

    if not result.result_image_url:
        message = "Provider reported completion without a result image."
        await _save_failure(ai_request_id, message, latency_ms, session_factory)
        log.error("generation.completed_without_result")
        return

    if provider_name == AIProviderName.OPENAI:
        # OpenAI's adapter already persisted the result to our own storage
        # and hands back the object key directly (see openai_provider.py) —
        # no re-fetch/re-upload needed.
        result_object_key = result.result_image_url
    else:
        result_object_key = await _persist_external_result(result.result_image_url, storage)

    async with transactional_session(session_factory) as db_session:
        ai_repo = SqlAlchemyAIRequestRepository(db_session)
        tryon_repo = SqlAlchemyTryOnRepository(db_session)

        ai_request = await ai_repo.get_by_id(ai_request_id)
        if ai_request is None or ai_request.is_terminal():
            return

        tryon = await tryon_repo.get_by_id(ai_request.tryon_id)

        settings = get_settings()
        cost_usd = _cost_per_generation(settings, provider_name)

        ai_request.mark_completed(
            {"result_object_key": result_object_key}, latency_ms=latency_ms, cost_usd=cost_usd
        )
        await ai_repo.save(ai_request)

        if tryon is not None and tryon.status.value in ("pending", "processing"):
            tryon.complete(result_object_key)
            await tryon_repo.save(tryon)

        # Meter this generation into the merchant's daily usage rollup —
        # see UsageService/UsageRecord (Phase 6) — in the SAME transaction
        # as the AIRequest/TryOn completion, so a crash between "generation
        # completed" and "usage recorded" is impossible: both commit
        # together or neither does.
        usage_service = UsageService(
            usage_repository=SqlAlchemyUsageRecordRepository(db_session),
            subscription_repository=SqlAlchemySubscriptionRepository(db_session),
            plan_repository=SqlAlchemyPlanRepository(db_session),
        )
        await usage_service.record_usage(
            ai_request.merchant_id,
            provider_name.value,
            cost_usd,
            occurred_on=datetime.now(UTC).date(),
        )

    log.info(
        "generation.completed",
        result_object_key=result_object_key,
        latency_ms=latency_ms,
        cost_usd=cost_usd,
    )


async def _persist_external_result(external_url: str, storage: SignedUrlProvider) -> str:
    """Downloads a provider-hosted result and re-persists it to our own storage."""
    async with httpx.AsyncClient() as client:
        response = await client.get(external_url, timeout=30.0)
        response.raise_for_status()
        content_type = response.headers.get("content-type", "image/png").split(";")[0]
        return storage.upload_bytes(
            key_prefix="tryon-results/generated", data=response.content, content_type=content_type
        )


async def _mark_failed(ai_request_id: str, message: str) -> None:
    """Used both for permanent failures and for retries-exhausted give-ups."""
    settings = get_settings()
    engine = create_engine(settings)
    session_factory = create_session_factory(engine)
    try:
        await _save_failure(AIRequestId.from_string(ai_request_id), message, 0, session_factory)
    finally:
        await engine.dispose()
