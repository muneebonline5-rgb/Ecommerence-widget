"""
Celery application factory.

Reuses the same `Settings` as the FastAPI app (src/config/settings.py) —
broker/backend URLs, retry counts, and time limits are configured in one
place, not duplicated between the API and worker processes.
"""

from __future__ import annotations

from celery import Celery

from src.config.settings import get_settings


def create_celery_app() -> Celery:
    settings = get_settings()

    app = Celery(
        "tryon_platform",
        broker=str(settings.celery_broker_url),
        backend=str(settings.celery_result_backend),
        include=["src.worker.tasks.generate_tryon_task"],
    )

    app.conf.update(
        # Late ack: a task is only removed from the queue after it
        # finishes, not as soon as a worker picks it up. Combined with
        # task_reject_on_worker_lost, this means a worker crashing mid-task
        # (OOM, deploy, hardware failure) puts the task back on the queue
        # for another worker to pick up, rather than silently losing it —
        # the core of "failure recovery" for this pipeline.
        task_acks_late=True,
        task_reject_on_worker_lost=True,
        # Fair dispatch: a worker only prefetches one task at a time rather
        # than grabbing a batch, so a slow long-running generation job
        # doesn't starve other workers of queued work sitting idle.
        worker_prefetch_multiplier=1,
        task_default_queue="default",
        task_routes={
            "src.worker.tasks.generate_tryon_task.generate_tryon": {"queue": "tryon_generation"},
        },
        result_expires=3600,
        timezone="UTC",
        enable_utc=True,
        # Structured, JSON-friendly task events for anything consuming
        # Celery's event stream (e.g. Flower, or a future admin dashboard
        # "queues" view per the project's Phase 7 admin dashboard scope).
        worker_send_task_events=True,
        task_send_sent_event=True,
    )

    return app


celery_app = create_celery_app()
