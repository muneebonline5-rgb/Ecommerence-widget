"""
Wires concrete AI provider adapters and the storage provider from
`Settings`, for use inside a task's async execution scope.

Built fresh per task invocation (see tasks/generate_tryon_task.py) rather
than once at worker-process startup: the httpx.AsyncClient these adapters
hold must belong to the same asyncio event loop it's used from, and each
task execution gets its own fresh event loop via `asyncio.run` — the same
"function-scoped, not session-scoped" lesson learned from this project's
Phase 1/2 test suite applies equally here.
"""

from __future__ import annotations

import httpx

from src.config.settings import Settings
from src.domain.repositories.ai_provider import AIProviderFactory
from src.domain.repositories.storage import SignedUrlProvider
from src.domain.value_objects.ai_provider import AIProviderName
from src.infrastructure.ai_providers.fashn_provider import FashnProviderAdapter
from src.infrastructure.ai_providers.flux_provider import FluxProviderAdapter
from src.infrastructure.ai_providers.kling_provider import KlingProviderAdapter
from src.infrastructure.ai_providers.openai_provider import OpenAIProviderAdapter
from src.infrastructure.ai_providers.provider_factory import RegistryAIProviderFactory
from src.infrastructure.storage.s3_signed_url_provider import S3SignedUrlProvider


def build_storage_provider(settings: Settings) -> SignedUrlProvider:
    return S3SignedUrlProvider(
        bucket_name=settings.storage_bucket_name,
        endpoint_url=settings.storage_endpoint_url,
        access_key_id=settings.storage_access_key_id,
        secret_access_key=settings.storage_secret_access_key,
        default_upload_ttl_seconds=settings.storage_signed_url_ttl_seconds,
    )


def build_provider_factory(
    settings: Settings, http_client: httpx.AsyncClient, storage: SignedUrlProvider
) -> AIProviderFactory:
    providers = {
        AIProviderName.FASHN: FashnProviderAdapter(
            http_client, api_key=settings.fashn_api_key, base_url=settings.fashn_api_base_url
        ),
        AIProviderName.OPENAI: OpenAIProviderAdapter(
            http_client,
            storage,
            api_key=settings.openai_api_key,
            base_url=settings.openai_api_base_url,
        ),
        AIProviderName.FLUX: FluxProviderAdapter(
            http_client, api_key=settings.flux_api_key, base_url=settings.flux_api_base_url
        ),
        AIProviderName.KLING: KlingProviderAdapter(
            http_client,
            access_key=settings.kling_access_key,
            secret_key=settings.kling_secret_key,
            base_url=settings.kling_api_base_url,
        ),
    }
    return RegistryAIProviderFactory(providers)
