from __future__ import annotations

from fastapi import FastAPI, Response
from fastapi.middleware.cors import CORSMiddleware

from src.config.settings import get_settings
from src.domain.exceptions.base import DomainError
from src.infrastructure.observability.setup import configure_logging, configure_sentry
from src.interfaces.api.middleware.metrics import MetricsMiddleware, metrics_endpoint
from src.interfaces.api.middleware.observability import RequestContextMiddleware
from src.interfaces.api.response import domain_error_handler, unhandled_exception_handler
from src.interfaces.api.v1.routers import (
    analytics,
    api_keys,
    billing,
    health,
    merchants,
    products,
    team,
    tryon,
    webhooks,
    widget_settings,
)


def create_app() -> FastAPI:
    settings = get_settings()

    # Must run before anything else so startup itself is logged/reported.
    configure_logging(settings)
    configure_sentry(settings, component="api")

    app = FastAPI(
        title="AI Try-On Platform API",
        version="0.1.0",
        docs_url="/docs" if settings.environment != "production" else None,
        redoc_url="/redoc" if settings.environment != "production" else None,
    )

    # Order matters: middleware added last runs first. Metrics wraps the
    # request-context middleware so recorded latency includes it, rather
    # than under-reporting by measuring only the inner handler.
    app.add_middleware(RequestContextMiddleware)
    app.add_middleware(MetricsMiddleware)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_allowed_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.add_exception_handler(DomainError, domain_error_handler)
    app.add_exception_handler(Exception, unhandled_exception_handler)

    api_v1_prefix = "/api/v1"
    app.include_router(merchants.router, prefix=api_v1_prefix)
    app.include_router(api_keys.router, prefix=api_v1_prefix)
    app.include_router(widget_settings.dashboard_router, prefix=api_v1_prefix)
    app.include_router(widget_settings.router, prefix=api_v1_prefix)
    app.include_router(team.router, prefix=api_v1_prefix)
    app.include_router(team.team_router, prefix=api_v1_prefix)
    app.include_router(tryon.router, prefix=api_v1_prefix)
    app.include_router(products.router, prefix=api_v1_prefix)
    app.include_router(analytics.router, prefix=api_v1_prefix)
    app.include_router(billing.router, prefix=api_v1_prefix)
    app.include_router(webhooks.router, prefix=api_v1_prefix)
    # Probes are intentionally unprefixed: orchestrator health checks
    # should not depend on an API version path.
    app.include_router(health.router)

    @app.get("/metrics", include_in_schema=False)
    async def metrics() -> Response:
        """Prometheus scrape target. Excluded from OpenAPI — it's infra, not API."""
        return metrics_endpoint()

    return app


app = create_app()
