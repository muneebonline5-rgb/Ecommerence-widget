# Worker (Celery)

## Where the code actually lives, and why

Unlike the JS-based apps in this monorepo (which use separate `node_modules`
per package via a JS package manager), Python doesn't have first-class
workspace tooling that makes "several apps sharing one internal library"
painless without either a monorepo build system (Bazel/Pants) or publishing
an internal package to a private index. Given this project's domain layer,
application services, and infrastructure adapters (DB repositories, AI
provider adapters, storage) need to be identical between the FastAPI process
and the Celery worker process — not reimplemented twice — the pragmatic,
honest choice was:

**The actual Celery app and tasks live inside `apps/api/src/worker/`,
reusing the exact same `domain/`, `application/`, and `infrastructure/`
code as the API.** This folder (`apps/worker/`) is the deployment
entrypoint: a separate container image/process that runs the worker code
from the `api` package, which is how these two processes are actually
deployed independently in production despite sharing one codebase.

This is a common, defensible pattern for Python FastAPI+Celery systems
that share a domain model — most production systems in this stack look
like this rather than duplicating repositories/entities across two
packages. It's called out explicitly here rather than left implicit,
since the top-level project structure document originally listed
`apps/worker` as its own folder.

## Running the worker

```bash
cd apps/api
pip install -e ".[dev]"

celery -A src.worker.celery_app worker \
  --loglevel=info \
  --queues=tryon_generation,default \
  --concurrency=4
```

## Docker

```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY apps/api/pyproject.toml apps/api/src ./
RUN pip install --no-cache-dir -e ".[dev]" --no-deps -e .
CMD ["celery", "-A", "src.worker.celery_app", "worker", "--loglevel=info", \
     "--queues=tryon_generation,default"]
```

## Monitoring

`worker_send_task_events=True` / `task_send_sent_event=True` are enabled in
`src/worker/celery_app.py`, so a standard Celery monitoring tool (e.g.
Flower) can attach to the same broker and show live task/queue state
without any additional wiring — relevant for the admin dashboard's planned
"Queues" view (Phase 7).
