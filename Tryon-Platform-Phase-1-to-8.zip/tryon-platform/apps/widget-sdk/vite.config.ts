import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { resolve } from "path";

// Single-file IIFE build: the whole point of "one script tag" is that the
// merchant's site makes exactly one request and gets a self-contained
// bundle. No code-splitting, no separate CSS file to forget to include.
export default defineConfig({
  plugins: [react()],
  // Library mode does NOT automatically replace process.env.NODE_ENV the
  // way Vite's app-mode build does — without this, React's own internal
  // `if (process.env.NODE_ENV === 'production')` check never resolves
  // statically, so both the dev AND prod builds of React/ReactDOM (with
  // all their dev-only warnings and checks) get bundled, roughly
  // quadrupling the shipped size of an embeddable widget that specifically
  // needs to stay small.
  define: {
    "process.env.NODE_ENV": JSON.stringify("production"),
  },
  build: {
    lib: {
      entry: resolve(__dirname, "src/index.ts"),
      name: "TryOnWidget",
      formats: ["iife"],
      fileName: () => "widget.js",
    },
    rollupOptions: {
      output: {
        // Inlines any CSS Vite would otherwise extract, since this ships
        // inside a Shadow DOM root rather than the host page's <head>.
        inlineDynamicImports: true,
      },
    },
    minify: "esbuild",
    sourcemap: true,
    // Keep an eye on this: the widget is embedded on merchant storefronts
    // where every extra KB costs real page-load time. ~150KB min / ~50KB
    // gzip is the current baseline for a React-based build (see
    // docs/widget-sdk.md); if this creeps up meaningfully, check first
    // whether NODE_ENV=production is still being applied correctly (see
    // the `define` block above) before assuming new code is the cause.
    chunkSizeWarningLimit: 200,
  },
  resolve: {
    alias: {
      "@": resolve(__dirname, "src"),
    },
  },
});
