import { describe, it, expect, vi } from "vitest";
import { retryWithBackoff } from "@/utils/retry";

describe("retryWithBackoff", () => {
  it("returns the result immediately on first success", async () => {
    const operation = vi.fn().mockResolvedValue("ok");
    const result = await retryWithBackoff(operation, {
      maxAttempts: 3,
      baseDelayMs: 1,
      maxDelayMs: 5,
    });
    expect(result).toBe("ok");
    expect(operation).toHaveBeenCalledTimes(1);
  });

  it("retries on failure and eventually succeeds", async () => {
    const operation = vi
      .fn()
      .mockRejectedValueOnce(new Error("fail 1"))
      .mockRejectedValueOnce(new Error("fail 2"))
      .mockResolvedValue("ok");

    const result = await retryWithBackoff(operation, {
      maxAttempts: 3,
      baseDelayMs: 1,
      maxDelayMs: 5,
    });

    expect(result).toBe("ok");
    expect(operation).toHaveBeenCalledTimes(3);
  });

  it("throws the last error after exhausting all attempts", async () => {
    const operation = vi.fn().mockRejectedValue(new Error("always fails"));

    await expect(
      retryWithBackoff(operation, { maxAttempts: 3, baseDelayMs: 1, maxDelayMs: 5 }),
    ).rejects.toThrow("always fails");
    expect(operation).toHaveBeenCalledTimes(3);
  });

  it("stops immediately when shouldRetry returns false, without exhausting attempts", async () => {
    const operation = vi.fn().mockRejectedValue(new Error("permanent failure"));

    await expect(
      retryWithBackoff(operation, {
        maxAttempts: 5,
        baseDelayMs: 1,
        maxDelayMs: 5,
        shouldRetry: () => false,
      }),
    ).rejects.toThrow("permanent failure");

    // Only the first attempt — shouldRetry=false must short-circuit, not
    // just skip the delay before an eventual identical failure.
    expect(operation).toHaveBeenCalledTimes(1);
  });

  it("respects shouldRetry per-error, retrying only errors it approves", async () => {
    class RetryableError extends Error {}
    class FatalError extends Error {}

    const operation = vi
      .fn()
      .mockRejectedValueOnce(new RetryableError("transient"))
      .mockRejectedValueOnce(new FatalError("permanent"));

    await expect(
      retryWithBackoff(operation, {
        maxAttempts: 5,
        baseDelayMs: 1,
        maxDelayMs: 5,
        shouldRetry: (error) => error instanceof RetryableError,
      }),
    ).rejects.toThrow("permanent");

    expect(operation).toHaveBeenCalledTimes(2);
  });
});
