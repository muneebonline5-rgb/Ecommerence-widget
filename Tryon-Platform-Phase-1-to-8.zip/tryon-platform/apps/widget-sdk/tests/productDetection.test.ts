import { describe, it, expect } from "vitest";
import { detectProduct } from "@/utils/productDetection";

function makeDoc(html: string): Document {
  const parser = new DOMParser();
  return parser.parseFromString(html, "text/html");
}

describe("detectProduct", () => {
  it("detects a product from JSON-LD", () => {
    const doc = makeDoc(`
      <html><head>
        <script type="application/ld+json">
          {"@context":"https://schema.org","@type":"Product","name":"Blue Sneakers","image":"https://shop.example/img.jpg","sku":"SKU-123"}
        </script>
      </head><body></body></html>
    `);

    const result = detectProduct(doc);
    expect(result.source).toBe("json-ld");
    expect(result.title).toBe("Blue Sneakers");
    expect(result.imageUrl).toBe("https://shop.example/img.jpg");
    expect(result.externalId).toBe("SKU-123");
  });

  it("handles JSON-LD image as an array, using the first entry", () => {
    const doc = makeDoc(`
      <html><head>
        <script type="application/ld+json">
          {"@type":"Product","name":"Red Hat","image":["https://shop.example/a.jpg","https://shop.example/b.jpg"]}
        </script>
      </head></html>
    `);

    const result = detectProduct(doc);
    expect(result.imageUrl).toBe("https://shop.example/a.jpg");
  });

  it("finds a Product inside an @graph array", () => {
    const doc = makeDoc(`
      <html><head>
        <script type="application/ld+json">
          {"@graph":[{"@type":"BreadcrumbList"},{"@type":"Product","name":"Green Scarf","image":"https://shop.example/c.jpg"}]}
        </script>
      </head></html>
    `);

    const result = detectProduct(doc);
    expect(result.source).toBe("json-ld");
    expect(result.title).toBe("Green Scarf");
  });

  it("falls back to OpenGraph when no JSON-LD product is present", () => {
    const doc = makeDoc(`
      <html><head>
        <meta property="og:type" content="product" />
        <meta property="og:title" content="Yellow Jacket" />
        <meta property="og:image" content="https://shop.example/d.jpg" />
        <meta property="product:retailer_item_id" content="RET-456" />
      </head></html>
    `);

    const result = detectProduct(doc);
    expect(result.source).toBe("open-graph");
    expect(result.title).toBe("Yellow Jacket");
    expect(result.imageUrl).toBe("https://shop.example/d.jpg");
    expect(result.externalId).toBe("RET-456");
  });

  it("returns source 'none' for a non-product page", () => {
    const doc = makeDoc(`<html><head><title>Blog post</title></head><body></body></html>`);
    const result = detectProduct(doc);
    expect(result.source).toBe("none");
    expect(result.title).toBeNull();
  });

  it("ignores malformed JSON-LD instead of throwing", () => {
    const doc = makeDoc(`
      <html><head>
        <script type="application/ld+json">{ not valid json </script>
      </head></html>
    `);

    expect(() => detectProduct(doc)).not.toThrow();
    expect(detectProduct(doc).source).toBe("none");
  });

  it("ignores JSON-LD for non-Product types (e.g. Organization)", () => {
    const doc = makeDoc(`
      <html><head>
        <script type="application/ld+json">
          {"@type":"Organization","name":"Acme Inc"}
        </script>
      </head></html>
    `);

    expect(detectProduct(doc).source).toBe("none");
  });

  it("prefers JSON-LD over OpenGraph when both are present", () => {
    const doc = makeDoc(`
      <html><head>
        <script type="application/ld+json">
          {"@type":"Product","name":"JSON-LD Name"}
        </script>
        <meta property="og:type" content="product" />
        <meta property="og:title" content="OpenGraph Name" />
      </head></html>
    `);

    expect(detectProduct(doc).title).toBe("JSON-LD Name");
  });
});
