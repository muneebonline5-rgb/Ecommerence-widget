import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { EventTracker } from "@/core/EventTracker";

describe("EventTracker", () => {
  beforeEach(() => {
    vi.useFakeTimers();
    global.fetch = vi.fn().mockResolvedValue({ ok: true });
  });

  afterEach(() => {
    vi.useRealTimers();
    vi.restoreAllMocks();
  });

  it("does not send a request for an empty queue", async () => {
    const tracker = new EventTracker("tk_live_abc", "https://api.example.com");
    await tracker.flush();
    expect(fetch).not.toHaveBeenCalled();
  });

  it("batches tracked events into a single POST on flush", async () => {
    const tracker = new EventTracker("tk_live_abc", "https://api.example.com");
    tracker.track("widget_loaded", { merchant_id: "m_1" });
    tracker.track("button_clicked", { merchant_id: "m_1" });

    await tracker.flush();

    expect(fetch).toHaveBeenCalledTimes(1);
    const call = (fetch as ReturnType<typeof vi.fn>).mock.calls[0];
    if (!call) throw new Error("Expected fetch to have been called");
    const [url, requestInit] = call;
    expect(url).toBe("https://api.example.com/api/v1/analytics/events");
    const body = JSON.parse(requestInit.body as string);
    expect(body.events).toHaveLength(2);
    expect(body.events[0].type).toBe("widget_loaded");
    expect(body.events[1].type).toBe("button_clicked");
  });

  it("auto-flushes once the batch reaches the max size", async () => {
    const tracker = new EventTracker("tk_live_abc", "https://api.example.com");
    for (let i = 0; i < 20; i++) {
      tracker.track("button_clicked", { i });
    }
    // track() fires flush() without awaiting internally; let microtasks settle.
    await Promise.resolve();
    await Promise.resolve();

    expect(fetch).toHaveBeenCalledTimes(1);
  });

  it("flushes automatically on the periodic timer once started", async () => {
    const tracker = new EventTracker("tk_live_abc", "https://api.example.com");
    tracker.start();
    tracker.track("widget_loaded", {});

    await vi.advanceTimersByTimeAsync(5100);

    expect(fetch).toHaveBeenCalledTimes(1);
    tracker.destroy();
  });

  it("does not throw when the network request fails (best-effort delivery)", async () => {
    global.fetch = vi.fn().mockRejectedValue(new Error("network down"));
    const tracker = new EventTracker("tk_live_abc", "https://api.example.com");
    tracker.track("widget_loaded", {});

    await expect(tracker.flush()).resolves.not.toThrow();
  });

  it("stops tracking new events after destroy()", async () => {
    const tracker = new EventTracker("tk_live_abc", "https://api.example.com");
    tracker.destroy();
    tracker.track("widget_loaded", {});

    await tracker.flush();
    expect(fetch).not.toHaveBeenCalled();
  });

  it("clears the flush interval on destroy so it doesn't fire afterward", async () => {
    const tracker = new EventTracker("tk_live_abc", "https://api.example.com");
    tracker.start();
    tracker.destroy();

    await vi.advanceTimersByTimeAsync(10000);
    expect(fetch).not.toHaveBeenCalled();
  });
});
