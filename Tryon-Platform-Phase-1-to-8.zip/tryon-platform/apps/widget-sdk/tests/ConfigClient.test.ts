import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { ConfigClient } from "@/core/ConfigClient";
import { WidgetError } from "@/types";

const SAMPLE_CONFIG = {
  id: "ws_1",
  merchant_id: "m_1",
  is_enabled: true,
  position: "bottom_right",
  theme: {
    primary_color: "#111827",
    accent_color: "#6366F1",
    text_color: "#FFFFFF",
    font_family: "Inter",
    button_shape: "circle",
    border_radius_px: 16,
  },
  button_label: "Try It On",
  allowed_origins: [],
  sdk_version_pin: null,
  updated_at: "2026-01-01T00:00:00Z",
};

describe("ConfigClient", () => {
  beforeEach(() => {
    vi.useFakeTimers();
    global.fetch = vi.fn();
  });

  afterEach(() => {
    vi.useRealTimers();
    vi.restoreAllMocks();
  });

  it("fetches config and sends the API key header", async () => {
    (global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => SAMPLE_CONFIG,
    });

    const client = new ConfigClient("tk_live_abc", "https://api.example.com");
    const config = await client.getConfig();

    expect(config).toEqual(SAMPLE_CONFIG);
    expect(fetch).toHaveBeenCalledWith(
      "https://api.example.com/api/v1/widget/config",
      expect.objectContaining({ headers: { "X-API-Key": "tk_live_abc" } }),
    );
  });

  it("strips trailing slashes from the base URL", async () => {
    (global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => SAMPLE_CONFIG,
    });

    const client = new ConfigClient("tk_live_abc", "https://api.example.com///");
    await client.getConfig();

    expect(fetch).toHaveBeenCalledWith(
      "https://api.example.com/api/v1/widget/config",
      expect.anything(),
    );
  });

  it("caches the config and does not refetch within the TTL", async () => {
    (global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => SAMPLE_CONFIG,
    });

    const client = new ConfigClient("tk_live_abc");
    await client.getConfig();
    await client.getConfig();
    await client.getConfig();

    expect(fetch).toHaveBeenCalledTimes(1);
  });

  it("coalesces concurrent in-flight requests into one fetch", async () => {
    let resolveResponse!: (value: unknown) => void;
    const pending = new Promise((resolve) => {
      resolveResponse = resolve;
    });
    (global.fetch as ReturnType<typeof vi.fn>).mockReturnValue(pending);

    const client = new ConfigClient("tk_live_abc");
    const call1 = client.getConfig();
    const call2 = client.getConfig();

    resolveResponse({ ok: true, status: 200, json: async () => SAMPLE_CONFIG });

    const [result1, result2] = await Promise.all([call1, call2]);
    expect(result1).toEqual(SAMPLE_CONFIG);
    expect(result2).toEqual(SAMPLE_CONFIG);
    expect(fetch).toHaveBeenCalledTimes(1);
  });

  it("does not retry on a 401 (invalid API key) — fails fast", async () => {
    (global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue({
      ok: false,
      status: 401,
      json: async () => ({}),
    });

    const client = new ConfigClient("tk_live_bad");
    await expect(client.getConfig()).rejects.toThrow(WidgetError);
    expect(fetch).toHaveBeenCalledTimes(1);
  });

  it("retries on a transient 500 and eventually succeeds", async () => {
    (global.fetch as ReturnType<typeof vi.fn>)
      .mockResolvedValueOnce({ ok: false, status: 500, json: async () => ({}) })
      .mockResolvedValueOnce({ ok: true, status: 200, json: async () => SAMPLE_CONFIG });

    const client = new ConfigClient("tk_live_abc");
    const configPromise = client.getConfig();

    // Advance past the jittered backoff delay between attempt 1 and 2.
    await vi.advanceTimersByTimeAsync(5000);

    const config = await configPromise;
    expect(config).toEqual(SAMPLE_CONFIG);
    expect(fetch).toHaveBeenCalledTimes(2);
  });
});
