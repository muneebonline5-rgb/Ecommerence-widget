import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { TryOnSDK } from "@/core/TryOnSDK";

const ENABLED_CONFIG = {
  id: "ws_1",
  merchant_id: "m_1",
  is_enabled: true,
  position: "bottom_right",
  theme: {
    primary_color: "#111827",
    accent_color: "#6366F1",
    text_color: "#FFFFFF",
    font_family: "Inter",
    button_shape: "circle",
    border_radius_px: 16,
  },
  button_label: "Try It On",
  allowed_origins: [],
  sdk_version_pin: null,
  updated_at: "2026-01-01T00:00:00Z",
};

function mockConfigResponse(config: unknown) {
  global.fetch = vi.fn().mockResolvedValue({
    ok: true,
    status: 200,
    json: async () => config,
  });
}

function setProductPage() {
  document.head.innerHTML = `
    <script type="application/ld+json">
      {"@type":"Product","name":"Test Product","image":"https://shop.example/x.jpg"}
    </script>
  `;
}

describe("TryOnSDK", () => {
  beforeEach(() => {
    document.head.innerHTML = "";
    document.body.innerHTML = "";
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it("renders the floating button on a detected product page", async () => {
    mockConfigResponse(ENABLED_CONFIG);
    setProductPage();

    const sdk = new TryOnSDK();
    await sdk.init({ apiKey: "tk_live_abc" });

    const host = document.getElementById("tryon-widget-host");
    expect(host).not.toBeNull();
    expect(host?.shadowRoot?.querySelector('[data-testid="tryon-floating-button"]')).not.toBeNull();

    sdk.destroy();
  });

  it("does not render anything on a non-product page", async () => {
    mockConfigResponse(ENABLED_CONFIG);
    // No JSON-LD / OpenGraph product markup in the document.

    const sdk = new TryOnSDK();
    await sdk.init({ apiKey: "tk_live_abc" });

    expect(document.getElementById("tryon-widget-host")).toBeNull();
    sdk.destroy();
  });

  it("renders in manual mode even without product-page detection", async () => {
    mockConfigResponse(ENABLED_CONFIG);

    const sdk = new TryOnSDK();
    await sdk.init({ apiKey: "tk_live_abc", manualMode: true });

    expect(document.getElementById("tryon-widget-host")).not.toBeNull();
    sdk.destroy();
  });

  it("does not render when the merchant has disabled the widget", async () => {
    mockConfigResponse({ ...ENABLED_CONFIG, is_enabled: false });
    setProductPage();

    const sdk = new TryOnSDK();
    await sdk.init({ apiKey: "tk_live_abc" });

    expect(document.getElementById("tryon-widget-host")).toBeNull();
    sdk.destroy();
  });

  it("rejects an obviously invalid API key without making a network call", async () => {
    global.fetch = vi.fn();
    const sdk = new TryOnSDK();

    await sdk.init({ apiKey: "not-a-real-key" });

    expect(fetch).not.toHaveBeenCalled();
    expect(document.getElementById("tryon-widget-host")).toBeNull();
  });

  it("never throws even when the config request fails entirely", async () => {
    global.fetch = vi.fn().mockRejectedValue(new Error("network down"));
    const sdk = new TryOnSDK();

    await expect(sdk.init({ apiKey: "tk_live_abc" })).resolves.not.toThrow();
    expect(document.getElementById("tryon-widget-host")).toBeNull();
  });

  it("is idempotent — calling init() twice does not double-fetch", async () => {
    mockConfigResponse(ENABLED_CONFIG);
    setProductPage();

    const sdk = new TryOnSDK();
    await sdk.init({ apiKey: "tk_live_abc" });
    await sdk.init({ apiKey: "tk_live_abc" });

    expect(fetch).toHaveBeenCalledTimes(1);
    sdk.destroy();
  });

  it("open() shows the modal and close() hides it", async () => {
    mockConfigResponse(ENABLED_CONFIG);
    setProductPage();

    const sdk = new TryOnSDK();
    await sdk.init({ apiKey: "tk_live_abc" });

    const host = document.getElementById("tryon-widget-host");

    sdk.open();
    expect(host?.shadowRoot?.querySelector('[data-testid="tryon-modal-overlay"]')).not.toBeNull();

    sdk.close();
    expect(host?.shadowRoot?.querySelector('[data-testid="tryon-modal-overlay"]')).toBeNull();

    sdk.destroy();
  });

  it("open() before init() has completed is a safe no-op", () => {
    const sdk = new TryOnSDK();
    expect(() => sdk.open()).not.toThrow();
  });

  it("destroy() removes the shadow host and stops rendering", async () => {
    mockConfigResponse(ENABLED_CONFIG);
    setProductPage();

    const sdk = new TryOnSDK();
    await sdk.init({ apiKey: "tk_live_abc" });
    sdk.destroy();

    expect(document.getElementById("tryon-widget-host")).toBeNull();
  });

  it("setTheme() updates the rendered button's styling", async () => {
    mockConfigResponse(ENABLED_CONFIG);
    setProductPage();

    const sdk = new TryOnSDK();
    await sdk.init({ apiKey: "tk_live_abc" });

    sdk.setTheme({ primary_color: "#ff0000" });

    const host = document.getElementById("tryon-widget-host");
    const button = host?.shadowRoot?.querySelector(
      '[data-testid="tryon-floating-button"]',
    ) as HTMLElement | null;
    expect(button?.style.backgroundColor).toBe("rgb(255, 0, 0)");

    sdk.destroy();
  });

  it("getVersion() returns a semver-looking string", () => {
    const sdk = new TryOnSDK();
    expect(sdk.getVersion()).toMatch(/^\d+\.\d+\.\d+$/);
  });
});
