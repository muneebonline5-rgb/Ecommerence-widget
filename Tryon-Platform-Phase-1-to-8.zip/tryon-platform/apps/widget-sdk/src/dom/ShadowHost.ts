/**
 * Creates a Shadow DOM host for the widget.
 *
 * Shadow DOM (not just a plain `<div>`) is the whole point here: the widget
 * is embedded on arbitrary merchant storefronts with unknown, uncontrolled
 * global CSS. A regular div is one `* { margin: 0 }` reset or one
 * `.button { ... }` collision away from breaking. `mode: "open"` is used
 * (not "closed") so the merchant's own devtools/debugging isn't blocked —
 * the isolation this needs is CSS/DOM scoping, not secrecy.
 */
const HOST_ELEMENT_ID = "tryon-widget-host";

export function createShadowHost(): { host: HTMLElement; shadowRoot: ShadowRoot } {
  const existing = document.getElementById(HOST_ELEMENT_ID);
  if (existing?.shadowRoot) {
    return { host: existing, shadowRoot: existing.shadowRoot };
  }

  const host = document.createElement("div");
  host.id = HOST_ELEMENT_ID;
  // Host element itself must not participate in the page's layout flow —
  // its Shadow DOM children handle their own fixed/absolute positioning.
  host.style.all = "initial";
  host.style.position = "fixed";
  host.style.zIndex = "2147483647"; // max safe z-index, guarantees on-top

  document.body.appendChild(host);
  const shadowRoot = host.attachShadow({ mode: "open" });

  return { host, shadowRoot };
}

export function removeShadowHost(): void {
  document.getElementById(HOST_ELEMENT_ID)?.remove();
}
