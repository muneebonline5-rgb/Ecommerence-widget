import { useMemo } from "react";
import type { WidgetConfig } from "@/types";

const POSITION_STYLES: Record<WidgetConfig["position"], React.CSSProperties> = {
  bottom_right: { bottom: 20, right: 20 },
  bottom_left: { bottom: 20, left: 20 },
  top_right: { top: 20, right: 20 },
  top_left: { top: 20, left: 20 },
};

const SHAPE_RADIUS: Record<WidgetConfig["theme"]["button_shape"], string> = {
  circle: "50%",
  pill: "999px",
  square: "8px",
};

export interface FloatingButtonProps {
  config: WidgetConfig;
  onClick: () => void;
}

export function FloatingButton({ config, onClick }: FloatingButtonProps): React.JSX.Element {
  const style = useMemo<React.CSSProperties>(
    () => ({
      position: "fixed",
      ...POSITION_STYLES[config.position],
      backgroundColor: config.theme.primary_color,
      color: config.theme.text_color,
      fontFamily: config.theme.font_family,
      borderRadius:
        config.theme.button_shape === "square"
          ? `${config.theme.border_radius_px}px`
          : SHAPE_RADIUS[config.theme.button_shape],
      border: "none",
      padding: config.theme.button_shape === "circle" ? "16px" : "12px 24px",
      fontSize: "14px",
      fontWeight: 600,
      cursor: "pointer",
      boxShadow: "0 4px 12px rgba(0, 0, 0, 0.15)",
      transition: "transform 0.15s ease, box-shadow 0.15s ease",
    }),
    [config],
  );

  return (
    <button
      type="button"
      style={style}
      onClick={onClick}
      onMouseEnter={(e) => (e.currentTarget.style.transform = "scale(1.05)")}
      onMouseLeave={(e) => (e.currentTarget.style.transform = "scale(1)")}
      aria-label={config.button_label}
      data-testid="tryon-floating-button"
    >
      {config.button_label}
    </button>
  );
}
