import type { WidgetConfig } from "@/types";
import { FloatingButton } from "@/dom/FloatingButton";
import { Modal } from "@/dom/Modal";

export interface WidgetAppProps {
  config: WidgetConfig;
  merchantId: string;
  apiBaseUrl: string;
  onButtonClick: () => void;
  onModalClose: () => void;
  /** Controlled externally so TryOn.open()/close() can drive the modal too, not just the button. */
  isModalOpen: boolean;
}

export function WidgetApp({
  config,
  merchantId,
  apiBaseUrl,
  onButtonClick,
  onModalClose,
  isModalOpen,
}: WidgetAppProps): React.JSX.Element | null {
  if (!config.is_enabled) {
    return null;
  }

  return (
    <>
      <FloatingButton config={config} onClick={onButtonClick} />
      {isModalOpen && (
        <Modal
          config={config}
          merchantId={merchantId}
          apiBaseUrl={apiBaseUrl}
          onClose={onModalClose}
        />
      )}
    </>
  );
}
