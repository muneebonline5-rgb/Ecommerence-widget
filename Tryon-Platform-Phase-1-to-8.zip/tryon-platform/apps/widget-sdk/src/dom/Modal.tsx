import { useEffect, useRef } from "react";
import type { WidgetConfig } from "@/types";

export interface ModalProps {
  config: WidgetConfig;
  merchantId: string;
  apiBaseUrl: string;
  onClose: () => void;
}

/**
 * The try-on flow itself (image upload, AI generation, result display) is
 * loaded in an iframe rather than rendered directly in the Shadow DOM.
 *
 * This is a deliberate isolation boundary beyond Shadow DOM's CSS scoping:
 * the try-on flow handles the customer's uploaded photo and talks to the
 * AI generation backend (Phase 4), and an iframe with its own origin means
 * a bug or compromise in the host merchant's page JavaScript cannot read or
 * tamper with that flow's DOM, network requests, or the uploaded image data
 * — a same-origin script on the host page CAN reach into a Shadow DOM
 * (open mode), but it cannot reach across an iframe boundary to a
 * different origin.
 *
 * The iframe URL is intentionally not implemented as a full try-on
 * experience yet — that's the Phase 4 AI-provider work — this establishes
 * the isolation boundary and lifecycle (open/close/escape-key/backdrop
 * click) that the real flow will load into.
 */
export function Modal({ config, merchantId, apiBaseUrl, onClose }: ModalProps): React.JSX.Element {
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    const handleEscape = (event: KeyboardEvent): void => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handleEscape);
    return () => document.removeEventListener("keydown", handleEscape);
  }, [onClose]);

  const iframeSrc = `${apiBaseUrl.replace(/\/+$/, "")}/embed/tryon?merchant_id=${encodeURIComponent(merchantId)}`;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={`${config.button_label} — virtual try-on`}
      style={overlayStyle}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      data-testid="tryon-modal-overlay"
    >
      <div style={panelStyle}>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close"
          style={closeButtonStyle}
          data-testid="tryon-modal-close"
        >
          ×
        </button>
        <iframe
          ref={iframeRef}
          src={iframeSrc}
          title="Virtual try-on"
          style={iframeStyle}
          allow="camera"
          sandbox="allow-scripts allow-same-origin allow-forms"
        />
      </div>
    </div>
  );
}

const overlayStyle: React.CSSProperties = {
  position: "fixed",
  inset: 0,
  backgroundColor: "rgba(0, 0, 0, 0.5)",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  zIndex: 2147483647,
};

const panelStyle: React.CSSProperties = {
  position: "relative",
  width: "min(480px, 92vw)",
  height: "min(720px, 88vh)",
  backgroundColor: "#ffffff",
  borderRadius: "16px",
  overflow: "hidden",
  boxShadow: "0 20px 60px rgba(0, 0, 0, 0.3)",
};

const closeButtonStyle: React.CSSProperties = {
  position: "absolute",
  top: 8,
  right: 8,
  zIndex: 1,
  width: 32,
  height: 32,
  borderRadius: "50%",
  border: "none",
  backgroundColor: "rgba(0, 0, 0, 0.06)",
  fontSize: 20,
  lineHeight: 1,
  cursor: "pointer",
};

const iframeStyle: React.CSSProperties = {
  width: "100%",
  height: "100%",
  border: "none",
};
