import { TryOnSDK, SDK_VERSION } from "@/core/TryOnSDK";
import type { TryOnInitOptions } from "@/types";

/**
 * The public global surface: `TryOn.init()`, `TryOn.open()`, etc.
 *
 * Auto-initialization reads `data-*` attributes off the script tag itself
 * (the standard pattern for one-script-tag embeds, matching how e.g.
 * Stripe.js and Google Analytics do it) so the simplest possible install is
 * truly one line:
 *
 *   <script src="https://cdn.tryon-platform.com/widget.js" data-api-key="tk_live_..."></script>
 *
 * Merchants who need more control (custom init timing, manual mode) can
 * instead omit `data-api-key` and call `TryOn.init({...})` themselves.
 */
interface TryOnGlobal {
  init: (options: TryOnInitOptions) => Promise<void>;
  open: () => void;
  close: () => void;
  destroy: () => void;
  setTheme: (theme: Parameters<TryOnSDK["setTheme"]>[0]) => void;
  version: string;
}

function createGlobal(): TryOnGlobal {
  const sdk = new TryOnSDK();
  return {
    init: (options) => sdk.init(options),
    open: () => sdk.open(),
    close: () => sdk.close(),
    destroy: () => sdk.destroy(),
    setTheme: (theme) => sdk.setTheme(theme),
    version: SDK_VERSION,
  };
}

function findOwnScriptTag(): HTMLScriptElement | null {
  // `document.currentScript` is the reliable way to identify "the script
  // tag that is executing right now" — this is an IIFE bundle, so it's
  // available synchronously at the top level exactly when this file runs.
  if (document.currentScript instanceof HTMLScriptElement) {
    return document.currentScript;
  }
  // Fallback for edge cases (e.g. script injected dynamically after load,
  // where currentScript may already be null by the time this code runs):
  // fall back to the most recently added tag matching our own filename.
  const scripts = document.querySelectorAll<HTMLScriptElement>('script[src*="widget.js"]');
  return scripts.length > 0 ? scripts[scripts.length - 1]! : null;
}

function autoInit(global: TryOnGlobal): void {
  const scriptTag = findOwnScriptTag();
  const apiKey = scriptTag?.getAttribute("data-api-key");
  if (!apiKey) {
    return; // No data-api-key => merchant intends to call TryOn.init() manually.
  }

  const apiBaseUrl = scriptTag?.getAttribute("data-api-base-url") ?? undefined;
  const manualMode = scriptTag?.getAttribute("data-manual-mode") === "true";

  void global.init({ apiKey, ...(apiBaseUrl ? { apiBaseUrl } : {}), manualMode });
}

const tryOnGlobal = createGlobal();

declare global {
  interface Window {
    TryOn?: TryOnGlobal;
  }
}

if (typeof window !== "undefined") {
  // Guards against double-registration if the script tag is somehow
  // included twice on the same page — last one to load wins for the
  // global, but each IIFE instance still only auto-inits once for itself.
  window.TryOn = window.TryOn ?? tryOnGlobal;
  autoInit(tryOnGlobal);
}

export { tryOnGlobal as TryOn };
export type { TryOnGlobal };
