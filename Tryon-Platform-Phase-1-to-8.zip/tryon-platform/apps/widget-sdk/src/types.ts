/**
 * Shared types for the widget SDK. Kept in one file since they're small and
 * referenced across nearly every module — splitting them up would cost more
 * in import-hunting than it'd save in organization.
 */

export type WidgetPosition = "bottom_right" | "bottom_left" | "top_right" | "top_left";
export type WidgetButtonShape = "circle" | "pill" | "square";

export interface WidgetTheme {
  primary_color: string;
  accent_color: string;
  text_color: string;
  font_family: string;
  button_shape: WidgetButtonShape;
  border_radius_px: number;
}

/** Mirrors the backend's WidgetSettingsResponse schema exactly — see apps/api. */
export interface WidgetConfig {
  id: string;
  merchant_id: string;
  is_enabled: boolean;
  position: WidgetPosition;
  theme: WidgetTheme;
  button_label: string;
  allowed_origins: string[];
  sdk_version_pin: string | null;
  updated_at: string;
}

export interface TryOnInitOptions {
  /** The merchant's public API key, e.g. "tk_live_...". Required. */
  apiKey: string;
  /** Overrides the config endpoint's base URL — for staging/local dev only. */
  apiBaseUrl?: string;
  /** Skips automatic product-page detection and floating-button injection. */
  manualMode?: boolean;
}

export type WidgetEventType =
  | "widget_loaded"
  | "button_clicked"
  | "modal_opened"
  | "modal_closed"
  | "image_uploaded"
  | "generation_started"
  | "generation_completed"
  | "generation_failed"
  | "result_downloaded"
  | "conversion";

export interface WidgetEvent {
  type: WidgetEventType;
  properties: Record<string, unknown>;
  timestamp: string;
}

/** Thrown internally for conditions the SDK should recover from silently in production. */
export class WidgetError extends Error {
  constructor(
    message: string,
    public readonly code: string,
    /** False for errors that can never succeed on retry (e.g. an invalid API key). */
    public readonly retryable: boolean = true,
  ) {
    super(message);
    this.name = "WidgetError";
  }
}
