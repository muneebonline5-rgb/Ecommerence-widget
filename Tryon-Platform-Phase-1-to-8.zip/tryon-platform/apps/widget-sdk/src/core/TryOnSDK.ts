import { createRoot, type Root } from "react-dom/client";
import { flushSync } from "react-dom";
import { createElement } from "react";
import type { TryOnInitOptions, WidgetConfig, WidgetTheme } from "@/types";
import { WidgetError } from "@/types";
import { ConfigClient } from "@/core/ConfigClient";
import { EventTracker } from "@/core/EventTracker";
import { createShadowHost, removeShadowHost } from "@/dom/ShadowHost";
import { WidgetApp } from "@/dom/WidgetApp";
import { detectProduct } from "@/utils/productDetection";

export const SDK_VERSION = "0.1.0";

type SdkState = "uninitialized" | "initializing" | "ready" | "failed" | "destroyed";

/**
 * The widget's public surface. Every method is wrapped so a failure here
 * can never throw an uncaught error into the merchant's page — the single
 * hard rule for embeddable third-party scripts is "never break the host
 * page," even when our own backend is down.
 */
export class TryOnSDK {
  private state: SdkState = "uninitialized";
  private configClient: ConfigClient | null = null;
  private eventTracker: EventTracker | null = null;
  private config: WidgetConfig | null = null;
  private reactRoot: Root | null = null;
  private isModalOpen = false;
  private merchantId = "";
  private apiBaseUrl = "";

  async init(options: TryOnInitOptions): Promise<void> {
    if (this.state === "ready" || this.state === "initializing") {
      return; // idempotent: a second init() call (e.g. from a duplicate script tag) is a no-op
    }

    this.state = "initializing";

    try {
      if (!options.apiKey || !options.apiKey.startsWith("tk_")) {
        throw new WidgetError(
          "A valid apiKey is required to initialize the widget.",
          "missing_api_key",
          false,
        );
      }

      this.apiBaseUrl = options.apiBaseUrl ?? "https://api.tryon-platform.com";
      this.configClient = new ConfigClient(options.apiKey, this.apiBaseUrl);
      this.eventTracker = new EventTracker(options.apiKey, this.apiBaseUrl);
      this.eventTracker.start();

      const config = await this.configClient.getConfig();
      this.config = config;
      this.merchantId = config.merchant_id;

      if (!config.is_enabled) {
        this.state = "ready"; // valid, just nothing to render
        return;
      }

      if (!options.manualMode) {
        const product = detectProduct();
        if (product.source === "none") {
          // Not a product page — nothing to attach the button to. This is
          // an expected, silent no-op (e.g. the homepage, a blog post), not
          // an error.
          this.state = "ready";
          return;
        }
      }

      this.render();
      this.eventTracker.track("widget_loaded", { merchant_id: this.merchantId });
      this.state = "ready";
    } catch (error) {
      this.state = "failed";
      reportSilently(error);
    }
  }

  open(): void {
    if (this.state !== "ready" || !this.config) return;
    this.isModalOpen = true;
    this.eventTracker?.track("modal_opened", { merchant_id: this.merchantId });
    this.render();
  }

  close(): void {
    if (this.state !== "ready") return;
    this.isModalOpen = false;
    this.eventTracker?.track("modal_closed", { merchant_id: this.merchantId });
    this.render();
  }

  setTheme(theme: Partial<WidgetTheme>): void {
    if (!this.config) return;
    this.config = { ...this.config, theme: { ...this.config.theme, ...theme } };
    this.render();
  }

  destroy(): void {
    this.eventTracker?.destroy();
    this.reactRoot?.unmount();
    removeShadowHost();

    this.state = "destroyed";
    this.config = null;
    this.reactRoot = null;
    this.configClient = null;
    this.eventTracker = null;
    this.isModalOpen = false;
  }

  /** Exposed for host-page debugging/support tickets ("what version is running on this site?"). */
  getVersion(): string {
    return SDK_VERSION;
  }

  private render(): void {
    if (!this.config) return;

    if (!this.reactRoot) {
      const { shadowRoot } = createShadowHost();
      const mountPoint = document.createElement("div");
      shadowRoot.appendChild(mountPoint);
      this.reactRoot = createRoot(mountPoint);
    }

    flushSync(() => {
      this.reactRoot!.render(
        createElement(WidgetApp, {
          config: this.config!,
          merchantId: this.merchantId,
          apiBaseUrl: this.apiBaseUrl,
          isModalOpen: this.isModalOpen,
          onButtonClick: () => {
            this.eventTracker?.track("button_clicked", { merchant_id: this.merchantId });
            this.open();
          },
          onModalClose: () => this.close(),
        }),
      );
    });
  }
}

function reportSilently(error: unknown): void {
  // Errors during init must never surface to the merchant's console as an
  // uncaught exception (that's a support ticket for a third-party script
  // breaking someone's storefront), but they should still be visible to
  // anyone actually debugging — console.warn, not swallowed entirely.
  // eslint-disable-next-line no-console
  console.warn("[TryOn Widget] Initialization issue:", error);
}
