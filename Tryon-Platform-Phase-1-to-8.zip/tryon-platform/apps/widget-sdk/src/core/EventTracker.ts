import type { WidgetEvent, WidgetEventType } from "@/types";

const FLUSH_INTERVAL_MS = 5000;
const MAX_BATCH_SIZE = 20;

/**
 * Batches analytics events instead of sending one request per event — a
 * single try-on flow can fire half a dozen events (loaded, clicked, opened,
 * uploaded, generation started/completed) and firing a request per event
 * would be a meaningfully worse page-weight/latency cost on the merchant's
 * storefront than the analytics value justifies.
 *
 * Events are POSTed via `navigator.sendBeacon` on page unload (fire-and-forget,
 * survives the page closing) and via `fetch` on the periodic timer otherwise.
 */
export class EventTracker {
  private queue: WidgetEvent[] = [];
  private flushTimer: ReturnType<typeof setInterval> | null = null;
  private readonly endpoint: string;
  private readonly apiKey: string;
  private destroyed = false;

  constructor(apiKey: string, apiBaseUrl: string) {
    this.apiKey = apiKey;
    this.endpoint = `${apiBaseUrl.replace(/\/+$/, "")}/api/v1/analytics/events`;
  }

  start(): void {
    if (this.flushTimer !== null) return;
    this.flushTimer = setInterval(() => void this.flush(), FLUSH_INTERVAL_MS);

    if (typeof window !== "undefined") {
      window.addEventListener("pagehide", this.flushOnUnload);
    }
  }

  track(type: WidgetEventType, properties: Record<string, unknown> = {}): void {
    if (this.destroyed) return;

    this.queue.push({ type, properties, timestamp: new Date().toISOString() });
    if (this.queue.length >= MAX_BATCH_SIZE) {
      void this.flush();
    }
  }

  async flush(): Promise<void> {
    if (this.queue.length === 0) return;

    const batch = this.queue;
    this.queue = [];

    try {
      await fetch(this.endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-API-Key": this.apiKey },
        body: JSON.stringify({ events: batch }),
        keepalive: true,
      });
    } catch {
      // Analytics delivery is best-effort by design: a dropped batch of
      // events must never surface an error to the merchant's storefront or
      // interrupt the customer's try-on flow. Silently drop and move on.
    }
  }

  destroy(): void {
    this.destroyed = true;
    if (this.flushTimer !== null) {
      clearInterval(this.flushTimer);
      this.flushTimer = null;
    }
    if (typeof window !== "undefined") {
      window.removeEventListener("pagehide", this.flushOnUnload);
    }
    this.queue = [];
  }

  private flushOnUnload = (): void => {
    if (this.queue.length === 0) return;
    // sendBeacon is used specifically here (not fetch/keepalive) because it
    // is guaranteed by spec to be queued before the page unloads, which
    // fetch's keepalive flag does not guarantee across all browsers.
    if (typeof navigator !== "undefined" && navigator.sendBeacon) {
      const payload = JSON.stringify({ events: this.queue });
      navigator.sendBeacon(this.endpoint, new Blob([payload], { type: "application/json" }));
      this.queue = [];
    }
  };
}
