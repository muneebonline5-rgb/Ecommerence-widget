import type { WidgetConfig } from "@/types";
import { WidgetError } from "@/types";
import { DEFAULT_RETRY_OPTIONS, retryWithBackoff } from "@/utils/retry";

const DEFAULT_API_BASE_URL = "https://api.tryon-platform.com";
const CONFIG_CACHE_TTL_MS = 5 * 60 * 1000;

interface CachedConfig {
  config: WidgetConfig;
  fetchedAt: number;
}

/**
 * Fetches and caches the merchant's widget configuration. A short in-memory
 * cache (not persisted across page loads — see docs/widget-sdk.md for why
 * localStorage is deliberately avoided here) keeps repeat calls to
 * `TryOn.init()` within one page session from re-hitting the network, while
 * still picking up merchant config changes within a few minutes rather than
 * requiring a page reload indefinitely.
 */
export class ConfigClient {
  private readonly apiBaseUrl: string;
  private readonly apiKey: string;
  private cached: CachedConfig | null = null;
  private inFlight: Promise<WidgetConfig> | null = null;

  constructor(apiKey: string, apiBaseUrl: string = DEFAULT_API_BASE_URL) {
    this.apiKey = apiKey;
    this.apiBaseUrl = apiBaseUrl.replace(/\/+$/, "");
  }

  async getConfig(): Promise<WidgetConfig> {
    if (this.cached && Date.now() - this.cached.fetchedAt < CONFIG_CACHE_TTL_MS) {
      return this.cached.config;
    }

    // Coalesces concurrent callers (e.g. init() called twice in quick
    // succession) into a single network request instead of racing two.
    if (this.inFlight) {
      return this.inFlight;
    }

    this.inFlight = this.fetchConfig();
    try {
      const config = await this.inFlight;
      this.cached = { config, fetchedAt: Date.now() };
      return config;
    } finally {
      this.inFlight = null;
    }
  }

  private async fetchConfig(): Promise<WidgetConfig> {
    return retryWithBackoff(
      async () => {
        const response = await fetch(`${this.apiBaseUrl}/api/v1/widget/config`, {
          method: "GET",
          headers: { "X-API-Key": this.apiKey },
        });

        if (response.status === 401) {
          // Retrying a bad API key can't ever succeed.
          throw new WidgetError("Invalid API key.", "invalid_api_key", false);
        }

        if (!response.ok) {
          throw new WidgetError(
            `Widget config request failed with status ${response.status}.`,
            "config_fetch_failed",
          );
        }

        return (await response.json()) as WidgetConfig;
      },
      {
        ...DEFAULT_RETRY_OPTIONS,
        shouldRetry: (error) => !(error instanceof WidgetError) || error.retryable,
      },
    );
  }
}
