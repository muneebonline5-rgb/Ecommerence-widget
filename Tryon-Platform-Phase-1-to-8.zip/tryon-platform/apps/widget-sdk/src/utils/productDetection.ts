/**
 * Detects whether the current page is an ecommerce product page, and
 * extracts what it can about the product — without requiring the merchant
 * to add any custom markup. Checks multiple signals in priority order,
 * since different storefront platforms (Shopify, WooCommerce, custom)
 * emit different ones and rarely emit all of them.
 */

export interface DetectedProduct {
  title: string | null;
  imageUrl: string | null;
  externalId: string | null;
  source: "json-ld" | "open-graph" | "none";
}

export function detectProduct(doc: Document = document): DetectedProduct {
  const jsonLdProduct = detectFromJsonLd(doc);
  if (jsonLdProduct) {
    return jsonLdProduct;
  }

  const openGraphProduct = detectFromOpenGraph(doc);
  if (openGraphProduct) {
    return openGraphProduct;
  }

  return { title: null, imageUrl: null, externalId: null, source: "none" };
}

function detectFromJsonLd(doc: Document): DetectedProduct | null {
  const scripts = doc.querySelectorAll('script[type="application/ld+json"]');

  for (const script of Array.from(scripts)) {
    const parsed = safeJsonParse(script.textContent ?? "");
    if (!parsed) continue;

    // JSON-LD can be a single object or an @graph array of objects — check both shapes.
    const candidates: unknown[] = Array.isArray(parsed)
      ? parsed
      : Array.isArray(parsed["@graph"])
        ? (parsed["@graph"] as unknown[])
        : [parsed];

    for (const candidate of candidates) {
      if (isRecord(candidate) && candidate["@type"] === "Product") {
        const image = candidate["image"];
        const imageUrl = Array.isArray(image) ? (image[0] ?? null) : ((image as string) ?? null);

        return {
          title: typeof candidate["name"] === "string" ? candidate["name"] : null,
          imageUrl: typeof imageUrl === "string" ? imageUrl : null,
          externalId: extractProductId(candidate),
          source: "json-ld",
        };
      }
    }
  }

  return null;
}

function detectFromOpenGraph(doc: Document): DetectedProduct | null {
  const type = getMetaContent(doc, "og:type");
  if (type !== "product" && type !== "og:product") {
    return null;
  }

  const title = getMetaContent(doc, "og:title");
  const imageUrl = getMetaContent(doc, "og:image");
  if (!title && !imageUrl) {
    return null;
  }

  return {
    title,
    imageUrl,
    externalId: getMetaContent(doc, "product:retailer_item_id"),
    source: "open-graph",
  };
}

function extractProductId(candidate: Record<string, unknown>): string | null {
  const sku = candidate["sku"];
  if (typeof sku === "string" && sku.length > 0) return sku;

  const productId = candidate["productID"];
  if (typeof productId === "string" && productId.length > 0) return productId;

  return null;
}

function getMetaContent(doc: Document, property: string): string | null {
  const element = doc.querySelector(`meta[property="${property}"]`);
  return element?.getAttribute("content") ?? null;
}

function safeJsonParse(text: string): Record<string, unknown> | unknown[] | null {
  if (!text.trim()) return null;
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
