/**
 * Retries an async operation with exponential backoff + jitter.
 *
 * Jitter matters here specifically: if a merchant's config-fetch CDN edge
 * has a blip, every visitor's browser hitting that edge would otherwise
 * retry in near-lockstep, turning a transient blip into a thundering-herd
 * spike right as the origin recovers. Full jitter (random delay in
 * [0, computed backoff]) spreads that out.
 */
export interface RetryOptions {
  maxAttempts: number;
  baseDelayMs: number;
  maxDelayMs: number;
  /** Return false to stop retrying immediately (e.g. an error that can never succeed on retry). */
  shouldRetry?: (error: unknown) => boolean;
}

export const DEFAULT_RETRY_OPTIONS: RetryOptions = {
  maxAttempts: 3,
  baseDelayMs: 300,
  maxDelayMs: 3000,
};

export async function retryWithBackoff<T>(
  operation: () => Promise<T>,
  options: RetryOptions = DEFAULT_RETRY_OPTIONS,
): Promise<T> {
  let lastError: unknown;

  for (let attempt = 0; attempt < options.maxAttempts; attempt++) {
    try {
      return await operation();
    } catch (error) {
      lastError = error;
      const isLastAttempt = attempt === options.maxAttempts - 1;
      const canRetry = options.shouldRetry ? options.shouldRetry(error) : true;
      if (isLastAttempt || !canRetry) {
        break;
      }

      const exponentialDelay = Math.min(options.baseDelayMs * 2 ** attempt, options.maxDelayMs);
      const jitteredDelay = Math.random() * exponentialDelay;
      await sleep(jitteredDelay);
    }
  }

  throw lastError;
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
