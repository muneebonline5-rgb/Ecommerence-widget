# Widget SDK

The embeddable script merchants add to their storefront to enable virtual
try-on. Built with Vite + React + TypeScript, bundled to a single IIFE file
so installation is exactly one script tag.

## Install

```html
<script src="https://cdn.tryon-platform.com/widget.js" data-api-key="tk_live_..."></script>
```

That's it. The SDK auto-detects product pages (via JSON-LD `Product` schema
or OpenGraph `product` meta tags — no custom markup required), injects a
floating button themed from the merchant's dashboard settings, and handles
everything else.

### Manual control

For merchants who want to control exactly when/where the widget appears:

```html
<script src="https://cdn.tryon-platform.com/widget.js" data-manual-mode="true"></script>
<script>
  TryOn.init({ apiKey: "tk_live_...", manualMode: true }).then(() => {
    document.getElementById("my-custom-button").addEventListener("click", () => TryOn.open());
  });
</script>
```

## Public API

| Method | Description |
|---|---|
| `TryOn.init(options)` | Fetches config and mounts the widget. Idempotent — safe to call more than once. |
| `TryOn.open()` | Opens the try-on modal. |
| `TryOn.close()` | Closes the modal. |
| `TryOn.setTheme(theme)` | Overrides theme properties at runtime (partial updates supported). |
| `TryOn.destroy()` | Unmounts everything and tears down the Shadow DOM host. |
| `TryOn.version` | The running SDK version string. |

`init(options)`: `{ apiKey: string; apiBaseUrl?: string; manualMode?: boolean }`

## Architecture decisions

**Single IIFE bundle, no code splitting.** The entire point of "one script
tag" is that it's genuinely one network request. `vite.config.ts` builds in
library mode with `formats: ["iife"]` and inlines everything — no separate
CSS file a merchant could forget to include, no dynamic imports.

**`process.env.NODE_ENV` is set explicitly in the Vite config.** Library
mode does *not* automatically strip this the way Vite's normal app-mode
build does. Without the explicit `define`, React's own internal dev/prod
conditional never resolves statically, and both the development AND
production builds of React/ReactDOM ship in the bundle — this was caught
during Phase 3 development and cut the bundle from ~482 KB to ~152 KB
(150 KB → 49 KB gzipped). If the bundle size ever unexpectedly balloons,
check this first before assuming new code is the cause.

**Shadow DOM, `mode: "open"`.** Isolates the widget's styles from whatever
uncontrolled global CSS exists on the merchant's storefront (and vice
versa) without resorting to iframe-for-everything, which would make the
floating button/modal feel visually disconnected from the page. `open`
(not `closed`) mode is used deliberately — the isolation needed here is
CSS/DOM scoping, not secrecy, and `closed` mode would block the merchant's
own devtools debugging for no security benefit.

**The try-on flow itself loads in an iframe, inside the Shadow DOM modal.**
This is a second, stronger isolation boundary than Shadow DOM alone: the
try-on flow handles the customer's uploaded photo and will talk to the AI
generation backend (Phase 4). An iframe on a different origin means a bug
or compromise in the *host merchant's own* page JavaScript cannot reach
across into that flow's DOM or network requests — Shadow DOM in open mode
alone would not stop a same-origin script from doing that.

**No `localStorage`/persisted cache across page loads.** `ConfigClient`
caches in memory only, for the lifetime of one page view (5-minute TTL).
This trades a small amount of redundant fetching for a simpler, safer
model: no risk of serving a stale merchant config indefinitely if a
customer keeps a tab open, and no browser-storage footprint on someone
else's website — a private-by-default posture is more defensible for a
widget with no control over the host page's privacy policy.

**Retry uses full jitter, and distinguishes retryable from fatal errors.**
An invalid API key (401) is retried zero times — retrying can't ever
succeed. A transient 5xx gets exponential backoff with randomized delay
(not fixed backoff), so a blip on our CDN edge doesn't turn into a
synchronized retry storm from every storefront visitor's browser at once.

**Analytics delivery is best-effort, by design.** `EventTracker` batches
events and never lets a delivery failure surface as an error — a dropped
analytics batch must never interrupt or visibly break a customer's actual
try-on flow. Uses `navigator.sendBeacon` on page unload specifically
(rather than `fetch` with `keepalive`) since `sendBeacon` is spec-guaranteed
to be queued before the page closes, which `keepalive` is not, consistently,
across browsers.

**Known caveat, tracked for Phase 4/5 integration:** `EventTracker` runs a
`setInterval` once `start()` is called, which is only cleared by calling
`destroy()`. In auto-init mode (the default script-tag install) this is
fine — the timer lives for the page's lifetime, same as any analytics
script. In manual/SPA-style integrations that call `init()`/`destroy()`
repeatedly across route changes, callers must pair every `init()` with a
`destroy()` or the interval will accumulate. This is documented rather than
auto-handled because the "SPA re-init" pattern doesn't have a real caller
yet (that's the merchant-dashboard/Next.js integration work, Phase 7) —
revisit once there's an actual usage pattern to design against, rather than
guessing at one now.

## What's verified vs. scaffolded

**Actually run and passing:** 38 unit/component tests (Vitest + jsdom) —
`retryWithBackoff`'s retry/jitter/fatal-error logic, `detectProduct`'s
JSON-LD and OpenGraph parsing (including malformed-input handling),
`ConfigClient`'s caching/coalescing/retry semantics, `EventTracker`'s
batching and best-effort delivery, and `TryOnSDK`'s full public API
(idempotent init, product-page gating, manual mode, `setTheme`,
`destroy`). TypeScript compiles in strict mode with zero errors. ESLint
passes with zero errors. The actual built IIFE bundle (not just the
source) was smoke-tested end-to-end in a simulated browser page: script
auto-init, Shadow DOM mounting, floating button rendering, and
`TryOn.open()`/`close()` were all exercised directly against `dist/widget.js`.

**Scaffolded for later phases:** the iframe's actual try-on experience
(image upload, AI generation, result display — this is Phase 4's AI
provider work), the `/api/v1/analytics/events` backend endpoint
`EventTracker` posts to (Phase 5), and the `/embed/tryon` page the modal's
iframe points to.

## Local development

```bash
cd apps/widget-sdk
npm install
npm run typecheck   # tsc --noEmit
npm test             # vitest run
npm run build         # tsc --noEmit && vite build -> dist/widget.js
npm run lint
```
