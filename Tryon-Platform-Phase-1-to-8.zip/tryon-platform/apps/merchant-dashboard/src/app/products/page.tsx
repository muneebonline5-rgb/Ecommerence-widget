"use client";

import { DashboardShell } from "@/components/dashboard-shell";
import { useMerchant } from "@/components/merchant-context";
import {
  Badge,
  Button,
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  EmptyState,
  ErrorState,
  Input,
  Label,
  LoadingState,
} from "@/components/ui";
import { useApi } from "@/lib/use-api";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";

function ProductsContent() {
  const api = useApi();
  const queryClient = useQueryClient();
  const { merchant } = useMerchant();
  const merchantId = merchant!.id;

  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    external_id: "",
    title: "",
    product_url: "",
    image_url: "",
    category: "",
  });
  const [actionError, setActionError] = useState<string | null>(null);

  const products = useQuery({
    queryKey: ["products", merchantId],
    queryFn: () => api.products.list(merchantId),
  });

  const invalidate = () => {
    void queryClient.invalidateQueries({ queryKey: ["products", merchantId] });
  };

  const createProduct = useMutation({
    mutationFn: () =>
      api.products.create(merchantId, {
        external_id: form.external_id,
        title: form.title,
        product_url: form.product_url,
        image_url: form.image_url,
        category: form.category || undefined,
      }),
    onSuccess: () => {
      setShowForm(false);
      setForm({ external_id: "", title: "", product_url: "", image_url: "", category: "" });
      setActionError(null);
      invalidate();
    },
    onError: (error: Error) => setActionError(error.message),
  });

  const toggleEligible = useMutation({
    mutationFn: ({ productId, eligible }: { productId: string; eligible: boolean }) =>
      api.products.setTryOnEligible(merchantId, productId, eligible),
    onSuccess: invalidate,
    onError: (error: Error) => setActionError(error.message),
  });

  const removeProduct = useMutation({
    mutationFn: (productId: string) => api.products.remove(merchantId, productId),
    onSuccess: invalidate,
    onError: (error: Error) => setActionError(error.message),
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Products</h1>
          <p className="text-sm text-muted-foreground">
            Products eligible for virtual try-on. Auto-detected products appear here too.
          </p>
        </div>
        <Button onClick={() => setShowForm((v) => !v)}>
          {showForm ? "Cancel" : "Add product"}
        </Button>
      </div>

      {actionError && (
        <div className="rounded-md border border-destructive/40 bg-destructive/5 p-3 text-sm text-destructive">
          {actionError}
        </div>
      )}

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>New product</CardTitle>
          </CardHeader>
          <CardContent>
            <form
              className="grid gap-4 md:grid-cols-2"
              onSubmit={(event) => {
                event.preventDefault();
                createProduct.mutate();
              }}
            >
              {(
                [
                  ["external_id", "External ID (your SKU)", true],
                  ["title", "Title", true],
                  ["product_url", "Product URL", true],
                  ["image_url", "Image URL", true],
                  ["category", "Category (optional)", false],
                ] as const
              ).map(([key, label, required]) => (
                <div key={key} className="space-y-1">
                  <Label htmlFor={key}>{label}</Label>
                  <Input
                    id={key}
                    required={required}
                    value={form[key]}
                    onChange={(event) => setForm((f) => ({ ...f, [key]: event.target.value }))}
                  />
                </div>
              ))}
              <div className="md:col-span-2">
                <Button type="submit" disabled={createProduct.isPending}>
                  {createProduct.isPending ? "Creating…" : "Create product"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {products.isLoading ? (
        <LoadingState label="Loading products…" />
      ) : products.error ? (
        <ErrorState message={(products.error as Error).message} onRetry={products.refetch} />
      ) : (products.data ?? []).length === 0 ? (
        <EmptyState
          title="No products yet"
          description="Add one manually, or they'll appear automatically as the widget detects product pages."
        />
      ) : (
        <Card>
          <CardContent className="p-0">
            <table className="w-full text-sm">
              <thead className="border-b bg-muted/40 text-left">
                <tr>
                  <th className="p-3 font-medium">Title</th>
                  <th className="p-3 font-medium">External ID</th>
                  <th className="p-3 font-medium">Category</th>
                  <th className="p-3 font-medium">Try-on</th>
                  <th className="p-3 font-medium" />
                </tr>
              </thead>
              <tbody>
                {(products.data ?? []).map((product) => (
                  <tr key={product.id} className="border-b last:border-0">
                    <td className="p-3">{product.title}</td>
                    <td className="p-3 text-muted-foreground">{product.external_id}</td>
                    <td className="p-3 text-muted-foreground">{product.category ?? "—"}</td>
                    <td className="p-3">
                      <Badge tone={product.is_try_on_eligible ? "success" : "neutral"}>
                        {product.is_try_on_eligible ? "Eligible" : "Disabled"}
                      </Badge>
                    </td>
                    <td className="p-3">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="secondary"
                          onClick={() =>
                            toggleEligible.mutate({
                              productId: product.id,
                              eligible: !product.is_try_on_eligible,
                            })
                          }
                        >
                          {product.is_try_on_eligible ? "Disable" : "Enable"}
                        </Button>
                        <Button
                          variant="destructive"
                          onClick={() => removeProduct.mutate(product.id)}
                        >
                          Delete
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

export default function ProductsPage() {
  return (
    <DashboardShell>
      <ProductsContent />
    </DashboardShell>
  );
}
