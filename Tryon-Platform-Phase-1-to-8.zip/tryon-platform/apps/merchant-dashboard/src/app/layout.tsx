import { Providers } from "@/components/providers";
import { ClerkProvider } from "@clerk/nextjs";
import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Merchant Dashboard — Try-On Platform",
  description: "Manage your virtual try-on widget, products, analytics, and billing.",
};

/**
 * Every route in this app is per-user and authenticated — there is no
 * meaningful "static" version of a merchant's own dashboard. Forcing
 * dynamic rendering here (rather than letting Next.js attempt static
 * prerendering at build time) is both correct and necessary: Clerk's
 * provider requires a real publishable key to initialize, so a build-time
 * prerender pass fails outright rather than producing a useful artifact.
 */
export const dynamic = "force-dynamic";

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <ClerkProvider>
      <html lang="en">
        <body className="min-h-screen antialiased">
          <Providers>{children}</Providers>
        </body>
      </html>
    </ClerkProvider>
  );
}
