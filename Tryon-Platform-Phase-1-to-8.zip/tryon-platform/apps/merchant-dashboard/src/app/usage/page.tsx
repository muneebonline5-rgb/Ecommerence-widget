"use client";

import { DashboardShell } from "@/components/dashboard-shell";
import { useMerchant } from "@/components/merchant-context";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  EmptyState,
  ErrorState,
  LoadingState,
} from "@/components/ui";
import { useApi } from "@/lib/use-api";
import { formatCurrency, formatDate } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import { ApiError } from "@tryon-platform/sdk";

function UsageContent() {
  const api = useApi();
  const { merchant } = useMerchant();
  const merchantId = merchant!.id;

  const usage = useQuery({
    queryKey: ["usage-summary", merchantId],
    queryFn: () => api.billing.getUsageSummary(merchantId),
    retry: false,
  });

  if (usage.isLoading) return <LoadingState label="Loading usage…" />;

  // Usage is computed against a plan's allowance, so it genuinely requires
  // a subscription — surfaced as an explanatory empty state rather than an
  // error, since it's an expected state for Free-tier merchants.
  if (usage.error instanceof ApiError && usage.error.code === "no_active_subscription") {
    return (
      <EmptyState
        title="No active subscription"
        description="Usage tracking against a plan allowance becomes available once you subscribe."
      />
    );
  }
  if (usage.error) {
    return <ErrorState message={(usage.error as Error).message} onRetry={usage.refetch} />;
  }

  const data = usage.data!;
  const percentUsed =
    data.included_generations > 0
      ? Math.min(100, (data.used_generations / data.included_generations) * 100)
      : 0;
  const providers = Object.entries(data.breakdown_by_provider);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Usage</h1>
        <p className="text-sm text-muted-foreground">
          {formatDate(data.period_start)} – {formatDate(data.period_end)}
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Generations</CardTitle>
          <CardDescription>
            {data.used_generations.toLocaleString()} of{" "}
            {data.included_generations.toLocaleString()} included
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="h-3 w-full overflow-hidden rounded-full bg-muted">
            <div
              className={`h-full rounded-full transition-all ${
                data.overage_generations > 0 ? "bg-amber-500" : "bg-primary"
              }`}
              style={{ width: `${percentUsed}%` }}
              role="progressbar"
              aria-valuenow={Math.round(percentUsed)}
              aria-valuemin={0}
              aria-valuemax={100}
            />
          </div>
          {data.overage_generations > 0 ? (
            <p className="text-sm text-amber-700">
              {data.overage_generations.toLocaleString()} generations over your allowance —{" "}
              {formatCurrency(data.overage_cost_usd)} in overage charges this period.
            </p>
          ) : (
            <p className="text-sm text-muted-foreground">Within your plan allowance.</p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>By AI provider</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {providers.length === 0 ? (
            <div className="p-6">
              <EmptyState title="No generations this period" />
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead className="border-b bg-muted/40 text-left">
                <tr>
                  <th className="p-3 font-medium">Provider</th>
                  <th className="p-3 text-right font-medium">Generations</th>
                  <th className="p-3 text-right font-medium">Cost</th>
                </tr>
              </thead>
              <tbody>
                {providers.map(([provider, stats]) => (
                  <tr key={provider} className="border-b last:border-0">
                    <td className="p-3 capitalize">{provider}</td>
                    <td className="p-3 text-right">{stats.count.toLocaleString()}</td>
                    <td className="p-3 text-right">{formatCurrency(stats.cost_usd)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

export default function UsagePage() {
  return (
    <DashboardShell>
      <UsageContent />
    </DashboardShell>
  );
}
