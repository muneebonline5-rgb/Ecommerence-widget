"use client";

import { DashboardShell } from "@/components/dashboard-shell";
import { useMerchant } from "@/components/merchant-context";
import {
  Badge,
  Button,
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  EmptyState,
  ErrorState,
  Input,
  Label,
  LoadingState,
} from "@/components/ui";
import { useApi } from "@/lib/use-api";
import { formatDateTime } from "@/lib/utils";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";

function ApiKeysContent() {
  const api = useApi();
  const queryClient = useQueryClient();
  const { merchant } = useMerchant();
  const merchantId = merchant!.id;

  const [label, setLabel] = useState("");
  const [environment, setEnvironment] = useState<"live" | "test">("test");
  const [revealedKey, setRevealedKey] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  const keys = useQuery({
    queryKey: ["api-keys", merchantId],
    queryFn: () => api.apiKeys.list(merchantId),
  });

  const issueKey = useMutation({
    mutationFn: () => api.apiKeys.issue(merchantId, label, environment),
    onSuccess: (issued) => {
      // The backend returns the plaintext secret exactly once, at issuance
      // (see Phase 1's ApiKeyService) — there is no way to retrieve it
      // again, so it must be surfaced immediately and prominently.
      setRevealedKey(issued.plaintext_key);
      setLabel("");
      setActionError(null);
      void queryClient.invalidateQueries({ queryKey: ["api-keys", merchantId] });
    },
    onError: (error: Error) => setActionError(error.message),
  });

  const revokeKey = useMutation({
    mutationFn: (apiKeyId: string) => api.apiKeys.revoke(merchantId, apiKeyId),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["api-keys", merchantId] });
    },
    onError: (error: Error) => setActionError(error.message),
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">API Keys</h1>
        <p className="text-sm text-muted-foreground">
          Used by the widget script on your storefront to authenticate.
        </p>
      </div>

      {actionError && (
        <div className="rounded-md border border-destructive/40 bg-destructive/5 p-3 text-sm text-destructive">
          {actionError}
        </div>
      )}

      {revealedKey && (
        <Card className="border-amber-400 bg-amber-50">
          <CardHeader>
            <CardTitle>Copy your key now</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-amber-900">
              This is the only time this secret will ever be shown. Store it somewhere safe before
              leaving this page.
            </p>
            <code className="block break-all rounded border bg-background p-3 font-mono text-xs">
              {revealedKey}
            </code>
            <Button variant="secondary" onClick={() => setRevealedKey(null)}>
              I&apos;ve saved it
            </Button>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Issue a new key</CardTitle>
        </CardHeader>
        <CardContent>
          <form
            className="flex flex-wrap items-end gap-3"
            onSubmit={(event) => {
              event.preventDefault();
              issueKey.mutate();
            }}
          >
            <div className="space-y-1">
              <Label htmlFor="label">Label</Label>
              <Input
                id="label"
                required
                placeholder="Production storefront"
                value={label}
                onChange={(event) => setLabel(event.target.value)}
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="environment">Environment</Label>
              <select
                id="environment"
                className="h-9 rounded-md border bg-background px-3 text-sm"
                value={environment}
                onChange={(event) => setEnvironment(event.target.value as "live" | "test")}
              >
                <option value="test">test</option>
                <option value="live">live</option>
              </select>
            </div>
            <Button type="submit" disabled={issueKey.isPending}>
              {issueKey.isPending ? "Issuing…" : "Issue key"}
            </Button>
          </form>
        </CardContent>
      </Card>

      {keys.isLoading ? (
        <LoadingState label="Loading keys…" />
      ) : keys.error ? (
        <ErrorState message={(keys.error as Error).message} onRetry={keys.refetch} />
      ) : (keys.data ?? []).length === 0 ? (
        <EmptyState title="No API keys yet" description="Issue one to install the widget." />
      ) : (
        <Card>
          <CardContent className="p-0">
            <table className="w-full text-sm">
              <thead className="border-b bg-muted/40 text-left">
                <tr>
                  <th className="p-3 font-medium">Label</th>
                  <th className="p-3 font-medium">Prefix</th>
                  <th className="p-3 font-medium">Env</th>
                  <th className="p-3 font-medium">Status</th>
                  <th className="p-3 font-medium">Last used</th>
                  <th className="p-3 font-medium" />
                </tr>
              </thead>
              <tbody>
                {(keys.data ?? []).map((key) => (
                  <tr key={key.id} className="border-b last:border-0">
                    <td className="p-3">{key.label}</td>
                    <td className="p-3 font-mono text-xs text-muted-foreground">
                      {key.key_prefix}…
                    </td>
                    <td className="p-3 text-muted-foreground">{key.environment}</td>
                    <td className="p-3">
                      <Badge tone={key.status === "active" ? "success" : "neutral"}>
                        {key.status}
                      </Badge>
                    </td>
                    <td className="p-3 text-muted-foreground">
                      {key.last_used_at ? formatDateTime(key.last_used_at) : "Never"}
                    </td>
                    <td className="p-3 text-right">
                      {key.status === "active" && (
                        <Button variant="destructive" onClick={() => revokeKey.mutate(key.id)}>
                          Revoke
                        </Button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

export default function ApiKeysPage() {
  return (
    <DashboardShell>
      <ApiKeysContent />
    </DashboardShell>
  );
}
