"use client";

import { DashboardShell } from "@/components/dashboard-shell";
import { useMerchant } from "@/components/merchant-context";
import {
  Badge,
  Button,
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  EmptyState,
  ErrorState,
  LoadingState,
} from "@/components/ui";
import { useApi } from "@/lib/use-api";
import { formatCurrency, formatDate } from "@/lib/utils";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ApiError } from "@tryon-platform/sdk";
import type { BillingInterval } from "@tryon-platform/types";
import { useState } from "react";

function BillingContent() {
  const api = useApi();
  const queryClient = useQueryClient();
  const { merchant } = useMerchant();
  const merchantId = merchant!.id;

  const [interval, setInterval] = useState<BillingInterval>("monthly");
  const [actionError, setActionError] = useState<string | null>(null);

  const plans = useQuery({ queryKey: ["plans"], queryFn: () => api.billing.listPlans() });

  const subscription = useQuery({
    queryKey: ["subscription", merchantId],
    queryFn: () => api.billing.getSubscription(merchantId),
    retry: false,
  });

  const invoices = useQuery({
    queryKey: ["invoices", merchantId],
    queryFn: () => api.billing.listInvoices(merchantId),
  });

  const refreshBilling = () => {
    void queryClient.invalidateQueries({ queryKey: ["subscription", merchantId] });
    void queryClient.invalidateQueries({ queryKey: ["invoices", merchantId] });
  };

  const onError = (error: Error) => setActionError(error.message);

  const subscribe = useMutation({
    mutationFn: (tier: string) => api.billing.subscribe(merchantId, tier, interval),
    onSuccess: () => {
      setActionError(null);
      refreshBilling();
    },
    onError,
  });

  const changePlan = useMutation({
    mutationFn: (tier: string) => api.billing.changePlan(merchantId, tier, interval),
    onSuccess: () => {
      setActionError(null);
      refreshBilling();
    },
    onError,
  });

  const cancelSubscription = useMutation({
    mutationFn: () => api.billing.cancelSubscription(merchantId, true),
    onSuccess: () => {
      setActionError(null);
      refreshBilling();
    },
    onError,
  });

  const reactivate = useMutation({
    mutationFn: () => api.billing.reactivateSubscription(merchantId),
    onSuccess: () => {
      setActionError(null);
      refreshBilling();
    },
    onError,
  });

  const hasSubscription =
    subscription.data !== undefined &&
    !(
      subscription.error instanceof ApiError &&
      subscription.error.code === "no_active_subscription"
    );

  const currentPlanId = subscription.data?.plan_id;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Billing</h1>
        <p className="text-sm text-muted-foreground">Manage your plan, and view invoice history.</p>
      </div>

      {actionError && (
        <div className="rounded-md border border-destructive/40 bg-destructive/5 p-3 text-sm text-destructive">
          {actionError}
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Current subscription</CardTitle>
        </CardHeader>
        <CardContent>
          {subscription.isLoading ? (
            <LoadingState label="Loading…" />
          ) : !hasSubscription ? (
            <p className="text-sm text-muted-foreground">
              No active subscription — you&apos;re on the Free tier. Choose a plan below to upgrade.
            </p>
          ) : subscription.data ? (
            <div className="flex flex-wrap items-center gap-4">
              <Badge
                tone={
                  subscription.data.status === "active" || subscription.data.status === "trialing"
                    ? "success"
                    : subscription.data.status === "past_due"
                      ? "warning"
                      : "danger"
                }
              >
                {subscription.data.status}
              </Badge>
              <span className="text-sm text-muted-foreground">
                {subscription.data.billing_interval} · renews{" "}
                {formatDate(subscription.data.current_period_end)}
              </span>
              {subscription.data.cancel_at_period_end ? (
                <Button onClick={() => reactivate.mutate()} disabled={reactivate.isPending}>
                  Resume subscription
                </Button>
              ) : (
                <Button
                  variant="destructive"
                  onClick={() => cancelSubscription.mutate()}
                  disabled={cancelSubscription.isPending}
                >
                  Cancel at period end
                </Button>
              )}
            </div>
          ) : null}
        </CardContent>
      </Card>

      <div>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-lg font-semibold">Plans</h2>
          <div className="flex gap-1 rounded-md border p-1">
            {(["monthly", "yearly"] as const).map((option) => (
              <button
                key={option}
                onClick={() => setInterval(option)}
                className={`rounded px-3 py-1 text-sm transition ${
                  interval === option
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-muted"
                }`}
              >
                {option}
              </button>
            ))}
          </div>
        </div>

        {plans.isLoading ? (
          <LoadingState label="Loading plans…" />
        ) : plans.error ? (
          <ErrorState message={(plans.error as Error).message} onRetry={plans.refetch} />
        ) : (plans.data ?? []).length === 0 ? (
          <EmptyState
            title="No plans configured"
            description="A platform admin needs to create plans first (see docs/stripe-setup.md)."
          />
        ) : (
          <div className="grid gap-4 md:grid-cols-3">
            {(plans.data ?? []).map((plan) => {
              const price =
                interval === "yearly" ? plan.yearly_price_usd : plan.monthly_price_usd;
              const unavailable = interval === "yearly" && plan.yearly_price_usd === null;
              const isCurrent = plan.id === currentPlanId;

              return (
                <Card key={plan.id} className={isCurrent ? "border-primary" : undefined}>
                  <CardHeader>
                    <CardTitle>{plan.name}</CardTitle>
                    <CardDescription>
                      {unavailable
                        ? "Not available yearly"
                        : `${formatCurrency(price ?? 0)} / ${interval === "yearly" ? "year" : "month"}`}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <ul className="space-y-1 text-sm text-muted-foreground">
                      <li>{plan.included_generations.toLocaleString()} generations included</li>
                      <li>{formatCurrency(plan.overage_price_usd)} per extra generation</li>
                    </ul>
                    {isCurrent ? (
                      <Badge tone="success">Current plan</Badge>
                    ) : (
                      <Button
                        className="w-full"
                        disabled={unavailable || subscribe.isPending || changePlan.isPending}
                        onClick={() =>
                          hasSubscription
                            ? changePlan.mutate(plan.tier)
                            : subscribe.mutate(plan.tier)
                        }
                      >
                        {hasSubscription ? "Switch to this plan" : "Subscribe"}
                      </Button>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      <div>
        <h2 className="mb-3 text-lg font-semibold">Invoices</h2>
        {invoices.isLoading ? (
          <LoadingState label="Loading invoices…" />
        ) : invoices.error ? (
          <ErrorState message={(invoices.error as Error).message} onRetry={invoices.refetch} />
        ) : (invoices.data ?? []).length === 0 ? (
          <EmptyState title="No invoices yet" />
        ) : (
          <Card>
            <CardContent className="p-0">
              <table className="w-full text-sm">
                <thead className="border-b bg-muted/40 text-left">
                  <tr>
                    <th className="p-3 font-medium">Period</th>
                    <th className="p-3 font-medium">Amount</th>
                    <th className="p-3 font-medium">Status</th>
                    <th className="p-3 font-medium" />
                  </tr>
                </thead>
                <tbody>
                  {(invoices.data ?? []).map((invoice) => (
                    <tr key={invoice.id} className="border-b last:border-0">
                      <td className="p-3">
                        {formatDate(invoice.period_start)} – {formatDate(invoice.period_end)}
                      </td>
                      <td className="p-3">{formatCurrency(invoice.amount_due_usd)}</td>
                      <td className="p-3">
                        <Badge
                          tone={
                            invoice.status === "paid"
                              ? "success"
                              : invoice.status === "open"
                                ? "warning"
                                : "neutral"
                          }
                        >
                          {invoice.status}
                        </Badge>
                      </td>
                      <td className="p-3 text-right">
                        {invoice.hosted_invoice_url && (
                          <a
                            href={invoice.hosted_invoice_url}
                            target="_blank"
                            rel="noreferrer"
                            className="text-sm underline"
                          >
                            View
                          </a>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

export default function BillingPage() {
  return (
    <DashboardShell>
      <BillingContent />
    </DashboardShell>
  );
}
