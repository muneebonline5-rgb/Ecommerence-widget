"use client";

import { DashboardShell } from "@/components/dashboard-shell";
import { useMerchant } from "@/components/merchant-context";
import {
  Badge,
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  ErrorState,
  LoadingState,
} from "@/components/ui";
import { useApi } from "@/lib/use-api";
import { formatCurrency, formatDate } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import { ApiError } from "@tryon-platform/sdk";

function StatCard({ title, value, hint }: { title: string; value: string | number; hint?: string }) {
  return (
    <Card>
      <CardHeader>
        <CardDescription>{title}</CardDescription>
        <CardTitle className="text-2xl">{value}</CardTitle>
      </CardHeader>
      {hint && (
        <CardContent>
          <p className="text-xs text-muted-foreground">{hint}</p>
        </CardContent>
      )}
    </Card>
  );
}

function OverviewContent() {
  const api = useApi();
  const { merchant } = useMerchant();
  const merchantId = merchant!.id;

  const analytics = useQuery({
    queryKey: ["analytics-summary", merchantId, 7],
    queryFn: () => api.analytics.summary(merchantId, 7),
  });

  // A merchant on the Free tier legitimately has no subscription, and the
  // backend returns no_active_subscription for that — treated as an
  // expected state here, not an error to surface.
  const subscription = useQuery({
    queryKey: ["subscription", merchantId],
    queryFn: () => api.billing.getSubscription(merchantId),
    retry: false,
  });

  const usage = useQuery({
    queryKey: ["usage-summary", merchantId],
    queryFn: () => api.billing.getUsageSummary(merchantId),
    retry: false,
  });

  if (analytics.isLoading) return <LoadingState label="Loading overview…" />;
  if (analytics.error) {
    return <ErrorState message={(analytics.error as Error).message} onRetry={analytics.refetch} />;
  }

  const counts = analytics.data?.counts_by_event_type ?? {};
  const widgetLoads = counts["widget_loaded"] ?? 0;
  const generations = counts["generation_completed"] ?? 0;
  const conversions = counts["conversion"] ?? 0;
  const conversionRate = widgetLoads > 0 ? ((conversions / widgetLoads) * 100).toFixed(1) : "0.0";

  const subscriptionMissing =
    subscription.error instanceof ApiError &&
    (subscription.error.code === "no_active_subscription" || subscription.error.status === 404);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Overview</h1>
        <p className="text-sm text-muted-foreground">
          {merchant!.name} · {merchant!.domain}
        </p>
      </div>

      <section className="grid gap-4 md:grid-cols-4">
        <StatCard title="Widget loads (7d)" value={widgetLoads} />
        <StatCard title="Generations (7d)" value={generations} />
        <StatCard title="Conversions (7d)" value={conversions} />
        <StatCard title="Conversion rate" value={`${conversionRate}%`} hint="Conversions / loads" />
      </section>

      <section className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Subscription</CardTitle>
          </CardHeader>
          <CardContent>
            {subscription.isLoading ? (
              <LoadingState label="Loading…" />
            ) : subscriptionMissing ? (
              <p className="text-sm text-muted-foreground">
                No active subscription — currently on the Free tier.
              </p>
            ) : subscription.error ? (
              <p className="text-sm text-destructive">{(subscription.error as Error).message}</p>
            ) : subscription.data ? (
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <Badge
                    tone={
                      subscription.data.status === "active" ||
                      subscription.data.status === "trialing"
                        ? "success"
                        : subscription.data.status === "past_due"
                          ? "warning"
                          : "danger"
                    }
                  >
                    {subscription.data.status}
                  </Badge>
                  <span className="text-muted-foreground">
                    {subscription.data.billing_interval}
                  </span>
                </div>
                <p className="text-muted-foreground">
                  Renews {formatDate(subscription.data.current_period_end)}
                </p>
                {subscription.data.cancel_at_period_end && (
                  <p className="text-amber-700">Cancels at period end.</p>
                )}
              </div>
            ) : null}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Usage this period</CardTitle>
          </CardHeader>
          <CardContent>
            {usage.isLoading ? (
              <LoadingState label="Loading…" />
            ) : usage.error ? (
              <p className="text-sm text-muted-foreground">
                Usage becomes available once you have an active subscription.
              </p>
            ) : usage.data ? (
              <div className="space-y-2 text-sm">
                <p>
                  <span className="text-2xl font-semibold">{usage.data.used_generations}</span>{" "}
                  <span className="text-muted-foreground">
                    / {usage.data.included_generations} included
                  </span>
                </p>
                {usage.data.overage_generations > 0 && (
                  <p className="text-amber-700">
                    {usage.data.overage_generations} over —{" "}
                    {formatCurrency(usage.data.overage_cost_usd)}
                  </p>
                )}
              </div>
            ) : null}
          </CardContent>
        </Card>
      </section>
    </div>
  );
}

export default function OverviewPage() {
  return (
    <DashboardShell>
      <OverviewContent />
    </DashboardShell>
  );
}
