"use client";

import { DashboardShell } from "@/components/dashboard-shell";
import { useMerchant } from "@/components/merchant-context";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  EmptyState,
  ErrorState,
  LoadingState,
} from "@/components/ui";
import { useApi } from "@/lib/use-api";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

const RANGES = [
  { days: 7, label: "7 days" },
  { days: 30, label: "30 days" },
  { days: 90, label: "90 days" },
] as const;

// Ordered to match the actual customer journey the widget emits (see
// WidgetEventType in apps/widget-sdk) so the chart reads as a funnel.
const FUNNEL_ORDER = [
  "widget_loaded",
  "button_clicked",
  "modal_opened",
  "image_uploaded",
  "generation_started",
  "generation_completed",
  "result_downloaded",
  "conversion",
] as const;

const FUNNEL_LABELS: Record<string, string> = {
  widget_loaded: "Loaded",
  button_clicked: "Clicked",
  modal_opened: "Opened",
  image_uploaded: "Uploaded",
  generation_started: "Started",
  generation_completed: "Completed",
  result_downloaded: "Downloaded",
  conversion: "Converted",
};

function AnalyticsContent() {
  const api = useApi();
  const { merchant } = useMerchant();
  const merchantId = merchant!.id;
  const [days, setDays] = useState<number>(7);

  const analytics = useQuery({
    queryKey: ["analytics-summary", merchantId, days],
    queryFn: () => api.analytics.summary(merchantId, days),
  });

  if (analytics.isLoading) return <LoadingState label="Loading analytics…" />;
  if (analytics.error) {
    return <ErrorState message={(analytics.error as Error).message} onRetry={analytics.refetch} />;
  }

  const counts = analytics.data?.counts_by_event_type ?? {};
  const totalEvents = Object.values(counts).reduce((sum, n) => sum + n, 0);
  const chartData = FUNNEL_ORDER.map((eventType) => ({
    stage: FUNNEL_LABELS[eventType] ?? eventType,
    count: counts[eventType] ?? 0,
  }));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Analytics</h1>
          <p className="text-sm text-muted-foreground">Widget funnel for the selected period.</p>
        </div>
        <div className="flex gap-1 rounded-md border p-1">
          {RANGES.map((range) => (
            <button
              key={range.days}
              onClick={() => setDays(range.days)}
              className={`rounded px-3 py-1 text-sm transition ${
                days === range.days
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-muted"
              }`}
            >
              {range.label}
            </button>
          ))}
        </div>
      </div>

      {totalEvents === 0 ? (
        <EmptyState
          title="No events recorded yet"
          description="Once the widget is installed and receiving traffic, funnel data will appear here."
        />
      ) : (
        <>
          <Card>
            <CardHeader>
              <CardTitle>Conversion funnel</CardTitle>
              <CardDescription>{totalEvents} total events in this period</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="stage" fontSize={12} />
                    <YAxis allowDecimals={false} fontSize={12} />
                    <Tooltip />
                    <Bar dataKey="count" fill="hsl(222 47% 11%)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>All events</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <table className="w-full text-sm">
                <thead className="border-b bg-muted/40 text-left">
                  <tr>
                    <th className="p-3 font-medium">Event type</th>
                    <th className="p-3 text-right font-medium">Count</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(counts)
                    .sort((a, b) => b[1] - a[1])
                    .map(([eventType, count]) => (
                      <tr key={eventType} className="border-b last:border-0">
                        <td className="p-3">{FUNNEL_LABELS[eventType] ?? eventType}</td>
                        <td className="p-3 text-right font-medium">{count}</td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}

export default function AnalyticsPage() {
  return (
    <DashboardShell>
      <AnalyticsContent />
    </DashboardShell>
  );
}
