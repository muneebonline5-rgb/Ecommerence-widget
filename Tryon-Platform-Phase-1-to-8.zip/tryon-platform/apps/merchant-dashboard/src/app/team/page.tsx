"use client";

import { DashboardShell } from "@/components/dashboard-shell";
import { useMerchant } from "@/components/merchant-context";
import {
  Button,
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  EmptyState,
  ErrorState,
  Input,
  Label,
  LoadingState,
} from "@/components/ui";
import { useApi } from "@/lib/use-api";
import { formatDate } from "@/lib/utils";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";

function TeamContent() {
  const api = useApi();
  const queryClient = useQueryClient();
  const { merchant } = useMerchant();
  const merchantId = merchant!.id;

  const [userId, setUserId] = useState("");
  const [roleId, setRoleId] = useState("");
  const [actionError, setActionError] = useState<string | null>(null);

  const members = useQuery({
    queryKey: ["team", merchantId],
    queryFn: () => api.team.list(merchantId),
  });

  const currentUser = useQuery({ queryKey: ["me"], queryFn: () => api.auth.me() });

  const invalidate = () => {
    void queryClient.invalidateQueries({ queryKey: ["team", merchantId] });
  };
  const onError = (error: Error) => setActionError(error.message);

  const addMember = useMutation({
    mutationFn: () => api.team.add(merchantId, userId, roleId),
    onSuccess: () => {
      setUserId("");
      setRoleId("");
      setActionError(null);
      invalidate();
    },
    onError,
  });

  const removeMember = useMutation({
    mutationFn: (memberUserId: string) => api.team.remove(merchantId, memberUserId),
    onSuccess: invalidate,
    onError,
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Team</h1>
        <p className="text-sm text-muted-foreground">
          Who can access this merchant account, and with what role.
        </p>
      </div>

      {actionError && (
        <div className="rounded-md border border-destructive/40 bg-destructive/5 p-3 text-sm text-destructive">
          {actionError}
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Add a team member</CardTitle>
          <CardDescription>
            The person must have signed in at least once before they can be added — see the
            TeamService notes on Clerk invitations.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form
            className="flex flex-wrap items-end gap-3"
            onSubmit={(event) => {
              event.preventDefault();
              addMember.mutate();
            }}
          >
            <div className="space-y-1">
              <Label htmlFor="user_id">User ID</Label>
              <Input
                id="user_id"
                required
                value={userId}
                onChange={(event) => setUserId(event.target.value)}
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="role_id">Role ID</Label>
              <Input
                id="role_id"
                required
                value={roleId}
                onChange={(event) => setRoleId(event.target.value)}
              />
            </div>
            <Button type="submit" disabled={addMember.isPending}>
              {addMember.isPending ? "Adding…" : "Add member"}
            </Button>
          </form>
        </CardContent>
      </Card>

      {members.isLoading ? (
        <LoadingState label="Loading team…" />
      ) : members.error ? (
        <ErrorState message={(members.error as Error).message} onRetry={members.refetch} />
      ) : (members.data ?? []).length === 0 ? (
        <EmptyState title="No team members yet" />
      ) : (
        <Card>
          <CardContent className="p-0">
            <table className="w-full text-sm">
              <thead className="border-b bg-muted/40 text-left">
                <tr>
                  <th className="p-3 font-medium">User ID</th>
                  <th className="p-3 font-medium">Role ID</th>
                  <th className="p-3 font-medium">Joined</th>
                  <th className="p-3 font-medium" />
                </tr>
              </thead>
              <tbody>
                {(members.data ?? []).map((member) => {
                  const isSelf = currentUser.data?.id === member.user_id;
                  return (
                    <tr key={member.id} className="border-b last:border-0">
                      <td className="p-3 font-mono text-xs">
                        {member.user_id}
                        {isSelf && <span className="ml-2 text-muted-foreground">(you)</span>}
                      </td>
                      <td className="p-3 font-mono text-xs text-muted-foreground">
                        {member.role_id}
                      </td>
                      <td className="p-3 text-muted-foreground">{formatDate(member.created_at)}</td>
                      <td className="p-3 text-right">
                        {!isSelf && (
                          <Button
                            variant="destructive"
                            onClick={() => removeMember.mutate(member.user_id)}
                          >
                            Remove
                          </Button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

export default function TeamPage() {
  return (
    <DashboardShell>
      <TeamContent />
    </DashboardShell>
  );
}
