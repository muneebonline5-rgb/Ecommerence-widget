"use client";

import { DashboardShell } from "@/components/dashboard-shell";
import { useMerchant } from "@/components/merchant-context";
import {
  Button,
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  ErrorState,
  Input,
  Label,
  LoadingState,
} from "@/components/ui";
import { useApi } from "@/lib/use-api";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type { WidgetPosition, WidgetSettings } from "@tryon-platform/types";
import { useEffect, useState } from "react";

const POSITIONS: WidgetPosition[] = ["bottom_right", "bottom_left", "top_right", "top_left"];
const SHAPES = ["circle", "pill", "square"] as const;

function WidgetContent() {
  const api = useApi();
  const queryClient = useQueryClient();
  const { merchant } = useMerchant();
  const merchantId = merchant!.id;

  const [theme, setTheme] = useState<WidgetSettings["theme"] | null>(null);
  const [origins, setOrigins] = useState("");
  const [actionError, setActionError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  const settings = useQuery({
    queryKey: ["widget-settings", merchantId],
    queryFn: () => api.widgetSettings.get(merchantId),
  });

  // Seed local form state once the real settings arrive. Deliberately keyed
  // on the fetched object so a refetch after save re-syncs rather than
  // leaving the form showing stale local edits.
  useEffect(() => {
    if (settings.data) {
      setTheme(settings.data.theme);
      setOrigins(settings.data.allowed_origins.join("\n"));
    }
  }, [settings.data]);

  const invalidate = () => {
    void queryClient.invalidateQueries({ queryKey: ["widget-settings", merchantId] });
  };

  const onMutationError = (error: Error) => {
    setActionError(error.message);
    setSaved(false);
  };

  const saveTheme = useMutation({
    mutationFn: () => api.widgetSettings.updateTheme(merchantId, theme!),
    onSuccess: () => {
      setActionError(null);
      setSaved(true);
      invalidate();
    },
    onError: onMutationError,
  });

  const savePosition = useMutation({
    mutationFn: (position: WidgetPosition) =>
      api.widgetSettings.updatePosition(merchantId, position),
    onSuccess: invalidate,
    onError: onMutationError,
  });

  const saveOrigins = useMutation({
    mutationFn: () =>
      api.widgetSettings.updateAllowedOrigins(
        merchantId,
        origins.split("\n").map((o) => o.trim()).filter(Boolean),
      ),
    onSuccess: () => {
      setActionError(null);
      setSaved(true);
      invalidate();
    },
    onError: onMutationError,
  });

  const toggleEnabled = useMutation({
    mutationFn: (enabled: boolean) => api.widgetSettings.setEnabled(merchantId, enabled),
    onSuccess: invalidate,
    onError: onMutationError,
  });

  if (settings.isLoading) return <LoadingState label="Loading widget settings…" />;
  if (settings.error) {
    return <ErrorState message={(settings.error as Error).message} onRetry={settings.refetch} />;
  }

  const data = settings.data!;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Widget</h1>
        <p className="text-sm text-muted-foreground">
          Customize how the try-on widget appears on your storefront.
        </p>
      </div>

      {actionError && (
        <div className="rounded-md border border-destructive/40 bg-destructive/5 p-3 text-sm text-destructive">
          {actionError}
        </div>
      )}
      {saved && !actionError && (
        <div className="rounded-md border border-emerald-300 bg-emerald-50 p-3 text-sm text-emerald-800">
          Saved.
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Status</CardTitle>
          <CardDescription>
            {data.is_enabled
              ? "The widget is live on your storefront."
              : "The widget is disabled and will not render."}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button
            variant={data.is_enabled ? "destructive" : "primary"}
            onClick={() => toggleEnabled.mutate(!data.is_enabled)}
            disabled={toggleEnabled.isPending}
          >
            {data.is_enabled ? "Disable widget" : "Enable widget"}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Appearance</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-1">
              <Label htmlFor="position">Position</Label>
              <select
                id="position"
                className="h-9 w-full rounded-md border bg-background px-3 text-sm"
                value={data.position}
                onChange={(event) => savePosition.mutate(event.target.value as WidgetPosition)}
              >
                {POSITIONS.map((p) => (
                  <option key={p} value={p}>
                    {p.replace("_", " ")}
                  </option>
                ))}
              </select>
            </div>
            {theme && (
              <div className="space-y-1">
                <Label htmlFor="button_shape">Button shape</Label>
                <select
                  id="button_shape"
                  className="h-9 w-full rounded-md border bg-background px-3 text-sm"
                  value={theme.button_shape}
                  onChange={(event) =>
                    setTheme({
                      ...theme,
                      button_shape: event.target.value as (typeof SHAPES)[number],
                    })
                  }
                >
                  {SHAPES.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          {theme && (
            <>
              <div className="grid gap-4 md:grid-cols-3">
                {(
                  [
                    ["primary_color", "Primary color"],
                    ["accent_color", "Accent color"],
                    ["text_color", "Text color"],
                  ] as const
                ).map(([key, label]) => (
                  <div key={key} className="space-y-1">
                    <Label htmlFor={key}>{label}</Label>
                    <div className="flex gap-2">
                      <input
                        type="color"
                        aria-label={label}
                        className="h-9 w-12 rounded border"
                        value={theme[key]}
                        onChange={(event) => setTheme({ ...theme, [key]: event.target.value })}
                      />
                      <Input
                        id={key}
                        value={theme[key]}
                        onChange={(event) => setTheme({ ...theme, [key]: event.target.value })}
                      />
                    </div>
                  </div>
                ))}
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-1">
                  <Label htmlFor="font_family">Font family</Label>
                  <Input
                    id="font_family"
                    value={theme.font_family}
                    onChange={(event) => setTheme({ ...theme, font_family: event.target.value })}
                  />
                </div>
                <div className="space-y-1">
                  <Label htmlFor="border_radius_px">Border radius (px)</Label>
                  <Input
                    id="border_radius_px"
                    type="number"
                    min={0}
                    max={999}
                    value={theme.border_radius_px}
                    onChange={(event) =>
                      setTheme({ ...theme, border_radius_px: Number(event.target.value) })
                    }
                  />
                </div>
              </div>

              <Button onClick={() => saveTheme.mutate()} disabled={saveTheme.isPending}>
                {saveTheme.isPending ? "Saving…" : "Save appearance"}
              </Button>
            </>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Allowed origins</CardTitle>
          <CardDescription>
            One origin per line (e.g. https://shop.example.com). Leave empty to allow any origin.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <textarea
            aria-label="Allowed origins"
            className="h-28 w-full rounded-md border bg-background p-3 font-mono text-xs"
            value={origins}
            onChange={(event) => setOrigins(event.target.value)}
          />
          <Button onClick={() => saveOrigins.mutate()} disabled={saveOrigins.isPending}>
            {saveOrigins.isPending ? "Saving…" : "Save origins"}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Install</CardTitle>
          <CardDescription>
            Add this one script tag to your storefront, using an API key from the API Keys page.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <code className="block break-all rounded border bg-muted/40 p-3 font-mono text-xs">
            {`<script src="https://cdn.tryon-platform.com/widget.js" data-api-key="tk_live_..."></script>`}
          </code>
        </CardContent>
      </Card>
    </div>
  );
}

export default function WidgetPage() {
  return (
    <DashboardShell>
      <WidgetContent />
    </DashboardShell>
  );
}
