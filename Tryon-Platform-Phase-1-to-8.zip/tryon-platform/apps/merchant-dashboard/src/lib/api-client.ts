"use client";

import { useAuth } from "@clerk/nextjs";
import { ApiClient, createApi, type Api } from "@tryon-platform/sdk";
import { useMemo } from "react";

const JWT_TEMPLATE = process.env.NEXT_PUBLIC_CLERK_JWT_TEMPLATE ?? "tryon-backend";

/**
 * Client-Component equivalent of createServerApi(). Memoized on the
 * `getToken` identity so React Query's queryFn references stay stable
 * across renders — otherwise every render would produce a new api object
 * and defeat query caching.
 */
export function useApi(): Api {
  const { getToken } = useAuth();

  return useMemo(() => {
    const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;
    if (!baseUrl) {
      throw new Error("NEXT_PUBLIC_API_BASE_URL is not set.");
    }

    const client = new ApiClient({
      baseUrl,
      getToken: () => getToken({ template: JWT_TEMPLATE }),
    });
    return createApi(client);
  }, [getToken]);
}
