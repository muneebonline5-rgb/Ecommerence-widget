import { auth } from "@clerk/nextjs/server";
import { ApiClient, createApi, type Api } from "@tryon-platform/sdk";

/**
 * Builds an API client for use in Server Components and Route Handlers.
 *
 * The Clerk session token is fetched per-request via `auth().getToken()`
 * rather than cached, because the token is short-lived and rotates — the
 * SDK's `getToken` callback signature exists precisely so each request
 * resolves a fresh one instead of holding a stale string.
 *
 * NOTE on the JWT template: Phase 2's backend `AuthService.authenticate`
 * reads `email` (required on first sign-in) and `name` from the token's
 * claims. Clerk's *default* session token does not include these, so a
 * custom JWT template named below must be configured in the Clerk
 * Dashboard — see docs/clerk-frontend-setup.md. Passing an unconfigured
 * template name to getToken() returns null rather than throwing, which is
 * why `ApiClient` surfaces a clear "not_authenticated" error instead of a
 * confusing downstream 401.
 */
const JWT_TEMPLATE = process.env.NEXT_PUBLIC_CLERK_JWT_TEMPLATE ?? "tryon-backend";

export function getApiBaseUrl(): string {
  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;
  if (!baseUrl) {
    throw new Error(
      "NEXT_PUBLIC_API_BASE_URL is not set. Copy .env.example to .env.local and configure it.",
    );
  }
  return baseUrl;
}

export function createServerApi(): Api {
  const client = new ApiClient({
    baseUrl: getApiBaseUrl(),
    getToken: async () => {
      const { getToken } = await auth();
      return getToken({ template: JWT_TEMPLATE });
    },
  });
  return createApi(client);
}
