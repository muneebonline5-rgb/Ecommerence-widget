"use client";

import { useApi } from "@/lib/use-api";
import { useQuery } from "@tanstack/react-query";
import type { Merchant } from "@tryon-platform/types";
import { createContext, useContext, useMemo, useState, type ReactNode } from "react";

interface MerchantContextValue {
  merchant: Merchant | null;
  merchants: Merchant[];
  isLoading: boolean;
  error: Error | null;
  selectMerchant: (merchantId: string) => void;
}

const MerchantContext = createContext<MerchantContextValue | null>(null);

/**
 * Resolves which merchant(s) the signed-in user belongs to by calling
 * GET /api/v1/auth/my-merchants — the one endpoint that doesn't require
 * already knowing a merchant_id. Everything downstream (widget settings,
 * products, billing, analytics) is scoped to the selected merchant.
 *
 * A user can legitimately belong to several merchants (agencies managing
 * multiple brands — see the TeamMembership design in Phase 2), so this
 * holds a selection rather than assuming exactly one.
 */
export function MerchantProvider({ children }: { children: ReactNode }) {
  const api = useApi();
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const { data, isLoading, error } = useQuery({
    queryKey: ["my-merchants"],
    queryFn: () => api.auth.myMerchants(),
  });

  const merchants = useMemo(() => data ?? [], [data]);

  const merchant = useMemo(() => {
    if (merchants.length === 0) return null;
    if (selectedId) {
      return merchants.find((m) => m.id === selectedId) ?? merchants[0] ?? null;
    }
    return merchants[0] ?? null;
  }, [merchants, selectedId]);

  const value = useMemo<MerchantContextValue>(
    () => ({
      merchant,
      merchants,
      isLoading,
      error: (error as Error) ?? null,
      selectMerchant: setSelectedId,
    }),
    [merchant, merchants, isLoading, error],
  );

  return <MerchantContext.Provider value={value}>{children}</MerchantContext.Provider>;
}

export function useMerchant(): MerchantContextValue {
  const context = useContext(MerchantContext);
  if (!context) {
    throw new Error("useMerchant must be used within a MerchantProvider.");
  }
  return context;
}

export function useMerchantId(): string | null {
  const { merchant } = useMerchant();
  return merchant?.id ?? null;
}
