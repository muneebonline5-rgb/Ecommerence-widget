"use client";

import { useMerchant } from "@/components/merchant-context";
import { cn } from "@/lib/utils";
import { UserButton } from "@clerk/nextjs";
import Link from "next/link";
import { usePathname } from "next/navigation";

const NAV_ITEMS = [
  { href: "/", label: "Overview" },
  { href: "/analytics", label: "Analytics" },
  { href: "/products", label: "Products" },
  { href: "/widget", label: "Widget" },
  { href: "/billing", label: "Billing" },
  { href: "/usage", label: "Usage" },
  { href: "/api-keys", label: "API Keys" },
  { href: "/team", label: "Team" },
] as const;

export function Sidebar() {
  const pathname = usePathname();
  const { merchant, merchants, selectMerchant } = useMerchant();

  return (
    <aside className="flex w-60 shrink-0 flex-col border-r bg-muted/30">
      <div className="border-b p-4">
        <p className="text-sm font-semibold">Try-On Platform</p>
        {merchants.length > 1 ? (
          <select
            aria-label="Select merchant"
            className="mt-2 w-full rounded-md border bg-background px-2 py-1 text-xs"
            value={merchant?.id ?? ""}
            onChange={(event) => selectMerchant(event.target.value)}
          >
            {merchants.map((m) => (
              <option key={m.id} value={m.id}>
                {m.name}
              </option>
            ))}
          </select>
        ) : (
          merchant && <p className="mt-1 text-xs text-muted-foreground">{merchant.name}</p>
        )}
      </div>

      <nav className="flex flex-1 flex-col gap-1 p-3">
        {NAV_ITEMS.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "rounded-md px-3 py-2 text-sm transition",
              pathname === item.href
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:bg-muted hover:text-foreground",
            )}
          >
            {item.label}
          </Link>
        ))}
      </nav>

      <div className="border-t p-4">
        <UserButton afterSignOutUrl="/sign-in" />
      </div>
    </aside>
  );
}
