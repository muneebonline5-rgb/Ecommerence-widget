"use client";

import { useMerchant } from "@/components/merchant-context";
import { Sidebar } from "@/components/sidebar";
import { EmptyState, ErrorState, LoadingState } from "@/components/ui";
import type { ReactNode } from "react";

/**
 * Gates every dashboard page on having resolved a merchant first. Without
 * this, each page would independently have to handle "we don't know which
 * merchant yet" — and every merchant-scoped API call needs that ID.
 */
export function DashboardShell({ children }: { children: ReactNode }) {
  const { merchant, isLoading, error } = useMerchant();

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <main className="flex-1 overflow-y-auto p-8">
        {isLoading ? (
          <LoadingState label="Loading your account…" />
        ) : error ? (
          <ErrorState message={error.message} />
        ) : !merchant ? (
          <EmptyState
            title="No merchant account found"
            description="Your user isn't a member of any merchant team yet. Ask an admin to add you, or create a merchant account."
          />
        ) : (
          children
        )}
      </main>
    </div>
  );
}
