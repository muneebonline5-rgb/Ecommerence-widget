import { Badge, Button, EmptyState, ErrorState, LoadingState } from "@/components/ui";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";

describe("LoadingState", () => {
  it("renders a default label", () => {
    render(<LoadingState />);
    expect(screen.getByText(/loading/i)).toBeInTheDocument();
  });

  it("renders a custom label", () => {
    render(<LoadingState label="Verifying admin access…" />);
    expect(screen.getByText("Verifying admin access…")).toBeInTheDocument();
  });
});

describe("ErrorState", () => {
  it("surfaces the backend's real error message rather than a generic string", () => {
    render(<ErrorState message="This action requires the 'billing:edit' permission." />);
    expect(
      screen.getByText("This action requires the 'billing:edit' permission."),
    ).toBeInTheDocument();
  });

  it("shows a retry control only when a handler is supplied", async () => {
    const onRetry = vi.fn();
    const { rerender } = render(<ErrorState message="Network error" onRetry={onRetry} />);

    const retry = screen.getByRole("button", { name: /try again/i });
    await userEvent.click(retry);
    expect(onRetry).toHaveBeenCalledOnce();

    rerender(<ErrorState message="Network error" />);
    expect(screen.queryByRole("button", { name: /try again/i })).not.toBeInTheDocument();
  });
});

describe("EmptyState", () => {
  it("renders title and optional description", () => {
    render(<EmptyState title="No merchants yet" description="They appear here once registered." />);
    expect(screen.getByText("No merchants yet")).toBeInTheDocument();
    expect(screen.getByText("They appear here once registered.")).toBeInTheDocument();
  });
});

describe("Button", () => {
  it("is disabled when the disabled prop is set and does not fire onClick", async () => {
    const onClick = vi.fn();
    render(
      <Button disabled onClick={onClick}>
        Suspend
      </Button>,
    );
    const button = screen.getByRole("button", { name: "Suspend" });
    expect(button).toBeDisabled();
    await userEvent.click(button);
    expect(onClick).not.toHaveBeenCalled();
  });
});

describe("Badge", () => {
  it("renders its content for each supported tone", () => {
    render(
      <>
        <Badge tone="success">active</Badge>
        <Badge tone="danger">suspended</Badge>
        <Badge tone="warning">pending</Badge>
        <Badge tone="neutral">free</Badge>
      </>,
    );
    expect(screen.getByText("active")).toBeInTheDocument();
    expect(screen.getByText("suspended")).toBeInTheDocument();
    expect(screen.getByText("pending")).toBeInTheDocument();
    expect(screen.getByText("free")).toBeInTheDocument();
  });
});
