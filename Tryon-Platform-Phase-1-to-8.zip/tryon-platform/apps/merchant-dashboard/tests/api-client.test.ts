import { ApiClient, ApiError, createApi } from "@tryon-platform/sdk";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const BASE_URL = "http://api.test";

function makeClient(token: string | null = "test-jwt-token") {
  return new ApiClient({ baseUrl: BASE_URL, getToken: async () => token });
}

function mockJsonResponse(body: unknown, status = 200) {
  return {
    ok: status >= 200 && status < 300,
    status,
    text: async () => JSON.stringify(body),
  };
}

/**
 * `mock.calls[n]` is `T | undefined` under noUncheckedIndexedAccess.
 * This asserts the call happened and returns it typed, so each test reads
 * cleanly instead of repeating a non-null assertion.
 */
function fetchCall(index = 0): [string, { headers: Record<string, string>; body?: string }] {
  const calls = (global.fetch as ReturnType<typeof vi.fn>).mock.calls;
  const call = calls[index];
  if (!call) throw new Error(`Expected fetch call at index ${index}, got ${calls.length} calls`);
  return call as [string, { headers: Record<string, string>; body?: string }];
}

describe("ApiClient", () => {
  beforeEach(() => {
    global.fetch = vi.fn();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it("forwards the Clerk token as a bearer Authorization header", async () => {
    (global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(mockJsonResponse({ id: "m_1" }));

    await makeClient("abc123").get("/api/v1/merchants/m_1");

    const [, init] = fetchCall();
    expect(init.headers.Authorization).toBe("Bearer abc123");
  });

  it("throws not_authenticated without ever calling fetch when there is no token", async () => {
    await expect(makeClient(null).get("/api/v1/auth/me")).rejects.toMatchObject({
      code: "not_authenticated",
      status: 401,
    });
    expect(global.fetch).not.toHaveBeenCalled();
  });

  it("serializes search params onto the URL, skipping undefined values", async () => {
    (global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(mockJsonResponse([]));

    await makeClient().get("/api/v1/merchants", { limit: 50, offset: 0, cursor: undefined });

    const [url] = fetchCall();
    expect(url).toContain("limit=50");
    expect(url).toContain("offset=0");
    expect(url).not.toContain("cursor");
  });

  it("parses the backend error envelope into an ApiError carrying the real code", async () => {
    (global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(
      mockJsonResponse(
        {
          error: {
            code: "insufficient_permission",
            message: "This action requires the 'billing:edit' permission.",
            details: { required_permission: "billing:edit" },
          },
        },
        403,
      ),
    );

    const error = (await makeClient()
      .get("/api/v1/billing/merchants/m_1/subscription")
      .catch((e: unknown) => e)) as ApiError;

    expect(error).toBeInstanceOf(ApiError);
    expect(error.code).toBe("insufficient_permission");
    expect(error.status).toBe(403);
    expect(error.details.required_permission).toBe("billing:edit");
  });

  it("falls back to a generic error when the body is not the expected envelope", async () => {
    (global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(
      mockJsonResponse({ unexpected: true }, 500),
    );

    const error = (await makeClient()
      .get("/api/v1/anything")
      .catch((e: unknown) => e)) as ApiError;
    expect(error.code).toBe("unknown_error");
    expect(error.status).toBe(500);
  });

  it("returns undefined for a 204 without attempting to parse a body", async () => {
    (global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue({
      ok: true,
      status: 204,
      text: async () => {
        throw new Error("204 responses must not be body-parsed");
      },
    });

    await expect(makeClient().delete("/api/v1/merchants/m_1/team/u_1")).resolves.toBeUndefined();
  });

  it("sends a JSON content-type and body only when a body is provided", async () => {
    (global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(mockJsonResponse({}));

    await makeClient().post("/api/v1/merchants", { name: "Acme" });
    const [, withBody] = fetchCall(0);
    expect(withBody.headers["Content-Type"]).toBe("application/json");
    expect(withBody.body).toBe(JSON.stringify({ name: "Acme" }));

    await makeClient().post("/api/v1/merchants/m_1/activate");
    const [, withoutBody] = fetchCall(1);
    expect(withoutBody.headers["Content-Type"]).toBeUndefined();
    expect(withoutBody.body).toBeUndefined();
  });

  it("passes extra headers through, e.g. Idempotency-Key", async () => {
    (global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(mockJsonResponse({}));

    await makeClient().post("/api/v1/tryon/generate", { customer_image_key: "k" }, {
      "Idempotency-Key": "idem-123",
    });

    const [, init] = fetchCall();
    expect(init.headers["Idempotency-Key"]).toBe("idem-123");
  });
});

describe("createApi resource paths", () => {
  beforeEach(() => {
    global.fetch = vi.fn().mockResolvedValue(mockJsonResponse({}));
  });

  afterEach(() => vi.restoreAllMocks());

  /**
   * These assert the exact URLs the dashboards call, so a typo in a path
   * fails here rather than as a confusing 404 at runtime. Each expected
   * path corresponds to a route registered in apps/api/src/main.py.
   */
  it.each([
    ["auth.me", (api: ReturnType<typeof createApi>) => api.auth.me(), "/api/v1/auth/me"],
    [
      "auth.myMerchants",
      (api: ReturnType<typeof createApi>) => api.auth.myMerchants(),
      "/api/v1/auth/my-merchants",
    ],
    [
      "merchants.list",
      (api: ReturnType<typeof createApi>) => api.merchants.list(),
      "/api/v1/merchants",
    ],
    [
      "products.list",
      (api: ReturnType<typeof createApi>) => api.products.list("m_1"),
      "/api/v1/merchants/m_1/products",
    ],
    [
      "billing.listPlans",
      (api: ReturnType<typeof createApi>) => api.billing.listPlans(),
      "/api/v1/billing/plans",
    ],
    [
      "billing.getSubscription",
      (api: ReturnType<typeof createApi>) => api.billing.getSubscription("m_1"),
      "/api/v1/billing/merchants/m_1/subscription",
    ],
    [
      "analytics.summary",
      (api: ReturnType<typeof createApi>) => api.analytics.summary("m_1"),
      "/api/v1/analytics/merchants/m_1/summary",
    ],
    [
      "widgetSettings.get",
      (api: ReturnType<typeof createApi>) => api.widgetSettings.get("m_1"),
      "/api/v1/merchants/m_1/widget-settings",
    ],
  ])("%s hits %s", async (_name, call, expectedPath) => {
    const api = createApi(makeClient());
    await call(api);
    const [url] = fetchCall();
    expect(String(url)).toContain(expectedPath);
  });
});
