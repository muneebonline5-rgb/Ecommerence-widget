import { AdminShell } from "@/components/admin-shell";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { render, screen, waitFor } from "@testing-library/react";
import type { ReactNode } from "react";
import { beforeEach, describe, expect, it, vi } from "vitest";

/**
 * The admin shell's whole job is deciding whether to render its children,
 * based on the REAL `is_platform_admin` flag from GET /auth/me. These tests
 * drive that decision through the api layer (mocked at the module boundary,
 * so the component's own logic is genuinely exercised) rather than
 * asserting on hardcoded UI.
 *
 * Note this is a UX gate, not the security boundary — the backend enforces
 * require_platform_admin independently on every admin endpoint (Phase 2).
 */
const meMock = vi.fn();

vi.mock("@/lib/use-api", () => ({
  useApi: () => ({ auth: { me: meMock } }),
}));

vi.mock("@/components/admin-sidebar", () => ({
  AdminSidebar: () => <nav data-testid="admin-sidebar" />,
}));

function renderWithQuery(ui: ReactNode) {
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });
  return render(<QueryClientProvider client={queryClient}>{ui}</QueryClientProvider>);
}

describe("AdminShell", () => {
  beforeEach(() => {
    meMock.mockReset();
  });

  it("shows a verifying state while the identity check is in flight", () => {
    meMock.mockReturnValue(new Promise(() => {})); // never resolves
    renderWithQuery(
      <AdminShell>
        <p>secret admin content</p>
      </AdminShell>,
    );
    expect(screen.getByText(/verifying admin access/i)).toBeInTheDocument();
    expect(screen.queryByText("secret admin content")).not.toBeInTheDocument();
  });

  it("renders children when the backend reports the user IS a platform admin", async () => {
    meMock.mockResolvedValue({
      id: "u_1",
      email: "admin@platform.test",
      full_name: "Admin",
      is_platform_admin: true,
    });

    renderWithQuery(
      <AdminShell>
        <p>secret admin content</p>
      </AdminShell>,
    );

    await waitFor(() => {
      expect(screen.getByText("secret admin content")).toBeInTheDocument();
    });
  });

  it("blocks children when the backend reports the user is NOT a platform admin", async () => {
    meMock.mockResolvedValue({
      id: "u_2",
      email: "merchant@shop.test",
      full_name: "Merchant",
      is_platform_admin: false,
    });

    renderWithQuery(
      <AdminShell>
        <p>secret admin content</p>
      </AdminShell>,
    );

    await waitFor(() => {
      expect(screen.getByText(/platform admin access required/i)).toBeInTheDocument();
    });
    expect(screen.queryByText("secret admin content")).not.toBeInTheDocument();
  });

  it("surfaces the backend error and hides children when the identity check fails", async () => {
    meMock.mockRejectedValue(new Error("Token has expired."));

    renderWithQuery(
      <AdminShell>
        <p>secret admin content</p>
      </AdminShell>,
    );

    await waitFor(() => {
      expect(screen.getByText("Token has expired.")).toBeInTheDocument();
    });
    expect(screen.queryByText("secret admin content")).not.toBeInTheDocument();
  });

  it("always renders the sidebar, regardless of admin status", async () => {
    meMock.mockResolvedValue({
      id: "u_2",
      email: "merchant@shop.test",
      full_name: null,
      is_platform_admin: false,
    });

    renderWithQuery(
      <AdminShell>
        <p>secret admin content</p>
      </AdminShell>,
    );

    expect(screen.getByTestId("admin-sidebar")).toBeInTheDocument();
  });
});
