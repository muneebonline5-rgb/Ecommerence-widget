import { describe, expect, it } from "vitest";
import { cn, formatCurrency, formatDate, formatDateTime, humanizeEventType } from "@/lib/utils";

describe("cn", () => {
  it("merges class names", () => {
    expect(cn("a", "b")).toBe("a b");
  });

  it("resolves conflicting tailwind utilities in favor of the last one", () => {
    expect(cn("px-2", "px-4")).toBe("px-4");
  });

  it("drops falsy values", () => {
    expect(cn("a", false && "b", undefined, "c")).toBe("a c");
  });
});

describe("formatCurrency", () => {
  it("formats whole dollars", () => {
    expect(formatCurrency(29)).toBe("$29.00");
  });

  it("formats sub-cent overage rates without dropping precision to zero", () => {
    // Overage rates from Phase 6 plans are often fractions of a cent; the
    // formatter rounds to 2dp, which is correct for display but worth
    // pinning so nobody "fixes" it into scientific notation later.
    expect(formatCurrency(0.1)).toBe("$0.10");
  });

  it("formats zero", () => {
    expect(formatCurrency(0)).toBe("$0.00");
  });
});

describe("formatDate / formatDateTime", () => {
  it("formats an ISO date into a readable form", () => {
    expect(formatDate("2026-01-15T10:30:00Z")).toMatch(/Jan 15, 2026/);
  });

  it("includes a time component in formatDateTime", () => {
    const formatted = formatDateTime("2026-01-15T10:30:00Z");
    expect(formatted).toMatch(/Jan 15, 2026/);
    expect(formatted).toMatch(/\d{2}:\d{2}/);
  });
});

describe("humanizeEventType", () => {
  it.each([
    ["widget_loaded", "Widget Loaded"],
    ["generation_completed", "Generation Completed"],
    ["conversion", "Conversion"],
  ])("turns %s into %s", (input, expected) => {
    expect(humanizeEventType(input)).toBe(expected);
  });

  it("handles an unknown future event type without special-casing", () => {
    // Deliberately not a lookup table — a new AnalyticsEventType added to
    // the backend must render sensibly here without a frontend change.
    expect(humanizeEventType("some_brand_new_event")).toBe("Some Brand New Event");
  });
});
