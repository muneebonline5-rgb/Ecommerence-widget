/** @type {import('next').NextConfig} */
const nextConfig = {
  // The shared @tryon-platform/types and @tryon-platform/sdk packages ship
  // as raw TypeScript (see their package.json "main" fields) rather than a
  // separately compiled dist/ — transpilePackages lets Next.js's own
  // build pipeline compile them in-place instead of requiring a second,
  // redundant build step for two tiny internal packages.
  transpilePackages: ["@tryon-platform/types", "@tryon-platform/sdk"],
  eslint: {
    ignoreDuringBuilds: false,
  },
};

module.exports = nextConfig;
