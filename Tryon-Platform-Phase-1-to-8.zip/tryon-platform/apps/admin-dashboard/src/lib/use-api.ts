"use client";

import { useAuth } from "@clerk/nextjs";
import { ApiClient, createApi, type Api } from "@tryon-platform/sdk";
import { useMemo } from "react";

/**
 * Builds an API client bound to the current Clerk session.
 *
 * `getToken` is passed as a function rather than a resolved string because
 * Clerk rotates short-lived session tokens — resolving once at hook time
 * would hand the SDK a token that expires mid-session. The SDK calls it
 * per-request instead.
 *
 * IMPORTANT: the backend's AuthService reads `email` (and `name`) directly
 * from the JWT claims, which Clerk's DEFAULT session token does not
 * include. A custom JWT Template named "tryon-backend" must be configured
 * in the Clerk Dashboard — see docs/clerk-frontend-setup.md. Without it,
 * every API call fails with `invalid_token`.
 */
export function useApi(): Api {
  const { getToken } = useAuth();

  return useMemo(() => {
    const client = new ApiClient({
      baseUrl: process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://localhost:8000",
      getToken: () => getToken({ template: "tryon-backend" }),
    });
    return createApi(client);
  }, [getToken]);
}
