import { clerkMiddleware, createRouteMatcher } from "@clerk/nextjs/server";

// Everything except the sign-in/sign-up routes requires an authenticated
// Clerk session. The backend independently re-verifies the JWT on every
// API call (see Phase 2's ClerkJWTVerifier) — this middleware is a UX
// concern (redirect to sign-in rather than render a broken page), not the
// security boundary.
const isPublicRoute = createRouteMatcher(["/sign-in(.*)", "/sign-up(.*)"]);

export default clerkMiddleware(async (auth, request) => {
  if (!isPublicRoute(request)) {
    await auth.protect();
  }
});

export const config = {
  matcher: ["/((?!_next|[^?]*\\.(?:html?|css|js(?!on)|jpe?g|webp|png|gif|svg|ttf|woff2?)).*)"],
};
