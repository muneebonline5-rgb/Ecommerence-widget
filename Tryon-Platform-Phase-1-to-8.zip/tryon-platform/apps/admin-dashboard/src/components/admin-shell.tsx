"use client";

import { AdminSidebar } from "@/components/admin-sidebar";
import { EmptyState, ErrorState, LoadingState } from "@/components/ui";
import { useApi } from "@/lib/use-api";
import { useQuery } from "@tanstack/react-query";
import type { ReactNode } from "react";

/**
 * Gates every admin page on the caller actually being a platform admin.
 *
 * This checks the real `is_platform_admin` flag returned by the backend's
 * GET /auth/me — it is NOT the security boundary. The backend independently
 * enforces `require_platform_admin` on every admin-only endpoint (see
 * Phase 2), so a user who bypassed this UI check would still get a 403 from
 * the API. This exists so a non-admin sees a clear explanation instead of a
 * page full of failed requests.
 */
export function AdminShell({ children }: { children: ReactNode }) {
  const api = useApi();
  const me = useQuery({ queryKey: ["me"], queryFn: () => api.auth.me() });

  return (
    <div className="flex min-h-screen">
      <AdminSidebar />
      <main className="flex-1 overflow-y-auto p-8">
        {me.isLoading ? (
          <LoadingState label="Verifying admin access…" />
        ) : me.error ? (
          <ErrorState message={(me.error as Error).message} onRetry={() => void me.refetch()} />
        ) : !me.data?.is_platform_admin ? (
          <EmptyState
            title="Platform admin access required"
            description="Your account isn't a platform administrator. If you're a merchant, use the merchant dashboard instead."
          />
        ) : (
          children
        )}
      </main>
    </div>
  );
}
