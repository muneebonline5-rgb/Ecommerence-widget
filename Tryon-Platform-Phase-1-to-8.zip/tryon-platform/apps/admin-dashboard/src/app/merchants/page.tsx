"use client";

import { AdminShell } from "@/components/admin-shell";
import {
  Badge,
  Button,
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  EmptyState,
  ErrorState,
  Input,
  Label,
  LoadingState,
} from "@/components/ui";
import { useApi } from "@/lib/use-api";
import { formatDate } from "@/lib/utils";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ApiError } from "@tryon-platform/sdk";
import type { Merchant, MerchantStatus } from "@tryon-platform/types";
import { useState } from "react";

const TIERS = ["free", "starter", "growth", "enterprise"] as const;

function statusTone(status: MerchantStatus): "neutral" | "success" | "warning" | "danger" {
  if (status === "active") return "success";
  if (status === "suspended") return "danger";
  if (status === "pending") return "warning";
  return "neutral";
}

function MerchantRow({ merchant }: { merchant: Merchant }) {
  const api = useApi();
  const queryClient = useQueryClient();
  const [suspendReason, setSuspendReason] = useState("");
  const [actionError, setActionError] = useState<string | null>(null);

  const invalidate = () =>
    queryClient.invalidateQueries({ queryKey: ["admin", "merchants"] });

  const onError = (error: unknown) => {
    setActionError(
      error instanceof ApiError ? error.message : "Something went wrong. Please try again.",
    );
  };

  const suspend = useMutation({
    mutationFn: () => api.merchants.suspend(merchant.id, suspendReason),
    onSuccess: () => {
      setSuspendReason("");
      setActionError(null);
      void invalidate();
    },
    onError,
  });

  const activate = useMutation({
    mutationFn: () => api.merchants.activate(merchant.id),
    onSuccess: () => {
      setActionError(null);
      void invalidate();
    },
    onError,
  });

  const changeTier = useMutation({
    mutationFn: (tier: string) => api.merchants.changeTier(merchant.id, tier),
    onSuccess: () => {
      setActionError(null);
      void invalidate();
    },
    onError,
  });

  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between gap-4">
          <div>
            <CardTitle className="text-base">{merchant.name}</CardTitle>
            <CardDescription>
              {merchant.domain} · {merchant.contact_email}
            </CardDescription>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            <Badge tone={statusTone(merchant.status)}>{merchant.status}</Badge>
            <Badge>{merchant.tier}</Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-xs text-muted-foreground">
          Joined {formatDate(merchant.created_at)}
          {merchant.suspended_reason && ` · Suspended: ${merchant.suspended_reason}`}
        </p>

        {actionError && <p className="text-sm text-destructive">{actionError}</p>}

        <div className="flex flex-wrap items-end gap-2">
          <div className="min-w-[200px] flex-1">
            <Label htmlFor={`reason-${merchant.id}`}>Suspension reason</Label>
            <Input
              id={`reason-${merchant.id}`}
              value={suspendReason}
              onChange={(event) => setSuspendReason(event.target.value)}
              placeholder="Reason required to suspend"
            />
          </div>
          <Button
            variant="destructive"
            disabled={!suspendReason.trim() || suspend.isPending}
            onClick={() => suspend.mutate()}
          >
            {suspend.isPending ? "Suspending…" : "Suspend"}
          </Button>
          <Button
            variant="secondary"
            disabled={activate.isPending}
            onClick={() => activate.mutate()}
          >
            {activate.isPending ? "Activating…" : "Activate"}
          </Button>

          <select
            aria-label={`Change tier for ${merchant.name}`}
            className="h-9 rounded-md border bg-background px-2 text-sm"
            value={merchant.tier}
            disabled={changeTier.isPending}
            onChange={(event) => changeTier.mutate(event.target.value)}
          >
            {TIERS.map((tier) => (
              <option key={tier} value={tier}>
                {tier}
              </option>
            ))}
          </select>
        </div>
      </CardContent>
    </Card>
  );
}

export default function AdminMerchantsPage() {
  const api = useApi();
  const merchants = useQuery({
    queryKey: ["admin", "merchants"],
    queryFn: () => api.merchants.list(200, 0),
  });

  return (
    <AdminShell>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-semibold">Merchants</h1>
          <p className="text-sm text-muted-foreground">
            Every tenant on the platform. Suspension and tier changes take effect immediately.
          </p>
        </div>

        {merchants.isLoading ? (
          <LoadingState label="Loading merchants…" />
        ) : merchants.error ? (
          <ErrorState
            message={(merchants.error as Error).message}
            onRetry={() => void merchants.refetch()}
          />
        ) : (merchants.data?.length ?? 0) === 0 ? (
          <EmptyState
            title="No merchants yet"
            description="Merchants appear here once they register through the platform."
          />
        ) : (
          <div className="space-y-4">
            {merchants.data?.map((merchant) => (
              <MerchantRow key={merchant.id} merchant={merchant} />
            ))}
          </div>
        )}
      </div>
    </AdminShell>
  );
}
