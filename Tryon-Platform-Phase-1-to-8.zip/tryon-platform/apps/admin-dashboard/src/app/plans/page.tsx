"use client";

import { AdminShell } from "@/components/admin-shell";
import {
  Badge,
  Button,
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  EmptyState,
  ErrorState,
  Input,
  Label,
  LoadingState,
} from "@/components/ui";
import { useApi } from "@/lib/use-api";
import { formatCurrency } from "@/lib/utils";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ApiError } from "@tryon-platform/sdk";
import { useState } from "react";

const TIERS = ["free", "starter", "pro", "enterprise"] as const;

export default function AdminPlansPage() {
  const api = useApi();
  const queryClient = useQueryClient();

  const plans = useQuery({ queryKey: ["admin", "plans"], queryFn: () => api.billing.listPlans() });

  const [form, setForm] = useState({
    tier: "starter",
    name: "Starter",
    monthly_price_usd: "29",
    monthly_stripe_price_id: "",
    yearly_price_usd: "",
    yearly_stripe_price_id: "",
    included_generations: "100",
    overage_price_usd: "0.10",
  });
  const [formError, setFormError] = useState<string | null>(null);

  const createPlan = useMutation({
    mutationFn: () =>
      api.billing.createPlan({
        tier: form.tier,
        name: form.name,
        monthly_price_usd: Number(form.monthly_price_usd),
        monthly_stripe_price_id: form.monthly_stripe_price_id,
        included_generations: Number(form.included_generations),
        overage_price_usd: Number(form.overage_price_usd),
        // Yearly pricing is optional — the backend requires price and
        // Stripe ID to be provided together, so send neither when blank.
        ...(form.yearly_stripe_price_id && form.yearly_price_usd
          ? {
              yearly_price_usd: Number(form.yearly_price_usd),
              yearly_stripe_price_id: form.yearly_stripe_price_id,
            }
          : {}),
      }),
    onSuccess: () => {
      setFormError(null);
      void queryClient.invalidateQueries({ queryKey: ["admin", "plans"] });
    },
    onError: (error: unknown) => {
      setFormError(
        error instanceof ApiError ? error.message : "Failed to create plan. Please try again.",
      );
    },
  });

  const setField = (field: keyof typeof form) => (value: string) =>
    setForm((prev) => ({ ...prev, [field]: value }));

  return (
    <AdminShell>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-semibold">Billing Plans</h1>
          <p className="text-sm text-muted-foreground">
            Create the Stripe Product and Price first — see docs/stripe-setup.md — then register
            the plan here with its price IDs.
          </p>
        </div>

        {plans.isLoading ? (
          <LoadingState label="Loading plans…" />
        ) : plans.error ? (
          <ErrorState message={(plans.error as Error).message} onRetry={() => void plans.refetch()} />
        ) : (plans.data?.length ?? 0) === 0 ? (
          <EmptyState
            title="No plans configured"
            description="Register your first plan using the form below."
          />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {plans.data?.map((plan) => (
              <Card key={plan.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base">{plan.name}</CardTitle>
                    <Badge tone={plan.is_active ? "success" : "neutral"}>
                      {plan.is_active ? "active" : "inactive"}
                    </Badge>
                  </div>
                  <CardDescription>{plan.tier}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-1 text-sm">
                  <p>{formatCurrency(plan.monthly_price_usd)}/mo</p>
                  {plan.yearly_price_usd !== null && (
                    <p className="text-muted-foreground">
                      {formatCurrency(plan.yearly_price_usd)}/yr
                    </p>
                  )}
                  <p className="text-muted-foreground">
                    {plan.included_generations.toLocaleString()} generations included
                  </p>
                  <p className="text-muted-foreground">
                    {formatCurrency(plan.overage_price_usd)} per overage generation
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Register a plan</CardTitle>
            <CardDescription>
              Platform-admin only. The Stripe price IDs must already exist in Stripe.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {formError && <p className="text-sm text-destructive">{formError}</p>}

            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <Label htmlFor="tier">Tier</Label>
                <select
                  id="tier"
                  className="h-9 w-full rounded-md border bg-background px-2 text-sm"
                  value={form.tier}
                  onChange={(event) => setField("tier")(event.target.value)}
                >
                  {TIERS.map((tier) => (
                    <option key={tier} value={tier}>
                      {tier}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <Label htmlFor="name">Display name</Label>
                <Input
                  id="name"
                  value={form.name}
                  onChange={(event) => setField("name")(event.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="monthly_price">Monthly price (USD)</Label>
                <Input
                  id="monthly_price"
                  type="number"
                  step="0.01"
                  value={form.monthly_price_usd}
                  onChange={(event) => setField("monthly_price_usd")(event.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="monthly_price_id">Monthly Stripe price ID</Label>
                <Input
                  id="monthly_price_id"
                  value={form.monthly_stripe_price_id}
                  onChange={(event) => setField("monthly_stripe_price_id")(event.target.value)}
                  placeholder="price_..."
                />
              </div>
              <div>
                <Label htmlFor="yearly_price">Yearly price (USD, optional)</Label>
                <Input
                  id="yearly_price"
                  type="number"
                  step="0.01"
                  value={form.yearly_price_usd}
                  onChange={(event) => setField("yearly_price_usd")(event.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="yearly_price_id">Yearly Stripe price ID (optional)</Label>
                <Input
                  id="yearly_price_id"
                  value={form.yearly_stripe_price_id}
                  onChange={(event) => setField("yearly_stripe_price_id")(event.target.value)}
                  placeholder="price_..."
                />
              </div>
              <div>
                <Label htmlFor="included">Included generations</Label>
                <Input
                  id="included"
                  type="number"
                  value={form.included_generations}
                  onChange={(event) => setField("included_generations")(event.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="overage">Overage price (USD)</Label>
                <Input
                  id="overage"
                  type="number"
                  step="0.0001"
                  value={form.overage_price_usd}
                  onChange={(event) => setField("overage_price_usd")(event.target.value)}
                />
              </div>
            </div>

            <Button
              disabled={!form.monthly_stripe_price_id.trim() || createPlan.isPending}
              onClick={() => createPlan.mutate()}
            >
              {createPlan.isPending ? "Creating…" : "Create plan"}
            </Button>
          </CardContent>
        </Card>
      </div>
    </AdminShell>
  );
}
