import { Providers } from "@/components/providers";
import { ClerkProvider } from "@clerk/nextjs";
import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Admin Dashboard — Try-On Platform",
  description: "Platform administration: merchants, plans, and system health.",
};

/**
 * Same reasoning as the merchant dashboard: every route here is
 * authenticated and per-user, so static prerendering at build time is both
 * meaningless and impossible (Clerk's provider needs a real publishable
 * key to initialize).
 */
export const dynamic = "force-dynamic";

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <ClerkProvider>
      <html lang="en">
        <body className="min-h-screen antialiased">
          <Providers>{children}</Providers>
        </body>
      </html>
    </ClerkProvider>
  );
}
