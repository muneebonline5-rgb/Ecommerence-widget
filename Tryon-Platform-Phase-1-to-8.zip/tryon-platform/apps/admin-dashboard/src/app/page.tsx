"use client";

import { AdminShell } from "@/components/admin-shell";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  ErrorState,
  LoadingState,
} from "@/components/ui";
import { useApi } from "@/lib/use-api";
import { useQuery } from "@tanstack/react-query";
import type { Merchant } from "@tryon-platform/types";

function StatCard({ title, value }: { title: string; value: string | number }) {
  return (
    <Card>
      <CardHeader>
        <CardDescription>{title}</CardDescription>
        <CardTitle className="text-2xl">{value}</CardTitle>
      </CardHeader>
    </Card>
  );
}

function countBy<T extends string>(items: Merchant[], key: (m: Merchant) => T): Record<string, number> {
  return items.reduce<Record<string, number>>((acc, item) => {
    const bucket = key(item);
    acc[bucket] = (acc[bucket] ?? 0) + 1;
    return acc;
  }, {});
}

export default function AdminOverviewPage() {
  const api = useApi();

  // Platform stats are derived from the real merchants list rather than a
  // dedicated stats endpoint — the backend has no aggregate-metrics API,
  // and inventing fake numbers here would be worse than computing honest
  // ones from data we actually have.
  const merchants = useQuery({
    queryKey: ["admin", "merchants"],
    queryFn: () => api.merchants.list(200, 0),
  });

  return (
    <AdminShell>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-semibold">Platform Overview</h1>
          <p className="text-sm text-muted-foreground">
            Live tenant counts across the platform.
          </p>
        </div>

        {merchants.isLoading ? (
          <LoadingState label="Loading merchants…" />
        ) : merchants.error ? (
          <ErrorState
            message={(merchants.error as Error).message}
            onRetry={() => void merchants.refetch()}
          />
        ) : (
          <>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <StatCard title="Total merchants" value={merchants.data?.length ?? 0} />
              <StatCard
                title="Active"
                value={merchants.data?.filter((m) => m.status === "active").length ?? 0}
              />
              <StatCard
                title="Suspended"
                value={merchants.data?.filter((m) => m.status === "suspended").length ?? 0}
              />
              <StatCard
                title="Pending"
                value={merchants.data?.filter((m) => m.status === "pending").length ?? 0}
              />
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Merchants by tier</CardTitle>
                <CardDescription>Distribution across billing tiers.</CardDescription>
              </CardHeader>
              <CardContent>
                <dl className="grid gap-3 sm:grid-cols-4">
                  {Object.entries(countBy(merchants.data ?? [], (m) => m.tier)).map(
                    ([tier, count]) => (
                      <div key={tier} className="rounded-md border p-3">
                        <dt className="text-xs uppercase text-muted-foreground">{tier}</dt>
                        <dd className="text-lg font-semibold">{count}</dd>
                      </div>
                    ),
                  )}
                  {(merchants.data?.length ?? 0) === 0 && (
                    <p className="text-sm text-muted-foreground">No merchants yet.</p>
                  )}
                </dl>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </AdminShell>
  );
}
