# Stripe Setup Guide

This walks through getting Stripe ready for local development or a new
environment. See `docs/architecture.md`'s Phase 6 section for the
architectural rationale behind these choices.

## 1. Create a Stripe account and get API keys

1. Sign up at https://dashboard.stripe.com if you haven't already.
2. Stay in **Test mode** (toggle top-right) for everything below until
   you're ready for production.
3. Go to **Developers → API keys** and copy the **Secret key**
   (`sk_test_...`) into `STRIPE_SECRET_KEY` in your `.env`.

## 2. Create Products and Prices for each plan

For each plan tier (Starter, Pro, Enterprise — Free has no Stripe price at
all, since $0 plans don't need billing), create a Product with one or two
Prices (monthly, and optionally yearly):

```bash
# Using the Stripe CLI (https://stripe.com/docs/stripe-cli)
stripe products create --name "Starter"
stripe prices create \
  --product <prod_id_from_above> \
  --unit-amount 2900 \
  --currency usd \
  --recurring[interval]=month

stripe prices create \
  --product <prod_id_from_above> \
  --unit-amount 29000 \
  --currency usd \
  --recurring[interval]=year
```

Or do the same via **Products** in the Stripe Dashboard. Either way, note
each Price ID (`price_...`) — you'll need them in the next step.

## 3. Register the plans with the platform

Set the price IDs you just created in `.env`:

```bash
PLAN_STARTER_MONTHLY_PRICE_ID=price_...
PLAN_STARTER_YEARLY_PRICE_ID=price_...
# ...repeat for Pro and Enterprise
```

Then, as a platform admin, register each plan via the API (this is
deliberately an explicit API call rather than something auto-created from
env vars at startup — plan pricing changes are consequential and worth a
visible, auditable action):

```bash
curl -X POST https://your-api/api/v1/billing/plans \
  -H "Authorization: Bearer <platform-admin-jwt>" \
  -H "Content-Type: application/json" \
  -d '{
    "tier": "starter",
    "name": "Starter",
    "monthly_price_usd": 29.00,
    "monthly_stripe_price_id": "price_...",
    "yearly_price_usd": 290.00,
    "yearly_stripe_price_id": "price_...",
    "included_generations": 100,
    "overage_price_usd": 0.10
  }'
```

Repeat for `pro` and `enterprise`. Verify with `GET /api/v1/billing/plans`
(public, no auth needed — it's just the pricing catalog).

## 4. Configure the webhook endpoint

1. In the Stripe Dashboard: **Developers → Webhooks → Add endpoint**.
2. URL: `https://your-api/api/v1/webhooks/stripe`
3. Subscribe to these events (the ones `WebhookService` actually handles —
   see `src/application/services/webhook_service.py`):
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
   - `invoice.paid`
   - `invoice.finalized`
   - `invoice.payment_failed`
4. Copy the **Signing secret** (`whsec_...`) into `STRIPE_WEBHOOK_SECRET`.

### Local development: forwarding webhooks

```bash
stripe listen --forward-to localhost:8000/api/v1/webhooks/stripe
```

This prints a `whsec_...` value for local use — put that in your local
`.env`'s `STRIPE_WEBHOOK_SECRET` instead of the Dashboard one (Stripe CLI
webhooks are signed with a different, session-specific secret).

## 5. Test the flow end-to-end

```bash
# Trigger a test event through the CLI:
stripe trigger invoice.paid
```

Watch your API logs (structured JSON via structlog) for
`webhook.processed` — if you see `webhook.duplicate_ignored` on a retry,
the idempotency ledger is working correctly.

## Notes on what's NOT automated here, deliberately

- **Plan creation is a manual, explicit API call**, not something that
  happens automatically from `.env` values at startup. Pricing changes are
  significant business decisions; making them require an explicit,
  authenticated action (and leaving an audit trail via the platform-admin
  JWT) is safer than a silent config-driven sync that could misfire.
- **Metered overage usage is computed and displayed, but not yet pushed to
  a Stripe metered price via `PaymentGateway.report_usage`.** This requires
  persisting a Stripe subscription item ID, which the current
  `Subscription` entity doesn't model — tracked as follow-up work, not
  implemented partially. See `UsageService`'s docstring.
