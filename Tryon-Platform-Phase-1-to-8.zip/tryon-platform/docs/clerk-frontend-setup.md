# Clerk Frontend Setup

Required to run either dashboard. There is one non-obvious step (the custom
JWT template) that the dashboards **will not work without** — it's the first
section below for that reason.

## 1. The custom JWT template (required — read this first)

Phase 2's backend `AuthService.authenticate` reads two claims from the
incoming token:

- `sub` — the Clerk user ID (present in Clerk's default token)
- `email` — **required on a user's first sign-in**, to create their local
  `User` record
- `name` — optional, used for display

**Clerk's default session token does not include `email` or `name`.** With
the default token, a brand-new user's first API call fails with
`invalid_token: Token is missing an email claim required for first sign-in`.

So you must create a JWT template:

1. Clerk Dashboard → **Configure → Sessions → JWT Templates → New template**
2. Name it exactly `tryon-backend` (or set
   `NEXT_PUBLIC_CLERK_JWT_TEMPLATE` in both dashboards to whatever you name it)
3. Set the claims to:

```json
{
  "email": "{{user.primary_email_address}}",
  "name": "{{user.full_name}}"
}
```

4. Save. Clerk merges these with the standard claims (`sub`, `exp`, `iat`, etc.).

The dashboards request this template explicitly via
`getToken({ template: "tryon-backend" })` — see
`src/lib/use-api.ts` and `src/lib/api-server.ts`. If the template doesn't
exist, Clerk returns `null` and the SDK raises a clear
`not_authenticated` error rather than a confusing downstream 401.

## 2. Backend JWKS configuration

The backend verifies these tokens against Clerk's published JWKS. Set in
`apps/api/.env`:

```bash
CLERK_JWKS_URL=https://<your-instance>.clerk.accounts.dev/.well-known/jwks.json
CLERK_SECRET_KEY=sk_test_...
CLERK_PUBLISHABLE_KEY=pk_test_...
```

Find your instance's JWKS URL in Clerk Dashboard → **Configure → API keys →
Show JWT public key → JWKS URL**.

## 3. Dashboard environment variables

Both dashboards need (see each app's `.env.example`):

```bash
NEXT_PUBLIC_API_BASE_URL=http://localhost:8000
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_test_...
CLERK_SECRET_KEY=sk_test_...
NEXT_PUBLIC_CLERK_JWT_TEMPLATE=tryon-backend
```

The merchant dashboard runs on port 3000, the admin dashboard on 3001.
Both origins are in the backend's default `CORS_ALLOWED_ORIGINS`.

## 4. Granting platform-admin access

The admin dashboard gates on `User.is_platform_admin`, which is a column on
the local `users` table — **not** a Clerk role. There is deliberately no API
to grant it (privilege escalation via API would be a poor design); set it
directly:

```sql
UPDATE users SET is_platform_admin = true WHERE email = 'you@example.com';
```

The user must have signed in at least once first, so their `users` row
exists.

## 5. Getting a merchant to appear in the merchant dashboard

The merchant dashboard resolves your merchants via
`GET /api/v1/auth/my-merchants`, which reads `team_memberships`. A newly
signed-in user belongs to no merchant and will see "No merchant account
found" — which is correct, not a bug.

To get set up:

1. Register a merchant: `POST /api/v1/merchants`
2. Find your `users.id` and a `roles.id` (the `owner` role is seeded by
   migration `0002`)
3. Add yourself: `POST /api/v1/merchants/{merchant_id}/team` with
   `{"user_id": "...", "role_id": "..."}`

Step 3 requires the `team:manage` permission, so for the very first member
you'll need to insert the membership row directly:

```sql
INSERT INTO team_memberships (id, merchant_id, user_id, role_id, created_at, updated_at)
VALUES (gen_random_uuid(), '<merchant_id>', '<user_id>',
        (SELECT id FROM roles WHERE name = 'owner'), now(), now());
```

This bootstrapping gap (the first team member of a new merchant) is a real
limitation worth solving properly in a later phase — most likely by having
merchant registration automatically create an owner membership for the
registering user, which would require registration to be an authenticated
endpoint rather than the public one it is today.

## Verifying it works

With the backend running and both env files configured:

```bash
cd apps/merchant-dashboard && npm run dev   # http://localhost:3000
cd apps/admin-dashboard && npm run dev       # http://localhost:3001
```

Sign in. The merchant dashboard's overview page calls
`/auth/my-merchants` then `/analytics/.../summary` and
`/billing/.../subscription` — check the Network tab: every panel is backed
by a real request. If you see a 401, the JWT template (step 1) is almost
certainly the cause.
