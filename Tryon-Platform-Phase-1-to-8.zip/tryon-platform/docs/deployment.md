# Deployment & Observability

## Running the full stack locally

```bash
cp apps/api/.env.example apps/api/.env   # fill in secrets
docker compose up --build
```

The compose file runs migrations as a one-shot `migrate` service that both
`api` and `worker` wait on via `service_completed_successfully`. That
ordering is deliberate: without it, a fresh environment races the schema
and fails with confusing "relation does not exist" errors.

## Probes: liveness vs. readiness

Two endpoints, and the distinction is load-bearing:

| Endpoint | Question | Checks dependencies? | Orchestrator action on failure |
|---|---|---|---|
| `/healthz` | Is the process alive? | **No** | Restart the container |
| `/readyz` | Can it serve traffic now? | **Yes** (Postgres, Redis) | Remove from load balancer, keep running |

`/healthz` deliberately checks nothing downstream. If liveness depended on
Postgres, a brief database blip would fail liveness on every replica
simultaneously, get them all killed, and turn a recoverable dependency
outage into a total one. Readiness pulls a replica out of rotation but
leaves it running, so it rejoins automatically when the dependency
recovers.

Both dependency checks in `/readyz` are individually timeout-bounded (3s).
An unbounded readiness check that hangs is indistinguishable from a crashed
process to most orchestrators, and gets treated far more harshly.

**Configure your orchestrator's health check against `/healthz`, and its
load-balancer target-group check against `/readyz`.** The Dockerfile's own
`HEALTHCHECK` uses `/healthz` for the same reason.

## Metrics

Prometheus scrape target: `GET /metrics` (excluded from OpenAPI — it's
infrastructure, not merchant-facing API surface).

| Metric | Type | Labels |
|---|---|---|
| `tryon_http_requests_total` | counter | method, route, status_code |
| `tryon_http_request_duration_seconds` | histogram | method, route |
| `tryon_http_requests_in_flight` | gauge | — |
| `tryon_stripe_webhooks_total` | counter | event_type, outcome |

### The cardinality guard

`route` is the **route template** (`/merchants/{merchant_id}`), never the
actual path. Labelling by raw path would mint a new time series per
merchant ID — unbounded cardinality that reliably takes down a Prometheus
server. Unmatched requests (404 scans) collapse to `route="unmatched"` so a
scanner can't mint label values either. Both properties are pinned by tests
in `tests/integration/test_observability.py`.

### Known gap: worker metrics are not exported

Generation counters are deliberately **not** defined. Generations complete
inside the Celery worker — a separate process — so a counter incremented
there would never appear on the API process's `/metrics` scrape. Exporting
them correctly requires either a Prometheus Pushgateway or a per-worker
exporter endpoint. Defining a counter that silently stays at zero would be
worse than omitting it. Until that's built, worker health is observable
through structured logs (every generation logs `generation.completed` /
`generation.failed` with provider, latency and cost) and Celery's own
event stream via Flower.

## Structured logging

JSON in staging/production, human-readable console in development.

Every log line emitted while handling a request carries a `request_id`,
bound via structlog contextvars — including lines from deep inside
application services that know nothing about HTTP. An inbound
`X-Request-ID` header is honored rather than overwritten, so a trace can
span a load balancer or upstream gateway. The ID is echoed back in the
response, so a user reporting an error can hand over a value that finds
every related log line.

Health and metrics endpoints are excluded from request logging — probes
fire constantly and would bury real traffic.

## Sentry

Disabled entirely when `SENTRY_DSN` is blank, so local development needs no
Sentry account.

`before_send` scrubs `Authorization`, `X-API-Key`, `Stripe-Signature` and
`Cookie` headers before anything leaves the process. Sentry's own default
scrubbing covers common field names but not our custom `X-API-Key` header,
which would otherwise be transmitted verbatim — a live merchant credential
leaving our infrastructure. `send_default_pii=False` is also set.

`traces_sample_rate` defaults to 0.1 rather than 1.0: full tracing on the
widget config endpoint, which every storefront pageview hits, would be
prohibitively expensive.

## Container security

Both images are multi-stage. The builder stage carries `build-essential`;
the runtime stage does not — a production image containing a compiler is a
meaningfully larger attack surface for anything that achieves code
execution. Both run as a non-root user (`uid 10001`).

## CI

`.github/workflows/ci.yml` runs three jobs:

- **backend** — ruff lint + format check, `alembic upgrade head` followed by
  `alembic check` (catches a model change shipped without its migration),
  and the full pytest suite against real Postgres and Redis service
  containers. Postgres-specific types (JSONB, ARRAY, UUID) and Redis Lua
  scripting have no faithful in-memory substitute.
- **frontend** — matrix across widget-sdk, merchant-dashboard and
  admin-dashboard: typecheck, tests, production build.
- **security** — `pip-audit` and `npm audit --omit=dev`. Deliberately
  **non-blocking**: a newly published advisory with no available fix must
  not wedge every unrelated PR. Findings surface as workflow warnings for
  triage rather than a red build nobody can fix.

## What is NOT included

**No Terraform / ECS task definitions.** Writing infrastructure-as-code I
cannot apply against a real AWS account would produce plausible-looking
HCL of unknown correctness — worse than nothing, because it invites
deploying it. The Docker images, compose file and CI pipeline here are all
verified working; the cloud topology should be authored against a real
account where `terraform plan` actually runs.

**No OpenTelemetry tracing.** Sentry provides error tracking and basic
performance tracing. Full distributed tracing across API → Celery → AI
provider is worthwhile but needs a collector deployment to be meaningful.
