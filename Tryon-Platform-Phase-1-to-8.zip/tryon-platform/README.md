# AI Try-On Platform

Enterprise-grade, multi-tenant SaaS that lets ecommerce brands embed an
AI-powered virtual try-on widget on their storefronts with a single script
tag. Built with Clean Architecture, Domain-Driven Design, and SOLID
principles throughout the backend.

## Monorepo layout

```
apps/
  landing/              Next.js marketing site (not yet built)
  merchant-dashboard/    Next.js merchant dashboard — Phase 7 complete (port 3000)
  admin-dashboard/       Next.js platform admin dashboard — Phase 7 complete (port 3001)
  widget-sdk/            Embeddable widget (Vite + React + Shadow DOM) — Phase 3 complete
  api/                   FastAPI backend — Clean Architecture (Phases 1, 2 & 4 complete)
  worker/                Celery background workers — deployment entrypoint (Phase 4 complete, code lives in apps/api/src/worker)
packages/
  ui/                    Shared shadcn/ui component library (not yet built)
  shared/                Shared utilities (not yet built)
  sdk/                   Typed API client used by both dashboards (Phase 7)
  types/                 Shared TypeScript types — mirrors backend schemas (Phase 7)
  config/                Shared tsconfig/eslint/tailwind config (not yet built)
docs/
  architecture.md         Architecture decisions and rationale
```

## Status: Phase 8 of 8 — complete and verified

See `docs/architecture.md`, `docs/stripe-setup.md`,
`docs/clerk-frontend-setup.md`, `docs/deployment.md`, and
`apps/widget-sdk/README.md` for full rationale. Summary of what's real vs.
planned:

| Phase | Scope | Status |
|---|---|---|
| 1 | Monorepo skeleton, full DB schema, Clean Architecture backend, Merchant/API Key/Widget Settings vertical slice | ✅ Done — 44 tests passing, zero schema drift |
| 2 | Clerk auth + JWT, RBAC (roles/permissions/team membership), rate limiting | ✅ Done — 91 tests passing (81 unit + 10 integration vs. real Postgres/Redis), zero schema drift |
| 3 | Widget SDK core (init, Shadow DOM, floating button, public API) | ✅ Done — 38 tests passing, built bundle smoke-tested end-to-end, zero typecheck/lint errors |
| 4 | AI provider abstraction (FASHN/OpenAI/Flux/Kling) + Celery pipeline | ✅ Done — 173 tests passing (148 unit + 25 integration vs. real Postgres/Redis/mocked-S3), zero schema drift |
| 5 | Products API, TryOn↔Product linkage, analytics event ingestion | ✅ Done — 217 tests passing (184 unit + 33 integration), zero schema drift |
| 6 | Stripe billing: customers, subscriptions, usage metering, invoices, webhooks | ✅ Done — 322 tests passing (280 unit + 42 integration), zero schema drift |
| 7 | Merchant + Admin dashboards (Next.js) | ✅ Done — both build clean, 52 frontend tests passing, all screens on real APIs |
| 8 | Observability, CI/CD, containerization + production-readiness audit | ✅ Done — 343 backend tests, probes/metrics/logging verified against real deps; see caveats in `docs/deployment.md` |

## Backend quick start

```bash
cd apps/api
cp .env.example .env
pip install -e ".[dev]"
alembic upgrade head
uvicorn src.main:app --reload
# → http://localhost:8000/docs
```

Run tests:

```bash
pytest tests/unit                 # no external dependencies
pytest tests/integration          # requires Postgres, see docker-compose.test.yml
```
