import type { ApiErrorBody } from "@tryon-platform/types";

/**
 * Thrown for any non-2xx response. Carries the backend's own error code
 * (see apps/api/src/interfaces/api/response.py) so callers can branch on
 * `error.code` — e.g. "insufficient_permission" to show a permission
 * message, or "rate_limit_exceeded" to show a retry-after notice — instead
 * of parsing prose.
 */
export class ApiError extends Error {
  constructor(
    message: string,
    public readonly code: string,
    public readonly status: number,
    public readonly details: Record<string, unknown> = {},
  ) {
    super(message);
    this.name = "ApiError";
  }
}

export interface ApiClientOptions {
  baseUrl: string;
  /**
   * Resolves the current Clerk session token. Deliberately a function (not
   * a static string) since both apps call this per-request — a server
   * component or route handler uses Clerk's `auth().getToken()`, a client
   * component uses `useAuth().getToken()` — and the token can rotate.
   */
  getToken: () => Promise<string | null>;
}

export interface RequestOptions {
  method?: "GET" | "POST" | "PUT" | "DELETE";
  body?: unknown;
  searchParams?: Record<string, string | number | boolean | undefined>;
  /** Extra headers, e.g. Idempotency-Key for POST /tryon/generate. */
  headers?: Record<string, string>;
}

export class ApiClient {
  constructor(private readonly options: ApiClientOptions) {}

  async request<T>(path: string, opts: RequestOptions = {}): Promise<T> {
    const token = await this.options.getToken();
    if (!token) {
      throw new ApiError("Not authenticated.", "not_authenticated", 401);
    }

    const url = new URL(path, this.options.baseUrl);
    if (opts.searchParams) {
      for (const [key, value] of Object.entries(opts.searchParams)) {
        if (value !== undefined) url.searchParams.set(key, String(value));
      }
    }

    const response = await fetch(url.toString(), {
      method: opts.method ?? "GET",
      headers: {
        Authorization: `Bearer ${token}`,
        ...(opts.body ? { "Content-Type": "application/json" } : {}),
        ...opts.headers,
      },
      body: opts.body ? JSON.stringify(opts.body) : undefined,
      cache: "no-store",
    });

    if (response.status === 204) {
      return undefined as T;
    }

    const rawText = await response.text();
    const data = rawText ? JSON.parse(rawText) : undefined;

    if (!response.ok) {
      const errorBody = data as ApiErrorBody | undefined;
      throw new ApiError(
        errorBody?.error?.message ?? `Request failed with status ${response.status}.`,
        errorBody?.error?.code ?? "unknown_error",
        response.status,
        errorBody?.error?.details ?? {},
      );
    }

    return data as T;
  }

  get<T>(path: string, searchParams?: RequestOptions["searchParams"]): Promise<T> {
    return this.request<T>(path, { method: "GET", searchParams });
  }

  post<T>(path: string, body?: unknown, headers?: Record<string, string>): Promise<T> {
    return this.request<T>(path, { method: "POST", body, headers });
  }

  put<T>(path: string, body?: unknown): Promise<T> {
    return this.request<T>(path, { method: "PUT", body });
  }

  delete<T>(path: string): Promise<T> {
    return this.request<T>(path, { method: "DELETE" });
  }
}
