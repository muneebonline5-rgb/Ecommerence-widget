import type {
  AnalyticsSummary,
  ApiKeyResponse,
  CurrentUser,
  Invoice,
  IssuedApiKeyResponse,
  Merchant,
  Plan,
  Product,
  Subscription,
  TeamMembership,
  UsageSummary,
  WidgetSettings,
} from "@tryon-platform/types";
import type { ApiClient } from "./client";

/**
 * Thin, typed wrappers over `ApiClient` — one function per backend
 * endpoint, grouped by resource. Every path here corresponds exactly to a
 * route registered in apps/api/src/main.py; see that file's router
 * inclusions for the authoritative mapping.
 */
export function createApi(client: ApiClient) {
  return {
    auth: {
      me: () => client.get<CurrentUser>("/api/v1/auth/me"),
      myMerchants: () => client.get<Merchant[]>("/api/v1/auth/my-merchants"),
    },

    merchants: {
      list: (limit = 50, offset = 0) =>
        client.get<Merchant[]>("/api/v1/merchants", { limit, offset }),
      get: (merchantId: string) => client.get<Merchant>(`/api/v1/merchants/${merchantId}`),
      register: (payload: { name: string; domain: string; contact_email: string }) =>
        client.post<Merchant>("/api/v1/merchants", payload),
      suspend: (merchantId: string, reason: string) =>
        client.post<Merchant>(`/api/v1/merchants/${merchantId}/suspend`, { reason }),
      activate: (merchantId: string) =>
        client.post<Merchant>(`/api/v1/merchants/${merchantId}/activate`),
      changeTier: (merchantId: string, tier: string) =>
        client.post<Merchant>(`/api/v1/merchants/${merchantId}/tier`, { tier }),
    },

    widgetSettings: {
      get: (merchantId: string) =>
        client.get<WidgetSettings>(`/api/v1/merchants/${merchantId}/widget-settings`),
      updateTheme: (
        merchantId: string,
        theme: {
          primary_color: string;
          accent_color: string;
          text_color: string;
          font_family: string;
          button_shape: string;
          border_radius_px: number;
        },
      ) =>
        client.put<WidgetSettings>(
          `/api/v1/merchants/${merchantId}/widget-settings/theme`,
          theme,
        ),
      updatePosition: (merchantId: string, position: string) =>
        client.put<WidgetSettings>(`/api/v1/merchants/${merchantId}/widget-settings/position`, {
          position,
        }),
      updateAllowedOrigins: (merchantId: string, origins: string[]) =>
        client.put<WidgetSettings>(
          `/api/v1/merchants/${merchantId}/widget-settings/allowed-origins`,
          { origins },
        ),
      setEnabled: (merchantId: string, isEnabled: boolean) =>
        client.put<WidgetSettings>(`/api/v1/merchants/${merchantId}/widget-settings/enabled`, {
          is_enabled: isEnabled,
        }),
    },

    apiKeys: {
      list: (merchantId: string) =>
        client.get<ApiKeyResponse[]>(`/api/v1/merchants/${merchantId}/api-keys`),
      issue: (merchantId: string, label: string, environment: "live" | "test") =>
        client.post<IssuedApiKeyResponse>(`/api/v1/merchants/${merchantId}/api-keys`, {
          label,
          environment,
        }),
      revoke: (merchantId: string, apiKeyId: string) =>
        client.delete<ApiKeyResponse>(`/api/v1/merchants/${merchantId}/api-keys/${apiKeyId}`),
    },

    team: {
      list: (merchantId: string) =>
        client.get<TeamMembership[]>(`/api/v1/merchants/${merchantId}/team`),
      add: (merchantId: string, userId: string, roleId: string) =>
        client.post<TeamMembership>(`/api/v1/merchants/${merchantId}/team`, {
          user_id: userId,
          role_id: roleId,
        }),
      changeRole: (merchantId: string, userId: string, roleId: string) =>
        client.put<TeamMembership>(`/api/v1/merchants/${merchantId}/team/${userId}/role`, {
          role_id: roleId,
        }),
      remove: (merchantId: string, userId: string) =>
        client.delete<void>(`/api/v1/merchants/${merchantId}/team/${userId}`),
    },

    products: {
      list: (merchantId: string, limit = 50, offset = 0) =>
        client.get<Product[]>(`/api/v1/merchants/${merchantId}/products`, { limit, offset }),
      get: (merchantId: string, productId: string) =>
        client.get<Product>(`/api/v1/merchants/${merchantId}/products/${productId}`),
      create: (
        merchantId: string,
        payload: {
          external_id: string;
          title: string;
          product_url: string;
          image_url: string;
          category?: string;
          is_try_on_eligible?: boolean;
        },
      ) => client.post<Product>(`/api/v1/merchants/${merchantId}/products`, payload),
      update: (
        merchantId: string,
        productId: string,
        payload: { title: string; product_url: string; image_url: string; category?: string },
      ) => client.put<Product>(`/api/v1/merchants/${merchantId}/products/${productId}`, payload),
      setTryOnEligible: (merchantId: string, productId: string, eligible: boolean) =>
        client.put<Product>(
          `/api/v1/merchants/${merchantId}/products/${productId}/try-on-eligible`,
          { is_try_on_eligible: eligible },
        ),
      remove: (merchantId: string, productId: string) =>
        client.delete<void>(`/api/v1/merchants/${merchantId}/products/${productId}`),
    },

    analytics: {
      summary: (merchantId: string, days = 7) =>
        client.get<AnalyticsSummary>(`/api/v1/analytics/merchants/${merchantId}/summary`, {
          days,
        }),
    },

    billing: {
      listPlans: () => client.get<Plan[]>("/api/v1/billing/plans"),
      createPlan: (payload: Record<string, unknown>) =>
        client.post<Plan>("/api/v1/billing/plans", payload),
      ensureCustomer: (merchantId: string) =>
        client.post<{ stripe_customer_id: string }>(
          `/api/v1/billing/merchants/${merchantId}/customer`,
        ),
      getSubscription: (merchantId: string) =>
        client.get<Subscription>(`/api/v1/billing/merchants/${merchantId}/subscription`),
      subscribe: (merchantId: string, tier: string, interval: string, trialDays?: number) =>
        client.post<Subscription>(`/api/v1/billing/merchants/${merchantId}/subscribe`, {
          tier,
          interval,
          trial_days: trialDays,
        }),
      changePlan: (merchantId: string, tier: string, interval?: string) =>
        client.put<Subscription>(`/api/v1/billing/merchants/${merchantId}/subscription`, {
          tier,
          interval,
        }),
      cancelSubscription: (merchantId: string, atPeriodEnd: boolean) =>
        client.post<Subscription>(`/api/v1/billing/merchants/${merchantId}/subscription/cancel`, {
          at_period_end: atPeriodEnd,
        }),
      reactivateSubscription: (merchantId: string) =>
        client.post<Subscription>(
          `/api/v1/billing/merchants/${merchantId}/subscription/reactivate`,
        ),
      listInvoices: (merchantId: string, limit = 50, offset = 0) =>
        client.get<Invoice[]>(`/api/v1/billing/merchants/${merchantId}/invoices`, {
          limit,
          offset,
        }),
      getUsageSummary: (merchantId: string, periodStart?: string, periodEnd?: string) =>
        client.get<UsageSummary>(`/api/v1/billing/merchants/${merchantId}/usage`, {
          period_start: periodStart,
          period_end: periodEnd,
        }),
    },
  };
}

export type Api = ReturnType<typeof createApi>;
