/**
 * Types mirroring the FastAPI backend's response schemas exactly (see
 * apps/api/src/interfaces/api/v1/schemas/*.py). Kept in one shared package
 * so the merchant and admin dashboards never drift from what the backend
 * actually returns — this file is the single source of truth for both.
 */

// --- Merchants (Phase 1) ---

export type MerchantStatus = "pending" | "active" | "suspended" | "churned";
export type MerchantTier = "free" | "starter" | "growth" | "enterprise";

export interface Merchant {
  id: string;
  name: string;
  domain: string;
  contact_email: string;
  status: MerchantStatus;
  tier: MerchantTier;
  suspended_reason: string | null;
  created_at: string;
  updated_at: string;
}

// --- API Keys (Phase 1) ---

export type ApiKeyEnvironment = "live" | "test";
export type ApiKeyStatus = "active" | "revoked";

export interface ApiKeyResponse {
  id: string;
  label: string;
  environment: ApiKeyEnvironment;
  key_prefix: string;
  status: ApiKeyStatus;
  last_used_at: string | null;
  created_at: string;
  revoked_at: string | null;
}

export interface IssuedApiKeyResponse extends ApiKeyResponse {
  plaintext_key: string;
}

// --- Widget Settings (Phase 1) ---

export type WidgetPosition = "bottom_right" | "bottom_left" | "top_right" | "top_left";
export type WidgetButtonShape = "circle" | "pill" | "square";

export interface WidgetTheme {
  primary_color: string;
  accent_color: string;
  text_color: string;
  font_family: string;
  button_shape: WidgetButtonShape;
  border_radius_px: number;
}

export interface WidgetSettings {
  id: string;
  merchant_id: string;
  is_enabled: boolean;
  position: WidgetPosition;
  theme: WidgetTheme;
  button_label: string;
  allowed_origins: string[];
  sdk_version_pin: string | null;
  updated_at: string;
}

// --- Auth / Team (Phase 2) ---

export interface CurrentUser {
  id: string;
  email: string;
  full_name: string | null;
  is_platform_admin: boolean;
}

export interface TeamMembership {
  id: string;
  merchant_id: string;
  user_id: string;
  role_id: string;
  created_at: string;
  updated_at: string;
}

// --- Products (Phase 5) ---

export interface Product {
  id: string;
  merchant_id: string;
  external_id: string;
  title: string;
  product_url: string;
  image_url: string;
  category: string | null;
  is_try_on_eligible: boolean;
  metadata: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

// --- Analytics (Phase 5) ---

export interface AnalyticsSummary {
  start: string;
  end: string;
  counts_by_event_type: Record<string, number>;
}

// --- Try-On (Phase 4) ---

export type ProviderRequestStatus = "queued" | "processing" | "completed" | "failed";
export type AIProviderName = "fashn" | "openai" | "flux" | "kling";

export interface TryOnStatusResponse {
  tryon_id: string;
  tryon_status: string;
  provider_status: ProviderRequestStatus | null;
  result_image_url: string | null;
  error_message: string | null;
  updated_at: string;
}

// --- Billing (Phase 6) ---

export type PlanTier = "free" | "starter" | "pro" | "enterprise";
export type BillingInterval = "monthly" | "yearly";
export type SubscriptionStatus = "trialing" | "active" | "past_due" | "canceled";
export type InvoiceStatus = "draft" | "open" | "paid" | "void" | "uncollectible";

export interface Plan {
  id: string;
  tier: PlanTier;
  name: string;
  monthly_price_usd: number;
  yearly_price_usd: number | null;
  included_generations: number;
  overage_price_usd: number;
  is_active: boolean;
}

export interface Subscription {
  id: string;
  merchant_id: string;
  plan_id: string;
  status: SubscriptionStatus;
  billing_interval: BillingInterval;
  current_period_start: string;
  current_period_end: string;
  cancel_at_period_end: boolean;
  trial_end: string | null;
}

export interface Invoice {
  id: string;
  stripe_invoice_id: string;
  status: InvoiceStatus;
  amount_due_usd: number;
  amount_paid_usd: number;
  period_start: string;
  period_end: string;
  hosted_invoice_url: string | null;
}

export interface UsageSummary {
  period_start: string;
  period_end: string;
  included_generations: number;
  used_generations: number;
  overage_generations: number;
  overage_cost_usd: number;
  breakdown_by_provider: Record<string, { count: number; cost_usd: number }>;
}

// --- Error envelope (consistent across every endpoint, see Phase 1) ---

export interface ApiErrorBody {
  error: {
    code: string;
    message: string;
    details: Record<string, unknown>;
  };
}
